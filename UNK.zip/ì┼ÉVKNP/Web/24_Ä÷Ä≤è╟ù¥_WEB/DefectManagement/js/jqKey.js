﻿//=============================================================================
//	jqKey
//=============================================================================
(function($){
	$.fn.jqKey = function(options){
		window.onhelp=function(){return false;}
		var defaults = {
			"Enter":false
			,"Tab":false
			,"F1":null
			,"F2":null
			,"F3":null
			,"F4":null
			,"F5":null
			,"F6":null
			,"F7":null
			,"F8":null
			,"F9":null
			,"F10":null
			,"F11":null
			,"F12":null
			,"ESC":null
		};
		var setting = $.extend(defaults,options);
		var method = function(e){

			var Focus_Move = function(df,shift){
				//フォームオブジェクトが何番目か探す
				var ln = df.length;
				var i;
				for (i=0;i<ln;i++){
					if (df[i]==obj) break;
				}
				//フォーカスを取得できないものは飛ばします
				var mv = (shift?-1:1);
				var j = (ln+i+mv) % ln;
				var Fo,Fs;
				while(true){

					Fo	=	df[j];
					Fs	=	Fo.style;
					if	(Fo.type!="hidden" &&
						Fo.style.visibility!="hidden" &&
						!Fo.disabled &&
						Fo.tabIndex!=-1 &&
						Fs.visibility!="hidden" &&
						Fs.display!="none"){
						//対象のオブジェクトを戻す
						return Fo;
					}
					j=(j+mv+ln) % ln;
				}
				//Hitしない場合
				return df[i];
			}
			var df = document.forms[0];
			var	k	=	e.keyCode;
			var	s	=	e.shiftKey;
			var	c	=	e.ctrlKey;
			var	a	=	e.altKey;
			var	obj	=	e.target;
			var blKey	=	true;
			if (!setting.Enter&&k==13) return true;
			if (!setting.Tab&&k==9) return true;
			switch(k){
				case 13:
					switch(obj.type){
					// case"button":
					case"file":case"textarea":
						blKey = true;
						break;
					case"radio":case"checkbox":
//						setTimeout(function(){obj.click();},1)
//						blKey = true;
//						break;
					case"text":case"select-one":case"select-multiple":
						blKey = false;
						break;
					default:
						blKey = false;
						break;
					}
					//keyイベントを処理するもののみ抽出
					if (!blKey){
						//次のフォームオブジェクト探す
						obj = Focus_Move(df,s);
					}
				break;
				case 9:		//tab
					switch(obj.type){
					case"file":
						blKey = true;
						break;
					default:
						//次のフォームオブジェクト探す
						obj = Focus_Move(df,s);
						blKey = false;
						break;
					}

				break;
				case 8:		//backspace
					switch(obj.type){
					case"text":case"textarea":case"password":
					    blKey = !obj.readOnly;
						break;
					default:
						// if(confirm("backspaceが押されました。\n前ページへ移動しますか？")){
						// 	blKey = true;
						// }else{
						// 	blKey = false;
					    // }
					    blKey = false;
						break;
					}

				break;
				case 27://ESC
					if(setting.ESC){
						setting.ESC();
						blKey = false;
					}
				break;
				default:
					if(k>=112&&k<=123){
						var F = setting["F"+(k-111)];
						if(F)F(obj,s,c,a);
						blKey = false;
					}
				break;
			}



			if(!blKey){
				//イベントを伝播しない
				//IE規定の動作キャンセル
				if(document.all) window.event.keyCode = 0;
				try { obj.focus();} catch(e) {}
				//if(obj.select&&obj.type!="button") obj.select();
			}
			return blKey;
		};

        this.each(function() {
			$(this).keydown(function(e){
				return method(e);
			});
		});
	}
})(jQuery);


/* 
   
<機能>
Enter、Tabでのフォーム移動
Functionキー制御・・・・・・Fキー押下時の関数登録可能です。
[BackSpace]キーでのページ遷移抑制

<OPTION>
Enter	true/false
Tab	true/false
F1～F12,ESC	function(object,shiftKey,ctrlKey,altKey){}
object	キー押下時のオブジェクト
shiftKey	shiftKeyの状態:true/false
trlKey	ctrlKeyの状態:true/false
altKey	altkeyの状態:true/false

*/