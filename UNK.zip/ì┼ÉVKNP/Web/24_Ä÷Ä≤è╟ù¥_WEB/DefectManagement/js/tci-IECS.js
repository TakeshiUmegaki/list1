﻿/* tci-IECS.js
*
* trans-cosmos inc. Image Entry Client Script
*
* [references]
* jquery.js http://jquery.com/
* jqueryrotate.js http://code.google.com/p/jqueryrotate/
* jqKey.js http://d.hatena.ne.jp/Hidepyon/
*
* [settings]
* - 帳票イメージはimgタグでid属性にformImageを設定
* - フォーカスエリアはdivタグでclass属性にfocusAreaを設定
* - 入力項目はinputタグでclass属性にfieldを設定 & 座標・サイズを各属性に設定（ data-left, data-top, data-height, data-width ）
* - 各機能ボタンにイベントのbindと処理の記述
* - ファンクションキーの処理の記述
*
* [made by]
* Shantery Co. 2011.7.26
*
*/

// globalスコープ変数定義（イメージ表示のカレント設定値等）
var zoom_default = 0.5; // 初期倍率
var zoom_max = 3.0; // 最大倍率
var zoom_min = 0.1; // 最小倍率
var crnt_zoom = zoom_default; // 倍率
var crnt_rotate = 0; // 回転度
var crnt_top = 0; // フォーカスエリアの縦座標
var crnt_left = 0; // フォーカスエリアの横座標
var crnt_height = 0; // フォーカスエリアの縦サイズ
var crnt_width = 0; // フォーカスエリアの横サイズ
var crnt_top_offset = 30;
var crnt_left_offset = 30;

// カレント設定値でイメージを表示
function showCurrentImage() {

    var fi = $('#formImage');
    var di = $('#divImage');
    var fa = $('div.focusArea');

    fa.css('display', 'none');

    var iwO = fi.width();
    var ihO = fi.height();
    var iX;
    var iY;

    var iRotation;

    // 倍率、回転度の設定
    if (crnt_rotate == 0) {
        iX = 0;
        iY = 0;
        iRotation = 0;
    }
    if (crnt_rotate == 90) {
        iX = 0;
        iY = ihO * -1;
        iRotation = 1;
    }
    if (crnt_rotate == 180) {
        iX = iwO * -1;
        iY = ihO * -1;
        iRotation = 2;
    }
    if (crnt_rotate == 270) {
        iX = iwO * -1;
        iY = 0;
        iRotation = 3;
    }

    if(jQuery.support.checkOn &&
       jQuery.support.noCloneEvent &&
       window.globalStorage) {
        fi.css("-moz-transform-origin", 'left top');
        fi.css("-moz-transform", 'scale(' + crnt_zoom + ') rotate(' + crnt_rotate + 'deg) translate(' + iX + 'px,' + iY + 'px) '); 
    } else {
        // ページロード時に退避しておいたイメージのデフォルト幅、高さを取得
        var fiW = $('#imageW').val();
        var fiH = $('#imageH').val();

        // 倍率、回転度の設定
        fi.css('filter', 'progid:DXImageTransform.Microsoft.BasicImage(rotation=' + iRotation + ')'); 
        fi.css('width', fiW * crnt_zoom);
        fi.css('height', fiH * crnt_zoom);
    }

    // フォーカスエリアの設定
    fa.css('top', crnt_top * crnt_zoom);
    fa.css('left', crnt_left * crnt_zoom);
    fa.css('height', crnt_height * crnt_zoom);
    fa.css('width', crnt_width * crnt_zoom);

    if (isDeviated(di, fa)) {
        // フォーカスエリアが視界から外れていたらスクロール
        di.scrollTop(crnt_top * crnt_zoom - crnt_top_offset);
        di.scrollLeft(crnt_left * crnt_zoom - crnt_left_offset);
    }
    
    fa.css('display', 'block');
    
}

// フォーカスエリアが視界から外れているか
function isDeviated(di, fa) {
    
    var ret = false;

    ret = 
        (di[0].scrollTop > fa[0].style.posTop) ||
        (di[0].scrollLeft > fa[0].style.posLeft) ||
        (di[0].clientHeight < (fa[0].style.posTop + fa[0].style.posHeight - di[0].scrollTop)) ||
        (di[0].clientWidth < (fa[0].style.posLeft + fa[0].style.posWidth - di[0].scrollLeft));
    
    return ret;

}

var masterSource = []; // マスタ値連想配列
    
// マスターの値を各項目にセットする
//  src  : マスター値（連想配列　キー：マスターカラム名　値：マスターカラム値）
//  dst  : セット対象項目のセレクタ（クラス名等）
//  rmsp : スペースをカットするかどうか
//  ※セット対象項目のdata-master-columns属性には引用するマスターのカラム名をパイプ区切りでセットしてある前提
function setMasterValues(src, dst, rmsp) {
    $(dst).each(function() {
        var masterValues = $(this).data('master-columns');
        var masterColumns = $(this).data('master-columns').split(/[\|｜]/g);
        $.each(masterColumns, function() {
            var masterColumn = this;
            masterValues = masterValues.replace(masterColumn, src[masterColumn]);
        });
        if (rmsp) {
            masterValues = masterValues.split(/[\| ]/g).join('').split(/[｜　]/g).join('');
        } else {
            masterValues = masterValues.split('|').join(' ').split('｜').join('　');
        }
        $(this).val(masterValues).focus();
    });
}

// ドキュメント読み込み時の処理
$(document).ready(function () {

    // [入力項目](input class="field") のfocusイベント登録
    $("input.field").bind("focus", function (e) {
        // 読み取り専用以外文章の末尾にフォーカスを設定
        //if (!e.target.readOnly) {
      　//    $(e.target).caret($(e.target).val().length, $(e.target).val().length);
        //}
        
        // それぞれフォーカスした項目に格納していた座標、サイズを設定
        crnt_top = $(e.target).data('top');
        crnt_left = $(e.target).data('left');
        crnt_height = $(e.target).data('height');
        crnt_width = $(e.target).data('width');
        
        showCurrentImage();
    });

    // ----------------------------------------------------------------
    // イベント登録

    // [拡大](input class="extend") clickイベント
    $("input.extend").bind("click", function (e) {
        if (crnt_zoom < zoom_max) crnt_zoom = ((crnt_zoom * 10) + 1) / 10;
        showCurrentImage();
    });

    // [縮小](input class="reduce") clickイベント
    $("input.reduce").bind("click", function (e) {
        if (crnt_zoom > zoom_min) crnt_zoom = ((crnt_zoom * 10) - 1) / 10;
        showCurrentImage();
    });

    // [元に戻す](input class="default") clickイベント
    $("input.default").bind("click", function (e) {
        crnt_zoom = zoom_default;
        showCurrentImage();
    });

    // [回転](input class="rotate") clickイベント
    $("input.rotate").bind("click", function (e) {
        crnt_rotate += 90;
        if (crnt_rotate == 360) crnt_rotate = 0;
        showCurrentImage();
    });

    // [ＸＸ](input class="xxxxxx") clickイベント
    // $("input.xxxxxx").bind("click", function (e) {
    //     処理を記述
    // });

    $(window).bind("load", function (e) {
        // イメージのデフォルト幅、高さを退避
        $("#imageW").val($("#formImage").width());
        $("#imageH").val($("#formImage").height());
    
        // イメージ初期表示
        showCurrentImage();

        // 初期フォーカス設定
        $("input.field")[0].focus();
    });

});
