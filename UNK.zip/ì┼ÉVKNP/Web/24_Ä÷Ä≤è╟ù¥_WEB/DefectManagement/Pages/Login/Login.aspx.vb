﻿Imports System.Data
Imports System.Collections.Generic
Imports DefectManagement.clsUtility
Imports CommonSystem
Imports DefectManagement.clsConst

Partial Class Login
    Inherits System.Web.UI.Page

#Region "Event"

#Region "ページロード"
    ''' <summary>
    '''  ページロード
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        ' ログ出力モード設定
        setLogOutput()

        ' 不正アクセスからの戻りの場合メッセージを表示
        If (Me.Session("NotifyBar.Html") <> Nothing) Then
            Dim html As String = DirectCast(Me.Session("NotifyBar.Html"), String)
            Me.Session("NotifyBar.Html") = Nothing
            ClsNotifyBar.Show(Me, html, ClsNotifyBar.Cls.Error)
        End If

        If Not IsPostBack Then

            '初期化
            SetInit()

        End If

    End Sub
#End Region

#Region "ログインボタン押下処理"
    ''' <summary>
    ''' ログインボタン押下処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub btnLogin_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnLogin.Click

        ' イベントの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        '入力チェック処理
        If Not InputCheck() Then
            Return
        End If

        'ログイン実行
        Call LoginExec()

        ' イベントの終了ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

    End Sub
#End Region

#End Region

#Region "method"

#Region "初期設定"
    ''' <summary>
    ''' 初期設定
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetInit()
        Me.lblVersion.Text = "FlowScope Ver." & System.Configuration.ConfigurationManager.AppSettings("SYS_VERSION") & _
                             " (Last Update:" & System.Configuration.ConfigurationManager.AppSettings("SYS_LAST_UPDATE") & ")"
    End Sub
#End Region

#Region "入力チェック処理"
    ''' <summary>
    ''' 入力チェック処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Function InputCheck() As Boolean

        Dim strError As String = ""

        ' メソッドの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        '*******************************
        '必須チェック
        '*******************************
        'ユーザーID
        If String.IsNullOrEmpty(Me.txtUser.Text) Then
            ClsNotifyBar.Show(Me, "ユーザーIDが未入力です。", ClsNotifyBar.Cls.Error)
            Return False
        End If

        'パスワード
        If String.IsNullOrEmpty(Me.txtPassword.Text) Then
            ClsNotifyBar.Show(Me, "パスワードが未入力です。", ClsNotifyBar.Cls.Error)
            Return False
        End If

        Return True

    End Function
#End Region

#Region "ログイン実行処理"
    ''' <summary>
    ''' ログイン実行処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub LoginExec()

        'ユーザー情報取得
        Dim objLoginDataAccess As New LoginDataAccess
        Dim dt As DataTable = objLoginDataAccess.GetSqlUser(Me.txtUser.Text, GetHashedString(Me.txtPassword.Text))

        ' メソッドの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        'ゼロ件の場合ログインできない
        If dt.Rows.Count = 0 Then
            ClsNotifyBar.Show(Me, "ユーザーIDまたはパスワードが違います。", ClsNotifyBar.Cls.Error)
            Return
        End If

        '更新日時更新処理
        Dim dictParam As New Dictionary(Of String, String)
        dictParam.Add("USER_ID", Me.txtUser.Text)
        Dim intResult As Integer = objLoginDataAccess.UpdSqlMCmUserUpdateDate(dictParam)

        '要求元へリダイレクト 
        FormsAuthentication.RedirectFromLoginPage(Me.txtUser.Text, True)
        ' メニューへ遷移します
        Me.Response.Redirect("~/Pages/Menu/Menu.aspx", True)

    End Sub
#End Region

#Region "ログ出力モード設定"
    ''' <summary>
    ''' ログ出力モード設定
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub setLogOutput()

        ' ログ出力レベル設定
        CommonLog.SetLogOutputMode = System.Int32.Parse(System.Configuration.ConfigurationManager.AppSettings(CONF_LOG_OUTPUT_LEVEL))

        ' ログ日時分割出力モード設定
        CommonLog.SetLogDateHourDivideMode = System.Int32.Parse(System.Configuration.ConfigurationManager.AppSettings(CONF_LOG_DIVIDE_MODE))

        ' ログの出力先を設定
        CommonLog.SetLogFileOutputPath = System.Configuration.ConfigurationManager.AppSettings(CONF_LOG_OUTPUT_PATH)

    End Sub
#End Region

#End Region

End Class
