﻿Imports CommonSystem
Imports DefectManagement.clsConst
Imports DefectManagement.clsUtility
Imports System.Drawing
Imports System.Diagnostics
Imports System.Data
Imports System.Security.Cryptography
Imports System
Imports System.IO

Partial Public Class SqlExecute
    Inherits System.Web.UI.Page

#Region " ページロード時 "
    ''' <summary>
    ''' ページロード時
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        ' イベントの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        If Not IsPostBack Then

            '初期化
            SetInit()

            btnExecute.Attributes.Add("onclick", "if (confirm('SQLを実行します。よろしいですか？') ==false) return false;")

        End If

        ' イベントの終了ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

    End Sub
#End Region

#Region " 初期設定 "
    ''' <summary>
    ''' 初期設定
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetInit()

        ' メソッドの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        ' 画面上部のメニュー遷移表示
        Me.hplRoot2.Text = "システムメンテナンス"
        Me.hplRoot3.Text = "SQL実行(更新)"

        ' SQL選択Listの表示用データソース定義
        Dim dt As New DataTable
        dt.Columns.Add("PATH", GetType(System.String))
        dt.Columns.Add("NAME", GetType(System.String))

        ' 先頭の固定SQL（任意SQL）の登録
        Dim dr As DataRow = dt.NewRow
        dr.Item("PATH") = String.Empty
        dr.Item("NAME") = "任意のSQLを実行"
        dt.Rows.Add(dr)

        ' SQLファイルの格納先
        Dim strSqlPath As String = ConfigurationManager.AppSettings("SQL_FOLDER")
        ' SQLファイル一覧取得
        Dim strFiles() As String = Directory.GetFiles(strSqlPath, "*.sql")
        Array.Sort(strFiles)
        ' SQLファイルの一覧をドロップダウンリスト用テーブルに登録
        For Each strF As String In strFiles
            Dim drwNew As DataRow = dt.NewRow
            drwNew.Item("PATH") = strF
            drwNew.Item("NAME") = Path.GetFileNameWithoutExtension(strF)
            dt.Rows.Add(drwNew)
        Next

        ' 帳票IDドロップダウンリストに値を設定
        SetDropDownList(Me.ddlSqlFiles, dt)


        ' メソッドの終了ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

    End Sub
#End Region

#Region "ドロップダウンリスト（SQLファイル）の選択変更時"
    ''' <summary>
    ''' ドロップダウンリスト（SQLファイル）の選択変更時
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub ddlSqlFiles_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ddlSqlFiles.SelectedIndexChanged
        ' ドロップダウンリストの先頭が選ばれた場合はSQL入力欄を空欄にして終わる
        If Me.ddlSqlFiles.SelectedIndex = 0 Then
            Me.txtSQL.Text = String.Empty
            Return
        End If

        ' 選択されたSQLファイルの内容を画面に表示する
        Dim strF As String = Me.ddlSqlFiles.SelectedValue
        Using sr As New StreamReader(strF, Encoding.GetEncoding("shift-jis"))
            Me.txtSQL.Text = sr.ReadToEnd
        End Using

    End Sub
#End Region

#Region "実行ボタン処理"
    ''' <summary>
    ''' 実行ボタン処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub btnExecute_ServerClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExecute.ServerClick

        ' SQLが指定されたコマンドで始まっていない場合は実行しません。
        Dim strSQL As String = Me.txtSQL.Text.Replace(vbNewLine, " ").Trim.ToUpper
        If Not strSQL.StartsWith("INSERT") AndAlso _
           Not strSQL.StartsWith("UPDATE") AndAlso _
           Not strSQL.StartsWith("DELETE") Then
            ClsNotifyBar.Show(Me, "実行が許可されたSQLではありません。", ClsNotifyBar.Cls.Error)
            Return
        End If

        ' 実行するSQLをログに出力します。
        clsUtility.WriteLog("SQLの実行", EventLogEntryType.SuccessAudit)
        clsUtility.WriteLog(Me.txtSQL.Text, EventLogEntryType.SuccessAudit)

        ' DB接続します
        Dim objclsDbAccess As New clsDbAccess
        Call objclsDbAccess.dbOpen()
        ' トランザクションの開始
        objclsDbAccess.mobjCommonDB.DB_Transaction()
        Try
            ' SQLを実行
            Dim stbSQL As New StringBuilder(String.Empty)
            stbSQL.Append(Me.txtSQL.Text)
            Dim intResult As Integer
            intResult = objclsDbAccess.mobjCommonDB.DB_ExecuteNonQuery(stbSQL.ToString)

            ' トランザクションの確定
            objclsDbAccess.mobjCommonDB.DB_Commit()

            ' SQLログ出力
            Call SqlLog(Page, Request, stbSQL.ToString, True, intResult)

            ' SQL実行完了メッセージを作成します。
            Dim stbMsg As New StringBuilder
            stbMsg.Append("SQLは正常に実行され、%COUNT%件のデータが処理されました。")
            stbMsg.Replace("%COUNT%", intResult.ToString)
            ' 作成されたメッセージを表示
            ClsNotifyBar.Show(Me, stbMsg.ToString, ClsNotifyBar.Cls.Success)

        Catch ex As Exception

            ' トランザクションの破棄
            objclsDbAccess.mobjCommonDB.DB_Rollback()

            ' SQLログ出力
            Call SqlLog(Page, Request, Me.txtSQL.Text, False, 0)

            ' エラーメッセージ表示
            ClsNotifyBar.Show(Me, "SQL実行時にエラーが発生しました。", ClsNotifyBar.Cls.Error)

        Finally

            ' DBセッションを切断
            objclsDbAccess.mobjCommonDB.DB_Close()

        End Try

    End Sub
#End Region

End Class