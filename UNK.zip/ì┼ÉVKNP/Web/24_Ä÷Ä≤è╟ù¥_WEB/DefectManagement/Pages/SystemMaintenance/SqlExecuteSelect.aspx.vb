﻿Imports CommonSystem
Imports DefectManagement.clsConst
Imports DefectManagement.clsUtility
Imports System.Drawing
Imports System.Diagnostics
Imports System.Data
Imports System.Security.Cryptography
Imports System
Imports System.IO

Partial Public Class SqlExecuteSelect
    Inherits System.Web.UI.Page

#Region " ページロード時 "
    ''' <summary>
    ''' ページロード時
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        ' イベントの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        If Not IsPostBack Then

            '初期化
            SetInit()

            ' セッションクリア
            Call SessionClear()

            btnExecute.Attributes.Add("onclick", "if (confirm('SQLを実行します。よろしいですか？') ==false) return false;")
            btnCsv.Attributes.Add("onclick", "if (confirm('抽出結果をダウンロードします。よろしいですか？') ==false) return false;")

        End If

        ' イベントの終了ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

    End Sub
#End Region

#Region " 初期設定 "
    ''' <summary>
    ''' 初期設定
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetInit()

        ' メソッドの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        ' 画面上部のメニュー遷移表示
        Me.hplRoot2.Text = "システムメンテナンス"
        Me.hplRoot3.Text = "SQL実行(検索)"

        ' SQL選択Listの表示用データソース定義
        Dim dt As New DataTable
        dt.Columns.Add("PATH", GetType(System.String))
        dt.Columns.Add("NAME", GetType(System.String))

        ' 先頭の固定SQL（任意SQL）の登録
        Dim dr As DataRow = dt.NewRow
        dr.Item("PATH") = String.Empty
        dr.Item("NAME") = "任意のSQLを実行"
        dt.Rows.Add(dr)

        ' SQLファイルの格納先
        Dim strSqlPath As String = ConfigurationManager.AppSettings("SQL_FOLDER_2")
        ' SQLファイル一覧取得
        Dim strFiles() As String = Directory.GetFiles(strSqlPath, "*.sql")
        Array.Sort(strFiles)
        ' SQLファイルの一覧をドロップダウンリスト用テーブルに登録
        For Each strF As String In strFiles
            Dim drwNew As DataRow = dt.NewRow
            drwNew.Item("PATH") = strF
            drwNew.Item("NAME") = Path.GetFileNameWithoutExtension(strF)
            dt.Rows.Add(drwNew)
        Next

        ' 帳票IDドロップダウンリストに値を設定
        SetDropDownList(Me.ddlSqlFiles, dt)


        ' メソッドの終了ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

    End Sub
#End Region

#Region "ドロップダウンリスト（SQLファイル）の選択変更時"
    ''' <summary>
    ''' ドロップダウンリスト（SQLファイル）の選択変更時
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub ddlSqlFiles_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ddlSqlFiles.SelectedIndexChanged
        ' ドロップダウンリストの先頭が選ばれた場合はSQL入力欄を空欄にして終わる
        If Me.ddlSqlFiles.SelectedIndex = 0 Then
            Me.txtSQL.Text = String.Empty
            Return
        End If

        ' 選択されたSQLファイルの内容を画面に表示する
        Dim strF As String = Me.ddlSqlFiles.SelectedValue
        Using sr As New StreamReader(strF, Encoding.GetEncoding("shift-jis"))
            Me.txtSQL.Text = sr.ReadToEnd
        End Using

    End Sub
#End Region

#Region "実行ボタン処理"
    ''' <summary>
    ''' 実行ボタン処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub btnExecute_ServerClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExecute.ServerClick

        ' SQLが指定されたコマンドで始まっていない場合は実行しません。
        Dim strSQL As String = Me.txtSQL.Text.Replace(vbNewLine, " ").Trim.ToUpper
        If Not strSQL.StartsWith("SELECT") Then
            ClsNotifyBar.Show(ScriptManager.GetCurrent(Me), "実行が許可されたSQLではありません。", ClsNotifyBar.Cls.Error)
            Return
        End If

        ' 実行するSQLをログに出力します。
        clsUtility.WriteLog("SQLの実行", EventLogEntryType.SuccessAudit)
        clsUtility.WriteLog(Me.txtSQL.Text, EventLogEntryType.SuccessAudit)

        ' DB接続します
        Dim objclsDbAccess As New clsDbAccess
        Call objclsDbAccess.dbOpen()
        Try
            ' SQLを実行
            Dim stbSQL As New StringBuilder(String.Empty)
            stbSQL.Append(Me.txtSQL.Text)
            Dim dt As DataTable
            dt = objclsDbAccess.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)

            ' SQLログ出力
            Call SqlLog(Page, Request, stbSQL.ToString, True, dt.Rows.Count)

            ' SQL実行完了メッセージを作成します。
            Dim stbMsg As New StringBuilder
            stbMsg.Append("SQLは正常に実行され、%COUNT%件のデータが抽出されました。")
            stbMsg.Replace("%COUNT%", dt.Rows.Count.ToString)
            ' 作成されたメッセージを表示
            ClsNotifyBar.Show(Me, stbMsg.ToString, ClsNotifyBar.Cls.Success)

            Me.GridView1.DataSource = dt
            Me.GridView1.DataBind()

            '検索結果をセッションに格納
            Me.Session(clsConst.SQL_RESULT_KEY) = dt

        Catch ex As Exception

            ' SQLログ出力
            Call SqlLog(Page, Request, Me.txtSQL.Text, False, 0)

            ' エラーメッセージ表示
            ClsNotifyBar.Show(Me, "SQL実行時にエラーが発生しました。", ClsNotifyBar.Cls.Error)

        Finally

            ' DBセッションを切断
            objclsDbAccess.mobjCommonDB.DB_Close()

        End Try

    End Sub
#End Region

#Region " セッションクリア "
    ''' <summary>
    ''' セッションクリア
    ''' </summary>
    Private Sub SessionClear()

        If Not Page.Session.Item(clsConst.SQL_RESULT_KEY) Is Nothing Then
            Page.Session.Remove(clsConst.SQL_RESULT_KEY)
        End If

    End Sub
#End Region

#Region "CSVボタン処理"
    ''' <summary>
    ''' CSVボタン処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub btnCsv_ServerClick(ByVal sender As System.Object, ByVal e As System.EventArgs)

        If Page.Session.Item(clsConst.SQL_RESULT_KEY) Is Nothing Then
            ' エラーメッセージ表示
            ClsNotifyBar.Show(ScriptManager.GetCurrent(Me), "有効な検索を実行してからCSV出力をしてください。", ClsNotifyBar.Cls.Normal)
            Return
        End If

        ' 一意となる作業フォルダを作成
        Dim strTemp As String = MakeTempFolder()
        Try
            'シフトJISエンコーディング
            Dim sjis As Encoding = Encoding.GetEncoding(932)

            ' 検索結果を取得
            Dim dtCsv As DataTable = Me.Session(clsConst.SQL_RESULT_KEY)

            ' SQL検索結果CSVの作成
            Dim strCsv1 As String = MakeCsv1(strTemp, dtCsv)

            ' 作成されたリストをZIPファイルに圧縮
            Dim strZipPath As String = MakeZip(strTemp, strCsv1)
            Dim strZipName As String = Path.GetFileName(strZipPath)

            ' ZIPファイルをクライアントに送信
            Response.Clear()
            Response.AppendHeader("Content-Disposition", "attachment;filename=" & HttpUtility.UrlEncode(strZipName))
            Response.ContentType = "application/octet-stream"
            Response.ContentEncoding = sjis
            Using fs As New FileStream(strZipPath, FileMode.Open)
                If fs.Length > 0 Then
                    Using br As New BinaryReader(fs)
                        Response.BinaryWrite(br.ReadBytes(Convert.ToInt32(fs.Length)))
                    End Using
                End If
            End Using
            Response.End()

        Finally
            ' 作業フォルダを削除します。
            Directory.Delete(strTemp, True)
        End Try

    End Sub
#End Region

#Region "SQL検索結果のCSV出力"
    ''' <summary>
    ''' SQL検索結果のCSV出力
    ''' </summary>
    ''' <param name="strTemp">出力先フォルダPATH</param>
    ''' <param name="dtCsv">出力元データ</param>
    ''' <returns>作成されたCSVファイルのフルPATH</returns>
    ''' <remarks></remarks>
    Private Function MakeCsv1(ByVal strTemp As String, _
                              ByVal dtCsv As DataTable) As String

        ' 出力下データ（検索結果）からCSV出力クラスを生成します。
        Dim clsCSV As New CommonCsv(dtCsv)

        ' 作成するCSVファイルのフルPATHを作成します。
        Dim strPath As String = Path.Combine(strTemp, ConfigurationManager.AppSettings("SQL_SELECT_FILE"))

        ' CSVファイルを出力します。
        clsCSV.SaveCsvWithHeader(strPath, False, True)

        Return strPath

    End Function
#End Region

End Class