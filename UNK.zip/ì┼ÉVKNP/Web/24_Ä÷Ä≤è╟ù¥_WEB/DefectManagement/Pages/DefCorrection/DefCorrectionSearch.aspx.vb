﻿Imports System.Data
Imports DefectManagement.clsConst
Imports DefectManagement.clsUtility

Partial Class DefCorrection_DefCorrectionSearch
    Inherits System.Web.UI.Page

#Region " 列挙体 "
    ''' <summary>
    ''' 検索結果リスト列番号
    ''' </summary>
    ''' <remarks></remarks>
    Private Enum enumGridColNo
        Def1Cnt = 0
        Def1Btn = 1
        Def2Cnt = 2
        Def2Btn = 3
    End Enum
#End Region


#Region " ページロード時 "
    ''' <summary>
    ''' ページロード時
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        ' イベントの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        If Not IsPostBack Then
            ' ページの表示モードをクエリストリングより取得して、ビューステートに格納
            Me.ViewState("MODE") = Me.Page.Request.QueryString("mode")

            ' 修正画面からの戻りの場合メッセージを表示
            If (Me.Session("NotifyBar.Html") <> Nothing) Then
                Dim html As String = DirectCast(Me.Session("NotifyBar.Html"), String)
                Me.Session("NotifyBar.Html") = Nothing
                ClsNotifyBar.Show(Me, html, ClsNotifyBar.Cls.Success)
            End If

            '初期化
            SetInit()
        End If

        Me.Title = "データ修正"
        Me.hplRoot2.Text = "データ修正"

        ' イベントの終了ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

    End Sub
#End Region

#Region " 検索ボタン押下時 "
    ''' <summary>
    ''' 検索ボタン押下時
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnSearch_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSearch.ServerClick

        ' イベントの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        ' 入力チェック
        If InputCheck() = False Then
            Return
        End If

        'セッションクリア
        SessionClear()

        ' 検索処理実行
        SearchList()

        ' イベントの終了ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

    End Sub
#End Region

#Region " GridView行データバウンド時 "
    ''' <summary>
    ''' GridView行データバウンド時
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub grdSearchList_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles grdSearchList.RowDataBound

        ' イベントの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        Dim oblCda As New CommonDataAccess    ' 共通系SQL発行クラス

        ' 現在行の種類によって処理を分岐
        Select Case e.Row.RowType

            ' 現在行がデータ行である場合
            Case DataControlRowType.DataRow
                Dim row = DirectCast(e.Row.DataItem, DataRowView)

                ' 不備①未処理件数取得
                Dim intDef1Cnt As Integer = row.Item("DEF_1_CNT")

                ' 不備②未処理件数取得
                Dim intDef2Cnt As Integer = row.Item("DEF_2_CNT")

                ' 不備①未処理件数が0件の場合、不備①開始ボタンを使用不可にする
                If intDef1Cnt = 0 Then
                    e.Row.Cells(enumGridColNo.Def1Btn).Enabled = False
                End If

                ' 不備②未処理件数が0件の場合、不備②開始ボタンを使用不可にする
                If intDef2Cnt = 0 Then
                    e.Row.Cells(enumGridColNo.Def2Btn).Enabled = False
                End If
        End Select

        ' イベントの終了ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

    End Sub
#End Region

#Region " GridView行操作時 "
    ''' <summary>
    ''' GridView行操作時
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub grdSearchList_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles grdSearchList.RowCommand

        ' イベントの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        ' コマンド名が“Def1”、“Def2”の場合にのみ処理
        If e.CommandName.Equals("Def1") OrElse e.CommandName.Equals("Def2") Then

            Dim strBtnStr As String = ""   ' 押下ボタンステータス（1:不備①未処理 2:不備②未処理）

            Select Case e.CommandName
                Case "Def1"
                    strBtnStr = "1"
                Case "Def2"
                    strBtnStr = "2"
            End Select

            ' isbn列の値を基にURLを生成し、リダイレクト
            Response.Redirect(String.Format("~/Pages/DefCorrection/DefDataCorrection.aspx?btnStr={0}", strBtnStr))

        End If

        ' イベントの終了ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

    End Sub
#End Region


#Region " 初期設定 "
    ''' <summary>
    ''' 初期設定
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetInit()

        ' メソッドの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        Dim objCda As New CommonDataAccess    ' 共通系SQL発行クラス

        ' 受付日にシステム日付を設定
        Me.txtReceiptDateFrom.Text = objCda.GetSysDate
        Me.txtReceiptDateTo.Text = objCda.GetSysDate

        '戻るボタンで戻ってこなかった場合セッションをクリア
        If Page.Request.QueryString("ReturnFlg") Is Nothing Then
            SessionClear()
        End If

        '検索キーをセット
        SetSessionSearchKey()

        ' 検索処理実行
        SearchList()

        ' メソッドの終了ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

    End Sub
#End Region

#Region " 検索結果リスト表示処理 "
    ''' <summary>
    ''' 検索結果リスト表示処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SearchList()

        ' メソッドの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        Dim objDfda As New DefCorrectionDataAccess           ' 不備修正SQL発行クラス
        Dim dicParam As New Dictionary(Of String, String)    ' 検索条件格納用

        ' 受付日Fromが入力されている場合、パラメータにセット
        If Not String.IsNullOrEmpty(Me.txtReceiptDateFrom.Text) Then
            dicParam.Add("RECEIPT_DATE_FROM", Format(CType(Me.txtReceiptDateFrom.Text, Date), "yyyy/MM/dd"))
        End If

        ' 受付日Toが入力されている場合、パラメータにセット
        If Not String.IsNullOrEmpty(Me.txtReceiptDateTo.Text) Then
            dicParam.Add("RECEIPT_DATE_TO", Format(CType(Me.txtReceiptDateTo.Text, Date), "yyyy/MM/dd"))
        End If

        'セッションに検索条件を格納
        Me.Session(clsConst.DCS_SEARCH_KEY) = dicParam

        ' 検索結果を表示
        Me.grdSearchList.DataSource = objDfda.GetDefList(dicParam)
        Me.grdSearchList.DataBind()

        ' メソッドの終了ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

    End Sub
#End Region

#Region " 入力チェック処理 "
    ''' <summary>
    ''' 入力チェック処理
    ''' </summary>
    ''' <returns>Boolean True:エラーなし False:エラー有り</returns>
    ''' <remarks></remarks>
    Private Function InputCheck() As Boolean

        ' メソッドの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        ' 受付日Fromが入力されている場合
        If Not String.IsNullOrEmpty(Me.txtReceiptDateFrom.Text) Then
            ' 日付書式チェック
            If Not isDate(Me.txtReceiptDateFrom.Text) Then
                ClsNotifyBar.Show(Me, "受付日Fromの日付が不正です。", ClsNotifyBar.Cls.Error)
                Return False
            End If
        End If

        ' 受付日Toが入力されている場合
        If Not String.IsNullOrEmpty(Me.txtReceiptDateTo.Text) Then
            ' 日付書式チェック
            If Not isDate(Me.txtReceiptDateTo.Text) Then
                ClsNotifyBar.Show(Me, "受付日Toの日付が不正です。", ClsNotifyBar.Cls.Error)
                Return False
            End If
        End If

        ' 受付日の大小関係チェック
        If Not String.IsNullOrEmpty(Me.txtReceiptDateFrom.Text) AndAlso Not String.IsNullOrEmpty(Me.txtReceiptDateTo.Text) Then
            If Format(CType(Me.txtReceiptDateFrom.Text, Date), "yyyy/MM/dd") > Format(CType(Me.txtReceiptDateTo.Text, Date), "yyyy/MM/dd") Then
                ClsNotifyBar.Show(Me, "受付日の大小関係が不正です。", ClsNotifyBar.Cls.Error)
                Return False
            End If

        End If

        Return True

        ' メソッドの終了ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

    End Function
#End Region

#Region " セッション内の検索キーをセット "

    ''' <summary>
    ''' セッション内の検索キーをセット
    ''' </summary>
    Private Sub SetSessionSearchKey()

        If Not Page.Session.Item(clsConst.DCS_SEARCH_KEY) Is Nothing Then

            Dim dicParam As Dictionary(Of String, String) = Me.Session(clsConst.DCS_SEARCH_KEY)    ' 検索条件格納用

            If dicParam.ContainsKey("RECEIPT_DATE_FROM") Then
                Me.txtReceiptDateFrom.Text = dicParam.Item("RECEIPT_DATE_FROM")
            End If

            If dicParam.ContainsKey("RECEIPT_DATE_TO") Then
                Me.txtReceiptDateTo.Text = dicParam.Item("RECEIPT_DATE_TO")
            End If

        End If

    End Sub

#End Region

#Region " セッションクリア "

    ''' <summary>
    ''' セッションクリア
    ''' </summary>
    Private Sub SessionClear()

        If Not Page.Session.Item(clsConst.DCS_SEARCH_KEY) Is Nothing Then
            Page.Session.Remove(clsConst.DCS_SEARCH_KEY)
        End If

    End Sub

#End Region

End Class
