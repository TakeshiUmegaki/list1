﻿Imports System
Imports System.Configuration
Imports System.Data
Imports System.IO
Imports System.Text
Imports Oracle.DataAccess.Client

Partial Class Menu
    Inherits System.Web.UI.Page

    Private Const USER_FILE As String = "UploadUserID.txt"

#Region "Event"

    ''' <summary>
    ''' ページロード時イベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        ' ポストバック時は何もしない
        If IsPostBack Then
            Return
        End If

        ' パスワード変更画面からの戻りの場合メッセージを表示
        If (Me.Session("NotifyBar.Html") <> Nothing) Then
            Dim html As String = DirectCast(Me.Session("NotifyBar.Html"), String)
            Me.Session("NotifyBar.Html") = Nothing
            ClsNotifyBar.Show(Me, html, ClsNotifyBar.Cls.Success)
        End If

        ' パスワード有効期日取得
        Dim objCommonDataAccess As New CommonDataAccess
        Dim strLimit As String = objCommonDataAccess.GetSqlPassLimit(Page.User.Identity.Name)
        ' パスワード変更警告開始期日を当日に加算する
        Dim dblAlart As Double = Convert.ToDouble(ConfigurationManager.AppSettings(clsConst.CONF_ALERT_LIMIT))
        Dim strAlert As String = DateTime.Now.AddDays(dblAlart).ToString("yyyyMMdd")
        ' 当日の日付を取得
        Dim strNow As String = DateTime.Now.ToString("yyyyMMdd")
        If strNow > strLimit Then
            ClsNotifyBar.Show(Me.Page, "パスワードの有効期限が切れました。変更してください。", ClsNotifyBar.Cls.Error)
        ElseIf strAlert > strLimit Then
            ClsNotifyBar.Show(Me.Page, "パスワードの有効期限が僅かです。変更してください。", ClsNotifyBar.Cls.Error)
        End If

        '権限情報取得
        Dim strRollCd As String = objCommonDataAccess.GetSqlAnth(Page.User.Identity.Name)

        ' お知らせ一覧の設定（表示）
        Call GetTiteleList()
        ' ファイル一覧の設定（表示）
        Call GetFileList()


        ' お知らせ登録エリアの表示設定を初期化
        Me.pnlInput1.Visible = True
        ' ファイル登録エリアの表示設定を初期化
        Me.pnlInput2.Visible = True

        Select Case strRollCd
            Case clsConst.SV, clsConst.SYSTEM
                'SV, システムは登録エリアを有効とする（非表示にしない）
                Me.gvInfoList.Columns(5).Visible = True
                Me.gvFileList.Columns(5).Visible = True
                Me.tblInfoListHCell6.Visible = True
                Me.tblFileListHCell6.Visible = True
            Case Else
                ' SV・システム以外は登録エリアを無効とする（非表示）
                ' お知らせ登録エリア
                Me.pnlInput1.Visible = False
                Me.gvInfoList.Columns(5).Visible = False
                Me.tblInfoListHCell6.Visible = False
                ' ファイル登録エリア
                Me.pnlInput2.Visible = False
                Me.gvFileList.Columns(5).Visible = False
                Me.tblFileListHCell6.Visible = False
        End Select

    End Sub

    ''' <summary>
    ''' お知らせ登録ボタンクリックイベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub btnEntryInfo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEntryInfo.Click
        ' 件名入力チェック
        If Me.txtTitle.Text.Trim.Length = 0 Then
            ' メッセージ表示
            ClsNotifyBar.Show(Me.Page, "件名を入力してください。", ClsNotifyBar.Cls.Error)
            Return
        End If
        ' 詳細入力チェック
        If Me.txtInfomation.Text.Trim.Length = 0 Then
            ' メッセージ表示
            ClsNotifyBar.Show(Me.Page, "詳細を入力してください。", ClsNotifyBar.Cls.Error)
            Return
        End If
        ' 件名入力文字に改行用文字"|"の存在チェック
        If Me.txtTitle.Text.IndexOf("|") >= 0 Then
            ' メッセージ表示
            ClsNotifyBar.Show(Me.Page, "件名に""|""は使用できません。。", ClsNotifyBar.Cls.Error)
            Return
        End If
        ' 詳細入力文字に改行用文字"|"の存在チェック
        If Me.txtInfomation.Text.IndexOf("|") >= 0 Then
            ' メッセージ表示
            ClsNotifyBar.Show(Me.Page, "詳細に""|""は使用できません。。", ClsNotifyBar.Cls.Error)
            Return
        End If
        ' 改行を"|"に置換後、件名は１００文字まで
        Dim strT As String = Me.txtTitle.Text.Replace(vbNewLine, "|")
        If strT.Length > 100 Then
            ' メッセージ表示
            ClsNotifyBar.Show(Me.Page, "件名は100文字までです。", ClsNotifyBar.Cls.Error)
            Return
        End If
        ' 改行を"|"に置換後、詳細は２０００文字まで
        Dim strI As String = Me.txtInfomation.Text.Replace(vbNewLine, "|")
        If strI.Length > 2000 Then
            ' メッセージ表示
            ClsNotifyBar.Show(Me.Page, "詳細は改行を含めて2000文字までです。", ClsNotifyBar.Cls.Error)
            Return
        End If

        ' 登録用引数辞書に登録内容を設定
        Dim dicParam As New Dictionary(Of String, String)
        dicParam.Add("TITLE", strT)
        dicParam.Add("INFO", strI)
        dicParam.Add("USER", Page.User.Identity.Name)

        ' お知らせをDBに新規登録
        Dim objMenuDataAccess As New MenuDataAccess
        objMenuDataAccess.InsSqlInfomaton(dicParam)

        ' メッセージ表示
        ClsNotifyBar.Show(Me.Page, "お知らせが登録されました。", ClsNotifyBar.Cls.Success)

        ' お知らせ一覧の設定（再表示）
        Call GetTiteleList()

        ' 入力欄のクリア
        Me.txtTitle.Text = String.Empty
        Me.txtInfomation.Text = String.Empty

    End Sub

    ''' <summary>
    ''' お知らせ一覧のボタンクリックイベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub gvInfoList_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gvInfoList.RowCommand

        ' クリックされたボタンの存在する行位置を取得します
        Dim intRow As Integer = Convert.ToInt32(e.CommandArgument)
        If intRow < 0 Then
            ' 想定外の行番号なら処理を行いません。
            Return
        End If

        ' DBのお知らせ情報更新の準備
        Dim objMenuDataAccess As New MenuDataAccess

        ' クリックされたボタンの判定
        Select Case e.CommandName
            Case "DeleteInfo"
                ' 削除ボタン処理

                ' 隠し列からクリックされた行のDBのKeyを取得
                Dim strSEQ As String = CType(Me.gvInfoList.Rows(intRow).FindControl("lblSEQ"), Label).Text
                ' DB更新処理へのパラメータ辞書を設定
                Dim dicParam As New Dictionary(Of String, String)
                dicParam.Add("SEQ", strSEQ)
                dicParam.Add("USER", Page.User.Identity.Name)
                ' お知らせ情報の更新
                objMenuDataAccess.UpdSqlInfomation(dicParam)
                ' お知らせ一覧の設定
                Call GetTiteleList()
                ' メッセージ表示
                ClsNotifyBar.Show(Me.Page, "お知らせの削除に成功しました。", ClsNotifyBar.Cls.Success)

        End Select
    End Sub

    ''' <summary>
    ''' ファイル登録ボタンクリックイベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub btnUpload_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpload.Click
        If FileUpload1.HasFile Then
            ' 登録ファイル名が入力されている場合

            ' ファイル受信準備
            Dim sjis As Encoding = Encoding.GetEncoding(932)
            Try
                ' 指定されたファイル名がシステムで使用している登録ユーザID保存ファイル名と同じ場合は
                ' メッセージを表示して登録はしない
                If FileUpload1.FileName.Equals(USER_FILE) Then
                    ClsNotifyBar.Show(Me.Page, "予約されたファイル名です。別のファイル名で登録してください。", ClsNotifyBar.Cls.Normal)
                    Return
                End If

                ' configからファイルの保存先ルートフォルダのPATHを取得します。
                Dim strUploadRoot As String = ConfigurationManager.AppSettings(clsConst.CONF_UPLOAD_ROOT)
                ' ルートフォルダ下に「yyyyMMddHHmmss」フォルダを作成します。
                Dim intRetry As Integer = 0
                Dim strFolder As String = String.Empty
                For intRetry = 0 To 30 Step 1
                    strFolder = Path.Combine(strUploadRoot, DateTime.Now.ToString("yyyyMMddHHmmss"))
                    If Directory.Exists(strFolder) Then
                        ' 既に同名のサブフォルダが存在する場合は１秒待ってから再作成を試みます
                        Threading.Thread.Sleep(1000)
                        Continue For
                    End If
                    Directory.CreateDirectory(strFolder)
                    Exit For
                Next
                If intRetry > 30 Then
                    ' 再作成を３０回（３０秒）試行しても成功しなかった場合はメッセージを表示して
                    ' 登録を中断します。
                    ClsNotifyBar.Show(Me.Page, "ファイルのアップロードに失敗しました。", ClsNotifyBar.Cls.Error)
                    Return
                End If

                ' アップロードファイルの保存
                FileUpload1.PostedFile.SaveAs(strFolder & "\" & FileUpload1.FileName)
                ' 登録者ID記録ファイルの保存
                Using sw As New StreamWriter(Path.Combine(strFolder, USER_FILE), False, sjis)
                    sw.Write(Page.User.Identity.Name)
                    sw.Flush()
                End Using

                ' ファイル一覧の設定
                Call GetFileList()

                ' メッセージ表示
                ClsNotifyBar.Show(Me.Page, "ファイルのアップロードに成功しました。", ClsNotifyBar.Cls.Success)

            Catch ex As Exception
                ClsNotifyBar.Show(Me.Page, "ファイルのアップロードに失敗しました。", ClsNotifyBar.Cls.Error)
            End Try
        Else
            ' 登録ファイル名が入力されていない場合

            ' メッセージを表示
            ClsNotifyBar.Show(Me.Page, "登録するファイルを指定してください。", ClsNotifyBar.Cls.Error)
        End If
    End Sub

    ''' <summary>
    ''' ファイル一覧のGridView内のボタンクリックイベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub gvFileList_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gvFileList.RowCommand

        ' クリックされたボタンの存在する行位置を取得します
        Dim intRow As Integer = Convert.ToInt32(e.CommandArgument)
        If intRow < 0 Then
            ' 想定外の行番号なら処理を行いません。
            Return
        End If

        ' configからファイルの保存先ルートフォルダのPATHを取得します。
        Dim strUploadRoot As String = ConfigurationManager.AppSettings(clsConst.CONF_UPLOAD_ROOT)
        ' GridViewに表示されている日時から保存先のサブフォルダ名を取得して
        ' ルートフォルダPATHと結合して絶対PATHに変換します。
        Dim strFolder As String = Me.gvFileList.Rows(intRow).Cells(0).Text
        strFolder = strFolder.Replace("/", String.Empty).Replace(" ", String.Empty).Replace(":", String.Empty)
        Dim strPath As String = Path.Combine(strUploadRoot, strFolder)

        ' 押されたボタンによって処理を分岐します。
        Select Case e.CommandName
            Case "Download"
                ' ファイル名をクリック（ファイルのダウンロード）
                ' シフトJISエンコード
                Dim sjis As Encoding = Encoding.GetEncoding(932)
                ' ボタンクリックに対するクライアントへのレスポンスをファイルダウンロードにします。
                Dim strName As String = CType(Me.gvFileList.Rows(intRow).FindControl("lblFileName"), Label).Text
                Dim strFile As String = Path.Combine(strPath, strName)
                Dim stbHead As New StringBuilder("attachment;filename=%FILE%")
                stbHead.Replace("%FILE%", HttpUtility.UrlEncode(strName))
                Response.Clear()
                Response.AppendHeader("Content-Disposition", stbHead.ToString)
                Response.ContentType = "application/octet-stream"
                Response.ContentEncoding = sjis
                Using fs As New FileStream(strFile, FileMode.Open)
                    If fs.Length > 0 Then
                        Using br As New BinaryReader(fs)
                            Response.BinaryWrite(br.ReadBytes(Convert.ToInt32(fs.Length)))
                        End Using
                    End If
                End Using

            Case "FileDelete"
                ' 削除をクリック
                ' 保存先フォルダの削除
                Directory.Delete(strPath, True)
                ' ファイル一覧の設定
                Call GetFileList()
                ' メッセージ表示
                ClsNotifyBar.Show(Me.Page, "ファイルの削除に成功しました。", ClsNotifyBar.Cls.Success)

        End Select
    End Sub

#End Region

#Region "method"

    ''' <summary>
    ''' お知らせ一覧の設定（表示）
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub GetTiteleList()

        ' DBからお知らせ情報を取得するための準備
        Dim objMenuDataAccess As New MenuDataAccess
        Dim sjis As Encoding = Encoding.GetEncoding(932)

        ' Newアイコンを表示する時間数
        Dim dblH As Integer = Convert.ToDouble(ConfigurationManager.AppSettings(clsConst.CONF_NEW_HOUR))
        ' 現在時刻
        Dim strNow As String = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")

        ' 画面のGridViewに設定するためのソーステーブルを作成
        Dim dtb As New DataTable
        dtb.Columns.Add("SEQ", GetType(String))
        dtb.Columns.Add("DATE", GetType(String))
        dtb.Columns.Add("INFO", GetType(String))
        dtb.Columns.Add("NAME", GetType(String))
        dtb.Columns.Add("ICON", GetType(String))
        dtb.Columns.Add("ROLL", GetType(String))

        ' DBからお知らせ情報を取得
        Dim dtbInfo As DataTable = objMenuDataAccess.GetSqlInfomation

        ' マウスを乗せると詳細が表示されるように設定されたタグを準備
        Dim stbInfo As New StringBuilder("<a class=""topics"" href=""#"" title=""%TITLE%|%MESSAGE%"">%TITLE%</a>")

        ' 取得したお知らせ情報を1件ずつソーステーブルに登録
        Dim dr As DataRow
        For Each drI As DataRow In dtbInfo.Rows
            ' 新規レコードを作製
            dr = dtb.NewRow
            ' 連番（DBのKeyで削除時に使用します。画面上は隠し列になっていて表示されません）
            dr.Item("SEQ") = Convert.ToString(drI.Item("SEQ"))
            ' 登録日時
            dr.Item("DATE") = Convert.ToString(drI.Item("CREATE_DATE"))
            ' 登録者名
            dr.Item("NAME") = Convert.ToString(drI.Item("USER_NAME"))
            ' 権限名
            dr.Item("ROLL") = Convert.ToString(drI.Item("CONFIG_VALUE"))
            ' マウスを乗せると詳細が表示されるタグ情報を生成
            Dim stbMsg As New StringBuilder(stbInfo.ToString)
            stbMsg.Replace("%TITLE%", Convert.ToString(drI.Item("TITLE")))
            stbMsg.Replace("%MESSAGE%", Convert.ToString(drI.Item("INFOMATION")))
            '生成したタグ情報を新規レコードに設定
            dr.Item("INFO") = stbMsg.ToString
            ' Newアイコンの設定
            Dim strNew As String = Convert.ToDateTime(drI.Item("CREATE_DATE")).AddHours(dblH).ToString("yyyy/MM/dd HH:mm:ss")
            If strNew > strNow Then
                ' 制限時間内ならアイコン表示
                dr.Item("ICON") = "~/img/New.gif"
            Else
                ' 制限時間を越えたらアイコンなし
                dr.Item("ICON") = DBNull.Value
            End If


            ' 新規レコードをソーステーブルに登録
            dtb.Rows.Add(dr)
        Next

        ' データの登録が完了したソーステーブルをGridViewに登録
        Me.gvInfoList.DataSource = dtb
        Me.gvInfoList.DataBind()

        Return
    End Sub

    ''' <summary>
    ''' ファイル一覧の設定（表示）
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub GetFileList()

        ' DBから登録者名、権限名を取得するための準備
        Dim objDB As New MenuDataAccess
        Dim sjis As Encoding = Encoding.GetEncoding(932)
        Dim dicUser As New Dictionary(Of String, DataRow)

        ' Newアイコンを表示する時間数
        Dim dblH As Integer = Convert.ToDouble(ConfigurationManager.AppSettings(clsConst.CONF_NEW_HOUR))
        ' 現在時刻
        Dim strNow As String = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")

        ' 画面のGridViewに設定するためのソーステーブルを作成
        Dim dtb As New DataTable
        dtb.Columns.Add("DATE", GetType(String))
        dtb.Columns.Add("FILE", GetType(String))
        dtb.Columns.Add("NAME", GetType(String))
        dtb.Columns.Add("ICON", GetType(String))
        dtb.Columns.Add("ROLL", GetType(String))

        ' configからファイルの保存先ルートフォルダのPATHを取得します。
        Dim strUploadRoot As String = ConfigurationManager.AppSettings(clsConst.CONF_UPLOAD_ROOT)
        If Not Directory.Exists(strUploadRoot) Then
            '
            ' ルートフォルダが存在しない場合は一覧を表示しない
            Me.gvFileList.DataSource = dtb
            Me.gvFileList.DataBind()
            Return
        End If

        ' ルートフォルダ下にあるサブフォルダの一覧を取得します。
        Dim strFolders() As String = Directory.GetDirectories(strUploadRoot, "*", SearchOption.TopDirectoryOnly)
        ' サブフォルダ１１つずｔ精査
        For Each strF As String In strFolders
            ' フォルダ名が数字１４桁でない場合は対象外
            Dim strName As String = Path.GetFileName(strF)
            If Not IsNumeric(strName) OrElse strName.Length <> 14 Then
                Continue For
            End If
            ' サブフォルダ名を yyyy/MM/dd HH:mm:ss 形式に編集
            Dim strDate As String = strName.Substring(0, 4) & "/" _
                                    & strName.Substring(4, 2) & "/" _
                                    & strName.Substring(6, 2) & " " _
                                    & strName.Substring(8, 2) & ":" _
                                    & strName.Substring(10, 2) & ":" _
                                    & strName.Substring(12, 2)
            ' サブフォルダ内のファイル一覧を取得
            Dim strFiles() As String = Directory.GetFiles(strF)
            ' サブフォルダ内にあるユーザID保存ファイルからユーザIDを取得してDBからユーザ名を取得
            Dim strUserID As String = String.Empty
            Using sr As New StreamReader(Path.Combine(strF, USER_FILE), sjis)
                strUserID = sr.ReadToEnd
            End Using
            ' 同じユーザIDを複数回検索にいかないようにするために一度検索した
            ' ユーザID情報は辞書に保存して２回目からは辞書から情報を引く
            Dim strUserName As String = String.Empty
            Dim strUserRoll As String = String.Empty
            If dicUser.ContainsKey(strUserID) Then
                '辞書にある
                strUserName = Convert.ToString(dicUser(strUserID).Item("USER_NAME"))
                strUserRoll = Convert.ToString(dicUser(strUserID).Item("CONFIG_VALUE"))
            Else
                ' 辞書にない
                ' ユーザ情報取得
                Dim dt As DataTable = objDB.GetSqlUserInfo(strUserID)
                If Not dt Is Nothing AndAlso dt.Rows.Count > 0 Then
                    strUserName = Convert.ToString(dt.Rows(0).Item("USER_NAME"))
                    strUserRoll = Convert.ToString(dt.Rows(0).Item("CONFIG_VALUE"))
                    ' 辞書に登録
                    dicUser.Add(strUserID, dt.Rows(0))
                End If
            End If
            ' サブフォルダ内のファイルを１つずつ精査
            For Each strUp As String In strFiles
                ' ユーザID保存ファイル（名称固定）の場合は一覧に設定しない
                If Path.GetFileName(strUp).Equals(USER_FILE) Then
                    Continue For
                End If
                ' ソーステーブルの新規レコードを作成
                Dim dr As DataRow = dtb.NewRow
                ' 登録日時
                dr.Item("DATE") = strDate
                ' ファイル名
                dr.Item("FILE") = Path.GetFileName(strUp)
                ' 登録者名
                dr.Item("NAME") = strUserName
                ' 権限
                dr.Item("ROLL") = strUserRoll
                ' Newアイコンの設定
                Dim strNew As String = Convert.ToDateTime(strDate).AddHours(dblH).ToString("yyyy/MM/dd HH:mm:ss")
                If strNew > strNow Then
                    ' 制限時間内ならアイコン表示
                    dr.Item("ICON") = "~/img/New.gif"
                Else
                    ' 制限時間を越えたらアイコンなし
                    dr.Item("ICON") = DBNull.Value
                End If

                ' 設定の終わった新規レコードをソーステーブルに登録
                dtb.Rows.Add(dr)
            Next
        Next

        ' ソーステーブルの中身を登録日時順（新し物から順）にソートする
        Dim dtbRet As DataTable = dtb.Clone
        Dim drwRet() As DataRow = dtb.Select("", "DATE DESC")
        For Each dr As DataRow In drwRet
            dtbRet.ImportRow(dr)
        Next

        ' データの登録が完了したソーステーブルをGridViewに登録
        Me.gvFileList.DataSource = dtbRet
        Me.gvFileList.DataBind()

        Return
    End Sub

#End Region

End Class

