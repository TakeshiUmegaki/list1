﻿Imports System.Data
Imports System.Collections.Generic
Imports DefectManagement.clsUtility
Imports Oracle.DataAccess.Client
Imports DefectManagement.clsConst

Partial Class UserManagement_UserPasswordEdit
    Inherits System.Web.UI.Page

#Region "Event"

#Region "ページロード"
    ''' <summary>
    '''  ページロード
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        ' イベントの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        If Not IsPostBack Then
            '初期化
            SetInit()
        End If

        ' イベントの終了ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

    End Sub
#End Region

#Region "登録ボタン押下処理"
    ''' <summary>
    ''' 登録ボタン押下処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub btnExec_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnExec.ServerClick

        ' イベントの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        '入力チェック処理
        If Not InputCheck() Then
            Return
        End If

        '排他制御
        If Not ViewState("Exclusion") = 1 Then
            '更新実行
            Call UpdExec()
        Else
            ClsNotifyBar.Show(Me, "他のユーザが既に更新を行っています。<BR>再度メニューからやり直して下さい。", ClsNotifyBar.Cls.Error)
        End If

        ' イベントの終了ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

        Me.Session("NotifyBar.Html") = "パスワードを更新しました。"

        ' メニューへ遷移します
        Me.Response.Redirect("~/Pages/Menu/Menu.aspx", True)

    End Sub
#End Region

#End Region

#Region "method"

#Region "初期設定"
    ''' <summary>
    ''' 初期設定
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetInit()

        ' メソッドの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        ' 前画面から渡された値を取得
        Me.hdnMode.Value = 2
        Me.hdnUserId.Value = Page.User.Identity.Name

        'ルート
        Me.hplRoot2.Text = "＞ユーザ管理(パスワード変更)"
        'ユーザID入力不可
        Me.txtUser.Enabled = False
        Me.btnExec.Value = "更新[F1]"
        '更新モードデータ取得
        UpdModeData()

        ' メソッドの終了ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

    End Sub
#End Region

#Region "入力チェック処理"
    ''' <summary>
    ''' 入力チェック処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Function InputCheck() As Boolean

        Dim strError As String = ""

        ' メソッドの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        '*******************************
        '必須チェック
        '*******************************
        'ユーザーID
        If String.IsNullOrEmpty(Me.txtUser.Text) Then
            ClsNotifyBar.Show(Me, "ユーザーIDが未入力です。", ClsNotifyBar.Cls.Error)
            Return False
        End If

        'パスワード
        If String.IsNullOrEmpty(Me.txtPassword.Text) Then
            ClsNotifyBar.Show(Me, "パスワードが未入力です。", ClsNotifyBar.Cls.Error)
            Return False
        End If

        'パスワード（確認）
        If String.IsNullOrEmpty(Me.txtPasswordConfirm.Text) Then
            ClsNotifyBar.Show(Me, "パスワード（確認）が未入力です。", ClsNotifyBar.Cls.Error)
            Return False
        End If


        '*******************************
        '文字種チェック
        '*******************************
        'パスワード
        If Not isAlphanumeric(Me.txtPassword.Text) Then
            ClsNotifyBar.Show(Me, "パスワードは半角英数で入力して下さい。", ClsNotifyBar.Cls.Error)
            Return False
        End If

        'パスワード(英数混在)
        If Not isMixedAlphanumeric(Me.txtPassword.Text) Then
            ClsNotifyBar.Show(Me, "パスワードには英数混在で入力して下さい。", ClsNotifyBar.Cls.Error)
            Return False
        End If

        'パスワード（確認）
        If Not isAlphanumeric(Me.txtPasswordConfirm.Text) Then
            ClsNotifyBar.Show(Me, "パスワード（確認）は半角英数で入力して下さい。", ClsNotifyBar.Cls.Error)
            Return False
        End If

        'パスワード（確認）(英数混在)
        If Not isMixedAlphanumeric(Me.txtPasswordConfirm.Text) Then
            ClsNotifyBar.Show(Me, "パスワード（確認）には英数混在で入力して下さい。", ClsNotifyBar.Cls.Error)
            Return False
        End If

        '*******************************
        '桁数チェック
        '*******************************
        'パスワード
        If Me.txtPassword.Text.Length < 6 Or Me.txtPassword.Text.Length > 20 Then
            ClsNotifyBar.Show(Me, "パスワードは6～20文字以内で入力して下さい。", ClsNotifyBar.Cls.Error)
            Return False
        End If

        'パスワード（確認）
        If Me.txtPasswordConfirm.Text.Length < 6 Or Me.txtPasswordConfirm.Text.Length > 20 Then
            ClsNotifyBar.Show(Me, "パスワード（確認）は6～20文字以内で入力して下さい。", ClsNotifyBar.Cls.Error)
            Return False
        End If


        '*******************************
        '関連チェック
        '*******************************
        'パスワード相違チェック
        If Me.txtPassword.Text <> Me.txtPasswordConfirm.Text Then
            ClsNotifyBar.Show(Me, "パスワードが一致しません。", ClsNotifyBar.Cls.Error)
            Return False
        End If
        ' 前回パスワードとの比較
        Dim strNewPass As String = GetHashedString(Me.txtPassword.Text)
        Dim strOldPass As String = Me.hdnPassword.Value
        If strNewPass.Equals(strOldPass) Then
            ClsNotifyBar.Show(Me, "変更前と同じパスワードは使用できません。", ClsNotifyBar.Cls.Error)
            Return False
        End If

        ' メソッドの終了ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

        Return True

    End Function
#End Region

#Region "更新モードデータ取得"
    ''' <summary>
    ''' 更新モードデータ取得
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub UpdModeData()

        ' メソッドの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        '画面入力情報格納
        Dim dictParam As New Dictionary(Of String, String)
        dictParam.Add("USER_ID", Me.hdnUserId.Value)

        'ユーザー情報取得
        Dim objUserManagementDataAccess As New UserManagementDataAccess
        Dim dt As DataTable = objUserManagementDataAccess.GetSqlMCmUser(dictParam)

        '画面へデータをセット
        For Each row As DataRow In dt.Rows

            Me.txtUser.Text = row.Item("USER_ID").ToString
            Me.hdnPassword.Value = row.Item("PASSWORD").ToString

        Next

        ' メソッドの終了ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

    End Sub
#End Region

#Region "更新処理"
    ''' <summary>
    ''' 更新処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub UpdExec()

        Dim dictParam As New Dictionary(Of String, String)

        ' メソッドの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        'ユーザー情報取得
        Dim objUserManagementDataAccess As New UserManagementDataAccess

        'パスワードの有効日数から有効期限を取得
        Dim dblLimit As Double = Convert.ToDouble(System.Configuration.ConfigurationManager.AppSettings(clsConst.CONF_PASSWORD_LIMIT))
        Dim datLimit As DateTime = DateTime.Now.AddDays(dblLimit)
        Dim strLimit As String = datLimit.ToString("yyyyMMdd")

        '画面入力情報格納
        dictParam.Add("USER_ID", Me.txtUser.Text)
        dictParam.Add("PASSWORD", GetHashedString(Me.txtPassword.Text))
        dictParam.Add("UPDATE_USER", Me.User.Identity.Name)
        dictParam.Add("LIMIT", strLimit)

        '登録実行
        Dim intResult As Integer = objUserManagementDataAccess.UpdSqlMCmUserPassword(dictParam)

        If intResult <> 1 Then
            If intResult = -1 Then
                ClsNotifyBar.Show(Me, "他のユーザが既に更新を行っています。<BR>しばらくしてから再度処理を行って下さい。", ClsNotifyBar.Cls.Error)

                ViewState("Exclusion") = 1

            Else
                ClsNotifyBar.Show(Me, "更新処理に失敗しました。", ClsNotifyBar.Cls.Error)
            End If
            Return
        End If

        ClsNotifyBar.Show(Me, "更新処理が完了しました。", ClsNotifyBar.Cls.Success)
        DirectCast(Me.Master, MasterPage).SetMenuControl()

        ' メソッドの終了ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

    End Sub
#End Region

#End Region

End Class
