﻿Imports System.Data
Imports System.Collections.Generic
Imports DefectManagement.clsUtility
Imports Oracle.DataAccess.Client
Imports DefectManagement.clsConst

Partial Class UserManagement_UserManagementEdit
    Inherits System.Web.UI.Page

#Region "Event"

#Region "ページロード"
    ''' <summary>
    '''  ページロード
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        ' イベントの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        If Not IsPostBack Then
            '初期化
            SetInit()
        End If

        ' イベントの終了ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

    End Sub
#End Region

#Region "登録ボタン押下処理"
    ''' <summary>
    ''' 登録ボタン押下処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub btnExec_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnExec.ServerClick

        ' イベントの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        '入力チェック処理
        If Not InputCheck() Then
            Return
        End If

        If Me.hdnMode.Value = 1 Then
            '登録実行
            Call InsExec()
        Else
            '排他制御
            If Not ViewState("Exclusion") = 1 Then
                '更新実行
                Call UpdExec()
            Else
                ClsNotifyBar.Show(Me, "他のユーザが既に更新を行っています。<BR>再度メニューからやり直して下さい。", ClsNotifyBar.Cls.Error)
            End If
        End If

        ' イベントの終了ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

    End Sub
#End Region

#End Region

#Region "method"

#Region "初期設定"
    ''' <summary>
    ''' 初期設定
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetInit()

        ' メソッドの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        ' 前画面から渡された値を取得
        Me.hdnMode.Value = Page.Request.QueryString("mode")
        Me.hdnUserId.Value = Page.Request.QueryString("UserId")

        '権限ドロップダウンリスト設定
        Dim objUserManagementDataAccess As New UserManagementDataAccess
        Dim dt As DataTable = objUserManagementDataAccess.GetSqlAnthDdl()
        SetDropDownList(Me.ddlUserRole, dt, False)

        '更新モードの場合
        If Me.hdnMode.Value = 2 Then
            'ルート
            Me.hplRoot2.Text = "＞ユーザ管理(修正)"
            'ユーザID入力不可
            Me.txtUser.Enabled = False
            Me.btnExec.Value = "更新[F1]"
            Me.lblPassMod.Visible = True
            '更新モードデータ取得
            UpdModeData()
        Else
            Me.txtUser.Focus()
        End If

        ' メソッドの終了ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

    End Sub
#End Region

#Region "入力チェック処理"
    ''' <summary>
    ''' 入力チェック処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Function InputCheck() As Boolean

        Dim strError As String = ""

        ' メソッドの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        '*******************************
        '必須チェック
        '*******************************
        'ユーザーID
        If String.IsNullOrEmpty(Me.txtUser.Text) Then
            ClsNotifyBar.Show(Me, "ユーザーIDが未入力です。", ClsNotifyBar.Cls.Error)
            Me.txtUser.Focus()
            Return False
        End If

        '登録モードの場合
        If Me.hdnMode.Value = 1 Then

            'パスワード
            If String.IsNullOrEmpty(Me.txtPassword.Text) Then
                ClsNotifyBar.Show(Me, "パスワードが未入力です。", ClsNotifyBar.Cls.Error)
                Me.txtPassword.Focus()
                Return False
            End If

            'パスワード（確認）
            If String.IsNullOrEmpty(Me.txtPasswordConfirm.Text) Then
                ClsNotifyBar.Show(Me, "パスワード（確認）が未入力です。", ClsNotifyBar.Cls.Error)
                Me.txtPasswordConfirm.Focus()
                Return False
            End If

        End If

        'ユーザー名（漢字）
        If String.IsNullOrEmpty(Me.txtUserName.Text) Then
            ClsNotifyBar.Show(Me, "ユーザー名（漢字）が未入力です。", ClsNotifyBar.Cls.Error)
            Me.txtUserName.Focus()
            Return False
        End If

        'ユーザー名（カナ）
        If String.IsNullOrEmpty(Me.txtUserNameKana.Text) Then
            ClsNotifyBar.Show(Me, "ユーザー名（カナ）が未入力です。", ClsNotifyBar.Cls.Error)
            Me.txtUserNameKana.Focus()
            Return False
        End If

        '*******************************
        '文字種チェック
        '*******************************
        'ユーザーID(半角英数)
        If Not isAlphanumeric(Me.txtUser.Text) Then
            ClsNotifyBar.Show(Me, "ユーザーIDは半角英数で入力して下さい。", ClsNotifyBar.Cls.Error)
            Return False
        End If

        'ユーザーID(先頭が半角英字)
        If Not isHContainletters(Me.txtUser.Text) Then
            ClsNotifyBar.Show(Me, "ユーザーIDは先頭が半角英字にして下さい。", ClsNotifyBar.Cls.Error)
            Return False
        End If

        '登録モードもしくは、更新モードで入力がある場合
        If Me.hdnMode.Value = 1 Or (Me.hdnMode.Value = 2 And Not String.IsNullOrEmpty(Me.txtPassword.Text)) Then
            'パスワード(半角英数)
            If Not isAlphanumeric(Me.txtPassword.Text) Then
                ClsNotifyBar.Show(Me, "パスワードは半角英数で入力して下さい。", ClsNotifyBar.Cls.Error)
                Return False
            End If

            'パスワード(英数混在)
            If Not isMixedAlphanumeric(Me.txtPassword.Text) Then
                ClsNotifyBar.Show(Me, "パスワードには英数混在で入力して下さい。", ClsNotifyBar.Cls.Error)
                Return False
            End If
        End If

        '登録モードもしくは、更新モードで入力がある場合
        If Me.hdnMode.Value = 1 Or (Me.hdnMode.Value = 2 And Not String.IsNullOrEmpty(Me.txtPasswordConfirm.Text)) Then
            'パスワード（確認）(半角英数)
            If Not isAlphanumeric(Me.txtPasswordConfirm.Text) Then
                ClsNotifyBar.Show(Me, "パスワード（確認）は半角英数で入力して下さい。", ClsNotifyBar.Cls.Error)
                Return False
            End If

            'パスワード（確認）(英数混在)
            If Not isMixedAlphanumeric(Me.txtPasswordConfirm.Text) Then
                ClsNotifyBar.Show(Me, "パスワード（確認）には英数混在で入力して下さい。", ClsNotifyBar.Cls.Error)
                Return False
            End If
        End If

        'ユーザー名（漢字）
        If Not isZenkaku(Me.txtUserName.Text) Then
            ClsNotifyBar.Show(Me, "ユーザー名（漢字）は全角で入力して下さい。", ClsNotifyBar.Cls.Error)
            Return False
        End If

        'ユーザー名（カナ）
        If Not isZenkaku(Me.txtUserNameKana.Text) Then
            ClsNotifyBar.Show(Me, "ユーザー名（カナ）は全角で入力して下さい。", ClsNotifyBar.Cls.Error)
            Return False
        End If

        '*******************************
        '桁数チェック
        '*******************************
        'ユーザーID
        If Me.txtUser.Text.Length < 6 Or Me.txtUser.Text.Length > 20 Then
            ClsNotifyBar.Show(Me, "ユーザーIDは6～20文字以内で入力して下さい。", ClsNotifyBar.Cls.Error)
            Return False
        End If

        '登録モードもしくは、更新モードで入力がある場合
        If Me.hdnMode.Value = 1 Or (Me.hdnMode.Value = 2 And Not String.IsNullOrEmpty(Me.txtPassword.Text)) Then
            'パスワード
            If Me.txtPassword.Text.Length < 6 Or Me.txtPassword.Text.Length > 20 Then
                ClsNotifyBar.Show(Me, "パスワードは6～20文字以内で入力して下さい。", ClsNotifyBar.Cls.Error)
                Return False
            End If
        End If

        '登録モードもしくは、更新モードで入力がある場合
        If Me.hdnMode.Value = 1 Or (Me.hdnMode.Value = 2 And Not String.IsNullOrEmpty(Me.txtPasswordConfirm.Text)) Then
            'パスワード（確認）
            If Me.txtPasswordConfirm.Text.Length < 6 Or Me.txtPasswordConfirm.Text.Length > 20 Then
                ClsNotifyBar.Show(Me, "パスワード（確認）は6～20文字以内で入力して下さい。", ClsNotifyBar.Cls.Error)
                Return False
            End If
        End If

        'ユーザー名（漢字）
        If Me.txtUserName.Text.Length > 30 Then
            ClsNotifyBar.Show(Me, "ユーザー名（漢字）は30文字以内で入力して下さい。", ClsNotifyBar.Cls.Error)
            Return False
        End If

        'ユーザー名（カナ）
        If Me.txtUserNameKana.Text.Length > 30 Then
            ClsNotifyBar.Show(Me, "ユーザー名（カナ）は30文字以内で入力して下さい。", ClsNotifyBar.Cls.Error)
            Return False
        End If

        '*******************************
        '関連チェック
        '*******************************
        'パスワード相違チェック
        If Me.txtPassword.Text <> Me.txtPasswordConfirm.Text Then
            ClsNotifyBar.Show(Me, "パスワードが一致しません。", ClsNotifyBar.Cls.Error)
            Return False
        End If

        ' メソッドの終了ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

        Return True

    End Function
#End Region

#Region "更新モードデータ取得"
    ''' <summary>
    ''' 更新モードデータ取得
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub UpdModeData()

        ' メソッドの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        '画面入力情報格納
        Dim dictParam As New Dictionary(Of String, String)
        dictParam.Add("USER_ID", Me.hdnUserId.Value)

        'ユーザー情報取得
        Dim objUserManagementDataAccess As New UserManagementDataAccess
        Dim dt As DataTable = objUserManagementDataAccess.GetSqlMCmUser(dictParam)

        '画面へデータをセット
        For Each row As DataRow In dt.Rows

            Me.txtUser.Text = row.Item("USER_ID").ToString
            Me.hdnPassword.Value = row.Item("PASSWORD").ToString
            Me.txtUserName.Text = row.Item("USER_NAME").ToString
            Me.txtUserNameKana.Text = row.Item("USER_NAME_KANA").ToString
            Me.ddlUserRole.SelectedValue = row.Item("ROLL_CD").ToString
            Me.hdnPassLimit.Value = row.Item("PASSWORD_LIMIT_DATE").ToString

        Next

        ' メソッドの終了ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

    End Sub
#End Region

#Region "登録処理"
    ''' <summary>
    ''' 登録処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub InsExec()

        Dim dictParam As New Dictionary(Of String, String)

        ' メソッドの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        'ユーザー情報取得
        Dim objUserManagementDataAccess As New UserManagementDataAccess

        '画面入力情報格納
        dictParam.Add("USER_ID", Me.txtUser.Text)

        Dim dt As DataTable = objUserManagementDataAccess.GetSqlMCmUser(dictParam)

        If dt.Rows.Count <> 0 Then
            ClsNotifyBar.Show(Me, "そのユーザーIDは既に存在します。", ClsNotifyBar.Cls.Error)
            Return
        End If

        '画面入力情報格納
        dictParam.Add("USER_NAME", Me.txtUserName.Text)
        dictParam.Add("USER_NAME_KANA", Me.txtUserNameKana.Text)
        dictParam.Add("ROLL_CD", Me.ddlUserRole.SelectedValue)
        dictParam.Add("PASSWORD", GetHashedString(Me.txtPassword.Text))
        dictParam.Add("CREATE_USER", Me.User.Identity.Name)
        dictParam.Add("UPDATE_USER", Me.User.Identity.Name)

        '登録実行
        Dim intResult As Integer = objUserManagementDataAccess.InsSqlMCmUser(dictParam)

        If intResult <> 1 Then
            ClsNotifyBar.Show(Me, "登録処理に失敗しました。", ClsNotifyBar.Cls.Error)
        End If

        'ユーザーIDと名前の初期化
        Me.txtUser.Text = String.Empty
        Me.txtUserName.Text = String.Empty
        Me.txtUserNameKana.Text = String.Empty

        Me.txtUser.Focus()

        ClsNotifyBar.Show(Me, "登録処理が完了しました。", ClsNotifyBar.Cls.Success)

        ' メソッドの終了ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

    End Sub
#End Region

#Region "更新処理"
    ''' <summary>
    ''' 更新処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub UpdExec()

        Dim dictParam As New Dictionary(Of String, String)

        ' メソッドの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        'ユーザー情報取得
        Dim objUserManagementDataAccess As New UserManagementDataAccess

        '画面入力情報格納
        dictParam.Add("USER_ID", Me.txtUser.Text)
        dictParam.Add("USER_NAME", Me.txtUserName.Text)
        dictParam.Add("USER_NAME_KANA", Me.txtUserNameKana.Text)
        dictParam.Add("ROLL_CD", Me.ddlUserRole.SelectedValue)

        'パスワードがブランクの場合、退避していたパスワードをセット
        If String.IsNullOrEmpty(Me.txtPassword.Text) Then
            dictParam.Add("PASSWORD", Me.hdnPassword.Value)
            dictParam.Add("LIMIT", Me.hdnPassLimit.Value)
        Else
            dictParam.Add("PASSWORD", GetHashedString(Me.txtPassword.Text))
            'パスワードの有効日数から有効期限を取得
            Dim datLimit As DateTime = DateTime.Now.AddDays(-1)
            Dim strLimit As String = datLimit.ToString("yyyyMMdd")
            dictParam.Add("LIMIT", strLimit)
        End If

        dictParam.Add("UPDATE_USER", Me.User.Identity.Name)

        '登録実行
        Dim intResult As Integer = objUserManagementDataAccess.UpdSqlMCmUser(dictParam)

        If intResult <> 1 Then
            If intResult = -1 Then
                ClsNotifyBar.Show(Me, "他のユーザが既に更新を行っています。<BR>しばらくしてから再度処理を行って下さい。", ClsNotifyBar.Cls.Error)

                ViewState("Exclusion") = 1

            Else
                ClsNotifyBar.Show(Me, "更新処理に失敗しました。", ClsNotifyBar.Cls.Error)
            End If
            Return
        End If

        ClsNotifyBar.Show(Me, "更新処理が完了しました。", ClsNotifyBar.Cls.Success)

        ' メソッドの終了ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

    End Sub
#End Region

#End Region

End Class
