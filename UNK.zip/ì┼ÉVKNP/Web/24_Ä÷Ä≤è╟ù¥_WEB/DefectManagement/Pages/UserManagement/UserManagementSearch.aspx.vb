﻿Imports System.Data
Imports System.Collections.Generic
Imports DefectManagement.clsUtility
Imports Oracle.DataAccess.Client
Imports DefectManagement.clsConst

Partial Class UserManagement_UserManagementSearch
    Inherits System.Web.UI.Page

#Region "Enum"

    Private Enum enumGridColNo
        ChkDel = 0
        UserId = 1
        UserName = 2
        UserNameKana = 3
        RollCd = 4
        UpdateUser = 5
    End Enum

#End Region

#Region "Event"

#Region "ページロード"
    ''' <summary>
    '''  ページロード
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        ' イベントの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        If Not IsPostBack Then
            '初期化
            SetInit()
        End If

        ' イベントの終了ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

    End Sub
#End Region

#Region "検索ボタン押下処理"
    ''' <summary>
    ''' 検索ボタン押下処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSearch.ServerClick

        ' イベントの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        '検索処理
        Call SearchExec()

        ' イベントの終了ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

    End Sub
#End Region

#Region "削除ボタン押下"
    ''' <summary>
    ''' 削除ボタン押下
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub btnDel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnDel.ServerClick

        ' イベントの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        '入力チェック処理
        If Not InputCheck() Then
            Return
        End If

        ' 削除処理
        DelExec()

        ' イベントの終了ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

    End Sub
#End Region

#Region "ボタン機能"
    ''' <summary>
    ''' ボタン機能
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub grdSearchList_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles grdSearchList.RowCommand

        ' イベントの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        ' コマンド名が“MoveRef”の場合にのみ処理
        If e.CommandName = "MoveRef" Then

            ' 主キー（ユーザCD列）の値を取得
            Dim strUsertId As String = Me.grdSearchList.DataKeys(e.CommandArgument).Value()

            ' isbn列の値を基にURLを生成し、リダイレクト
            Response.Redirect(String.Format("~/Pages/UserManagement/UserManagementEdit.aspx?mode={0}&UserId={1}", 2, strUsertId))

        End If

    End Sub
#End Region

#End Region

#Region "method"

#Region "初期設定"
    ''' <summary>
    ''' 初期設定
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetInit()

        ' メソッドの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        '権限ドロップダウンリスト設定
        Dim objUserManagementDataAccess As New UserManagementDataAccess
        Dim dt As DataTable = objUserManagementDataAccess.GetSqlAnthDdl()
        SetDropDownList(Me.ddlUserRole, dt, True, "全て")

        '件数初期化
        Me.lblSearchCount.Text = 0

        ' メソッドの終了ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

    End Sub
#End Region

#Region "入力チェック処理"
    ''' <summary>
    ''' 入力チェック処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Function InputCheck() As Boolean

        Dim DelFlg As Boolean = False

        ' メソッドの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        For Each row As GridViewRow In Me.grdSearchList.Rows
            Dim cb As CheckBox = CType(row.FindControl("chkDel"), CheckBox)
            'チェックがついている場合
            If cb.Checked Then
                DelFlg = True
            End If
        Next

        If Me.grdSearchList.Rows.Count = 0 OrElse Not DelFlg Then
            ClsNotifyBar.Show(Me, "削除対象のデータが存在しません。", ClsNotifyBar.Cls.Error)
            Return False
        End If

        ' メソッドの終了ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

        Return True

    End Function
#End Region

#Region "検索実行処理"
    ''' <summary>
    ''' 検索実行処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SearchExec()

        Dim dictParam As New Dictionary(Of String, String)

        ' メソッドの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        '画面入力情報格納
        If Not String.IsNullOrEmpty(Me.txtUser.Text) Then
            'ユーザID
            dictParam.Add("USER_ID", Me.txtUser.Text)
        End If

        If Not String.IsNullOrEmpty(Me.txtUserName.Text) Then
            'ユーザ名（漢字）
            dictParam.Add("USER_NAME", Me.txtUserName.Text)
        End If

        If Not String.IsNullOrEmpty(Me.txtUserNameKana.Text) Then
            'ユーザ名（カナ）
            dictParam.Add("USER_NAME_KANA", Me.txtUserNameKana.Text)
        End If

        If Me.ddlUserRole.SelectedValue <> "全て" Then
            'ユーザ権限
            dictParam.Add("ROLL_CD", Me.ddlUserRole.SelectedValue)
        End If

        'ユーザー情報取得
        Dim objUserManagementDataAccess As New UserManagementDataAccess
        Dim dt As DataTable = objUserManagementDataAccess.GetSqlMCmUser(dictParam)

        '画面表示
        Me.grdSearchList.DataSource = dt
        Me.grdSearchList.DataBind()

        '検索件数表示
        Me.lblSearchCount.Text = Me.grdSearchList.Rows.Count

        ' メソッドの終了ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

    End Sub
#End Region

#Region "削除実行処理"
    ''' <summary>
    ''' 削除実行処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub DelExec()

        ' メソッドの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        For Each row As GridViewRow In Me.grdSearchList.Rows

            Dim cb As CheckBox = CType(row.FindControl("chkDel"), CheckBox)

            'チェックがついている場合
            If cb.Checked Then

                '削除処理
                Dim objUserManagementDataAccess As New UserManagementDataAccess
                Dim dictParam As New Dictionary(Of String, String)
                dictParam.Add("USER_ID", Me.grdSearchList.DataKeys(row.RowIndex).Value())
                Dim intResult As Integer = objUserManagementDataAccess.DelSqlMCmUser(dictParam)

            End If

        Next

        '検索処理（再描画）
        Call SearchExec()

        ClsNotifyBar.Show(Me, "削除処理が完了しました。", ClsNotifyBar.Cls.Success)

        ' メソッドの終了ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

    End Sub
#End Region

#End Region

End Class
