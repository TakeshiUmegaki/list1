﻿Imports System
Imports System.Data
Imports System.Collections.Generic
Imports System.Diagnostics
Imports System.IO
Imports System.Text
Imports System.Configuration
Imports CommonSystem
Imports DefectManagement.clsConst
Imports System.Configuration.ConfigurationManager

Partial Class MasterPage
    Inherits System.Web.UI.MasterPage

#Region " 列挙体 "
    ''' <summary>
    ''' メニュー行番号
    ''' </summary>
    ''' <remarks></remarks>
    Private Enum enumMenu
        ViewSpc = 0        ' 空行
        ViewTop = 1        ' ▼業務照会
        ViewBiz = 2        '   ＞業務照会
        ViewDat = 3        '   ＞データ照会
        DefSpc = 4         ' 空行
        DefTop = 5         ' ▼データ修正
        DefCor = 6         '   ＞データ修正
        ExpeSpc = 7        ' 空行
        ExpeTop = 8        ' ▼実績照会
        ExpeRec = 9        ' 　＞受付
        ExpeRecPro = 10    ' 　　＞受付案件数
        ExpeRecImg = 11    ' 　　＞受付イメージ件数
        ExpeRecDat = 12    ' 　　＞受付時間別受付データ数
        ExpeDel = 13       ' 　＞納品
        ExpeDelPro = 14    ' 　　＞納品案件数
        ExpeDelImg = 15    ' 　　＞納品イメージ件数
        ExpeDelDat = 16    ' 　　＞納品時間別納品データ数
        ExpeDelEnd = 17    ' 　　＞納品時間別納品完了時間
        ExpeDelInq = 18    '  　 ＞納品実績照会
        ExpeDelTim = 19    '  　 ＞納品時間状況照会
        KanrSpc = 20       ' 空行
        KanrTop = 21       ' ▼管理系
        KanrUsr = 22       '   ＞ユーザー管理
        KanrUsrNew = 23    '     ＞新規登録
        KanrUsrEdt = 24    '     ＞修正／削除
        KanrUsrPas = 25    '     ＞パスワード変更
        MentSpc = 26       ' 空行
        MentTop = 27       ' ▼システムメンテナンス
        MentUpd = 28       '   ＞SQL実行（更新）
        MentSel = 29       '   ＞SQL実行（検索）
    End Enum
#End Region

#Region "Event"

#Region "ページ初期化"

    ''' <summary>
    ''' ページ初期化
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        '不正アクセス防止（URL直接入力時（リファラなし時）、外部ホストからの遷移はログインに戻す）
        If (Me.Request.UrlReferrer Is Nothing) OrElse (Not Me.Request.Url.Authority.Equals(Me.Request.UrlReferrer.Authority)) Then
            Me.Session("NotifyBar.Html") = "不正なアクセスと判断されました。再度、ログインしてください。"
            clsUtility.WriteLog(String.Format("{0}.{1} 不正アクセス Request.Url:{2} .UrlReferrer:{3}", New Object() { _
                                               Me.GetType().BaseType.FullName, _
                                               System.Reflection.MethodBase.GetCurrentMethod().Name, _
                                               Me.Request.Url, _
                                               Me.Request.UrlReferrer}), _
            EventLogEntryType.Error)
            Me.Response.Redirect("/Pages/Login/Login.aspx")
        End If
    End Sub

#End Region

#Region "ページロード"

    ''' <summary>
    ''' ページロード
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        ' イベントの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        If Not IsPostBack Then
            '初期化
            SetInit()

        End If

        ' イベントの終了ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

    End Sub

#End Region

#Region "ログアウトボタン押下"
    ''' <summary>
    ''' ログアウトボタン押下
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub btnLogout_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnLogout.Click

        ' イベントの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        Me.btnLogout.Enabled = False

        ' 更新日時更新処理
        Dim objLoginDataAccess As New LoginDataAccess
        Dim dictParam As New Dictionary(Of String, String)
        dictParam.Add("USER_ID", Page.User.Identity.Name)
        Dim intResult As Integer = objLoginDataAccess.UpdSqlMCmUserUpdateDate(dictParam)

        ' セッションクリア
        Session.Clear()

        ' 認証情報クリア 
        FormsAuthentication.SignOut()
        Response.Redirect("~/Pages/Login/Login.aspx")

        ' イベントの終了ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

    End Sub
#End Region

#Region "ページ描画前"

    ''' <summary>
    ''' ページ描画前
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.PreRender

        Dim sb As New StringBuilder()
        sb.AppendFormat("zoom_default = {0};", ConfigurationManager.AppSettings("ZOOM_DEFAULT"))
        sb.AppendFormat("zoom_max = {0};", ConfigurationManager.AppSettings("ZOOM_MAX"))
        sb.AppendFormat("zoom_min = {0};", ConfigurationManager.AppSettings("ZOOM_MIN"))
        sb.AppendFormat("crnt_zoom = {0};", ConfigurationManager.AppSettings("ZOOM_DEFAULT"))

        Me.Page.ClientScript.RegisterClientScriptBlock(Me.Page.GetType(), "tciIECS.js zoom settings", sb.ToString(), True)

    End Sub

#End Region


#End Region

#Region "Method"

#Region "初期設定"

    ''' <summary>
    ''' 初期設定
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetInit()

        ' メソッドの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        ' ユーザ名を表示
        Dim objCommonDataAccess As New CommonDataAccess
        Me.lblLoginUser.Text = objCommonDataAccess.GetSqlUserNm(Page.User.Identity.Name)

        Me.lblVersion.Text = "FlowScope Ver." & System.Configuration.ConfigurationManager.AppSettings("SYS_VERSION")

        ' メニュー制御処理
        Call SetMenuControl()

        ' メソッドの終了ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

    End Sub
#End Region

#Region "メニュ制御処理"

    ''' <summary>
    ''' メニュ制御処理
    ''' </summary>
    ''' <remarks></remarks>
    Friend Sub SetMenuControl()

        ' メソッドの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        ' 権限情報取得
        Dim objCommonDataAccess As New CommonDataAccess
        Dim strRollCd As String = objCommonDataAccess.GetSqlAnth(Page.User.Identity.Name)
        ' パスワード有効期日取得
        Dim strLimit As String = objCommonDataAccess.GetSqlPassLimit(Page.User.Identity.Name)
        ' パスワード変更警告開始期日を当日に加算する
        Dim dblAlart As Double = Convert.ToDouble(System.Configuration.ConfigurationManager.AppSettings(clsConst.CONF_ALERT_LIMIT))
        Dim strAlert As String = DateTime.Now.AddDays(dblAlart).ToString("yyyyMMdd")
        ' 当日の日付を取得
        Dim strNow As String = DateTime.Now.ToString("yyyyMMdd")
        If strNow > strLimit Then
            strRollCd = clsConst.CHANGE_PAS
        End If

        ' 初期値は全表示
        TableMenu.Rows(enumMenu.ViewSpc).Visible = True       ' 空行
        TableMenu.Rows(enumMenu.ViewTop).Visible = True       ' ▼業務照会
        TableMenu.Rows(enumMenu.ViewBiz).Visible = True       '   ＞業務照会
        TableMenu.Rows(enumMenu.ViewDat).Visible = True       '   ＞データ照会
        TableMenu.Rows(enumMenu.DefSpc).Visible = True        ' 空行
        TableMenu.Rows(enumMenu.DefTop).Visible = True        ' ▼データ修正
        TableMenu.Rows(enumMenu.DefCor).Visible = True        '   ＞データ修正
        TableMenu.Rows(enumMenu.ExpeSpc).Visible = True       ' 空行
        TableMenu.Rows(enumMenu.ExpeTop).Visible = True       ' ▼実績照会
        TableMenu.Rows(enumMenu.ExpeRec).Visible = True       ' 　＞受付
        TableMenu.Rows(enumMenu.ExpeRecPro).Visible = True    ' 　　＞受付案件数
        TableMenu.Rows(enumMenu.ExpeRecImg).Visible = True    ' 　　＞受付イメージ件数
        TableMenu.Rows(enumMenu.ExpeRecDat).Visible = True    ' 　　＞受付時間別受付データ数
        TableMenu.Rows(enumMenu.ExpeDel).Visible = True       ' 　＞納品
        TableMenu.Rows(enumMenu.ExpeDelPro).Visible = True    ' 　　＞納品案件数
        TableMenu.Rows(enumMenu.ExpeDelImg).Visible = True    ' 　　＞納品イメージ件数
        TableMenu.Rows(enumMenu.ExpeDelDat).Visible = True    ' 　　＞納品時間別納品データ数
        TableMenu.Rows(enumMenu.ExpeDelEnd).Visible = True    ' 　　＞納品時間別納品完了時間
        TableMenu.Rows(enumMenu.ExpeDelInq).Visible = True    ' 　　＞納品実績照会
        TableMenu.Rows(enumMenu.ExpeDelTim).Visible = True    ' 　　＞納品時間状況照会
        TableMenu.Rows(enumMenu.KanrSpc).Visible = True       ' 空行
        TableMenu.Rows(enumMenu.KanrTop).Visible = True       ' ▼管理系
        TableMenu.Rows(enumMenu.KanrUsr).Visible = True       '   ＞ユーザー管理
        TableMenu.Rows(enumMenu.KanrUsrNew).Visible = True    '     ＞新規登録
        TableMenu.Rows(enumMenu.KanrUsrEdt).Visible = True    '     ＞修正／削除
        TableMenu.Rows(enumMenu.KanrUsrPas).Visible = True    '     ＞パスワード変更
        TableMenu.Rows(enumMenu.MentSpc).Visible = True       ' 空行
        TableMenu.Rows(enumMenu.MentTop).Visible = True       ' ▼システムメンテナンス
        TableMenu.Rows(enumMenu.MentUpd).Visible = True       '   ＞SQL実行（更新）
        TableMenu.Rows(enumMenu.MentSel).Visible = True       '   ＞SQL実行（検索）

        ' **********************************************************
        ' 外部定義によって無効とされているメニューを非表示にします。
        ' **********************************************************
        If AppSettings("MENU_VIEW_01").Equals("0") AndAlso AppSettings("MENU_VIEW_02").Equals("0") Then
            TableMenu.Rows(enumMenu.ViewSpc).Visible = False       ' 空行
            TableMenu.Rows(enumMenu.ViewTop).Visible = False       ' ▼業務照会
        End If
        If AppSettings("MENU_VIEW_01").Equals("0") Then
            TableMenu.Rows(enumMenu.ViewBiz).Visible = False       '   ＞業務照会
        End If
        If AppSettings("MENU_VIEW_02").Equals("0") Then
            TableMenu.Rows(enumMenu.ViewDat).Visible = False       '   ＞データ照会
        End If
        If AppSettings("MENU_VIEW_16").Equals("0") Then
            TableMenu.Rows(enumMenu.DefSpc).Visible = False       ' 空行
            TableMenu.Rows(enumMenu.DefTop).Visible = False       ' ▼データ修正
            TableMenu.Rows(enumMenu.DefCor).Visible = False       ' 　＞データ修正
        End If
        If AppSettings("MENU_VIEW_03").Equals("0") AndAlso _
           AppSettings("MENU_VIEW_04").Equals("0") AndAlso _
           AppSettings("MENU_VIEW_05").Equals("0") AndAlso _
           AppSettings("MENU_VIEW_06").Equals("0") AndAlso _
           AppSettings("MENU_VIEW_07").Equals("0") AndAlso _
           AppSettings("MENU_VIEW_08").Equals("0") AndAlso _
           AppSettings("MENU_VIEW_09").Equals("0") AndAlso _
           AppSettings("MENU_VIEW_10").Equals("0") Then
            TableMenu.Rows(enumMenu.ExpeSpc).Visible = False       ' 空行
            TableMenu.Rows(enumMenu.ExpeTop).Visible = False       ' ▼実績照会
        End If
        If AppSettings("MENU_VIEW_03").Equals("0") AndAlso _
           AppSettings("MENU_VIEW_04").Equals("0") AndAlso _
           AppSettings("MENU_VIEW_05").Equals("0") Then
            TableMenu.Rows(enumMenu.ExpeRec).Visible = False       ' 　＞受付
        End If
        If AppSettings("MENU_VIEW_06").Equals("0") AndAlso _
           AppSettings("MENU_VIEW_07").Equals("0") AndAlso _
           AppSettings("MENU_VIEW_08").Equals("0") AndAlso _
           AppSettings("MENU_VIEW_09").Equals("0") AndAlso _
           AppSettings("MENU_VIEW_10").Equals("0") AndAlso _
           AppSettings("MENU_VIEW_17").Equals("0") Then
            TableMenu.Rows(enumMenu.ExpeDel).Visible = False        ' 　＞納品
        End If

        If AppSettings("MENU_VIEW_03").Equals("0") Then
            TableMenu.Rows(enumMenu.ExpeRecPro).Visible = False    ' 　　＞受付案件数
        End If
        If AppSettings("MENU_VIEW_04").Equals("0") Then
            TableMenu.Rows(enumMenu.ExpeRecImg).Visible = False    ' 　　＞受付イメージ件数
        End If
        If AppSettings("MENU_VIEW_05").Equals("0") Then
            TableMenu.Rows(enumMenu.ExpeRecDat).Visible = False    ' 　　＞受付時間別受付データ数
        End If
        If AppSettings("MENU_VIEW_06").Equals("0") Then
            TableMenu.Rows(enumMenu.ExpeDelPro).Visible = False    ' 　　＞納品案件数
        End If
        If AppSettings("MENU_VIEW_07").Equals("0") Then
            TableMenu.Rows(enumMenu.ExpeDelImg).Visible = False    ' 　　＞納品イメージ件数
        End If
        If AppSettings("MENU_VIEW_08").Equals("0") Then
            TableMenu.Rows(enumMenu.ExpeDelDat).Visible = False    ' 　　＞納品時間別納品データ数
        End If
        If AppSettings("MENU_VIEW_09").Equals("0") Then
            TableMenu.Rows(enumMenu.ExpeDelEnd).Visible = False    ' 　　＞納品時間別納品完了時間
        End If
        If AppSettings("MENU_VIEW_10").Equals("0") Then
            TableMenu.Rows(enumMenu.ExpeDelInq).Visible = False    ' 　　＞納品実績照会
        End If
        If AppSettings("MENU_VIEW_17").Equals("0") Then
            TableMenu.Rows(enumMenu.ExpeDelTim).Visible = False    ' 　　＞納品時間状況照会
        End If

        If AppSettings("MENU_VIEW_11").Equals("0") AndAlso _
           AppSettings("MENU_VIEW_12").Equals("0") AndAlso _
           AppSettings("MENU_VIEW_13").Equals("0") Then
            TableMenu.Rows(enumMenu.KanrSpc).Visible = False       ' 空行
            TableMenu.Rows(enumMenu.KanrTop).Visible = False       ' ▼管理系
            TableMenu.Rows(enumMenu.KanrUsr).Visible = False       '   ＞ユーザー管理
        End If
        If AppSettings("MENU_VIEW_11").Equals("0") Then
            TableMenu.Rows(enumMenu.KanrUsrNew).Visible = False    '     ＞新規登録
        End If
        If AppSettings("MENU_VIEW_12").Equals("0") Then
            TableMenu.Rows(enumMenu.KanrUsrEdt).Visible = False    '     ＞修正／削除
        End If
        If AppSettings("MENU_VIEW_13").Equals("0") Then
            TableMenu.Rows(enumMenu.KanrUsrPas).Visible = False    '     ＞パスワード変更
        End If
        If AppSettings("MENU_VIEW_14").Equals("0") AndAlso AppSettings("MENU_VIEW_15").Equals("0") Then
            TableMenu.Rows(enumMenu.MentSpc).Visible = False       ' 空行
            TableMenu.Rows(enumMenu.MentTop).Visible = False       ' ▼システムメンテナンス
        End If
        If AppSettings("MENU_VIEW_14").Equals("0") Then
            TableMenu.Rows(enumMenu.MentUpd).Visible = False       '   ＞SQL実行（更新）
        End If
        If AppSettings("MENU_VIEW_15").Equals("0") Then
            TableMenu.Rows(enumMenu.MentSel).Visible = False       '   ＞SQL実行（検索）
        End If

        ' 権限による画面制御処理
        Select Case strRollCd
            Case clsConst.OP  ' 一般

                TableMenu.Rows(enumMenu.KanrUsrNew).Visible = False    '     ＞新規登録
                TableMenu.Rows(enumMenu.KanrUsrEdt).Visible = False    '     ＞修正／削除
                TableMenu.Rows(enumMenu.MentSpc).Visible = False       ' 空行
                TableMenu.Rows(enumMenu.MentTop).Visible = False       ' ▼システムメンテナンス
                TableMenu.Rows(enumMenu.MentUpd).Visible = False       '   ＞SQL実行（更新）
                TableMenu.Rows(enumMenu.MentSel).Visible = False       '   ＞SQL実行（検索）

            Case clsConst.SV  ' SV

            Case clsConst.SYSTEM  ' システム

            Case clsConst.CHANGE_PAS

                TableMenu.Rows(enumMenu.ViewSpc).Visible = False       ' 空行
                TableMenu.Rows(enumMenu.ViewTop).Visible = False       ' ▼照会系
                TableMenu.Rows(enumMenu.ViewBiz).Visible = False       '   ＞業務照会
                TableMenu.Rows(enumMenu.ViewDat).Visible = False       '   ＞データ照会
                TableMenu.Rows(enumMenu.DefSpc).Visible = False       ' 空行
                TableMenu.Rows(enumMenu.DefTop).Visible = False       ' ▼データ修正
                TableMenu.Rows(enumMenu.DefCor).Visible = False       '   ＞データ修正
                TableMenu.Rows(enumMenu.ExpeSpc).Visible = False       ' 空行
                TableMenu.Rows(enumMenu.ExpeTop).Visible = False       ' ▼実績照会
                TableMenu.Rows(enumMenu.ExpeRec).Visible = False       ' 　＞受付
                TableMenu.Rows(enumMenu.ExpeRecPro).Visible = False    ' 　　＞受付案件数
                TableMenu.Rows(enumMenu.ExpeRecImg).Visible = False    ' 　　＞受付イメージ件数
                TableMenu.Rows(enumMenu.ExpeRecDat).Visible = False    ' 　　＞受付時間別受付データ数
                TableMenu.Rows(enumMenu.ExpeDel).Visible = False       ' 　＞納品
                TableMenu.Rows(enumMenu.ExpeDelPro).Visible = False    ' 　　＞納品案件数
                TableMenu.Rows(enumMenu.ExpeDelImg).Visible = False    ' 　　＞納品イメージ件数
                TableMenu.Rows(enumMenu.ExpeDelDat).Visible = False    ' 　　＞納品時間別納品データ数
                TableMenu.Rows(enumMenu.ExpeDelEnd).Visible = False    ' 　　＞納品時間別納品完了時間
                TableMenu.Rows(enumMenu.ExpeDelInq).Visible = False    ' 　　＞納品実績照会
                TableMenu.Rows(enumMenu.ExpeDelTim).Visible = False    ' 　　＞納品時間状況照会
                TableMenu.Rows(enumMenu.KanrUsrNew).Visible = False    '     ＞新規登録
                TableMenu.Rows(enumMenu.KanrUsrEdt).Visible = False    '     ＞修正／削除
                TableMenu.Rows(enumMenu.MentSpc).Visible = False       ' 空行
                TableMenu.Rows(enumMenu.MentTop).Visible = False       ' ▼システムメンテナンス
                TableMenu.Rows(enumMenu.MentUpd).Visible = False       '   ＞SQL実行（更新）
                TableMenu.Rows(enumMenu.MentSel).Visible = False       '   ＞SQL実行（検索）

        End Select

        ' メソッドの終了ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

    End Sub
#End Region

#End Region

End Class