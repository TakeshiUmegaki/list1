﻿Imports System.Data
Imports DefectManagement.clsConst
Imports DefectManagement.clsUtility

Partial Class DataInquirySearch
    Inherits System.Web.UI.Page

#Region " 列挙体 "

    Private Enum enumGridColNo
        ReceiptId = 0
        ImageFileName = 1
        SlipDefineId = 2
        ReceiptCount = 3
        ReceiptDate = 4
        DeliveryDate = 5
        ImageStatusNm = 6
        DefDivNm = 7
        DefRevCount = 8
        MoveDataBrowse = 9
        MoveDataBrowse2 = 10
        ImageId = 11
    End Enum

#End Region

#Region " ページロード時 "
    ''' <summary>
    ''' ページロード時
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        ' イベントの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        If Not IsPostBack Then
            '初期化
            SetInit()
        End If

        ' イベントの終了ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

    End Sub
#End Region

#Region " 検索ボタン押下 "
    ''' <summary>
    ''' 検索ボタン押下
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSearch.ServerClick

        ' イベントの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        ' 入力チェック
        If InputCheck() = False Then
            Return
        End If

        ' セッションクリア
        SessionClear()

        ' 検索処理実行
        SearchList()

        ' イベントの終了ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

    End Sub
#End Region

#Region " GridView行操作時 "
    ''' <summary>
    ''' GridView行操作時
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub grdSearchList_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles grdSearchList.RowCommand

        ' イベントの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        ' コマンド名が“Details”の場合にのみ処理
        If e.CommandName = "MoveDataBrowse" Then

            '現在表示されているページをセッションを格納
            Me.Session(clsConst.BID_PAGE_KEY) = Me.grdSearchList.PageIndex

            ' 主キー（ID列）の値を取得
            Dim strId As String = Me.grdSearchList.DataKeys(e.CommandArgument).Value()

            ' isbn列の値を基にURLを生成し、リダイレクト
            Response.Redirect(String.Format("~/Pages/Common/DefDataBrowse.aspx?ImageId={0}&mode={1}", strId, 2))

        ElseIf e.CommandName = "MoveDataBrowse2" Then

            '現在表示されているページをセッションを格納
            Me.Session(clsConst.BID_PAGE_KEY) = Me.grdSearchList.PageIndex

            ' 主キー（ID列）の値を取得
            Dim strId As String = Me.grdSearchList.DataKeys(e.CommandArgument).Value()

            ' isbn列の値を基にURLを生成し、リダイレクト
            Response.Redirect(String.Format("~/Pages/Common/DefDataBrowse.aspx?ImageId={0}&mode={1}", strId, 4))

        End If

        ' イベントの終了ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

    End Sub
#End Region

#Region " GridViewページインデックス変更中 "
    ''' <summary>
    ''' GridViewページインデックス変更中
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub grdSearchList_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles grdSearchList.PageIndexChanging

        ' イベントの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        ' 第二引数から、選択されたページindexを取得して、GridViewのページIndexに設定
        Me.Session(clsConst.BID_PAGE_KEY) = e.NewPageIndex

        Dim objBida As New DataInquiryDataAccess             ' データ照会SQL発行クラス
        Dim dicParam As Dictionary(Of String, String) = Me.Session(clsConst.DIS_SEARCH_KEY)          ' 検索条件格納用
        Dim dicSearchCol As Dictionary(Of String, String) = Me.Session(clsConst.DIS_SEARCH_COL)      ' 検索キー（項目）格納用
        Dim dicSearchStyle As Dictionary(Of String, String) = Me.Session(clsConst.DIS_SEARCH_STYLE)  ' 検索キー（スタイル）格納用

        ' 検索結果を表示
        Dim dt As DataTable = objBida.GetReceiptIdList(dicParam, dicSearchCol, dicSearchStyle)
        Me.grdSearchList.DataSource = dt
        'Me.UpdateDefDivName(DirectCast(Me.grdSearchList.DataSource, DataTable))

        If Not Page.Session.Item(clsConst.BID_PAGE_KEY) Is Nothing Then
            If Math.Ceiling(dt.Rows.Count / Me.grdSearchList.PageSize) >= Me.Session(clsConst.BID_PAGE_KEY) Then
                Me.grdSearchList.PageIndex = Me.Session(clsConst.BID_PAGE_KEY)
            End If
        End If

        Me.grdSearchList.DataBind()

        ' 検索ヒット件数を表示
        Me.lblSearchCount.Text = dt.Rows.Count

        ' イベントの終了ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

    End Sub
#End Region

#Region " 帳票ID値変更時 "
    ''' <summary>
    ''' 帳票ID値変更時
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub ddlSlipDefineId_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlSlipDefineId.SelectedIndexChanged
        Dim objDid As New DataInquiryDataAccess    ' データ照会系SQL発行クラス
        Dim dt As DataTable                        ' データ取得用

        ' イベントの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        ' 検索キー(項目）ドロップダウンリストに値を設定
        dt = objDid.GetSearchColDdl(Me.ddlSlipDefineId.SelectedValue)
        SetDropDownList(Me.ddlSearchCol1, dt, True)
        SetDropDownList(Me.ddlSearchCol2, dt, True)
        SetDropDownList(Me.ddlSearchCol3, dt, True)

        ' イベントの終了ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)
    End Sub
#End Region


#Region " 初期設定 "
    ''' <summary>
    ''' 初期設定
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetInit()

        Dim objCda As New CommonDataAccess              ' 共通系SQL発行クラス
        Dim objDid As New DataInquiryDataAccess         ' データ照会系SQL発行クラス
        Dim dt As DataTable                             ' データ取得用

        ' メソッドの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        ' 受付日From、Toにシステム日付を設定
        Me.txtReceiptDateFrom.Text = objCda.GetSysDate
        Me.txtReceiptDateTo.Text = objCda.GetSysDate

        '---------------------------------------------------
        ' 帳票IDドロップダウンリストに値を設定
        dt = objCda.GetSlipDefineIdDdl2(ConfigurationManager.AppSettings("TARGET_SLIP"))
        SetDropDownList(Me.ddlSlipDefineId, dt)

        ' 帳票IDドロップダウンリストの先頭行を選択
        Me.ddlSlipDefineId.SelectedIndex = 0

        '戻るボタンで戻ってこなかった場合セッションをクリア
        If Page.Request.QueryString("ReturnFlg") Is Nothing Then
            SessionClear()
        End If

        '検索キーをセット
        SetSessionSearchKey()

        '---------------------------------------------------
        ' 受付時間Fromドロップダウンリストに値を設定
        dt = objCda.GetReceiptPlanDdl(System.Configuration.ConfigurationManager.AppSettings("SEARCH_KEY_SLIP_ID"))
        SetDropDownList(Me.ddlReceiptCountFrom, dt, True)

        ' 受付時間Toドロップダウンリストに値を設定
        SetDropDownList(Me.ddlReceiptCountTo, dt, True)

        '---------------------------------------------------
        ' ステータスドロップダウンリストに値を設定
        dt = objCda.GetStatusDdl(clsConst.CONFIG_DIV_IMAGE_STATUS)
        SetDropDownList(Me.ddlReceiptStatus, dt, True)

        '---------------------------------------------------
        ' 不備区分ドロップダウンリストに値を設定
        dt = objDid.GetDefDivDdl()
        SetDropDownList(Me.ddlDefDiv, dt, True)

        '---------------------------------------------------
        ' 検索キー(項目）ドロップダウンリストに値を設定
        dt = objDid.GetSearchColDdl(Me.ddlSlipDefineId.SelectedValue)
        SetDropDownList(Me.ddlSearchCol1, dt, True)
        SetDropDownList(Me.ddlSearchCol2, dt, True)
        SetDropDownList(Me.ddlSearchCol3, dt, True)

        '---------------------------------------------------
        ' 検索キー（スタイル）ドロップダウンリストに値を設定
        dt = objDid.GetSearchStyleDdl()
        SetDropDownList(Me.ddlSearchStyle1, dt, True)
        SetDropDownList(Me.ddlSearchStyle2, dt, True)
        SetDropDownList(Me.ddlSearchStyle3, dt, True)

        ' ページングで表示する件数を設定
        Me.grdSearchList.PageSize = CInt(System.Configuration.ConfigurationManager.AppSettings(clsConst.CONF_DISP_PAGE))

        ' 検索処理実行
        SearchList()

        ' メソッドの終了ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

    End Sub

#End Region

#Region " 入力チェック処理 "
    ''' <summary>
    ''' 入力チェック処理
    ''' </summary>
    ''' <returns>Boolean True:エラーなし False:エラー有り</returns>
    ''' <remarks></remarks>
    Private Function InputCheck() As Boolean

        ' メソッドの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        ' 受付日Fromが入力されている場合
        If Not String.IsNullOrEmpty(Me.txtReceiptDateFrom.Text) Then
            ' 日付書式チェック
            If Not isDate(Me.txtReceiptDateFrom.Text) Then
                ClsNotifyBar.Show(Me, "受付日Fromの日付が不正です。", ClsNotifyBar.Cls.Error)
                Return False
            End If
        End If

        ' 受付日Toが入力されている場合
        If Not String.IsNullOrEmpty(Me.txtReceiptDateTo.Text) Then
            ' 日付書式チェック
            If Not isDate(Me.txtReceiptDateTo.Text) Then
                ClsNotifyBar.Show(Me, "受付日Toの日付が不正です。", ClsNotifyBar.Cls.Error)
                Return False
            End If
        End If

        ' 受付日の大小関係チェック
        If Not String.IsNullOrEmpty(Me.txtReceiptDateFrom.Text) AndAlso Not String.IsNullOrEmpty(Me.txtReceiptDateTo.Text) Then
            If Format(CType(Me.txtReceiptDateFrom.Text, Date), "yyyy/MM/dd") > Format(CType(Me.txtReceiptDateTo.Text, Date), "yyyy/MM/dd") Then
                ClsNotifyBar.Show(Me, "受付日の大小関係が不正です。", ClsNotifyBar.Cls.Error)
                Return False
            End If

        End If

        ' 受付時間の大小関係チェック
        If Not String.IsNullOrEmpty(Me.ddlReceiptCountFrom.Text) AndAlso Not String.IsNullOrEmpty(Me.ddlReceiptCountTo.Text) Then
            If Int(Me.ddlReceiptCountFrom.SelectedValue) > Int(Me.ddlReceiptCountTo.SelectedValue) Then
                ClsNotifyBar.Show(Me, "受付回数の大小関係が不正です。", ClsNotifyBar.Cls.Error)
                Return False
            End If

        End If

        '--------------------------------------------------
        '検索キー①関連チェック
        Dim SearchFlg As Integer = 0

        '検索キー（項目）
        If Not String.IsNullOrEmpty(Me.ddlSearchCol1.Text) Then
            SearchFlg = SearchFlg + 1
        End If

        '検索キー（スタイル）
        If Not String.IsNullOrEmpty(Me.ddlSearchStyle1.Text) Then
            SearchFlg = SearchFlg + 1
        End If

        '検索キー（データ）
        If Not String.IsNullOrEmpty(Me.txtSearchData1.Text) Then
            SearchFlg = SearchFlg + 1
        End If

        '何も入力されてないか、全て入力されている場合以外エラー
        If SearchFlg = 1 Or SearchFlg = 2 Then
            ClsNotifyBar.Show(Me, "検索キーの設定が不正です。", ClsNotifyBar.Cls.Error)
            Return False
        End If

        '--------------------------------------------------
        '検索キー②関連チェック
        SearchFlg = 0

        '検索キー（項目）
        If Not String.IsNullOrEmpty(Me.ddlSearchCol2.Text) Then
            SearchFlg = SearchFlg + 1
        End If

        '検索キー（スタイル）
        If Not String.IsNullOrEmpty(Me.ddlSearchStyle2.Text) Then
            SearchFlg = SearchFlg + 1
        End If

        '検索キー（データ）
        If Not String.IsNullOrEmpty(Me.txtSearchData2.Text) Then
            SearchFlg = SearchFlg + 1
        End If

        '何も入力されてないか、全て入力されている場合以外エラー
        If SearchFlg = 1 Or SearchFlg = 2 Then
            ClsNotifyBar.Show(Me, "検索キーの設定が不正です。", ClsNotifyBar.Cls.Error)
            Return False
        End If

        '--------------------------------------------------
        '検索キー③関連チェック
        SearchFlg = 0

        '検索キー（項目）
        If Not String.IsNullOrEmpty(Me.ddlSearchCol3.Text) Then
            SearchFlg = SearchFlg + 1
        End If

        '検索キー（スタイル）
        If Not String.IsNullOrEmpty(Me.ddlSearchStyle3.Text) Then
            SearchFlg = SearchFlg + 1
        End If

        '検索キー（データ）
        If Not String.IsNullOrEmpty(Me.txtSearchData3.Text) Then
            SearchFlg = SearchFlg + 1
        End If

        '何も入力されてないか、全て入力されている場合以外エラー
        If SearchFlg = 1 Or SearchFlg = 2 Then
            ClsNotifyBar.Show(Me, "検索キーの設定が不正です。", ClsNotifyBar.Cls.Error)
            Return False
        End If

        ' メソッドの終了ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

        Return True

    End Function
#End Region

#Region " 検索処理 "
    ''' <summary>
    ''' 検索処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SearchList()

        Dim objBida As New DataInquiryDataAccess             ' データ照会SQL発行クラス
        Dim dicParam As New Dictionary(Of String, String)    ' 検索条件格納用
        Dim dicSearchCol As New Dictionary(Of String, String)      ' 検索キー（項目）格納用
        Dim dicSearchStyle As New Dictionary(Of String, String)    ' 検索キー（スタイル）格納用

        ' メソッドの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        ' 受付日Fromが入力されている場合、パラメータにセット
        If Not String.IsNullOrEmpty(Me.txtReceiptDateFrom.Text) Then
            dicParam.Add("RECEIPT_DATE_FROM", Format(CType(Me.txtReceiptDateFrom.Text, Date), "yyyy/MM/dd"))
        End If

        ' 受付日Toが入力されている場合、パラメータにセット
        If Not String.IsNullOrEmpty(Me.txtReceiptDateTo.Text) Then
            dicParam.Add("RECEIPT_DATE_TO", Format(CType(Me.txtReceiptDateTo.Text, Date), "yyyy/MM/dd"))
        End If

        ' 受付時間Fromが入力されている場合、パラメータにセット
        If Not String.IsNullOrEmpty(Me.ddlReceiptCountFrom.Text) Then
            dicParam.Add("RECEIPT_COUNT_FROM", Me.ddlReceiptCountFrom.SelectedValue)
        End If

        ' 受付時間Toが入力されている場合、パラメータにセット
        If Not String.IsNullOrEmpty(Me.ddlReceiptCountTo.Text) Then
            dicParam.Add("RECEIPT_COUNT_TO", Me.ddlReceiptCountTo.SelectedValue)
        End If

        ' 帳票IDが入力されている場合、パラメータにセット
        If Not String.IsNullOrEmpty(Me.ddlSlipDefineId.Text) Then
            dicParam.Add("SLIP_DEFINE_ID", Me.ddlSlipDefineId.SelectedValue)
        End If

        ' ステータスが入力されている場合、パラメータにセット
        If Not String.IsNullOrEmpty(Me.ddlReceiptStatus.Text) Then
            dicParam.Add("IMAGE_STATUS", Me.ddlReceiptStatus.SelectedValue)
        End If

        ' 受付番号が入力されている場合、パラメータにセット
        If Not String.IsNullOrEmpty(Me.txtExcSubjectNo.Text) Then
            dicParam.Add("EXC_SUBJECT_NO", Me.txtExcSubjectNo.Text)
        End If

        ' 不備区分が入力されている場合、パラメータにセット
        If Not String.IsNullOrEmpty(Me.ddlDefDiv.Text) Then
            dicParam.Add("DEF_DIV", Me.ddlDefDiv.SelectedValue)
        End If

        ' 検索キーが入力されている場合、パラメータにセット
        If Not String.IsNullOrEmpty(Me.txtSearchData1.Text) Then

            Select Case Me.ddlSearchStyle1.SelectedValue
                Case "01"
                    dicParam.Add("SEARCH_DATA1", Me.txtSearchData1.Text)
                Case "02"
                    dicParam.Add("SEARCH_DATA1", "%" & Me.txtSearchData1.Text & "%")
                Case "03"
                    dicParam.Add("SEARCH_DATA1", Me.txtSearchData1.Text & "%")
                Case "04"
                    dicParam.Add("SEARCH_DATA1", "%" & Me.txtSearchData1.Text)
            End Select

            dicSearchCol.Add("SEARCH_COL1", Me.ddlSearchCol1.SelectedValue)
            dicSearchStyle.Add("SEARCH_STYLE1", Me.ddlSearchStyle1.SelectedValue)
        End If

        ' 検索キーが入力されている場合、パラメータにセット
        If Not String.IsNullOrEmpty(Me.txtSearchData2.Text) Then

            Select Case Me.ddlSearchStyle1.SelectedValue
                Case "01"
                    dicParam.Add("SEARCH_DATA2", Me.txtSearchData2.Text)
                Case "02"
                    dicParam.Add("SEARCH_DATA2", "%" & Me.txtSearchData2.Text & "%")
                Case "03"
                    dicParam.Add("SEARCH_DATA2", Me.txtSearchData2.Text & "%")
                Case "04"
                    dicParam.Add("SEARCH_DATA2", "%" & Me.txtSearchData2.Text)
            End Select

            dicSearchCol.Add("SEARCH_COL2", Me.ddlSearchCol2.SelectedValue)
            dicSearchStyle.Add("SEARCH_STYLE2", Me.ddlSearchStyle2.SelectedValue)
        End If

        ' 検索キーが入力されている場合、パラメータにセット
        If Not String.IsNullOrEmpty(Me.txtSearchData3.Text) Then

            Select Case Me.ddlSearchStyle1.SelectedValue
                Case "01"
                    dicParam.Add("SEARCH_DATA3", Me.txtSearchData3.Text)
                Case "02"
                    dicParam.Add("SEARCH_DATA3", "%" & Me.txtSearchData3.Text & "%")
                Case "03"
                    dicParam.Add("SEARCH_DATA3", Me.txtSearchData3.Text & "%")
                Case "04"
                    dicParam.Add("SEARCH_DATA3", "%" & Me.txtSearchData3.Text)
            End Select

            dicSearchCol.Add("SEARCH_COL3", Me.ddlSearchCol3.SelectedValue)
            dicSearchStyle.Add("SEARCH_STYLE3", Me.ddlSearchStyle3.SelectedValue)
        End If

        'セッションに検索条件を格納
        Me.Session(clsConst.DIS_SEARCH_KEY) = dicParam
        Me.Session(clsConst.DIS_SEARCH_COL) = dicSearchCol
        Me.Session(clsConst.DIS_SEARCH_STYLE) = dicSearchStyle

        ' 検索結果を表示
        Dim dt As DataTable = objBida.GetReceiptIdList(dicParam, dicSearchCol, dicSearchStyle)
        Me.grdSearchList.DataSource = dt
        'Me.UpdateDefDivName(DirectCast(Me.grdSearchList.DataSource, DataTable))

        If Not Page.Session.Item(clsConst.BID_PAGE_KEY) Is Nothing Then
            If Math.Ceiling(dt.Rows.Count / Me.grdSearchList.PageSize) >= Me.Session(clsConst.BID_PAGE_KEY) Then
                Me.grdSearchList.PageIndex = Me.Session(clsConst.BID_PAGE_KEY)
            End If
        End If

        Me.grdSearchList.DataBind()

        ' 検索ヒット件数を表示
        Me.lblSearchCount.Text = dt.Rows.Count

        ' メソッドの終了ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

    End Sub
#End Region

#Region " 不備区分の更新（機械チェック未実施のステータスだったときにブランクにする） "
    ''' <summary>
    ''' 不備区分の更新（機械チェック未実施のステータスだったときにブランクにする）
    ''' </summary>
    ''' <param name="dataSource">対象データ</param>
    Private Sub UpdateDefDivName(ByVal dataSource As DataTable)
        ''イメージステータスが機械チェック未実施のものだったら不備区分をブランクにする
        ''（Web.config->UNCHECKED_STATUSES）
        'For Each dr As DataRow In dataSource.Rows
        '    If (dr("IMAGE_STATUS_NM") Is DBNull.Value) Then Continue For
        '    If clsUtility.StartWith(DirectCast(dr("IMAGE_STATUS_NM"), String), ConfigurationManager.AppSettings("UNCHECKED_STATUSES")) Then
        '        dr("DEF_DIV_NM") = String.Empty
        '    End If
        'Next
    End Sub

#End Region

#Region " セッション内の検索キーをセット "

    ''' <summary>
    ''' セッション内の検索キーをセット
    ''' </summary>
    Private Sub SetSessionSearchKey()

        If Not Page.Session.Item(clsConst.DIS_SEARCH_KEY) Is Nothing Then

            Dim dicParam As Dictionary(Of String, String) = Me.Session(clsConst.DIS_SEARCH_KEY)          ' 検索条件格納用
            Dim dicSearchCol As Dictionary(Of String, String) = Me.Session(clsConst.DIS_SEARCH_COL)      ' 検索キー（項目）格納用
            Dim dicSearchStyle As Dictionary(Of String, String) = Me.Session(clsConst.DIS_SEARCH_STYLE)  ' 検索キー（スタイル）格納用

            If dicParam.ContainsKey("RECEIPT_DATE_FROM") Then
                Me.txtReceiptDateFrom.Text = dicParam.Item("RECEIPT_DATE_FROM")
            End If

            If dicParam.ContainsKey("RECEIPT_DATE_TO") Then
                Me.txtReceiptDateTo.Text = dicParam.Item("RECEIPT_DATE_TO")
            End If

            If dicParam.ContainsKey("RECEIPT_COUNT_FROM") Then
                Me.ddlReceiptCountFrom.SelectedValue = dicParam.Item("RECEIPT_COUNT_FROM")
            End If

            If dicParam.ContainsKey("RECEIPT_COUNT_TO") Then
                Me.ddlReceiptCountTo.SelectedValue = dicParam.Item("RECEIPT_COUNT_TO")
            End If

            If dicParam.ContainsKey("SLIP_DEFINE_ID") Then
                Me.ddlSlipDefineId.SelectedValue = dicParam.Item("SLIP_DEFINE_ID")
            End If

            If dicParam.ContainsKey("IMAGE_STATUS") Then
                Me.ddlReceiptStatus.SelectedValue = dicParam.Item("IMAGE_STATUS")
            End If

            If dicParam.ContainsKey("EXC_SUBJECT_NO") Then
                Me.txtExcSubjectNo.Text = dicParam.Item("EXC_SUBJECT_NO")
            End If

            If dicParam.ContainsKey("DEF_DIV") Then
                Me.ddlDefDiv.SelectedValue = dicParam.Item("DEF_DIV")
            End If

            If dicParam.ContainsKey("SEARCH_DATA1") Then
                Me.txtSearchData1.Text = dicParam.Item("SEARCH_DATA1").Replace("%", String.Empty)
            End If

            If dicParam.ContainsKey("SEARCH_DATA2") Then
                Me.txtSearchData2.Text = dicParam.Item("SEARCH_DATA2").Replace("%", String.Empty)
            End If

            If dicParam.ContainsKey("SEARCH_DATA3") Then
                Me.txtSearchData3.Text = dicParam.Item("SEARCH_DATA3").Replace("%", String.Empty)
            End If

            If dicSearchCol.ContainsKey("SEARCH_COL1") Then
                Me.ddlSearchCol1.SelectedValue = dicSearchCol.Item("SEARCH_COL1")
            End If

            If dicSearchCol.ContainsKey("SEARCH_COL2") Then
                Me.ddlSearchCol2.SelectedValue = dicSearchCol.Item("SEARCH_COL2")
            End If

            If dicSearchCol.ContainsKey("SEARCH_COL3") Then
                Me.ddlSearchCol3.SelectedValue = dicSearchCol.Item("SEARCH_COL3")
            End If

            If dicSearchStyle.ContainsKey("SEARCH_STYLE1") Then
                Me.ddlSearchStyle1.SelectedValue = dicSearchStyle.Item("SEARCH_STYLE1")
            End If

            If dicSearchStyle.ContainsKey("SEARCH_STYLE2") Then
                Me.ddlSearchStyle2.SelectedValue = dicSearchStyle.Item("SEARCH_STYLE2")
            End If

            If dicSearchStyle.ContainsKey("SEARCH_STYLE3") Then
                Me.ddlSearchStyle3.SelectedValue = dicSearchStyle.Item("SEARCH_STYLE3")
            End If

        End If

    End Sub

#End Region

#Region " セッションクリア "

    ''' <summary>
    ''' セッションクリア
    ''' </summary>
    Private Sub SessionClear()

        If Not Page.Session.Item(clsConst.DIS_SEARCH_KEY) Is Nothing Then
            Page.Session.Remove(clsConst.DIS_SEARCH_KEY)
            Page.Session.Remove(clsConst.DIS_SEARCH_COL)
            Page.Session.Remove(clsConst.DIS_SEARCH_STYLE)
        End If

        If Not Page.Session.Item(clsConst.BID_PAGE_KEY) Is Nothing Then
            Page.Session.Remove(clsConst.BID_PAGE_KEY)
        End If

    End Sub

#End Region

End Class
