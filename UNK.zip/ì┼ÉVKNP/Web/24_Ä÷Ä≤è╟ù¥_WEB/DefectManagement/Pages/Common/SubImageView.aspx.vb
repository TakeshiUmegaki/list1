﻿Imports System.Data
Imports DefectManagement.clsConst
Imports DefectManagement.clsUtility

Partial Public Class SubImageView
    Inherits System.Web.UI.Page

#Region " 変数 "
    Protected strImageUrl As String   'イメージURL
#End Region

#Region " ページロード時 "
    ''' <summary>
    ''' ページロード時
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        ' イベントの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        If Not IsPostBack Then

            '初期化
            SetInit()

        End If

        ' イベントの終了ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

    End Sub
#End Region


#Region " 初期設定 "
    ''' <summary>
    ''' 初期設定
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetInit()

        ' メソッドの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        ' イメージ参照SQL発行クラス
        Dim objDA As New ImageViewDataAccess
        ' 前画面から渡されたパラメータからイメージIDを取得
        Dim strImageId As String = Page.Request.QueryString("ImageId")
        ' イメージIDを記憶
        Me.ViewState("IMAGE_ID") = strImageId


        ' コンボボックス表示データの取得
        Dim dtList As DataTable = objDA.GetImageList(strImageId)
        SetDropDownList(Me.ddlImageList, dtList, False)
        Me.ddlImageList.SelectedValue = strImageId
        ' 表示対象イメージPathの取得
        Dim strImagePath As String = objDA.GetImagePath(strImageId)

        ' ファイル名の表示
        Me.txtFileName.Text = IO.Path.GetFileName(strImagePath)

        ' イメージパスの設定
        strImageUrl = Jpeg.GenerateUrl("Jpeg.aspx", strImagePath)

        DataBind()


        ' メソッドの終了ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

    End Sub
#End Region

#Region "ドロップダウンリスト選択"
    ''' <summary>
    ''' ドロップダウンリスト選択
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub ddlImageList_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ddlImageList.SelectedIndexChanged

        ' メソッドの開始ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        ' 選択されたイメージIDを取得
        Dim strImageId As String = Me.ddlImageList.SelectedValue

        ' イメージ参照SQL発行クラス
        Dim objDA As New ImageViewDataAccess
        ' 表示対象イメージPathの取得
        Dim strImagePath As String = objDA.GetImagePath(strImageId)
        ' ファイル名の表示
        Me.txtFileName.Text = IO.Path.GetFileName(strImagePath)
        ' イメージパスの設定
        strImageUrl = Jpeg.GenerateUrl("Jpeg.aspx", strImagePath)

        DataBind()

        '' isbn列の値を基にURLを生成し、リダイレクト
        'Response.Redirect(String.Format("~/Pages/DefCorrection/SubImageView.aspx?ImageId={0}", strImageId))


        ' メソッドの終了ログ出力
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

    End Sub
#End Region

End Class