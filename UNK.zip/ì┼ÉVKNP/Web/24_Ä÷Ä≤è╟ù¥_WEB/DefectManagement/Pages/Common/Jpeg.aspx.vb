﻿Imports System.Drawing
Imports System.Drawing.Imaging
Imports System.IO

Public Class Jpeg
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim jpegFilePath As String = HttpUtility.UrlDecode(HttpContext.Current.Request.QueryString("p"))
        If File.Exists(jpegFilePath) Then
            Using bmp = New Bitmap(jpegFilePath)
                bmp.Save(Response.OutputStream, ImageFormat.Jpeg)
            End Using
        Else
            'ファイルが存在しないときは「No image.」表示
            Using bmp = New Bitmap(300, 150, PixelFormat.Format32bppArgb)
                Using gph As Graphics = Graphics.FromImage(bmp)
                    Using font As New Font("Arial", 20)
                        Using brush As New SolidBrush(Color.Gray)
                            Dim point As New Point(10, 10)
                            gph.Clear(Color.White)
                            gph.DrawString("No image.", font, brush, point)
                        End Using
                    End Using
                End Using
                bmp.Save(Response.OutputStream, ImageFormat.Jpeg)
            End Using
        End If
        Response.End()
    End Sub

    ''' <summary>
    ''' Jpeg画像のURL
    ''' </summary>
    ''' <param name="jpegAspxUrl">現在のページから見たJpeg.aspxのURL</param>
    ''' <param name="jpegFilePath">読み込むJpegのファイルパス</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Shared Function GenerateUrl(ByVal jpegAspxUrl As String, ByVal jpegFilePath As String)
        Return String.Format("{0}?p={1}", jpegAspxUrl, HttpUtility.UrlEncode(jpegFilePath))
    End Function

End Class