Imports DefectManagement.clsConst
Imports System.Drawing

Partial Public Class DefDataBrowse
    Inherits System.Web.UI.Page

#Region " �񋓑� "

    Private Enum enumGridRevHistory
        EndTime = 0
        UpdateUser = 1
        DefFlg = 2
        ItemValue_2 = 3
        ItemValue = 4
        btnSelect = 5
    End Enum

#End Region

#Region " �ϐ� "
    Protected strImageUrl As String   '�C���[�WURL
#End Region


#Region " ���I�R���g���[����` "
    ' ���[���ږ�
    Protected WithEvents lblItem1 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem2 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem3 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem4 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem5 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem6 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem7 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem8 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem9 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem10 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem11 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem12 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem13 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem14 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem15 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem16 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem17 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem18 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem19 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem20 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem21 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem22 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem23 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem24 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem25 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem26 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem27 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem28 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem29 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem30 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem31 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem32 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem33 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem34 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem35 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem36 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem37 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem38 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem39 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem40 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem41 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem42 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem43 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem44 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem45 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem46 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem47 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem48 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem49 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem50 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem51 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem52 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem53 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem54 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem55 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem56 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem57 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem58 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem59 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem60 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem61 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem62 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem63 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem64 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem65 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem66 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem67 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem68 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem69 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem70 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem71 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem72 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem73 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem74 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem75 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem76 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem77 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem78 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem79 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem80 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem81 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem82 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem83 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem84 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem85 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem86 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem87 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem88 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem89 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem90 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem91 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem92 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem93 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem94 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem95 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem96 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem97 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem98 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem99 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem100 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem101 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem102 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem103 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem104 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem105 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem106 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem107 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem108 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem109 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem110 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem111 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem112 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem113 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem114 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem115 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem116 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem117 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem118 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem119 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem120 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem121 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem122 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem123 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem124 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem125 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem126 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem127 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem128 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem129 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem130 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem131 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem132 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem133 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem134 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem135 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem136 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem137 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem138 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem139 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem140 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem141 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem142 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem143 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem144 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem145 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem146 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem147 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem148 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem149 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem150 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem151 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem152 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem153 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem154 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem155 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem156 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem157 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem158 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem159 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem160 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem161 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem162 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem163 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem164 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem165 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem166 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem167 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem168 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem169 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem170 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem171 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem172 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem173 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem174 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem175 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem176 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem177 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem178 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem179 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem180 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem181 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem182 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem183 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem184 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem185 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem186 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem187 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem188 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem189 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem190 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem191 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem192 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem193 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem194 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem195 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem196 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem197 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem198 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem199 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents lblItem200 As System.Web.UI.WebControls.LinkButton

    ' ���ړ��e
    Protected WithEvents txtItem1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem2 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem3 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem4 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem5 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem6 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem7 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem8 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem9 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem10 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem11 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem12 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem13 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem14 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem15 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem16 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem17 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem18 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem19 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem20 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem21 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem22 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem23 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem24 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem25 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem26 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem27 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem28 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem29 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem30 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem31 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem32 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem33 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem34 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem35 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem36 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem37 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem38 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem39 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem40 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem41 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem42 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem43 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem44 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem45 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem46 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem47 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem48 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem49 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem50 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem51 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem52 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem53 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem54 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem55 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem56 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem57 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem58 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem59 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem60 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem61 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem62 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem63 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem64 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem65 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem66 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem67 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem68 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem69 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem70 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem71 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem72 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem73 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem74 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem75 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem76 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem77 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem78 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem79 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem80 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem81 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem82 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem83 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem84 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem85 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem86 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem87 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem88 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem89 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem90 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem91 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem92 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem93 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem94 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem95 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem96 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem97 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem98 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem99 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem100 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem101 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem102 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem103 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem104 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem105 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem106 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem107 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem108 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem109 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem110 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem111 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem112 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem113 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem114 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem115 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem116 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem117 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem118 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem119 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem120 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem121 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem122 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem123 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem124 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem125 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem126 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem127 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem128 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem129 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem130 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem131 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem132 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem133 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem134 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem135 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem136 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem137 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem138 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem139 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem140 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem141 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem142 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem143 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem144 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem145 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem146 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem147 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem148 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem149 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem150 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem151 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem152 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem153 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem154 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem155 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem156 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem157 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem158 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem159 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem160 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem161 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem162 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem163 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem164 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem165 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem166 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem167 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem168 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem169 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem170 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem171 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem172 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem173 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem174 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem175 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem176 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem177 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem178 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem179 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem180 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem181 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem182 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem183 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem184 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem185 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem186 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem187 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem188 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem189 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem190 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem191 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem192 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem193 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem194 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem195 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem196 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem197 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem198 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem199 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtItem200 As System.Web.UI.WebControls.TextBox

    ' �s���t���O
    Protected WithEvents txtDef1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef2 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef3 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef4 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef5 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef6 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef7 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef8 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef9 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef10 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef11 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef12 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef13 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef14 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef15 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef16 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef17 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef18 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef19 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef20 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef21 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef22 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef23 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef24 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef25 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef26 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef27 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef28 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef29 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef30 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef31 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef32 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef33 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef34 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef35 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef36 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef37 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef38 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef39 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef40 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef41 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef42 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef43 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef44 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef45 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef46 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef47 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef48 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef49 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef50 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef51 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef52 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef53 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef54 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef55 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef56 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef57 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef58 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef59 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef60 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef61 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef62 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef63 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef64 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef65 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef66 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef67 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef68 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef69 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef70 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef71 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef72 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef73 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef74 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef75 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef76 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef77 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef78 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef79 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef80 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef81 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef82 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef83 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef84 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef85 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef86 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef87 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef88 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef89 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef90 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef91 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef92 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef93 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef94 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef95 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef96 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef97 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef98 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef99 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef100 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef101 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef102 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef103 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef104 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef105 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef106 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef107 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef108 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef109 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef110 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef111 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef112 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef113 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef114 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef115 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef116 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef117 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef118 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef119 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef120 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef121 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef122 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef123 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef124 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef125 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef126 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef127 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef128 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef129 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef130 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef131 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef132 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef133 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef134 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef135 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef136 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef137 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef138 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef139 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef140 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef141 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef142 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef143 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef144 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef145 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef146 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef147 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef148 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef149 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef150 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef151 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef152 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef153 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef154 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef155 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef156 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef157 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef158 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef159 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef160 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef161 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef162 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef163 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef164 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef165 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef166 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef167 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef168 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef169 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef170 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef171 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef172 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef173 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef174 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef175 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef176 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef177 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef178 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef179 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef180 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef181 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef182 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef183 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef184 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef185 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef186 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef187 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef188 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef189 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef190 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef191 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef192 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef193 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef194 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef195 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef196 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef197 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef198 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef199 As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDef200 As System.Web.UI.WebControls.TextBox
#End Region

#Region " �y�[�W���[�h�� "
    ''' <summary>
    ''' �y�[�W���[�h��
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        ' �C�x���g�̊J�n���O�o��
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        If Not IsPostBack Then

            '������
            SetInit()

        End If

        ' �C�x���g�̏I�����O�o��
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

    End Sub
#End Region

#Region " �߂�{�^�������� "
    ''' <summary>
    ''' �߂�{�^��������
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnReturn_ServerClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnReturn.ServerClick

        ' �C�x���g�̊J�n���O�o��
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        Select Case Me.ViewState("MODE").ToString
            Case "1", "3"
                ' �Ɩ��Ɖ�i���ׁj�y�[�W�֖߂�
                Response.Redirect(String.Format("~/Pages/BusinessInquiry/BusinessInquiryDetails.aspx?ReturnFlg={0}", 1))
            Case "2", "4"
                ' �f�[�^�Ɖ�y�[�W�֖߂�
                Response.Redirect(String.Format("~/Pages/DataInquiry/DataInquirySearch.aspx?ReturnFlg={0}", 1))
            Case "5", "6"
                ' �[�i���яƉ�i���ׁj�y�[�W�֖߂�
                Response.Redirect(String.Format("~/Pages/ExperienceInquiry/DeliveryInquiryDetails.aspx?ReturnFlg={0}", 1))
        End Select

        ' �C�x���g�̏I�����O�o��
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

    End Sub
#End Region

#Region " �C�������|�b�v�A�b�v��ʃ��[�h�� "
    ''' <summary>
    ''' �C�������|�b�v�A�b�v��ʃ��[�h��
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Sub btnHistoryLoad_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHistoryLoad.Click

        ' �C�x���g�̊J�n���O�o��
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        Dim objDcda As New DefCorrectionDataAccess    ' �s���C��SQL���s�N���X
        Dim dtEntry As DataTable                      ' �G���g���[���e��������
        Dim dtRevHistory As DataTable                 ' �C��������������
        Dim strEntryColName As String                 ' �G���g���[��
        Dim dtGrid As New DataTable                   ' �O���b�h�\���p
        Dim dr As DataRow                             ' �f�[�^�s
        Dim i As Integer                              ' ���[�v�p
        Dim dateTime1 As DateTime
        Dim dateTime2 As DateTime
        Dim duration As TimeSpan
        Dim blnDefRow As Boolean

        ' �G���g���[�񖼂̎擾
        strEntryColName = objDcda.GetEntryColName(CType(Me.txtImageId.Text, Decimal), Me.txtItemId.Text)

        ' �G���g���[���e�̎擾
        dtEntry = objDcda.GetEntry(CType(Me.txtImageId.Text, Decimal), strEntryColName)

        ' �O���b�h�\���p�f�[�^�e�[�u���̗���`
        dtGrid.Columns.Add("END_TIME")
        dtGrid.Columns.Add("UPDATE_USER")
        dtGrid.Columns.Add("DEF_FLG")
        dtGrid.Columns.Add("ITEM_VALUE")
        dtGrid.Columns.Add("ITEM_VALUE_2")

        dr = dtGrid.NewRow

        ' �G���g���[���e���O���b�h�\���p�f�[�^�e�[�u���Ɋi�[
        If dtEntry.Rows.Count > 0 Then
            dr("END_TIME") = dtEntry.Rows(0)("CREATE_DATE").ToString
            dr("UPDATE_USER") = dtEntry.Rows(0)("OPERETOR").ToString
            dr("DEF_FLG") = dtEntry.Rows(0)("ENTRY_DEF").ToString
            dr("ITEM_VALUE") = dtEntry.Rows(0)("ENTRY_VALUE").ToString
            dr("ITEM_VALUE_2") = Left(dr("ITEM_VALUE"), 15)
        End If

        dtGrid.Rows.Add(dr)

        ' �C�������̎擾
        dtRevHistory = objDcda.GetRevHistory(CType(Me.txtImageId.Text, Decimal), Me.txtItemId.Text)

        For i = 0 To dtRevHistory.Rows.Count - 1

            ' ���[�v�Ώۍs���s���t���O�̏ꍇ
            If dtRevHistory.Rows(i)("ITEM_ID").ToString.IndexOf("DEF") >= 0 Then
                blnDefRow = True
            Else
                blnDefRow = False
            End If

            dr = dtGrid.NewRow

            ' �G���g���[���e���O���b�h�\���p�f�[�^�e�[�u���Ɋi�[
            dr("END_TIME") = dtRevHistory.Rows(i)("END_TIME").ToString
            dr("UPDATE_USER") = dtRevHistory.Rows(i)("OPERETOR").ToString

            ' ���̃f�[�^�����݂��Ȃ��ꍇ
            If dtRevHistory.Rows.Count - 1 < i + 1 Then
                ' ���[�v�Ώۍs���s���t���O�̏ꍇ
                If blnDefRow Then
                    dr("DEF_FLG") = dtRevHistory.Rows(i)("ITEM_VALUE_AFTER").ToString
                    dr("ITEM_VALUE") = dtGrid.Rows(dtGrid.Rows.Count - 1)("ITEM_VALUE").ToString
                Else
                    dr("DEF_FLG") = dtGrid.Rows(dtGrid.Rows.Count - 1)("DEF_FLG").ToString
                    dr("ITEM_VALUE") = dtRevHistory.Rows(i)("ITEM_VALUE_AFTER").ToString
                End If
                dr("ITEM_VALUE_2") = Left(dr("ITEM_VALUE"), 15)
                dtGrid.Rows.Add(dr)
            Else
                dateTime1 = DateTime.Parse(dtRevHistory.Rows(i)("END_TIME").ToString)
                dateTime2 = DateTime.Parse(dtRevHistory.Rows(i + 1)("END_TIME").ToString)

                ' ���[�v�Ώۍs�Ǝ��s�̍X�V�����̍��i�b�j���擾
                duration = dateTime2.Subtract(dateTime1)

                ' ����Web.config�Ŏw�肳�ꂽ�b���ȓ��Ȃ瓯��f�[�^�Ƃ݂Ȃ�
                If duration.TotalSeconds <= CInt(System.Configuration.ConfigurationManager.AppSettings("VALUE_DEF_IDENTITY_SECONDS")) Then
                    ' ���[�v�Ώۍs���s���t���O�̏ꍇ
                    If blnDefRow Then
                        dr("DEF_FLG") = dtRevHistory.Rows(i)("ITEM_VALUE_AFTER").ToString
                        dr("ITEM_VALUE") = dtRevHistory.Rows(i + 1)("ITEM_VALUE_AFTER").ToString
                    Else
                        dr("DEF_FLG") = dtRevHistory.Rows(i + 1)("ITEM_VALUE_AFTER").ToString
                        dr("ITEM_VALUE") = dtRevHistory.Rows(i)("ITEM_VALUE_AFTER").ToString
                    End If
                    dr("ITEM_VALUE_2") = Left(dr("ITEM_VALUE"), 15)
                    dtGrid.Rows.Add(dr)

                    i += 1
                Else  ' �s���t���O�ƍ��ڂ̑g�ݍ��킹��������Ȃ������ꍇ�́A��O�̒l��ݒ�
                    ' ���[�v�Ώۍs���s���t���O�̏ꍇ
                    If blnDefRow Then
                        dr("DEF_FLG") = dtRevHistory.Rows(i)("ITEM_VALUE_AFTER").ToString
                        dr("ITEM_VALUE") = dtGrid.Rows(dtGrid.Rows.Count - 1)("ITEM_VALUE").ToString
                    Else
                        dr("DEF_FLG") = dtGrid.Rows(dtGrid.Rows.Count - 1)("DEF_FLG").ToString
                        dr("ITEM_VALUE") = dtRevHistory.Rows(i)("ITEM_VALUE_AFTER").ToString
                    End If
                    dr("ITEM_VALUE_2") = Left(dr("ITEM_VALUE"), 15)
                    dtGrid.Rows.Add(dr)
                End If
            End If

        Next

        Me.grdRevHistory.DataSource = dtGrid
        Me.grdRevHistory.DataBind()

        Me.txtItem.Text = String.Empty

        ' �C�x���g�̏I�����O�o��
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

    End Sub
#End Region

#Region " �C������GridView�s���쎞 "
    ''' <summary>
    ''' �C������GridView�s���쎞
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub grdRevHistory_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles grdRevHistory.RowCommand

        ' �C�x���g�̊J�n���O�o��
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        ' �R�}���h�����gSelect�h�̏ꍇ�ɂ̂ݏ���
        If e.CommandName = "Select" Then
            ' �I���s�̓��͒l�������̃e�L�X�g�G���A�ɕ\��
            Me.txtItem.Text = Me.grdRevHistory.Rows(e.CommandArgument).Cells(enumGridRevHistory.ItemValue).Text
        End If

        ' �C�x���g�̏I�����O�o��
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)
    End Sub
#End Region

#Region " �C������GridView�s�쐬�� "
    ''' <summary>
    ''' �C������GridView�s�쐬��
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub grdRevHistory_RowCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles grdRevHistory.RowCreated

        ' �C�x���g�̊J�n���O�o��
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        If e.Row.RowType = DataControlRowType.DataRow OrElse e.Row.RowType = DataControlRowType.Header Then
            e.Row.Cells(enumGridRevHistory.ItemValue).Visible = False
        End If

        ' �C�x���g�̏I�����O�o��
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

    End Sub
#End Region


#Region " �����ݒ� "
    ''' <summary>
    ''' �����ݒ�
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetInit()

        ' ���\�b�h�̊J�n���O�o��
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_START, EventLogEntryType.Information)

        Dim objDcda As New DefCorrectionDataAccess    ' �s���C��SQL���s�N���X
        Dim strImageId As String                      ' �C���[�WID
        Dim dtDefDetail As DataTable
        Dim i As Integer

        Dim tdMenu As HtmlTableCell = CType(Page.Master.FindControl("tdMenu"), HtmlTableCell)

        ' ���T�C�h�̃��j���[���\���ɂ���
        tdMenu.Visible = False

        ' �O��ʂ���n���ꂽ�p�����[�^���擾
        Me.ViewState("MODE") = Page.Request.QueryString("mode")
        strImageId = Page.Request.QueryString("ImageId")

        ' �C���[�WID���L��
        Me.ViewState("IMAGE_ID") = strImageId
        ' ��ʕ\�����[�h�擾
        Dim strMode As String = Page.Request.QueryString("mode").ToString
        Dim strViewMode As String = "0"
        Select Case strMode
            Case "1", "2", "5"
                strViewMode = "0"
                Me.btnChangeTable.Value = "���͌���[F10]"
            Case "3", "4", "6"
                Me.divItem.Attributes("class") = "defBrowseEnt"
                strViewMode = "1"
                Me.btnChangeTable.Value = "�C������[F10]"
        End Select

        ' ��ʃ��[�h�ɂ��A�w�b�_���j���[�ύX
        Select Case Me.ViewState("MODE").ToString
            Case "1", "3"  ' �Ɩ��Ɖ�
                Me.hplRoot2.Text = "�Ɩ��󋵏Ɖ�"
                Me.hplRoot3.Text = "�Ɩ��󋵏Ɖ�i���ׁj��"
                Me.hplRoot4.Text = "�f�[�^�{��"

                Me.ViewState("RECEIPT_ID") = Page.Request.QueryString("ReceiptId")
                Me.ViewState("SLIP_DEFINE_ID") = Page.Request.QueryString("SlipDefineId")
            Case "2", "4"    ' �f�[�^�Ɖ�
                Me.hplRoot2.Text = "�f�[�^�Ɖ�"
                Me.hplRoot3.Text = "�f�[�^�{��"
                Me.hplRoot4.Visible = False
            Case "5", "6"    ' �[�i���яƉ�i�C���[�WID�P�ʁj
                Me.hplRoot2.Text = "�[�i���яƉ�"
                Me.hplRoot3.Text = "�[�i���яƉ�i���ׁj��"
                Me.hplRoot4.Text = "�f�[�^�{��"
            Case Else  ' ��O
                Me.hplRoot2.Visible = False
                Me.hplRoot3.Visible = False
                Me.hplRoot4.Visible = False
        End Select

        ' �s���ڍ׃f�[�^�擾
        dtDefDetail = objDcda.GetDefDetail(CType(strImageId, Decimal), strViewMode)

        ' �w�b�_���̃f�[�^�ݒ�
        Me.txtReceiptId.Text = dtDefDetail.Rows(0)("RECEIPT_ID").ToString
        Me.txtSlipDefineId.Text = dtDefDetail.Rows(0)("SLIP_DEFINE_ID").ToString
        Me.txtReceiptDate.Text = dtDefDetail.Rows(0)("BUSINESS_DATE").ToString
        Me.txtDefRevColCount.Text = dtDefDetail.Rows(0)("DEF_REV_COL_COUNT").ToString
        Me.txtHagakiDiv.Text = dtDefDetail.Rows(0)("SLIP_DEFINE_ID").ToString.Substring(0, 2)

        ' �C���[�W�p�X�̐ݒ�
        strImageUrl = Jpeg.GenerateUrl("Jpeg.aspx", dtDefDetail.Rows(0)("IMAGE_FILE_PATH").ToString & "\" & dtDefDetail.Rows(0)("IMAGE_FILE_NAME").ToString)

        DataBind()

        ' �ő�200���ڕ����[�v
        For i = 1 To 200 Step 1
            Dim lblItem As LinkButton = FindControl("lblItem" & i.ToString)
            Dim txtDef As TextBox = FindControl("txtDef" & i.ToString)
            Dim txtItem As TextBox = FindControl("txtItem" & i.ToString)
            Dim drRow As DataRow = dtDefDetail.Rows(i - 1)

            ' ���[���ږ��ݒ�
            lblItem = New LinkButton
            lblItem.ID = "lblItem" & i.ToString
            lblItem.Style("Position") = "Absolute"
            lblItem.Style("Top") = ((i * 30) - 15).ToString & "px"
            lblItem.Style("Left") = "10px"
            lblItem.Style("Width") = "150px"
            lblItem.Style("Height") = "15px"
            lblItem.Text = drRow("ITEM_NAME").ToString
            lblItem.OnClientClick = "openDialog(" & _
                                    "'" & i & "'" & _
                                    ",document.getElementById('ctl00_ContentMain_lblItem' + '" & i & "').innerText" & _
                                    ",'" & drRow("IMAGE_ID").ToString & "'" & _
                                    ",'" & drRow("ITEM_ID").ToString & "'" & _
                                    ");" & _
                                    "return false;"
            'lblItem.OnClientClick = "openDialog(" & _
            '                        "'" & i & "'" & _
            '                        ",document.getElementById('ctl00_ContentMain_lblItem' + '" & i & "').innerText" & _
            '                        ",document.getElementById('ctl00_ContentMain_txtDef' + '" & i & "').value" & _
            '                        ",document.getElementById('ctl00_ContentMain_txtItem' + '" & i & "').value" & _
            '                        ");" & _
            '                        "return false;"







            ' �s���t���O�ݒ�
            txtDef = New TextBox
            txtDef.ID = "txtDef" & i.ToString
            txtDef.Style("Position") = "Absolute"
            txtDef.Style("Top") = ((i * 30) - 20).ToString & "px"
            txtDef.Style("Left") = "130px"
            txtDef.Style("Width") = "20px"
            txtDef.Style("Height") = "15px"
            txtDef.ReadOnly = True
            txtDef.Attributes("data-left") = drRow("IMAGE_FOCUS_X").ToString
            txtDef.Attributes("data-top") = drRow("IMAGE_FOCUS_Y").ToString
            txtDef.Attributes("data-width") = drRow("IMAGE_FOCUS_W").ToString
            txtDef.Attributes("data-height") = drRow("IMAGE_FOCUS_H").ToString
            txtDef.TabIndex = -1
            txtDef.Text = drRow("ITEM_DEF").ToString

            ' �s���t���O������Ŗ����ꍇ�A�w�i�F��ԁA�t�H���g�𔒂ɂ���
            If Not txtDef.Text.Equals(DEF_FLG_ZZ) AndAlso Not txtDef.Text.Equals(DEF_FLG_00) Then
                txtDef.BackColor = Drawing.Color.Red
                txtDef.ForeColor = Drawing.Color.White
            Else
                ' �s���t���O���uZZ�v�̏ꍇ�A�w�i�F�����A�t�H���g�����ɂ���
                If txtDef.Text.Equals(DEF_FLG_ZZ) Then
                    txtDef.BackColor = Drawing.Color.Yellow
                    txtDef.ForeColor = Drawing.Color.Black
                Else
                    txtDef.BackColor = Drawing.Color.White
                    txtDef.ForeColor = Drawing.Color.Black
                End If
            End If

            ' ���ړ��e�ݒ�
            txtItem = New TextBox
            txtItem.ID = "txtItem" & i.ToString
            txtItem.Style("Position") = "Absolute"
            txtItem.Style("Top") = ((i * 30) - 20).ToString & "px"
            txtItem.Style("Left") = "160px"
            txtItem.Style("Width") = "320px"
            txtItem.Style("Height") = "15px"
            txtItem.ReadOnly = True
            txtItem.CssClass = "field"
            txtItem.Attributes("data-left") = drRow("IMAGE_FOCUS_X").ToString
            txtItem.Attributes("data-top") = drRow("IMAGE_FOCUS_Y").ToString
            txtItem.Attributes("data-width") = drRow("IMAGE_FOCUS_W").ToString
            txtItem.Attributes("data-height") = drRow("IMAGE_FOCUS_H").ToString
            txtItem.Text = drRow("ITEM").ToString

            divItem.Controls.Add(lblItem)
            divItem.Controls.Add(txtDef)
            divItem.Controls.Add(txtItem)

            ' �s���ڍ׃f�[�^�������Ȃ莟��A���[�v�I��
            If i = dtDefDetail.Rows.Count Then
                Exit For
            End If
        Next

        ' �֘A�C���[�W�\���{�^���̃N���C�A���g���ł̏������L�q����
        Dim strUrl As String = String.Format("SubImageView.aspx?ImageId={0}", strImageId)
        Me.btnImage.OnClientClick = String.Format("openWindow('{0}');return false;", strUrl)   '"window.open('" & strUrl & "', '');return false;"

        Me.imgCancel.OnClientClick = "document.getElementById('ctl00_ContentMain_btnHistoryClose').click();return false;"

        ' ���\�b�h�̏I�����O�o��
        clsUtility.WriteLog(Me.GetType().BaseType.FullName & "." & _
                            System.Reflection.MethodBase.GetCurrentMethod().Name & LOG_OUTPUT_END, EventLogEntryType.Information)

    End Sub
#End Region

#Region " �s���敪�̎擾�i�@�B�`�F�b�N�����{�̃X�e�[�^�X�������Ƃ��Ƀu�����N�ɂ���j "

    ''' <summary>
    ''' �s���敪�̎擾�i�@�B�`�F�b�N�����{�̃X�e�[�^�X�������Ƃ��Ƀu�����N�ɂ���j
    ''' </summary>
    ''' <param name="dataSource">�Ώۃf�[�^</param>
    Private Function GetDefDivName(ByVal dataSource As DataRow) As String
        Dim ret As String = String.Empty
        '�C���[�W�X�e�[�^�X���@�B�`�F�b�N�����{�̂��̂�������s���敪���u�����N�ɂ���
        '�iWeb.config->UNCHECKED_STATUSES�j
        If clsUtility.StartWith(DirectCast(dataSource("IMAGE_STATUS"), String), ConfigurationManager.AppSettings("UNCHECKED_STATUSES")) Then
            ret = String.Empty
        Else
            '�����{�ȊO�̃X�e�[�^�X�Ȃ�s���敪�����̂܂ܕԂ�
            ret = DirectCast(dataSource("DEF_DIV_NAME"), String)
        End If
        Return ret
    End Function

#End Region

#Region " btnChangeTable_ServerClick "
    Protected Sub btnChangeTable_ServerClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnChangeTable.ServerClick
        ' ��ʕ\�����[�h�擾
        Dim strMode As String = Me.ViewState("MODE").ToString
        Dim strViewMode As String = "0"
        Select Case strMode
            Case "1"
                strViewMode = "3"
            Case "2"
                strViewMode = "4"
            Case "3"
                strViewMode = "1"
            Case "4"
                strViewMode = "2"
            Case "5"
                strViewMode = "6"
            Case "6"
                strViewMode = "5"
        End Select
        Dim strImageID As String = Me.ViewState("IMAGE_ID").ToString

        Dim strSlipID As String = Me.ViewState("SLIP_DEFINE_ID")
        ' isbn��̒l�����URL�𐶐����A���_�C���N�g
        Response.Redirect(String.Format("~/Pages/Common/DefDataBrowse.aspx?mode={0}&ReceiptId={1}&ImageId={2}&SlipDefineId={3}", strViewMode, Me.txtReceiptId.Text, strImageID, strSlipID))

    End Sub
#End Region

End Class