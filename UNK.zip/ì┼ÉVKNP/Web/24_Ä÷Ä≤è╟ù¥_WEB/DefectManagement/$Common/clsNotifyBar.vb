﻿Imports System.Text
Imports System.Web.UI

''' <summary>
''' jqueryプラグイン「Notify bar」用ヘルパークラス
''' ※使用するページで以下の参照が必要
''' jquery core (jquery.js) http://jquery.com/
''' Notify bar  (jquery.notifyBar.js, jquery.notifyBar.css) http://www.dmitri.me/blog/notify-bar/
''' </summary>
Friend Class ClsNotifyBar

    Private Sub New()
    End Sub

    ''' <summary>
    ''' NotifyBarを表示する
    ''' </summary>
    ''' <param name="currentPage">現在のページ</param>
    ''' <param name="html">NotifyBarに表示させるHTML（メッセージ）</param>
    ''' <param name="cls">NotifyBarのスタイル種別</param>
    ''' <remarks></remarks>
    Friend Shared Sub Show(ByVal currentPage As Page, ByVal html As String, ByVal cls As Cls)

        Dim script As String = ClsNotifyBar.GetScript(html, cls)
        currentPage.ClientScript.RegisterStartupScript(currentPage.GetType(), Guid.NewGuid().ToString(), script, True)

    End Sub

    ''' <summary>
    ''' NotifyBarを表示する（UpdatePanel内から呼び出す場合）
    ''' </summary>
    ''' <param name="currentScriptManager">現在のページのScriptManager</param>
    ''' <param name="html">NotifyBarに表示させるHTML（メッセージ）</param>
    ''' <param name="cls">NotifyBarのスタイル種別</param>
    ''' <remarks></remarks>
    Friend Shared Sub Show(ByVal currentScriptManager As ScriptManager, ByVal html As String, ByVal cls As Cls)

        Dim script As String = ClsNotifyBar.GetScript(html, cls)
        currentScriptManager.RegisterStartupScript(currentScriptManager.Page, currentScriptManager.Page.GetType(), Guid.NewGuid().ToString(), script, True)

    End Sub

    Private Shared Function GetScript(ByVal html As String, ByVal cls As Cls) As String
        Dim ret As New StringBuilder()
        ret.Append("$.notifyBar({")
        ret.AppendFormat("html: '{0}',", html.Replace("'", "\'"))
        ret.AppendFormat("delay: {0},", 3000)
        ret.AppendFormat("cls: '{0}'", DirectCast(IIf(cls = ClsNotifyBar.Cls.Normal, String.Empty, cls.ToString().ToLower()), String))
        ret.Append("});")
        Return ret.ToString()
    End Function

    ''' <summary>
    ''' NotifyBarのスタイル種別
    ''' </summary>
    Enum Cls
        ''' <summary>
        ''' 標準
        ''' </summary>
        Normal
        ''' <summary>
        ''' 正常
        ''' </summary>
        Success
        ''' <summary>
        ''' エラー
        ''' </summary>
        [Error]
    End Enum

End Class

