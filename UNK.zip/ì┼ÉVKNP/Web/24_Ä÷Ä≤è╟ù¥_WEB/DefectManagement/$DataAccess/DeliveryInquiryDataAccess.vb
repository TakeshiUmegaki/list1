Imports System.Data
Imports Oracle.DataAccess.Client
Imports DefectManagement.clsConst

Public Class DeliveryInquiryDataAccess

#Region " �[�i���яƉ�ꗗ�擾 "
    ''' <summary>
    ''' �[�i���яƉ�ꗗ�擾
    ''' </summary>
    ''' <param name="dicParam">���������󂯓n���p</param>
    ''' <param name="blnSlipDefineList">True�F���[ID���̕\���@False�F�[�i�����̕\��</param>
    ''' <returns>�������ʃf�[�^�e�[�u��</returns>
    ''' <remarks></remarks>
    Public Function GetDeliveryDateList(ByVal dicParam As Dictionary(Of String, String), ByVal blnSlipDefineList As Boolean) As DataTable

        Const conDeliveryDate As String = "TO_CHAR(T_JJ_IMAGE.DELIVERY_DATE,'YYYY/MM/DD')"

        ' DB�ڑ����܂�
        Dim objclsDbAccess As New clsDbAccess

        Call objclsDbAccess.dbOpen()

        Try

            Dim stbSQL As New StringBuilder(String.Empty)
            Dim strTargetSlip As String = ConfigurationManager.AppSettings("TARGET_SLIP")

            'SQL�쐬
            stbSQL.AppendLine(" SELECT")

            stbSQL.AppendLine("         " & conDeliveryDate & " AS DELIVERY_DATE")

            If blnSlipDefineList = True Then
                stbSQL.AppendLine(",T_JJ_IMAGE.SLIP_DEFINE_ID")
                stbSQL.AppendLine(",T_JJ_IMAGE.SLIP_DEFINE_ID || ':' || M_SLIP_DEFINE.SLIP_DEFINE_NAME AS SLIP_DEFINE_NAME ")
            Else
                stbSQL.AppendLine(",'' AS SLIP_DEFINE_ID")
                stbSQL.AppendLine(",'' AS SLIP_DEFINE_NAME")
            End If

            ' ���R�����̍쐬
            For idx As Integer = 1 To 10 Step 1
                ' ���p�L���t���O�̒l��"1"�Ȃ炻�̍��v�l���擾
                Dim strUseKey As String = "DLV_USE_" & idx.ToString("00")
                Dim strUseVal As String = ConfigurationManager.AppSettings(strUseKey)
                Dim strFreeColmn As String = "Free" & idx.ToString("00")
                If strUseVal.Equals("1") Then
                    Dim strStsKey As String = "DLV_STS_" & idx.ToString("00")
                    Dim strStsVal As String = ConfigurationManager.AppSettings(strStsKey)
                    stbSQL.AppendLine("        ,SUM(CASE WHEN IMAGE_STATUS IN (" & strStsVal & ") THEN 1 ELSE 0 END) AS __FREE_CNT__")
                    stbSQL.Replace("__FREE_CNT__", strFreeColmn)
                Else
                    stbSQL.AppendLine("        ,0 AS __FREE_CNT__")
                    stbSQL.Replace("__FREE_CNT__", strFreeColmn)
                End If
            Next

            stbSQL.AppendLine(" FROM T_JJ_IMAGE")
            stbSQL.AppendLine("	     LEFT JOIN M_SLIP_DEFINE")
            stbSQL.AppendLine("        ON T_JJ_IMAGE.SLIP_DEFINE_ID = M_SLIP_DEFINE.SLIP_DEFINE_ID")
            stbSQL.AppendLine("       AND M_SLIP_DEFINE.DELETE_FLG = '0'")

            stbSQL.AppendLine("     WHERE TO_CHAR(T_JJ_IMAGE.DELIVERY_DATE,'YYYY/MM/DD') BETWEEN :DELIVERY_DATE_FROM AND :DELIVERY_DATE_TO ")

            ' ���[ID�����������Ɏw�肳��Ă���ꍇ
            If dicParam.ContainsKey("SLIP_DEFINE_ID") Then
                ' ���[ID�������ɐݒ�
                stbSQL.AppendLine("         AND T_JJ_IMAGE.SLIP_DEFINE_ID = :SLIP_DEFINE_ID ")
            End If

            If Not String.IsNullOrEmpty(strTargetSlip) Then
                stbSQL.AppendLine("      AND SUBSTRB(T_JJ_IMAGE.SLIP_DEFINE_ID, 1, 3) IN (" & strTargetSlip & ")")
            End If

            stbSQL.AppendLine("     GROUP BY")
            stbSQL.AppendLine("         " & conDeliveryDate)
            If blnSlipDefineList = True Then
                stbSQL.AppendLine("         ,T_JJ_IMAGE.SLIP_DEFINE_ID")
                stbSQL.AppendLine("         ,M_SLIP_DEFINE.SLIP_DEFINE_NAME")
            End If

            ' �p�����[�^�ݒ�
            Dim oraUpdateParam(dicParam.Count - 1) As OracleParameter
            Dim i As Integer = 0

            ' �[�i��From
            oraUpdateParam(i) = New OracleParameter("DELIVERY_DATE_FROM", OracleDbType.Char)
            oraUpdateParam(i).Value = dicParam.Item("DELIVERY_DATE_FROM")

            i = i + 1

            ' �[�i��To
            oraUpdateParam(i) = New OracleParameter("DELIVERY_DATE_TO", OracleDbType.Char)
            oraUpdateParam(i).Value = dicParam.Item("DELIVERY_DATE_TO")

            i = i + 1

            ' ���[ID�����������Ɏw�肳��Ă���ꍇ
            If dicParam.ContainsKey("SLIP_DEFINE_ID") Then
                oraUpdateParam(i) = New OracleParameter("SLIP_DEFINE_ID", OracleDbType.Char)
                oraUpdateParam(i).Value = dicParam.Item("SLIP_DEFINE_ID")
                i = i + 1
            End If

            ' �\�[�g��
            stbSQL.AppendLine(" ORDER BY DELIVERY_DATE")

            Dim dt As DataTable = objclsDbAccess.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString, oraUpdateParam)

            ' SQL���O�o��
            clsUtility.WriteLog(objclsDbAccess.mobjCommonDB.GetInfoMessage, EventLogEntryType.Information)

            '���s
            Return dt

        Finally
            objclsDbAccess.mobjCommonDB.DB_Close()
        End Try

    End Function

#End Region

#Region " �[�i���яƉ�i���ׁj�ꗗ�擾 "
    ''' <summary>
    ''' �[�i���яƉ�i���ׁj�ꗗ�擾
    ''' </summary>
    ''' <param name="strDeliveryDate">�[�i��</param>
    ''' <param name="strSlipDefineId">���[ID</param>
    ''' <returns>�������ʃf�[�^�e�[�u��</returns>
    ''' <remarks></remarks>
    Public Function GetImageIdList(ByVal strDeliveryDate As String, _
                                   ByVal strSlipDefineId As String) As DataTable

        ' DB�ڑ����܂�
        Dim objclsDbAccess As New clsDbAccess
        Dim strTargetSlip As String = ConfigurationManager.AppSettings("TARGET_SLIP")

        Call objclsDbAccess.dbOpen()

        Try
            Dim stbSQL As New StringBuilder(String.Empty)

            'SQL�쐬
            stbSQL.AppendLine("   SELECT T_JJ_IMAGE.IMAGE_ID, ")
            stbSQL.AppendLine("          TRIM(T_JJ_IMAGE.IMAGE_FILE_NAME) AS IMAGE_FILE_NAME, ")
            stbSQL.AppendLine("          T_JJ_IMAGE.SLIP_DEFINE_ID || ':' || M_SLIP_DEFINE.SLIP_DEFINE_NAME AS SLIP_DEFINE_ID, ")
            stbSQL.AppendLine("          T_JJ_IMAGE.EXC_SUBJECT_NO, ")
            stbSQL.AppendLine("          T_JJ_IMAGE.EXC_IMAGE_NO, ")
            stbSQL.AppendLine("          T_JJ_IMAGE.DELIVERY_DATE ")
            stbSQL.AppendLine("     FROM T_JJ_IMAGE ")
            stbSQL.AppendLine("          LEFT JOIN M_SLIP_DEFINE M_SLIP_DEFINE ")
            stbSQL.AppendLine("             ON T_JJ_IMAGE.SLIP_DEFINE_ID = M_SLIP_DEFINE.SLIP_DEFINE_ID ")
            stbSQL.AppendLine("    WHERE TO_CHAR(T_JJ_IMAGE.DELIVERY_DATE,'YYYY/MM/DD') = :DELIVERY_DATE ")
            If Not strSlipDefineId.Equals(String.Empty) Then
                stbSQL.AppendLine("      AND T_JJ_IMAGE.SLIP_DEFINE_ID = '" & strSlipDefineId & "'")
            End If
            If Not String.IsNullOrEmpty(strTargetSlip) Then
                stbSQL.AppendLine("      AND SUBSTRB(T_JJ_IMAGE.SLIP_DEFINE_ID, 1, 3) IN (" & strTargetSlip & ")")
            End If
            stbSQL.AppendLine(" ORDER BY T_JJ_IMAGE.IMAGE_ID ")

            '�p�����[�^�ݒ�
            Dim oraUpdateParam(0) As OracleParameter
            oraUpdateParam(0) = New OracleParameter("DELIVERY_DATE", OracleDbType.Char)
            oraUpdateParam(0).Value = strDeliveryDate

            Dim dt As DataTable = objclsDbAccess.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString, oraUpdateParam)

            ' SQL���O�o��
            clsUtility.WriteLog(objclsDbAccess.mobjCommonDB.GetInfoMessage, EventLogEntryType.Information)

            '���s
            Return dt

        Finally
            objclsDbAccess.mobjCommonDB.DB_Close()
        End Try

    End Function

#End Region

#Region " CSV�o�͗p�␳�擾 "
    ''' <summary>
    ''' CSV�o�͗p�␳�擾
    ''' </summary>
    ''' <param name="dicParam">���������󂯓n���p</param>
    ''' <returns>�������ʃf�[�^�e�[�u��</returns>
    ''' <remarks></remarks>
    Public Function GetCsvList(ByVal dicParam As Dictionary(Of String, String)) As DataTable

        ' DB�ڑ����܂�
        Dim objclsDbAccess As New clsDbAccess

        Call objclsDbAccess.dbOpen()

        Try

            Dim stbSQL As New StringBuilder(String.Empty)

            'SQL�쐬
            stbSQL.AppendLine("SELECT ")
            stbSQL.AppendLine("     R.RECEIPT_ID ")
            stbSQL.AppendLine("    ,R.RECEIPT_STATUS ")
            stbSQL.AppendLine("    ,I.IMAGE_STATUS ")
            stbSQL.AppendLine("    ,M.CONFIG_VALUE ")
            stbSQL.AppendLine("    ,E.* ")
            stbSQL.AppendLine("    ,I.SLIP_DEFINE_ID ")
            stbSQL.AppendLine("FROM T_JJ_RECEIPT R")
            stbSQL.AppendLine("    INNER JOIN T_JJ_IMAGE I")
            stbSQL.AppendLine("        ON R.RECEIPT_ID = I.RECEIPT_ID ")
            stbSQL.AppendLine("    INNER JOIN T_JJ_ENTRY_CORRECTION E")
            stbSQL.AppendLine("        ON I.IMAGE_ID = E.IMAGE_ID ")
            stbSQL.AppendLine("    LEFT JOIN M_CM_CONFIG M")
            stbSQL.AppendLine("        ON R.RECEIPT_STATUS = M.CONFIG_ID ")
            stbSQL.AppendLine("        AND M.CONFIG_DIV = '" & CONFIG_DIV_RECEIPT_STATUS & "' ")
            stbSQL.AppendLine("WHERE TO_CHAR(I.DELIVERY_DATE,'YYYY/MM/DD') BETWEEN :DELIVERY_DATE_FROM AND :DELIVERY_DATE_TO ")

            ' �p�����[�^�ݒ�
            Dim oraUpdateParam(dicParam.Count - 1) As OracleParameter
            Dim i As Integer = 0

            ' �[�i��From�������ɐݒ�
            oraUpdateParam(i) = New OracleParameter("DELIVERY_DATE_FROM", OracleDbType.Char)
            oraUpdateParam(i).Value = dicParam.Item("DELIVERY_DATE_FROM")

            i = i + 1

            ' �[�i��To�������ɐݒ�
            oraUpdateParam(i) = New OracleParameter("DELIVERY_DATE_TO", OracleDbType.Char)
            oraUpdateParam(i).Value = dicParam.Item("DELIVERY_DATE_TO")

            i = i + 1

            ' ���[ID�����������Ɏw�肳��Ă���ꍇ
            If dicParam.ContainsKey("SLIP_DEFINE_ID") Then
                stbSQL.AppendLine(" AND I.SLIP_DEFINE_ID = :SLIP_DEFINE_ID ")

                ' ���[ID�������ɐݒ�
                oraUpdateParam(i) = New OracleParameter("SLIP_DEFINE_ID", OracleDbType.Char)
                oraUpdateParam(i).Value = dicParam.Item("SLIP_DEFINE_ID")

                i = i + 1
            End If

            stbSQL.AppendLine("ORDER BY I.SLIP_DEFINE_ID, I.IMAGE_FILE_NAME ")

            Dim dt As DataTable = objclsDbAccess.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString, oraUpdateParam)

            ' SQL���O�o��
            clsUtility.WriteLog(objclsDbAccess.mobjCommonDB.GetInfoMessage, EventLogEntryType.Information)

            ' ���s
            Return dt

        Finally
            objclsDbAccess.mobjCommonDB.DB_Close()
        End Try

    End Function

#End Region

End Class
