Imports System.Data
Imports Oracle.DataAccess.Client
Imports DefectManagement.clsConst

Public Class DefCorrectionDataAccess
    Inherits clsDbAccess

#Region " �v���p�e�B "
    Private _def_report_type As String    ' �s������

    ''' <summary>
    ''' �s������
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property DefReportType() As String
        Get
            Return _def_report_type
        End Get
        Set(ByVal value As String)
            _def_report_type = value
        End Set
    End Property
#End Region

#Region " �s���C���������ʎ擾 "

    ''' <summary>
    ''' �s���C���������ʎ擾
    ''' </summary>
    ''' <param name="dicParam">���������󂯓n���p</param>
    ''' <returns>�������ʃf�[�^�e�[�u��</returns>
    ''' <remarks></remarks>
    Public Function GetDefList(ByVal dicParam As Dictionary(Of String, String)) As DataTable

        Call Me.dbOpen()

        Try

            Dim stbSQL As New StringBuilder(String.Empty)

            'SQL�쐬
            stbSQL.AppendLine("   SELECT NVL(SUM(CASE WHEN IMAGE.IMAGE_STATUS IN (" & ConfigurationManager.AppSettings("DEF_CORR_1_STS") & ") THEN 1 ELSE 0 END), 0) AS DEF_1_CNT, ")
            stbSQL.AppendLine("          NVL(SUM(CASE WHEN IMAGE.IMAGE_STATUS IN (" & ConfigurationManager.AppSettings("DEF_CORR_2_STS") & ") THEN 1 ELSE 0 END), 0) AS DEF_2_CNT ")
            stbSQL.AppendLine("     FROM T_JJ_RECEIPT RECEIPT ")
            stbSQL.AppendLine("          INNER JOIN T_JJ_IMAGE IMAGE ")
            stbSQL.AppendLine("             ON RECEIPT.RECEIPT_ID = IMAGE.RECEIPT_ID ")
            stbSQL.AppendLine("    WHERE RECEIPT.DELETE_FLG = '0' ")

            ' �p�����[�^�ݒ�
            Dim oraUpdateParam(dicParam.Count - 1) As OracleParameter
            Dim i As Integer = 0

            ' ��t��From�����������Ɏw�肳��Ă���ꍇ
            If dicParam.ContainsKey("RECEIPT_DATE_FROM") Then
                ' ��t��From�������ɐݒ�
                stbSQL.AppendLine("  AND  TO_CHAR(RECEIPT.RECEIPT_DATE,'YYYY/MM/DD') >= :RECEIPT_DATE_FROM ")

                oraUpdateParam(i) = New OracleParameter("RECEIPT_DATE_FROM", OracleDbType.Char)
                oraUpdateParam(i).Value = dicParam.Item("RECEIPT_DATE_FROM")

                i = i + 1
            End If

            ' ��t��To�����������Ɏw�肳��Ă���ꍇ
            If dicParam.ContainsKey("RECEIPT_DATE_TO") Then
                ' ��t��To�������ɐݒ�
                stbSQL.AppendLine("  AND  TO_CHAR(RECEIPT.RECEIPT_DATE,'YYYY/MM/DD') <= :RECEIPT_DATE_TO ")

                oraUpdateParam(i) = New OracleParameter("RECEIPT_DATE_TO", OracleDbType.Char)
                oraUpdateParam(i).Value = dicParam.Item("RECEIPT_DATE_TO")

                i = i + 1
            End If

            Dim dt As DataTable = Me.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString, oraUpdateParam)

            ' �擾������0���̏ꍇ�A�������ʕ\���p�Ƀ_�~�[�f�[�^��ݒ�
            If dt.Rows.Count = 0 Then
                Dim dr As DataRow

                dr = dt.NewRow

                dr("DEF_1_CNT") = 0
                dr("DEF_2_CNT") = 0

                dt.Rows.Add(dr)

            End If

            ' SQL���O�o��
            clsUtility.WriteLog(Me.mobjCommonDB.GetInfoMessage, EventLogEntryType.Information)

            '���s
            Return dt

        Finally
            Me.mobjCommonDB.DB_Close()
        End Try

    End Function

#End Region

#Region " �s���f�[�^���׎擾 "
    ''' <summary>
    ''' �s���f�[�^���׎擾
    ''' </summary>
    ''' <param name="strBtnStr">�����{�^���X�e�[�^�X 1:�s���@ 2:�s���A</param>
    ''' <param name="dicParam">���������󂯓n���p</param>
    ''' <returns>�������ʃf�[�^�e�[�u��</returns>
    ''' <remarks></remarks>
    Public Function GetDefDetails(ByVal strBtnStr As String, _
                                  ByVal dicParam As Dictionary(Of String, String)) As DataTable

        Dim strImageStatus As String      ' �����Ɏg�p����C���[�W�X�e�[�^�X

        ' �O��ʂŉ������ꂽ�{�^���ɂ��X�e�[�^�X�ύX
        Select Case strBtnStr
            Case "1"  ' �s���@
                strImageStatus = ConfigurationManager.AppSettings("DEF_CORR_1_STS")
            Case "2"  ' �s���A
                strImageStatus = ConfigurationManager.AppSettings("DEF_CORR_2_STS")
            Case Else  ' �{���Ȃ炱����ʂ邱�Ƃ͂Ȃ�
                strImageStatus = ""
        End Select

        Call Me.dbOpen()

        Try

            Dim stbSQL As New StringBuilder(String.Empty)

            'SQL�쐬
            stbSQL.AppendLine("   SELECT T_JJ_IMAGE.IMAGE_ID, ")
            stbSQL.AppendLine("          T_JJ_IMAGE.IMAGE_STATUS ")
            stbSQL.AppendLine("     FROM T_JJ_RECEIPT ")
            stbSQL.AppendLine("          INNER JOIN T_JJ_IMAGE ")
            stbSQL.AppendLine("             ON T_JJ_RECEIPT.RECEIPT_ID = T_JJ_IMAGE.RECEIPT_ID ")
            stbSQL.AppendLine("    WHERE T_JJ_IMAGE.IMAGE_STATUS IN (" & strImageStatus & ") ")
            stbSQL.AppendLine("      AND T_JJ_IMAGE.DELETE_FLG = '0' ")

            ' �p�����[�^�ݒ�
            Dim oraUpdateParam(dicParam.Count - 1) As OracleParameter
            Dim i As Integer = 0

            ' ��t��From�����������Ɏw�肳��Ă���ꍇ
            If dicParam.ContainsKey("RECEIPT_DATE_FROM") Then
                ' ��t��From�������ɐݒ�
                stbSQL.AppendLine("  AND  TO_CHAR(T_JJ_RECEIPT.RECEIPT_DATE,'YYYY/MM/DD') >= :RECEIPT_DATE_FROM ")

                oraUpdateParam(i) = New OracleParameter("RECEIPT_DATE_FROM", OracleDbType.Char)
                oraUpdateParam(i).Value = dicParam.Item("RECEIPT_DATE_FROM")

                i = i + 1
            End If

            ' ��t��To�����������Ɏw�肳��Ă���ꍇ
            If dicParam.ContainsKey("RECEIPT_DATE_TO") Then
                ' ��t��To�������ɐݒ�
                stbSQL.AppendLine("  AND  TO_CHAR(T_JJ_RECEIPT.RECEIPT_DATE,'YYYY/MM/DD') <= :RECEIPT_DATE_TO ")

                oraUpdateParam(i) = New OracleParameter("RECEIPT_DATE_TO", OracleDbType.Char)
                oraUpdateParam(i).Value = dicParam.Item("RECEIPT_DATE_TO")

                i = i + 1
            End If

            stbSQL.AppendLine(" ORDER BY T_JJ_IMAGE.PRIORITY, ")
            stbSQL.AppendLine("          T_JJ_RECEIPT.RECEIPT_DATE, ")
            stbSQL.AppendLine("          T_JJ_IMAGE.RECEIPT_ID, ")
            stbSQL.AppendLine("          T_JJ_IMAGE.IMAGE_ID ")

            Dim dt As DataTable = Me.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString, oraUpdateParam)

            ' SQL���O�o��
            clsUtility.WriteLog(Me.mobjCommonDB.GetInfoMessage, EventLogEntryType.Information)

            '���s
            Return dt

        Finally
            Me.mobjCommonDB.DB_Close()
        End Try

    End Function
#End Region

#Region " �s���f�[�^�ڍ׎擾 "
    ''' <summary>
    ''' �s���f�[�^�ڍ׎擾
    ''' </summary>
    ''' <param name="decImageId">�C���[�WID</param>
    ''' <returns>�������ʃf�[�^�e�[�u��</returns>
    ''' <remarks></remarks>
    Public Function GetDefDetail(ByVal decImageId As Decimal, Optional ByVal strMode As String = "0") As DataTable

        Call Me.dbOpen()

        Try

            Dim stbSQL As New StringBuilder(String.Empty)

            'SQL�쐬
            stbSQL.AppendLine("   SELECT LPAD(T_JJ_IMAGE.RECEIPT_ID,11,'0') AS RECEIPT_ID, ")
            stbSQL.AppendLine("          TRIM(T_JJ_IMAGE.IMAGE_FILE_NAME) AS IMAGE_FILE_NAME, ")
            stbSQL.AppendLine("          T_JJ_IMAGE.IMAGE_ID, ")
            stbSQL.AppendLine("          T_JJ_IMAGE.IMAGE_FILE_PATH, ")
            stbSQL.AppendLine("          T_JJ_IMAGE.SLIP_DEFINE_ID, ")
            stbSQL.AppendLine("          T_JJ_IMAGE.IMAGE_STATUS, ")
            stbSQL.AppendLine("          TO_CHAR(TO_DATE(BUSINESS_DATE),'YYYY/MM/DD') AS BUSINESS_DATE, ")
            stbSQL.AppendLine("          T_JJ_RECEIPT.RECEIPT_COUNT, ")
            stbSQL.AppendLine("          T_JJ_RECEIPT.RECEIPT_DATE, ")
            stbSQL.AppendLine("          NVL(T_JJ_IMAGE.DEF_REV_COUNT,0) AS DEF_REV_COUNT, ")
            stbSQL.AppendLine("          M_CM_ITEM.ITEM_ID, ")
            stbSQL.AppendLine("          M_CM_ITEM.ITEM_NAME, ")
            stbSQL.AppendLine("          M_CM_ITEM.ENTRY_COL_NAME, ")
            stbSQL.AppendLine("          M_CM_ITEM.IMAGE_FOCUS_X, ")
            stbSQL.AppendLine("          M_CM_ITEM.IMAGE_FOCUS_Y, ")
            stbSQL.AppendLine("          M_CM_ITEM.IMAGE_FOCUS_W, ")
            stbSQL.AppendLine("          M_CM_ITEM.IMAGE_FOCUS_H, ")
            stbSQL.AppendLine("          M_CM_ITEM.OPTION_CSSCLASS, ")
            stbSQL.AppendLine("          M_CM_ITEM.MASTER_COLUMNS, ")
            stbSQL.AppendLine("          M_CM_ITEM.ITEM_CHAR_COUNT, ")
            stbSQL.AppendLine("          M_CM_ITEM.ITEM_ATTRIBUTE_FLG, ")
            stbSQL.AppendLine("          V_JJ_ENTRY_CORRECTION.ITEM_DEF, ")
            stbSQL.AppendLine("          V_JJ_ENTRY_CORRECTION.ITEM, ")
            stbSQL.AppendLine("          M_CM_CONFIG.CONFIG_VALUE AS DEF_DIV_NAME, ")
            stbSQL.AppendLine("          (SELECT ")
            stbSQL.AppendLine("          	COUNT(ITEM_DEF) ")
            stbSQL.AppendLine("           FROM ")
            stbSQL.AppendLine("          	T_JJ_IMAGE ")
            stbSQL.AppendLine("          	LEFT JOIN V_JJ_ENTRY_CORRECTION ")
            stbSQL.AppendLine("          	  ON T_JJ_IMAGE.IMAGE_ID = V_JJ_ENTRY_CORRECTION.IMAGE_ID ")
            stbSQL.AppendLine("          	 AND V_JJ_ENTRY_CORRECTION.ITEM_DEF	<>	'00' ")
            stbSQL.AppendLine("           WHERE ")
            stbSQL.AppendLine("          		T_JJ_IMAGE.IMAGE_ID = :IMAGE_ID) AS DEF_REV_COL_COUNT ")
            stbSQL.AppendLine("     FROM T_JJ_RECEIPT ")
            stbSQL.AppendLine("          INNER JOIN T_JJ_IMAGE ")
            stbSQL.AppendLine("             ON T_JJ_RECEIPT.RECEIPT_ID = T_JJ_IMAGE.RECEIPT_ID ")
            stbSQL.AppendLine("          INNER JOIN M_CM_ITEM ")
            stbSQL.AppendLine("             ON T_JJ_IMAGE.SLIP_DEFINE_ID = M_CM_ITEM.SLIP_DEFINE_ID ")
            stbSQL.AppendLine("           LEFT JOIN V_JJ_ENTRY_CORRECTION ")
            stbSQL.AppendLine("             ON T_JJ_IMAGE.IMAGE_ID = V_JJ_ENTRY_CORRECTION.IMAGE_ID ")
            stbSQL.AppendLine("            AND M_CM_ITEM.ENTRY_COL_NAME = V_JJ_ENTRY_CORRECTION.ENTRY_COL_NAME ")
            stbSQL.AppendLine("           LEFT JOIN M_CM_CONFIG ")
            stbSQL.AppendLine("             ON M_CM_CONFIG.CONFIG_DIV = '" & CONFIG_DIV_DEF_DIV & "' ")
            stbSQL.AppendLine("            AND T_JJ_IMAGE.DEF_DIV = M_CM_CONFIG.CONFIG_ID ")
            stbSQL.AppendLine("    WHERE T_JJ_IMAGE.IMAGE_ID = :IMAGE_ID ")
            stbSQL.AppendLine("      AND M_CM_ITEM.DISPLAY_SORT_NO IS NOT NULL ")
            stbSQL.AppendLine(" ORDER BY M_CM_ITEM.DISPLAY_SORT_NO ")

            If strMode.Equals("1") Then
                stbSQL.Replace("V_JJ_ENTRY_CORRECTION", "V_JJ_ENTRY")
            End If

            ' �p�����[�^�ݒ�
            Dim oraUpdateParam(0) As OracleParameter

            '�C���[�WID�������ɐݒ�
            oraUpdateParam(0) = New OracleParameter("IMAGE_ID", OracleDbType.Decimal)
            oraUpdateParam(0).Value = decImageId

            Dim dt As DataTable = Me.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString, oraUpdateParam)

            ' SQL���O�o��
            clsUtility.WriteLog(Me.mobjCommonDB.GetInfoMessage, EventLogEntryType.Information)

            '���s
            Return dt

        Finally
            Me.mobjCommonDB.DB_Close()
        End Try

    End Function
#End Region

#Region " �C���[�W�X�e�[�^�X������� "
    ''' <summary>
    ''' �C���[�W�X�e�[�^�X�������
    ''' </summary>
    ''' <param name="decImageId">�C���[�WID</param>
    ''' <param name="strUserId">���[�UID</param>
    ''' <returns>�����Ώی���</returns>
    ''' <remarks></remarks>
    Public Function UpdateImageStatusRelease(ByVal decImageId As Decimal, ByVal strUserId As String) As Integer

        Dim stbSQL As New StringBuilder(String.Empty)

        Me.dbOpen()

        Try

            ' �C���[�W�X�e�[�^�X���X�V
            stbSQL.Length = 0
            stbSQL.AppendLine(" UPDATE T_JJ_IMAGE ")
            stbSQL.AppendLine("    SET IMAGE_STATUS = BEFORE_IMAGE_STATUS, ")
            stbSQL.AppendLine("        UPDATE_DATE = sysdate, ")
            stbSQL.AppendLine("        UPDATE_USER = :UPDATE_USER ")
            stbSQL.AppendLine("  WHERE IMAGE_ID = :IMAGE_ID ")

            ' �p�����[�^�ݒ�
            Dim oraUpdateParam(1) As OracleParameter

            oraUpdateParam(0) = New OracleParameter("UPDATE_USER", OracleDbType.Varchar2)
            oraUpdateParam(0).Value = strUserId
            oraUpdateParam(1) = New OracleParameter("IMAGE_ID", OracleDbType.Decimal)
            oraUpdateParam(1).Value = decImageId

            '���s
            Dim intResultCount As Integer = Me.mobjCommonDB.DB_ExecuteNonQuery(stbSQL.ToString, oraUpdateParam)

        Finally
            Me.mobjCommonDB.DB_Close()
        End Try

    End Function
#End Region

#Region " �C���[�W�X�e�[�^�X�X�V���� "
    ''' <summary>
    ''' �C���[�W�X�e�[�^�X�X�V����
    ''' </summary>
    ''' <param name="decImageId">�C���[�WID</param>
    ''' <param name="strUserId">���[�UID</param>
    ''' <param name="strImageStatus">�C���[�W�X�e�[�^�X</param>
    ''' <param name="strImageStatusBefore">�C���[�W�X�e�[�^�X�i�X�V�O�j</param>
    ''' <returns>�����Ώی���</returns>
    ''' <remarks></remarks>
    Private Function UpdateImageStatus(ByVal decImageId As Decimal, _
                                       ByVal strUserId As String, _
                                       ByVal strImageStatus As String, _
                                       Optional ByVal strImageStatusBefore As String = "") As Integer

        Dim stbSQL As New StringBuilder(String.Empty)

        ' �C���[�W�X�e�[�^�X���X�V
        stbSQL.Length = 0
        stbSQL.AppendLine(" UPDATE T_JJ_IMAGE ")
        stbSQL.AppendLine("    SET IMAGE_STATUS = :IMAGE_STATUS, ")
        stbSQL.AppendLine("        BEFORE_IMAGE_STATUS = IMAGE_STATUS, ")
        stbSQL.AppendLine("        UPDATE_DATE = sysdate, ")
        stbSQL.AppendLine("        UPDATE_USER = :UPDATE_USER ")
        stbSQL.AppendLine("  WHERE IMAGE_ID = :IMAGE_ID ")

        If Not String.IsNullOrEmpty(strImageStatusBefore) Then
            stbSQL.AppendLine("  AND IMAGE_STATUS = '" & strImageStatusBefore & "' ")
        End If

        ' �p�����[�^�ݒ�
        Dim oraUpdateParam(2) As OracleParameter

        oraUpdateParam(0) = New OracleParameter("IMAGE_STATUS", OracleDbType.Char)
        oraUpdateParam(0).Value = strImageStatus
        oraUpdateParam(1) = New OracleParameter("UPDATE_USER", OracleDbType.Varchar2)
        oraUpdateParam(1).Value = strUserId
        oraUpdateParam(2) = New OracleParameter("IMAGE_ID", OracleDbType.Decimal)
        oraUpdateParam(2).Value = decImageId

        ' ���s
        Dim intResultCount As Integer = Me.mobjCommonDB.DB_ExecuteNonQuery(stbSQL.ToString, oraUpdateParam)

        Return intResultCount

    End Function
#End Region

#Region " �C���[�W�����e�[�u���o�^���� "
    ''' <summary>
    ''' �C���[�W�����e�[�u���o�^����
    ''' </summary>
    ''' <param name="decImageId">�C���[�WID</param>
    ''' <param name="strUserId">���[�UID</param>
    ''' <param name="strImageStatus">�C���[�W�X�e�[�^�X</param>
    ''' <returns>�����Ώی���</returns>
    ''' <remarks></remarks>
    Private Function AddImageHistory(ByVal decImageId As Decimal, ByVal strUserId As String, ByVal strImageStatus As String) As Integer

        Dim stbSQL As New StringBuilder(String.Empty)

        ' �C���[�W�����e�[�u���ɒǉ�
        stbSQL.AppendLine(" INSERT INTO T_JJ_IMAGE_HISTORY ")
        stbSQL.AppendLine(" ( ")
        stbSQL.AppendLine("  IMAGE_ID, ")
        stbSQL.AppendLine("  IMAGE_STATUS, ")
        stbSQL.AppendLine("  CREATE_DATE, ")
        stbSQL.AppendLine("  CREATE_USER ")
        stbSQL.AppendLine(" ) ")
        stbSQL.AppendLine(" VALUES ")
        stbSQL.AppendLine(" ( ")
        stbSQL.AppendLine("  :IMAGE_ID, ")
        stbSQL.AppendLine("  :IMAGE_STATUS, ")
        stbSQL.AppendLine("  SYSDATE, ")
        stbSQL.AppendLine("  :CREATE_USER ")
        stbSQL.AppendLine(" ) ")

        ' �p�����[�^�ݒ�
        Dim oraUpdateParam(2) As OracleParameter

        oraUpdateParam(0) = New OracleParameter("IMAGE_ID", OracleDbType.Decimal)
        oraUpdateParam(0).Value = decImageId
        oraUpdateParam(1) = New OracleParameter("IMAGE_STATUS", OracleDbType.Char)
        oraUpdateParam(1).Value = strImageStatus
        oraUpdateParam(2) = New OracleParameter("CREATE_USER", OracleDbType.Varchar2)
        oraUpdateParam(2).Value = strUserId

        '���s
        Dim intResultCount As Integer = Me.mobjCommonDB.DB_ExecuteNonQuery(stbSQL.ToString, oraUpdateParam)

        Return intResultCount

    End Function
#End Region

#Region " �C���[�W�f�[�^�X�V "
    ''' <summary>
    ''' �C���[�W�f�[�^�X�V
    ''' </summary>
    ''' <param name="decImageId">�C���[�WID</param>
    ''' <param name="strUserId">���[�UID</param>
    ''' <param name="strImageStatusBefore">�C���[�W�X�e�[�^�X�i�X�V�O�j</param>
    ''' <param name="strImageStatusAfter">�C���[�W�X�e�[�^�X�i�X�V��j</param>
    ''' <param name="dt">����</param>
    ''' <param name="strBtnStr">�����{�^���X�e�[�^�X 1:�s���@ 2:�s���A</param>
    ''' <param name="intDefRevCount">�s��������</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function UpdateImageData(ByVal decImageId As Decimal, _
                                    ByVal strUserId As String, _
                                    ByVal strImageStatusBefore As String, _
                                    ByVal strImageStatusAfter As String, _
                                    ByVal dt As DataTable, _
                                    ByVal strBtnStr As String, _
                                    ByVal intDefRevCount As Integer) As Boolean

        Dim stbSQL As New StringBuilder(String.Empty)

        Try
            ' �f�[�^�x�[�X�ɐڑ�
            Call Me.dbOpen()

            ' �g�����U�N�V�����J�n
            Me.mobjCommonDB.DB_Transaction()

            ' �C���[�W�X�e�[�^�X�X�V
            ' �X�V�Ώی�����0���̏ꍇ�A�X�e�[�^�X����o�b�`�ɂ��C���[�W�X�e�[�^�X���ύX���ꂽ�Ƃ݂Ȃ��A
            ' ��ʏ�͍X�V������I�������悤�Ɍ����邪�A�f�[�^�x�[�X�ւ̓o�^�E�X�V�͍s��Ȃ��B
            If UpdateImageStatus(decImageId, strUserId, strImageStatusAfter, strImageStatusBefore) = 0 Then
                ' ���[���o�b�N
                Me.mobjCommonDB.DB_Rollback()

                Return True
            End If

            ' �C���[�W�����e�[�u���o�^
            AddImageHistory(decImageId, strUserId, strImageStatusAfter)

            ' �G���g���[�␳�e�[�u���X�V
            UpdateEntryCorrection(decImageId, strUserId, dt, strBtnStr, intDefRevCount)

            ' �����{�^���X�e�[�^�X���s���A�̏ꍇ
            Select Case strBtnStr
                Case "2"
                    ' �s�������񐔍X�V
                    UpdateDefRevCount(decImageId, strUserId, intDefRevCount)
            End Select

            ' �R�~�b�g
            Me.mobjCommonDB.DB_Commit()

            Return True

        Catch ex As Exception
            ' ���[���o�b�N
            Me.mobjCommonDB.DB_Rollback()

            Throw
        Finally
            Me.mobjCommonDB.DB_Close()
        End Try

    End Function
#End Region

#Region " �G���g���[�␳�e�[�u���X�V���� "
    ''' <summary>
    ''' �G���g���[�␳�e�[�u���X�V����
    ''' </summary>
    ''' <param name="decImageId">�C���[�WID</param>
    ''' <param name="strUserId">���[�UID</param>
    ''' <param name="dt">����</param>
    ''' <param name="strBtnStr">�����{�^���X�e�[�^�X 1:�s���@ 2:�s���A</param>
    ''' <param name="intDefRevCount">�s��������</param>
    ''' <returns>�����Ώی���</returns>
    ''' <remarks></remarks>
    Private Function UpdateEntryCorrection(ByVal decImageId As Decimal, _
                                           ByVal strUserId As String, _
                                           ByVal dt As DataTable, _
                                           Optional ByVal strBtnStr As String = "", _
                                           Optional ByVal intDefRevCount As Integer = 0) As Integer

        Dim stbSQL As New StringBuilder(String.Empty)
        Dim dr As DataRow
        Dim i As Integer

        ' �p�����[�^�ݒ�
        Dim oraUpdateParam(dt.Rows.Count + 1) As OracleParameter

        ' �G���g���[�␳�e�[�u�����X�V
        stbSQL.Length = 0
        stbSQL.AppendLine(" UPDATE T_JJ_ENTRY_CORRECTION ")
        stbSQL.AppendLine("    SET ")

        ' ���[���ڐ����X�V�J�����ݒ�
        For i = 0 To dt.Rows.Count - 1
            dr = dt.Rows(i)
            stbSQL.AppendLine(" " & dr("ENTRY_COL_NAME").ToString & "_DEF = '" & dr("ITEM_DEF").ToString & "', ")  ' �s���t���O
            stbSQL.AppendLine(" " & dr("ENTRY_COL_NAME").ToString & " = :ITEM" & i.ToString & ", ")          ' ����

            oraUpdateParam(i) = New OracleParameter("ITEM" & i.ToString, OracleDbType.NVarchar2)
            oraUpdateParam(i).Value = dr("ITEM").ToString

            ' �ύX�����������ڂ̂ݏ���
            If Not dr("ITEM").ToString.Equals(dr("ITEM_BEFORE").ToString) Then
                ' �C�������e�[�u���o�^
                AddRevHistory(decImageId, strUserId, strBtnStr, intDefRevCount, dr)
            End If

            ' �\�����莖���̕s���t���O�͗����ɓo�^���Ȃ�
            If Not dr("ITEM_ID").ToString.Equals("9999") Then
                ' �ύX�����������ڂ̂ݏ����i�s���t���O�Ή��j
                If Not dr("ITEM_DEF").ToString.Equals(dr("ITEM_DEF_BEFORE").ToString) Then
                    ' �C�������e�[�u���o�^
                    AddRevHistoryDef(decImageId, strUserId, strBtnStr, intDefRevCount, dr)
                End If
            End If
            
        Next

        stbSQL.AppendLine("        UPDATE_DATE = sysdate, ")
        stbSQL.AppendLine("        UPDATE_USER = :UPDATE_USER ")
        stbSQL.AppendLine("  WHERE IMAGE_ID = :IMAGE_ID ")

        oraUpdateParam(i) = New OracleParameter("UPDATE_USER", OracleDbType.Varchar2)
        oraUpdateParam(i).Value = strUserId
        oraUpdateParam(i + 1) = New OracleParameter("IMAGE_ID", OracleDbType.Decimal)
        oraUpdateParam(i + 1).Value = decImageId

        '���s
        Dim intResultCount As Integer = Me.mobjCommonDB.DB_ExecuteNonQuery(stbSQL.ToString, oraUpdateParam)

    End Function
#End Region

#Region " �C�������e�[�u���o�^���� "
    ''' <summary>
    ''' �C�������e�[�u���o�^����
    ''' </summary>
    ''' <param name="decImageId">�C���[�WID</param>
    ''' <param name="strUserId">���[�UID</param>
    ''' <param name="strBtnStr">�����{�^���X�e�[�^�X 1:�s���@ 2:�s���A</param>
    ''' <param name="intDefRevCount">�s��������</param>
    ''' <param name="dr">�Ώۍ��ڍs</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function AddRevHistory(ByVal decImageId As Decimal, _
                                   ByVal strUserId As String, _
                                   ByVal strBtnStr As String, _
                                   ByVal intDefRevCount As Integer, _
                                   ByVal dr As DataRow) As Integer

        Dim stbSQL As New StringBuilder(String.Empty)
        Dim strDefProCode As String    ' �s���H��

        ' �C�������e�[�u���ɒǉ�
        stbSQL.AppendLine(" INSERT INTO T_JJ_REV_HISTORY ")
        stbSQL.AppendLine(" ( ")
        stbSQL.AppendLine("  IMAGE_ID, ")
        stbSQL.AppendLine("  DEF_PRO_CODE, ")
        stbSQL.AppendLine("  DEF_REV_COUNT, ")
        stbSQL.AppendLine("  ITEM_ID, ")
        stbSQL.AppendLine("  ITEM_VALUE_BEFORE, ")
        stbSQL.AppendLine("  ITEM_VALUE_AFTER, ")
        stbSQL.AppendLine("  OPERETOR_ID, ")
        stbSQL.AppendLine("  END_TIME, ")
        stbSQL.AppendLine("  DELETE_FLG, ")
        stbSQL.AppendLine("  UPDATE_DATE, ")
        stbSQL.AppendLine("  UPDATE_USER ")
        stbSQL.AppendLine(" ) ")
        stbSQL.AppendLine(" VALUES ")
        stbSQL.AppendLine(" ( ")
        stbSQL.AppendLine("  :IMAGE_ID, ")
        stbSQL.AppendLine("  :DEF_PRO_CODE, ")
        stbSQL.AppendLine("  :DEF_REV_COUNT, ")
        stbSQL.AppendLine("  :ITEM_ID, ")
        stbSQL.AppendLine("  :ITEM_VALUE_BEFORE, ")
        stbSQL.AppendLine("  :ITEM_VALUE_AFTER, ")
        stbSQL.AppendLine("  :OPERETOR_ID, ")
        stbSQL.AppendLine("  SYSDATE, ")
        stbSQL.AppendLine("  '0', ")
        stbSQL.AppendLine("  SYSDATE, ")
        stbSQL.AppendLine("  :UPDATE_USER ")
        stbSQL.AppendLine(" ) ")

        ' �s�������{�^���ɉ����ĕs���H���ݒ�
        Select Case strBtnStr
            Case "1"  ' �s���@
                strDefProCode = "E"
            Case "2"  ' �s���A
                strDefProCode = "V"
            Case Else  ' �{��������ʂ邱�Ƃ͂Ȃ�
                strDefProCode = "Z"
        End Select

        ' �p�����[�^�ݒ�
        Dim oraUpdateParam(7) As OracleParameter

        oraUpdateParam(0) = New OracleParameter("IMAGE_ID", OracleDbType.Decimal)
        oraUpdateParam(0).Value = decImageId
        oraUpdateParam(1) = New OracleParameter("DEF_PRO_CODE", OracleDbType.Char)
        oraUpdateParam(1).Value = strBtnStr
        oraUpdateParam(2) = New OracleParameter("DEF_REV_COUNT", OracleDbType.Int16)
        oraUpdateParam(2).Value = intDefRevCount
        oraUpdateParam(3) = New OracleParameter("ITEM_ID", OracleDbType.Char)
        oraUpdateParam(3).Value = dr("ITEM_ID").ToString
        oraUpdateParam(4) = New OracleParameter("ITEM_VALUE_BEFORE", OracleDbType.Varchar2)
        oraUpdateParam(4).Value = dr("ITEM_BEFORE").ToString
        oraUpdateParam(5) = New OracleParameter("ITEM_VALUE_AFTER", OracleDbType.Varchar2)
        oraUpdateParam(5).Value = dr("ITEM").ToString
        oraUpdateParam(6) = New OracleParameter("OPERETOR_ID", OracleDbType.Char)
        oraUpdateParam(6).Value = strUserId
        oraUpdateParam(7) = New OracleParameter("UPDATE_USER", OracleDbType.Char)
        oraUpdateParam(7).Value = strUserId

        '���s
        Dim intResultCount As Integer = Me.mobjCommonDB.DB_ExecuteNonQuery(stbSQL.ToString, oraUpdateParam)

        Return intResultCount

    End Function
#End Region

#Region " �C�������e�[�u���o�^����(�s���t���O�p) "
    ''' <summary>
    ''' �C�������e�[�u���o�^����(�s���t���O�p)
    ''' </summary>
    ''' <param name="decImageId">�C���[�WID</param>
    ''' <param name="strUserId">���[�UID</param>
    ''' <param name="strBtnStr">�����{�^���X�e�[�^�X 1:�s���@ 2:�s���A</param>
    ''' <param name="intDefRevCount">�s��������</param>
    ''' <param name="dr">�Ώۍ��ڍs</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function AddRevHistoryDef(ByVal decImageId As Decimal, _
                                      ByVal strUserId As String, _
                                      ByVal strBtnStr As String, _
                                      ByVal intDefRevCount As Integer, _
                                      ByVal dr As DataRow) As Integer

        Dim stbSQL As New StringBuilder(String.Empty)
        Dim strDefProCode As String    ' �s���H��

        ' �C�������e�[�u���ɒǉ�
        stbSQL.AppendLine(" INSERT INTO T_JJ_REV_HISTORY ")
        stbSQL.AppendLine(" ( ")
        stbSQL.AppendLine("  IMAGE_ID, ")
        stbSQL.AppendLine("  DEF_PRO_CODE, ")
        stbSQL.AppendLine("  DEF_REV_COUNT, ")
        stbSQL.AppendLine("  ITEM_ID, ")
        stbSQL.AppendLine("  ITEM_VALUE_BEFORE, ")
        stbSQL.AppendLine("  ITEM_VALUE_AFTER, ")
        stbSQL.AppendLine("  OPERETOR_ID, ")
        stbSQL.AppendLine("  END_TIME, ")
        stbSQL.AppendLine("  DELETE_FLG, ")
        stbSQL.AppendLine("  UPDATE_DATE, ")
        stbSQL.AppendLine("  UPDATE_USER ")
        stbSQL.AppendLine(" ) ")
        stbSQL.AppendLine(" VALUES ")
        stbSQL.AppendLine(" ( ")
        stbSQL.AppendLine("  :IMAGE_ID, ")
        stbSQL.AppendLine("  :DEF_PRO_CODE, ")
        stbSQL.AppendLine("  :DEF_REV_COUNT, ")
        stbSQL.AppendLine("  :ITEM_ID, ")
        stbSQL.AppendLine("  :ITEM_VALUE_BEFORE, ")
        stbSQL.AppendLine("  :ITEM_VALUE_AFTER, ")
        stbSQL.AppendLine("  :OPERETOR_ID, ")
        stbSQL.AppendLine("  SYSDATE, ")
        stbSQL.AppendLine("  '0', ")
        stbSQL.AppendLine("  SYSDATE, ")
        stbSQL.AppendLine("  :UPDATE_USER ")
        stbSQL.AppendLine(" ) ")

        ' �s�������{�^���ɉ����ĕs���H���ݒ�
        Select Case strBtnStr
            Case "1"  ' �s���@
                strDefProCode = "E"
            Case "2"  ' �s���A
                strDefProCode = "V"
            Case Else  ' �{��������ʂ邱�Ƃ͂Ȃ�
                strDefProCode = "Z"
        End Select

        ' �p�����[�^�ݒ�
        Dim oraUpdateParam(7) As OracleParameter

        oraUpdateParam(0) = New OracleParameter("IMAGE_ID", OracleDbType.Decimal)
        oraUpdateParam(0).Value = decImageId
        oraUpdateParam(1) = New OracleParameter("DEF_PRO_CODE", OracleDbType.Char)
        oraUpdateParam(1).Value = strBtnStr
        oraUpdateParam(2) = New OracleParameter("DEF_REV_COUNT", OracleDbType.Int16)
        oraUpdateParam(2).Value = intDefRevCount
        oraUpdateParam(3) = New OracleParameter("ITEM_ID", OracleDbType.Char)
        oraUpdateParam(3).Value = dr("ITEM_ID").ToString & "DEF"
        oraUpdateParam(4) = New OracleParameter("ITEM_VALUE_BEFORE", OracleDbType.Varchar2)
        oraUpdateParam(4).Value = dr("ITEM_DEF_BEFORE").ToString
        oraUpdateParam(5) = New OracleParameter("ITEM_VALUE_AFTER", OracleDbType.Varchar2)
        oraUpdateParam(5).Value = dr("ITEM_DEF").ToString
        oraUpdateParam(6) = New OracleParameter("OPERETOR_ID", OracleDbType.Char)
        oraUpdateParam(6).Value = strUserId
        oraUpdateParam(7) = New OracleParameter("UPDATE_USER", OracleDbType.Char)
        oraUpdateParam(7).Value = strUserId

        '���s
        Dim intResultCount As Integer = Me.mobjCommonDB.DB_ExecuteNonQuery(stbSQL.ToString, oraUpdateParam)

        Return intResultCount

    End Function
#End Region

#Region " �s�������񐔍X�V���� "
    ''' <summary>
    ''' �s�������񐔍X�V����
    ''' </summary>
    ''' <param name="decImageId">�C���[�WID</param>
    ''' <param name="strUserId">���[�UID</param>
    ''' <param name="intDefRevCount">�s��������</param>
    ''' <returns>�����Ώی���</returns>
    ''' <remarks></remarks>
    Private Function UpdateDefRevCount(ByVal decImageId As Decimal, ByVal strUserId As String, ByVal intDefRevCount As Integer) As Integer

        Dim stbSQL As New StringBuilder(String.Empty)

        ' �C���[�W�X�e�[�^�X���X�V
        stbSQL.Length = 0
        stbSQL.AppendLine(" UPDATE T_JJ_IMAGE ")
        stbSQL.AppendLine("    SET DEF_REV_COUNT = :DEF_REV_COUNT, ")
        stbSQL.AppendLine("        UPDATE_DATE = sysdate, ")
        stbSQL.AppendLine("        UPDATE_USER = :UPDATE_USER ")
        stbSQL.AppendLine("  WHERE IMAGE_ID = :IMAGE_ID ")

        ' �p�����[�^�ݒ�
        Dim oraUpdateParam(2) As OracleParameter

        oraUpdateParam(0) = New OracleParameter("DEF_REV_COUNT", OracleDbType.Int16)
        oraUpdateParam(0).Value = intDefRevCount
        oraUpdateParam(1) = New OracleParameter("UPDATE_USER", OracleDbType.Varchar2)
        oraUpdateParam(1).Value = strUserId
        oraUpdateParam(2) = New OracleParameter("IMAGE_ID", OracleDbType.Decimal)
        oraUpdateParam(2).Value = decImageId

        '���s
        Dim intResultCount As Integer = Me.mobjCommonDB.DB_ExecuteNonQuery(stbSQL.ToString, oraUpdateParam)

    End Function
#End Region

#Region " �����ΏۃC���[�W�f�[�^���b�N���� "
    ''' <summary>
    ''' �����ΏۃC���[�W�f�[�^���b�N����
    ''' </summary>
    ''' <param name="decImageId">�C���[�WID</param>
    ''' <param name="strUserId">���[�UID</param>
    ''' <param name="strImageStr">�C���[�W�X�e�[�^�X</param>
    ''' <param name="strDataGetStr">�C���[�W�X�e�[�^�X(�f�[�^�擾���)</param>
    ''' <returns>True:���b�N���� False:���b�N���s</returns>
    ''' <remarks></remarks>
    Public Function SetImageForUpdate(ByVal decImageId As Decimal, ByVal strUserId As String, ByVal strImageStr As String, ByVal strDataGetStr As String) As Boolean

        Try

            Call Me.dbOpen()

            ' �g�����U�N�V�����J�n
            Me.mobjCommonDB.DB_Transaction()

            Dim stbSQL As New StringBuilder(String.Empty)

            'SQL�쐬
            stbSQL.AppendLine(" SELECT IMAGE_ID, ")
            stbSQL.AppendLine("        RECEIPT_ID, ")
            stbSQL.AppendLine("        IMAGE_STATUS, ")
            stbSQL.AppendLine("        IMAGE_FILE_NAME, ")
            stbSQL.AppendLine("        IMAGE_FILE_PATH, ")
            stbSQL.AppendLine("        IMAGE_STATE_FLG, ")
            stbSQL.AppendLine("        SLIP_DEFINE_ID, ")
            stbSQL.AppendLine("        BUSINESS_DATE, ")
            stbSQL.AppendLine("        PRIORITY, ")
            stbSQL.AppendLine("        ENTRY_DATE, ")
            stbSQL.AppendLine("        LOGIC_CHECK_DATE, ")
            stbSQL.AppendLine("        DEF_REV_COUNT, ")
            stbSQL.AppendLine("        DEF_DIV, ")
            stbSQL.AppendLine("        ESCA_FLG, ")
            stbSQL.AppendLine("        ESCA_CONF_DATE, ")
            stbSQL.AppendLine("        DELIVERY_DATE, ")
            stbSQL.AppendLine("        DELETE_FLG, ")
            stbSQL.AppendLine("        CREATE_DATE, ")
            stbSQL.AppendLine("        CREATE_USER, ")
            stbSQL.AppendLine("        UPDATE_DATE, ")
            stbSQL.AppendLine("        UPDATE_USER, ")
            stbSQL.AppendLine("        BEFORE_IMAGE_STATUS ")
            stbSQL.AppendLine("   FROM T_JJ_IMAGE ")
            stbSQL.AppendLine("  WHERE IMAGE_ID = :IMAGE_ID ")
            stbSQL.AppendLine("    AND IMAGE_STATUS = :IMAGE_STATUS ")
            stbSQL.AppendLine("    AND DELETE_FLG = '0' ")
            stbSQL.AppendLine(" FOR UPDATE OF IMAGE_ID NOWAIT ")

            ' �p�����[�^�ݒ�
            Dim oraForUpdateParam(1) As OracleParameter

            ' �����ɐݒ�
            oraForUpdateParam(0) = New OracleParameter("IMAGE_ID", OracleDbType.Decimal)
            oraForUpdateParam(0).Value = decImageId
            oraForUpdateParam(1) = New OracleParameter("IMAGE_STATUS", OracleDbType.Char)
            oraForUpdateParam(1).Value = strImageStr

            Dim dt As DataTable

            Try

                dt = Me.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString, oraForUpdateParam)

            Catch ex As OracleException  ' ���Ƀ��b�N���|�����Ă����ꍇ
                ' ���[���o�b�N
                Me.mobjCommonDB.DB_Rollback()

                Return False
            Finally
                ' SQL���O�o��
                clsUtility.WriteLog(Me.mobjCommonDB.GetInfoMessage, EventLogEntryType.Information)
            End Try

            ' �擾�f�[�^�����݂��Ȃ��ꍇ
            If dt.Rows.Count = 0 Then
                ' ���[���o�b�N
                Me.mobjCommonDB.DB_Rollback()

                Return False
            End If

            ' �C���[�W�X�e�[�^�X���f�[�^�擾�ɍX�V
            UpdateImageStatus(decImageId, strUserId, strDataGetStr)

            ' �C���[�W�����X�V
            AddImageHistory(decImageId, strUserId, strDataGetStr)

            ' �R�~�b�g
            Me.mobjCommonDB.DB_Commit()

            '���s
            Return True

        Catch ex As Exception
            ' ���[���o�b�N
            Me.mobjCommonDB.DB_Rollback()

            Throw
        Finally
            Me.mobjCommonDB.DB_Close()
        End Try

    End Function
#End Region

#Region " �G���g���[�񖼎擾 "
    ''' <summary>
    ''' �G���g���[�񖼎擾
    ''' </summary>
    ''' <param name="decImageId">�C���[�WID</param>
    ''' <param name="strItemId">����ID</param>
    ''' <returns>�G���g���[��</returns>
    ''' <remarks></remarks>
    Public Function GetEntryColName(ByVal decImageId As Decimal, ByVal strItemId As String) As String

        Call Me.dbOpen()

        Try

            Dim stbSQL As New StringBuilder(String.Empty)

            ' SQL�쐬
            stbSQL.AppendLine(" SELECT M_ITEM.ENTRY_COL_NAME ")
            stbSQL.AppendLine("   FROM T_JJ_IMAGE T_IMAGE ")
            stbSQL.AppendLine("        INNER JOIN M_CM_ITEM M_ITEM ")
            stbSQL.AppendLine("           ON T_IMAGE.SLIP_DEFINE_ID = M_ITEM.SLIP_DEFINE_ID ")
            stbSQL.AppendLine("  WHERE T_IMAGE.IMAGE_ID = :IMAGE_ID ")
            stbSQL.AppendLine("    AND M_ITEM.ITEM_ID   = :ITEM_ID ")

            ' �p�����[�^�ݒ�
            Dim oraUpdateParam(1) As OracleParameter

            ' ������ݒ�
            oraUpdateParam(0) = New OracleParameter("IMAGE_ID", OracleDbType.Decimal)
            oraUpdateParam(0).Value = decImageId
            oraUpdateParam(1) = New OracleParameter("ITEM_ID", OracleDbType.Varchar2)
            oraUpdateParam(1).Value = strItemId

            Dim dt As DataTable = Me.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString, oraUpdateParam)

            ' SQL���O�o��
            clsUtility.WriteLog(Me.mobjCommonDB.GetInfoMessage, EventLogEntryType.Information)

            ' ���s
            Return dt.Rows(0)(0).ToString

        Finally
            Me.mobjCommonDB.DB_Close()
        End Try

    End Function
#End Region

#Region " �G���g���[���e�擾 "
    ''' <summary>
    ''' �G���g���[���e�擾
    ''' </summary>
    ''' <param name="decImageId">�C���[�WID</param>
    ''' <param name="strEntryColName">�G���g���[��</param>
    ''' <returns>�������ʃf�[�^�e�[�u��</returns>
    ''' <remarks></remarks>
    Public Function GetEntry(ByVal decImageId As Decimal, ByVal strEntryColName As String) As DataTable

        Call Me.dbOpen()

        Try

            Dim stbSQL As New StringBuilder(String.Empty)

            ' SQL�쐬
            stbSQL.AppendLine(" SELECT T_ENTRY." & strEntryColName & " AS ENTRY_VALUE, ")
            stbSQL.AppendLine("        T_ENTRY." & strEntryColName & "_DEF AS ENTRY_DEF, ")
            stbSQL.AppendLine("        T_ENTRY.CREATE_USER || '/' || M_USER.USER_NAME AS OPERETOR, ")
            stbSQL.AppendLine("        T_ENTRY.CREATE_DATE ")
            stbSQL.AppendLine("   FROM T_JJ_ENTRY T_ENTRY ")
            stbSQL.AppendLine("        LEFT JOIN M_CM_USER M_USER ")
            stbSQL.AppendLine("          ON T_ENTRY.CREATE_USER = M_USER.USER_ID ")
            stbSQL.AppendLine("  WHERE T_ENTRY.IMAGE_ID = :IMAGE_ID ")

            ' �p�����[�^�ݒ�
            Dim oraUpdateParam(0) As OracleParameter

            ' ������ݒ�
            oraUpdateParam(0) = New OracleParameter("IMAGE_ID", OracleDbType.Decimal)
            oraUpdateParam(0).Value = decImageId

            Dim dt As DataTable = Me.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString, oraUpdateParam)

            ' SQL���O�o��
            clsUtility.WriteLog(Me.mobjCommonDB.GetInfoMessage, EventLogEntryType.Information)

            ' ���s
            Return dt

        Finally
            Me.mobjCommonDB.DB_Close()
        End Try

    End Function
#End Region

#Region " �C�������擾 "
    ''' <summary>
    ''' �C�������擾
    ''' </summary>
    ''' <param name="decImageId">�C���[�WID</param>
    ''' <param name="strItemId">����ID</param>
    ''' <returns>�������ʃf�[�^�e�[�u��</returns>
    ''' <remarks></remarks>
    Public Function GetRevHistory(ByVal decImageId As Decimal, ByVal strItemId As String) As DataTable

        Call Me.dbOpen()

        Try

            Dim stbSQL As New StringBuilder(String.Empty)

            ' SQL�쐬
            stbSQL.AppendLine("   SELECT REV_HISTORY.ITEM_ID, ")
            stbSQL.AppendLine("          REV_HISTORY.ITEM_VALUE_AFTER, ")
            stbSQL.AppendLine("          TRIM(REV_HISTORY.OPERETOR_ID) || '/' || M_USER.USER_NAME AS OPERETOR, ")
            stbSQL.AppendLine("          REV_HISTORY.END_TIME ")
            stbSQL.AppendLine("     FROM T_JJ_REV_HISTORY REV_HISTORY ")
            stbSQL.AppendLine("          LEFT JOIN M_CM_USER M_USER ")
            stbSQL.AppendLine("            ON TRIM(REV_HISTORY.OPERETOR_ID) = M_USER.USER_ID ")
            stbSQL.AppendLine("    WHERE REV_HISTORY.IMAGE_ID = :IMAGE_ID ")
            stbSQL.AppendLine("      AND REV_HISTORY.ITEM_ID LIKE :ITEM_ID ")
            stbSQL.AppendLine(" ORDER BY REV_HISTORY.END_TIME,REV_HISTORY.ITEM_ID ")

            ' �p�����[�^�ݒ�
            Dim oraUpdateParam(1) As OracleParameter

            ' ������ݒ�
            oraUpdateParam(0) = New OracleParameter("IMAGE_ID", OracleDbType.Decimal)
            oraUpdateParam(0).Value = decImageId
            oraUpdateParam(1) = New OracleParameter("ITEM_ID", OracleDbType.Varchar2)
            oraUpdateParam(1).Value = strItemId & "%"

            Dim dt As DataTable = Me.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString, oraUpdateParam)

            ' SQL���O�o��
            clsUtility.WriteLog(Me.mobjCommonDB.GetInfoMessage, EventLogEntryType.Information)

            ' ���s
            Return dt

        Finally
            Me.mobjCommonDB.DB_Close()
        End Try

    End Function
#End Region

End Class
