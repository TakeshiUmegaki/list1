﻿Imports System.Data
Imports Oracle.DataAccess.Client
Imports DefectManagement.clsConst

Public Class ImageViewDataAccess
    Inherits clsDbAccess

#Region "表示候補イメージ一覧の取得"
    ''' <summary>
    ''' 表示候補イメージ一覧の取得
    ''' </summary>
    ''' <param name="strImageId">イメージID</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetImageList(ByVal strImageId As String) As DataTable
        ' DB接続します
        Dim objclsDbAccess As New clsDbAccess

        Call objclsDbAccess.dbOpen()

        Try

            Dim stbSQL As New StringBuilder(String.Empty)

            ' SQL作成
            stbSQL.AppendLine("SELECT")
            stbSQL.AppendLine("     I.IMAGE_ID         AS IMAGE_ID")
            stbSQL.AppendLine("    ,M.SLIP_DEFINE_NAME AS SLIP_NAME")
            stbSQL.AppendLine("FROM")
            stbSQL.AppendLine("    T_JJ_IMAGE     I")
            stbSQL.AppendLine("    INNER JOIN")
            stbSQL.AppendLine("        M_SLIP_DEFINE M")
            stbSQL.AppendLine("    ON")
            stbSQL.AppendLine("        M.DELETE_FLG = '0'")
            stbSQL.AppendLine("        AND")
            stbSQL.AppendLine("        M.SLIP_DEFINE_ID = I.SLIP_DEFINE_ID")
            stbSQL.AppendLine("WHERE")
            stbSQL.AppendLine("    I.DELETE_FLG = '0'")
            stbSQL.AppendLine("    AND")

            stbSQL.AppendLine("    (")
            stbSQL.AppendLine("        I.EXC_SUBJECT_NO IN (")
            stbSQL.AppendLine("            SELECT")
            stbSQL.AppendLine("                II.EXC_SUBJECT_NO")
            stbSQL.AppendLine("            FROM")
            stbSQL.AppendLine("                T_JJ_IMAGE II")
            stbSQL.AppendLine("            WHERE")
            stbSQL.AppendLine("                II.DELETE_FLG = '0'")
            stbSQL.AppendLine("                AND")
            stbSQL.AppendLine("                II.IMAGE_ID   = :IMAGE_ID")
            stbSQL.AppendLine("        )")
            stbSQL.AppendLine("        OR")
            stbSQL.AppendLine("        I.IMAGE_ID = :IMAGE_ID")
            stbSQL.AppendLine("    )")

            stbSQL.AppendLine("ORDER BY")
            stbSQL.AppendLine("     M.SORT_NO")
            stbSQL.AppendLine("    ,I.IMAGE_ID")

            ' パラメータ設定
            Dim oraUpdateParam(0) As OracleParameter
            oraUpdateParam(0) = New OracleParameter("IMAGE_ID", OracleDbType.Decimal)
            oraUpdateParam(0).Value = strImageId

            Dim dt As DataTable = objclsDbAccess.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString, oraUpdateParam)

            ' SQLログ出力
            clsUtility.WriteLog(objclsDbAccess.mobjCommonDB.GetInfoMessage, EventLogEntryType.Information)

            ' 実行
            Return dt

        Finally
            objclsDbAccess.mobjCommonDB.DB_Close()
        End Try

    End Function
#End Region

#Region "表示対象イメージパスの取得"
    ''' <summary>
    ''' 表示対象イメージパスの取得
    ''' </summary>
    ''' <param name="strImageId">イメージID</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetImagePath(ByVal strImageId As String) As String
        ' DB接続します
        Dim objclsDbAccess As New clsDbAccess

        Call objclsDbAccess.dbOpen()

        Try

            Dim stbSQL As New StringBuilder(String.Empty)

            ' SQL作成
            stbSQL.AppendLine("SELECT")
            stbSQL.AppendLine("     I.IMAGE_FILE_PATH")
            stbSQL.AppendLine("    ,I.IMAGE_FILE_NAME")
            stbSQL.AppendLine("FROM")
            stbSQL.AppendLine("    T_JJ_IMAGE     I")
            stbSQL.AppendLine("WHERE")
            stbSQL.AppendLine("    I.DELETE_FLG = '0'")
            stbSQL.AppendLine("    AND")
            stbSQL.AppendLine("    I.IMAGE_ID = :IMAGE_ID")

            ' パラメータ設定
            Dim oraUpdateParam(0) As OracleParameter
            oraUpdateParam(0) = New OracleParameter("IMAGE_ID", OracleDbType.Decimal)
            oraUpdateParam(0).Value = strImageId

            Dim dt As DataTable = objclsDbAccess.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString, oraUpdateParam)
            If dt.Rows.Count <> 1 Then
                Return String.Empty
            End If

            ' SQLログ出力
            clsUtility.WriteLog(objclsDbAccess.mobjCommonDB.GetInfoMessage, EventLogEntryType.Information)

            ' 実行
            Dim strPath As String = Convert.ToString(dt.Rows(0).Item("IMAGE_FILE_PATH")).Trim
            Dim strName As String = Convert.ToString(dt.Rows(0).Item("IMAGE_FILE_NAME")).Trim
            Dim strImage As String = IO.Path.Combine(strPath, strName)

            Return strImage

        Finally
            objclsDbAccess.mobjCommonDB.DB_Close()
        End Try

    End Function
#End Region

End Class
