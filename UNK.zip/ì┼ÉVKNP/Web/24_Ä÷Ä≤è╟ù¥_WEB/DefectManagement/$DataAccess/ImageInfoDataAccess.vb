Imports System.Data
Imports Oracle.DataAccess.Client
Imports DefectManagement.clsConst

Public Class ImageInfoDataAccess

#Region " �C���[�W���擾 "
    ''' <summary>
    ''' �C���[�W���擾
    ''' </summary>
    ''' <param name="strImageId">�C���[�WID</param>
    ''' <returns>�������ʃf�[�^�e�[�u��</returns>
    ''' <remarks></remarks>
    Public Function GetImageInfo(ByVal strImageId As String) As DataTable

        ' DB�ڑ����܂�
        Dim objclsDbAccess As New clsDbAccess

        Call objclsDbAccess.dbOpen()

        Try
            Dim stbSQL As New StringBuilder(String.Empty)

            'SQL�쐬
            stbSQL.AppendLine(" SELECT")
            stbSQL.AppendLine(" T_JJ_IMAGE.IMAGE_ID")           '�C���[�WID
            stbSQL.AppendLine(",T_JJ_IMAGE.RECEIPT_ID")         '��tID
            stbSQL.AppendLine(",CASE")
            stbSQL.AppendLine("     WHEN T_JJ_IMAGE.IMAGE_STATUS IS NULL THEN ''")
            stbSQL.AppendLine("     ELSE T_JJ_IMAGE.IMAGE_STATUS || ':' || M_CM_CONFIG_IS.CONFIG_VALUE")
            stbSQL.AppendLine("     END IMAGE_STATUS")          '�C���[�W�X�e�[�^�X
            stbSQL.AppendLine(",T_JJ_IMAGE.IMAGE_FILE_NAME")    '�C���[�W�t�@�C����
            stbSQL.AppendLine(",T_JJ_IMAGE.IMAGE_FILE_PATH")    '�C���[�W�t�@�C���p�X
            stbSQL.AppendLine(",CASE")
            stbSQL.AppendLine("     WHEN T_JJ_IMAGE.IMAGE_STATE_FLG IS NULL THEN ''")
            stbSQL.AppendLine("     ELSE T_JJ_IMAGE.IMAGE_STATE_FLG || ':' || M_CM_CONFIG_ISF.CONFIG_VALUE")
            stbSQL.AppendLine("     END IMAGE_STATE_FLG")       '�C���[�W��ԃt���O
            stbSQL.AppendLine(",T_JJ_IMAGE.SLIP_DEFINE_ID AS SLIP_DEFINE")  '���[���ID
            stbSQL.AppendLine(",CASE")
            stbSQL.AppendLine("     WHEN T_JJ_IMAGE.SLIP_DEFINE_ID IS NULL THEN ''")
            stbSQL.AppendLine("     ELSE T_JJ_IMAGE.SLIP_DEFINE_ID || '�F' || M_SLIP_DEFINE_SDI.SLIP_DEFINE_NAME")
            stbSQL.AppendLine("     END SLIP_DEFINE_ID")        '���[���ID
            stbSQL.AppendLine(",T_JJ_IMAGE.BUSINESS_DATE")      '�Ɩ����t
            stbSQL.AppendLine(",CASE")
            stbSQL.AppendLine("     WHEN T_JJ_IMAGE.PRIORITY IS NULL THEN ''")
            stbSQL.AppendLine("     ELSE T_JJ_IMAGE.PRIORITY || '�F' || M_CM_CONFIG_P.CONFIG_VALUE")
            stbSQL.AppendLine("     END PRIORITY")              '�D��x
            stbSQL.AppendLine(",T_JJ_IMAGE.EXC_SUBJECT_NO")     '�Č��ԍ�
            stbSQL.AppendLine(",T_JJ_IMAGE.EXC_IMAGE_NO")       '�C���[�W�ԍ�
            stbSQL.AppendLine(",T_JJ_IMAGE.ENTRY_DATE")         '�G���g���[��������
            stbSQL.AppendLine(",T_JJ_IMAGE.DEF_REV_COUNT")      '�s��������
            stbSQL.AppendLine(",T_JJ_IMAGE.DELIVERY_DATE")      '�[�i����
            stbSQL.AppendLine(",T_JJ_IMAGE.EXC_IMAGE_KEY01")    '�ėp����1
            stbSQL.AppendLine(",T_JJ_IMAGE.EXC_IMAGE_KEY02")    '�ėp����2
            stbSQL.AppendLine(",T_JJ_IMAGE.DELETE_FLG")         '�폜�t���O
            stbSQL.AppendLine(",T_JJ_IMAGE.CREATE_DATE")        '�o�^����
            stbSQL.AppendLine(",T_JJ_IMAGE.CREATE_USER")        '�o�^���[�U�[
            stbSQL.AppendLine(",T_JJ_IMAGE.UPDATE_DATE")        '�X�V����
            stbSQL.AppendLine(",T_JJ_IMAGE.UPDATE_USER")        '�X�V���[�U�[
            stbSQL.AppendLine(" FROM T_JJ_IMAGE")
            stbSQL.AppendLine("	LEFT JOIN M_SLIP_DEFINE�@M_SLIP_DEFINE_SDI")    '���[��ރ}�X�^
            stbSQL.AppendLine("		ON T_JJ_IMAGE.SLIP_DEFINE_ID = M_SLIP_DEFINE_SDI.SLIP_DEFINE_ID")
            '�ݒ�l�}�X�^
            stbSQL.AppendLine("	LEFT JOIN M_CM_CONFIG M_CM_CONFIG_IS")      '�C���[�W�X�e�[�^�X
            stbSQL.AppendLine("		ON T_JJ_IMAGE.IMAGE_STATUS = M_CM_CONFIG_IS.CONFIG_ID")
            stbSQL.AppendLine("		AND M_CM_CONFIG_IS.CONFIG_DIV = '" & clsConst.CONFIG_DIV_IMAGE_STATUS & "'")
            stbSQL.AppendLine("	LEFT JOIN M_CM_CONFIG M_CM_CONFIG_ISF")     '�C���[�W��ԃt���O
            stbSQL.AppendLine("		ON T_JJ_IMAGE.IMAGE_STATE_FLG = M_CM_CONFIG_ISF.CONFIG_ID")
            stbSQL.AppendLine("		AND M_CM_CONFIG_ISF.CONFIG_DIV = '" & clsConst.CONFIG_DIV_IMAGE_STATE_FLG & "'")

            stbSQL.AppendLine("	LEFT JOIN M_CM_CONFIG M_CM_CONFIG_P")       '�D��x
            stbSQL.AppendLine("		ON T_JJ_IMAGE.PRIORITY = M_CM_CONFIG_P.CONFIG_ID")
            stbSQL.AppendLine("		AND M_CM_CONFIG_P.CONFIG_DIV = '" & clsConst.CONFIG_DIV_PRIORITY & "'")
            stbSQL.AppendLine(" WHERE T_JJ_IMAGE.IMAGE_ID = :IMAGE_ID")

            '�p�����[�^�ݒ�
            Dim oraUpdateParam(0) As OracleParameter
            oraUpdateParam(0) = New OracleParameter("IMAGE_ID", OracleDbType.Int64)
            oraUpdateParam(0).Value = strImageId

            Dim dt As DataTable = objclsDbAccess.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString, oraUpdateParam)

            ' SQL���O�o��
            clsUtility.WriteLog(objclsDbAccess.mobjCommonDB.GetInfoMessage, EventLogEntryType.Information)

            '���s
            Return dt

        Finally
            objclsDbAccess.mobjCommonDB.DB_Close()
        End Try

    End Function

#End Region

#Region " �ėp���ڎ擾 "
    ''' <summary>
    ''' �ėp���ڎ擾
    ''' </summary>
    ''' <param name="strSlipDefineId">���[���ID</param>
    ''' <returns>�������ʃf�[�^�e�[�u��</returns>
    ''' <remarks></remarks>
    Public Function GetExcItemName(ByVal strSlipDefineId As String) As DataTable

        ' DB�ڑ����܂�
        Dim objclsDbAccess As New clsDbAccess

        Call objclsDbAccess.dbOpen()

        Try
            Dim stbSQL As New StringBuilder(String.Empty)

            'SQL�쐬
            stbSQL.AppendLine(" SELECT")
            stbSQL.AppendLine(" M_CM_EXC_ITEM.ITEM_CODE") '���ڃR�[�h
            stbSQL.AppendLine(",M_CM_EXC_ITEM.ITEM_NAME") '���ږ�
            stbSQL.AppendLine(" FROM M_CM_EXC_ITEM")
            stbSQL.AppendLine(" WHERE M_CM_EXC_ITEM.SLIP_DEFINE_ID = :SLIP_DEFINE_ID")
            stbSQL.AppendLine(" ORDER BY M_CM_EXC_ITEM.ITEM_CODE")

            '�p�����[�^�ݒ�
            Dim oraUpdateParam(0) As OracleParameter
            oraUpdateParam(0) = New OracleParameter("SLIP_DEFINE_ID", OracleDbType.Int64)
            oraUpdateParam(0).Value = strSlipDefineId

            Dim dt As DataTable = objclsDbAccess.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString, oraUpdateParam)

            ' SQL���O�o��
            clsUtility.WriteLog(objclsDbAccess.mobjCommonDB.GetInfoMessage, EventLogEntryType.Information)

            '���s
            Return dt

        Finally
            objclsDbAccess.mobjCommonDB.DB_Close()
        End Try

    End Function

#End Region

End Class
