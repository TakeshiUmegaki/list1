Imports System.Data
Imports Oracle.DataAccess.Client
Imports DefectManagement.clsConst

Public Class ReceiptDataCountDataAccess

    Public Function GetList(ByVal dicParam As Dictionary(Of String, String)) As DataTable

        ' DB�ڑ����܂�
        Dim objclsDbAccess As New clsDbAccess

        Call objclsDbAccess.dbOpen()

        Try
            Dim strFrom As String = GetDateFrom(objclsDbAccess, dicParam)
            Dim strTo As String = GetDateTo(objclsDbAccess, dicParam)
            Dim dtCal As DataTable = GetCalender(objclsDbAccess, strFrom, strTo)

            Dim dtImage As DataTable = GetImageData(objclsDbAccess, dicParam)
            Dim lstDate As New List(Of String)
            Dim dicDate As New Dictionary(Of String, String())
            Dim dicSub As New Dictionary(Of String, Integer())
            Dim dicImg As New Dictionary(Of String, Integer())

            For Each dr As DataRow In dtImage.Rows

                Dim strRcp() As String = Split(Convert.ToString(dr.Item("CREATE_DATE")), " ")
                If strRcp(1) < "09:30" Then
                    strRcp(0) = GetPrevDate(dtCal, strRcp(0))
                    strRcp(1) = "18:30"
                End If

                If Not dicDate.ContainsKey(strRcp(0)) Then
                    Dim strTime(9) As String
                    For i As Integer = 0 To strTime.Length - 1 Step 1
                        strTime(i) = String.Empty
                    Next
                    dicDate.Add(strRcp(0), strTime)
                    lstDate.Add(strRcp(0))
                End If

                If Not dicSub.ContainsKey(strRcp(0)) Then
                    Dim intSub(10) As Integer
                    Dim intImg(10) As Integer
                    For i As Integer = 0 To intSub.Length - 1 Step 1
                        intSub(i) = 0
                    Next
                    For i As Integer = 0 To intImg.Length - 1 Step 1
                        intImg(i) = 0
                    Next
                    dicSub.Add(strRcp(0), intSub)
                    dicImg.Add(strRcp(0), intImg)
                    'lstDate.Add(strRcp(0))
                End If

                ' ��t���ԕʎ�t�f�[�^���̏W�v���Ԕ͈͎擾
                Dim str0930() As String = ConfigurationManager.AppSettings("REC_TIME_RANGE_0930").Split(",")
                Dim str1030() As String = ConfigurationManager.AppSettings("REC_TIME_RANGE_1030").Split(",")
                Dim str1130() As String = ConfigurationManager.AppSettings("REC_TIME_RANGE_1130").Split(",")
                Dim str1230() As String = ConfigurationManager.AppSettings("REC_TIME_RANGE_1230").Split(",")
                Dim str1330() As String = ConfigurationManager.AppSettings("REC_TIME_RANGE_1330").Split(",")
                Dim str1430() As String = ConfigurationManager.AppSettings("REC_TIME_RANGE_1430").Split(",")
                Dim str1530() As String = ConfigurationManager.AppSettings("REC_TIME_RANGE_1530").Split(",")
                Dim str1630() As String = ConfigurationManager.AppSettings("REC_TIME_RANGE_1630").Split(",")
                Dim str1730() As String = ConfigurationManager.AppSettings("REC_TIME_RANGE_1730").Split(",")
                Dim str1830() As String = ConfigurationManager.AppSettings("REC_TIME_RANGE_1830").Split(",")

                Dim intIndex As Integer = 0
                Select Case strRcp(1)
                    Case str0930(0) To str0930(1)
                        intIndex = 0
                    Case str1030(0) To str1030(1)
                        intIndex = 1
                    Case str1130(0) To str1130(1)
                        intIndex = 2
                    Case str1230(0) To str1230(1)
                        intIndex = 3
                    Case str1330(0) To str1330(1)
                        intIndex = 4
                    Case str1430(0) To str1430(1)
                        intIndex = 5
                    Case str1530(0) To str1530(1)
                        intIndex = 6
                    Case str1630(0) To str1630(1)
                        intIndex = 7
                    Case str1730(0) To str1730(1)
                        intIndex = 8
                    Case Else
                        intIndex = 9
                End Select

                'Dim strDelv As String = Convert.ToString(dr.Item("DELIVERY_DATE"))
                dicSub(strRcp(0))(intIndex) += Convert.ToInt32(dr.Item("SUB_CNT"))
                dicImg(strRcp(0))(intIndex) += Convert.ToInt32(dr.Item("IMG_CNT"))
            Next

            Dim dtRslt As DataTable = MakeResultTable()
            For Each strDlvDate As String In lstDate
                Dim strTemp() As String = Split(strDlvDate, "/")
                Dim strDate As String = strTemp(1) & "��" & strTemp(2) & "��"

                Dim dr1 As DataRow = dtRslt.NewRow
                dr1.Item(0) = strDate
                dr1.Item(1) = "�Č���"

                Dim dr2 As DataRow = dtRslt.NewRow
                dr2.Item(0) = strDate
                dr2.Item(1) = "�C���[�W��"

                Dim intTotal1 As Integer = 0
                Dim intTotal2 As Integer = 0
                For i As Integer = 0 To 9 Step 1
                    dr1.Item(3 + i) = dicSub(strDlvDate)(i).ToString
                    dr2.Item(3 + i) = dicImg(strDlvDate)(i).ToString
                    intTotal1 += dicSub(strDlvDate)(i)
                    intTotal2 += dicImg(strDlvDate)(i)
                Next
                dr1.Item(2) = intTotal1.ToString
                dr2.Item(2) = intTotal2.ToString

                dtRslt.Rows.Add(dr1)
                dtRslt.Rows.Add(dr2)
            Next

            Return dtRslt

        Finally
            objclsDbAccess.mobjCommonDB.DB_Close()
        End Try
    End Function

    Private Function MakeResultTable() As DataTable
        Dim dtRslt As New DataTable
        dtRslt.Columns.Add("RECEIPT_DATE", GetType(System.String))
        dtRslt.Columns.Add("TITLE", GetType(System.String))
        dtRslt.Columns.Add("TOTAL", GetType(System.String))
        dtRslt.Columns.Add("ITEM_0930", GetType(System.String))
        dtRslt.Columns.Add("ITEM_1030", GetType(System.String))
        dtRslt.Columns.Add("ITEM_1130", GetType(System.String))
        dtRslt.Columns.Add("ITEM_1230", GetType(System.String))
        dtRslt.Columns.Add("ITEM_1330", GetType(System.String))
        dtRslt.Columns.Add("ITEM_1430", GetType(System.String))
        dtRslt.Columns.Add("ITEM_1530", GetType(System.String))
        dtRslt.Columns.Add("ITEM_1630", GetType(System.String))
        dtRslt.Columns.Add("ITEM_1730", GetType(System.String))
        dtRslt.Columns.Add("ITEM_1830", GetType(System.String))

        Return dtRslt
    End Function

    Private Function GetDateFrom(ByVal objclsDbAccess As clsDbAccess, ByVal dicParam As Dictionary(Of String, String)) As String
        Dim stbSQL As New StringBuilder(String.Empty)
        stbSQL.AppendLine("SELECT")
        stbSQL.AppendLine("    MAX(YYYYMMDD)")
        stbSQL.AppendLine("FROM")
        stbSQL.AppendLine("    M_CM_HOLIDAY")
        stbSQL.AppendLine("WHERE")
        stbSQL.AppendLine("    YYYYMMDD < '%DateFrom%'")
        stbSQL.AppendLine("    AND")
        stbSQL.AppendLine("    HOLIDAY = '0'")
        stbSQL.Replace("%DateFrom%", dicParam("RECEIPT_DATE_FROM").Replace("/", String.Empty))

        Dim dtCal As DataTable = objclsDbAccess.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)
        Dim strCal As String = Convert.ToString(dtCal.Rows(0).Item(0))

        Return strCal.Substring(0, 4) & "/" & _
               strCal.Substring(4, 2) & "/" & _
               strCal.Substring(6, 2)
    End Function

    Private Function GetDateTo(ByVal objclsDbAccess As clsDbAccess, ByVal dicParam As Dictionary(Of String, String)) As String
        Dim stbSQL As New StringBuilder(String.Empty)
        stbSQL.AppendLine("SELECT")
        stbSQL.AppendLine("    MIN(YYYYMMDD)")
        stbSQL.AppendLine("FROM")
        stbSQL.AppendLine("    M_CM_HOLIDAY")
        stbSQL.AppendLine("WHERE")
        stbSQL.AppendLine("    YYYYMMDD > '%DateTo%'")
        stbSQL.AppendLine("    AND")
        stbSQL.AppendLine("    HOLIDAY = '0'")
        stbSQL.Replace("%DateTo%", dicParam("RECEIPT_DATE_TO").Replace("/", String.Empty))

        Dim dtCal As DataTable = objclsDbAccess.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)
        Dim strCal As String = Convert.ToString(dtCal.Rows(0).Item(0))

        Return strCal.Substring(0, 4) & "/" & _
               strCal.Substring(4, 2) & "/" & _
               strCal.Substring(6, 2)
    End Function

    Private Function GetCalender(ByVal objclsDbAccess As clsDbAccess, ByVal strDateFrom As String, ByVal strDateTo As String) As DataTable

        Dim stbSQL As New StringBuilder(String.Empty)
        stbSQL.AppendLine("SELECT")
        stbSQL.AppendLine("    YYYYMMDD")
        stbSQL.AppendLine("FROM")
        stbSQL.AppendLine("    M_CM_HOLIDAY")
        stbSQL.AppendLine("WHERE")
        stbSQL.AppendLine("    YYYYMMDD >= '%DateFrom%'")
        stbSQL.AppendLine("    AND")
        stbSQL.AppendLine("    HOLIDAY = '0'")
        stbSQL.AppendLine("ORDER BY")
        stbSQL.AppendLine("    YYYYMMDD")
        stbSQL.Replace("%DateFrom%", strDateFrom.Replace("/", String.Empty))
        stbSQL.Replace("%DateTo%", strDateTo.Replace("/", String.Empty))

        Dim dtCal As DataTable = objclsDbAccess.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)

        Return dtCal
    End Function

    Private Function GetImageData(ByVal objclsDbAccess As clsDbAccess, ByVal dicParam As Dictionary(Of String, String)) As DataTable

        ' �J�n���t���擾
        Dim stbFrom As New StringBuilder(dicParam("RECEIPT_DATE_FROM"))
        stbFrom.Append(" ")
        If dicParam.ContainsKey("RECEIPT_TIME_FROM") Then
            Dim strHH As String = Convert.ToInt32(Split(dicParam("RECEIPT_TIME_FROM"), ":")(0)).ToString("00")
            Dim strMI As String = Convert.ToInt32(Split(dicParam("RECEIPT_TIME_FROM"), ":")(1)).ToString("00")
            stbFrom.Append(strHH & ":" & strMI)
        Else
            stbFrom.Append("00:00")
        End If

        ' �I�����t���擾
        Dim stbTo As New StringBuilder(String.Empty)
        If dicParam.ContainsKey("RECEIPT_DATE_TO") Then
            stbTo.Append(dicParam("RECEIPT_DATE_TO"))
            stbTo.Append(" ")
            If dicParam.ContainsKey("RECEIPT_TIME_TO") Then
                Dim strHH As String = Convert.ToInt32(Split(dicParam("RECEIPT_TIME_TO"), ":")(0)).ToString("00")
                Dim strMI As String = Convert.ToInt32(Split(dicParam("RECEIPT_TIME_TO"), ":")(1)).ToString("00")
                stbTo.Append(strHH & ":" & strMI)
            Else
                stbTo.Append("23:59")
            End If
        End If

        Dim stbSQL As New StringBuilder(String.Empty)
        Dim strTargetSlip As String = ConfigurationManager.AppSettings("TARGET_SLIP")

        stbSQL.AppendLine("   SELECT BDAT.RECEIPT_DATE   AS CREATE_DATE, ")
        stbSQL.AppendLine("          NVL(SUBD.SUB_CNT,0) AS SUB_CNT, ")
        stbSQL.AppendLine("          NVL(IMGD.IMG_CNT,0) AS IMG_CNT ")
        stbSQL.AppendLine("     FROM ( ")
        stbSQL.AppendLine("           SELECT DISTINCT ")
        stbSQL.AppendLine("                  TO_CHAR(T_JJ_RECEIPT.RECEIPT_DATE, 'YYYY/MM/DD HH24:MI') AS RECEIPT_DATE ")
        stbSQL.AppendLine("             FROM T_JJ_RECEIPT ")
        stbSQL.AppendLine("                  INNER JOIN T_JJ_IMAGE ")
        stbSQL.AppendLine("                     ON T_JJ_RECEIPT.RECEIPT_ID = T_JJ_IMAGE.RECEIPT_ID ")
        stbSQL.AppendLine("            WHERE TO_CHAR(T_JJ_RECEIPT.RECEIPT_DATE, 'YYYY/MM/DD HH24:MI') >= '" & stbFrom.ToString & "'")

        If stbTo.Length > 0 Then
            stbSQL.AppendLine("              AND TO_CHAR(T_JJ_RECEIPT.RECEIPT_DATE, 'YYYY/MM/DD HH24:MI') <= '" & stbTo.ToString & "'")
        End If

        ' config�̑Ώے��[�Ɂu641�v���܂܂�Ă���ꍇ�͔�SS�A�܂܂�Ă��Ȃ��ꍇ��SS�Ƃ݂Ȃ�
        If strTargetSlip.Contains(SLIP_DEFINE_ID_NON_SS) Then
            stbSQL.AppendLine("              AND ( ")
            stbSQL.AppendLine("                      T_JJ_IMAGE.SLIP_DEFINE_ID LIKE '641%' ")
            stbSQL.AppendLine("                   OR T_JJ_IMAGE.SLIP_DEFINE_ID LIKE '661%' ")
            stbSQL.AppendLine("                  ) ")
        Else
            stbSQL.AppendLine("              AND ( ")
            stbSQL.AppendLine("                      T_JJ_IMAGE.SLIP_DEFINE_ID LIKE '601%' ")
            stbSQL.AppendLine("                   OR T_JJ_IMAGE.SLIP_DEFINE_ID LIKE '611%' ")
            stbSQL.AppendLine("                   OR T_JJ_IMAGE.SLIP_DEFINE_ID LIKE '621%' ")
            stbSQL.AppendLine("                   OR T_JJ_IMAGE.SLIP_DEFINE_ID LIKE '631%' ")
            stbSQL.AppendLine("                  ) ")
        End If

        stbSQL.AppendLine("              AND T_JJ_IMAGE.DELETE_FLG = '0' ")
        stbSQL.AppendLine("          ) BDAT ")
        stbSQL.AppendLine("          INNER JOIN ( ")
        stbSQL.AppendLine("                        SELECT RECEIPT_DATE AS RECEIPT_DATE, ")
        stbSQL.AppendLine("                               COUNT(*)    AS SUB_CNT ")
        stbSQL.AppendLine("                          FROM ( ")
        stbSQL.AppendLine("                                SELECT DISTINCT ")
        stbSQL.AppendLine("                                       TO_CHAR(T_JJ_RECEIPT.RECEIPT_DATE, 'YYYY/MM/DD HH24:MI') AS RECEIPT_DATE, ")
        stbSQL.AppendLine("                                       T_JJ_IMAGE.EXC_SUBJECT_NO                                AS EXC_SUBJECT_NO ")
        stbSQL.AppendLine("                                  FROM T_JJ_RECEIPT ")
        stbSQL.AppendLine("                                       INNER JOIN T_JJ_IMAGE ")
        stbSQL.AppendLine("                                          ON T_JJ_RECEIPT.RECEIPT_ID = T_JJ_IMAGE.RECEIPT_ID ")
        stbSQL.AppendLine("                                 WHERE TO_CHAR(T_JJ_RECEIPT.RECEIPT_DATE, 'YYYY/MM/DD HH24:MI') >= '" & stbFrom.ToString & "'")

        If stbTo.Length > 0 Then
            stbSQL.AppendLine("                                   AND TO_CHAR(T_JJ_RECEIPT.RECEIPT_DATE, 'YYYY/MM/DD HH24:MI') <= '" & stbTo.ToString & "'")
        End If

        ' config�̑Ώے��[�Ɂu641�v���܂܂�Ă���ꍇ�͔�SS�A�܂܂�Ă��Ȃ��ꍇ��SS�Ƃ݂Ȃ�
        If strTargetSlip.Contains(SLIP_DEFINE_ID_NON_SS) Then
            stbSQL.AppendLine("                                   AND ( ")
            stbSQL.AppendLine("                                           T_JJ_IMAGE.SLIP_DEFINE_ID LIKE '641%' ")
            stbSQL.AppendLine("                                        OR T_JJ_IMAGE.SLIP_DEFINE_ID LIKE '661%' ")
            stbSQL.AppendLine("                                       ) ")
        Else
            stbSQL.AppendLine("                                   AND ( ")
            stbSQL.AppendLine("                                           T_JJ_IMAGE.SLIP_DEFINE_ID LIKE '601%' ")
            stbSQL.AppendLine("                                        OR T_JJ_IMAGE.SLIP_DEFINE_ID LIKE '611%' ")
            stbSQL.AppendLine("                                        OR T_JJ_IMAGE.SLIP_DEFINE_ID LIKE '621%' ")
            stbSQL.AppendLine("                                        OR T_JJ_IMAGE.SLIP_DEFINE_ID LIKE '631%' ")
            stbSQL.AppendLine("                                       ) ")
        End If

        stbSQL.AppendLine("                                   AND T_JJ_IMAGE.DELETE_FLG = '0' ")
        stbSQL.AppendLine("                               ) ")
        stbSQL.AppendLine("                      GROUP BY RECEIPT_DATE ")
        stbSQL.AppendLine("                     ) SUBD ")
        stbSQL.AppendLine("             ON SUBD.RECEIPT_DATE = BDAT.RECEIPT_DATE ")
        stbSQL.AppendLine("          INNER JOIN ( ")
        stbSQL.AppendLine("                        SELECT TO_CHAR(T_JJ_RECEIPT.RECEIPT_DATE, 'YYYY/MM/DD HH24:MI') AS RECEIPT_DATE, ")
        stbSQL.AppendLine("                               COUNT(*)                                                 AS IMG_CNT ")
        stbSQL.AppendLine("                          FROM T_JJ_RECEIPT ")
        stbSQL.AppendLine("                               INNER JOIN T_JJ_IMAGE ")
        stbSQL.AppendLine("                                  ON T_JJ_RECEIPT.RECEIPT_ID = T_JJ_IMAGE.RECEIPT_ID ")
        stbSQL.AppendLine("                         WHERE TO_CHAR(T_JJ_RECEIPT.RECEIPT_DATE, 'YYYY/MM/DD HH24:MI') >= '" & stbFrom.ToString & "'")

        If stbTo.Length > 0 Then
            stbSQL.AppendLine("                           AND TO_CHAR(T_JJ_RECEIPT.RECEIPT_DATE, 'YYYY/MM/DD HH24:MI') <= '" & stbTo.ToString & "'")
        End If

        ' config�̑Ώے��[�Ɂu641�v���܂܂�Ă���ꍇ�͔�SS�A�܂܂�Ă��Ȃ��ꍇ��SS�Ƃ݂Ȃ�
        If strTargetSlip.Contains(SLIP_DEFINE_ID_NON_SS) Then
            stbSQL.AppendLine("                           AND ( ")
            stbSQL.AppendLine("                                   T_JJ_IMAGE.SLIP_DEFINE_ID LIKE '641%' ")
            stbSQL.AppendLine("                                OR T_JJ_IMAGE.SLIP_DEFINE_ID LIKE '661%' ")
            stbSQL.AppendLine("                               ) ")
        Else
            stbSQL.AppendLine("                           AND ( ")
            stbSQL.AppendLine("                                   T_JJ_IMAGE.SLIP_DEFINE_ID LIKE '601%' ")
            stbSQL.AppendLine("                                OR T_JJ_IMAGE.SLIP_DEFINE_ID LIKE '611%' ")
            stbSQL.AppendLine("                                OR T_JJ_IMAGE.SLIP_DEFINE_ID LIKE '621%' ")
            stbSQL.AppendLine("                                OR T_JJ_IMAGE.SLIP_DEFINE_ID LIKE '631%' ")
            stbSQL.AppendLine("                               ) ")
        End If

        stbSQL.AppendLine("                           AND T_JJ_IMAGE.DELETE_FLG = '0' ")
        stbSQL.AppendLine("                      GROUP BY TO_CHAR(T_JJ_RECEIPT.RECEIPT_DATE, 'YYYY/MM/DD HH24:MI') ")
        stbSQL.AppendLine("                     ) IMGD ")
        stbSQL.AppendLine("             ON IMGD.RECEIPT_DATE = BDAT.RECEIPT_DATE ")
        stbSQL.AppendLine(" ORDER BY BDAT.RECEIPT_DATE ")

        Dim dtRslt As DataTable = objclsDbAccess.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)

        Return dtRslt

    End Function

    Private Function GetPrevDate(ByVal dtCal As DataTable, ByVal strDate As String) As String

        Dim strNow As String = strDate.Replace("/", String.Empty)
        Dim strPrv As String = strNow
        For Each dr As DataRow In dtCal.Rows
            Dim strCal As String = Convert.ToString(dr.Item(0))
            If strCal >= strNow Then
                Return strPrv.Substring(0, 4) & "/" & _
                       strPrv.Substring(4, 2) & "/" & _
                       strPrv.Substring(6, 2)
            End If
            strPrv = strCal
        Next

        Return strDate

    End Function

    Private Function GetNextDate(ByVal dtCal As DataTable, ByVal strDate As String) As String

        Dim strNow As String = strDate.Replace("/", String.Empty)
        For Each dr As DataRow In dtCal.Rows
            Dim strCal As String = Convert.ToString(dr.Item(0))
            If strCal > strNow Then
                Return strCal.Substring(0, 4) & "/" & _
                       strCal.Substring(4, 2) & "/" & _
                       strCal.Substring(6, 2)
            End If
        Next

        Return strDate

    End Function


End Class
