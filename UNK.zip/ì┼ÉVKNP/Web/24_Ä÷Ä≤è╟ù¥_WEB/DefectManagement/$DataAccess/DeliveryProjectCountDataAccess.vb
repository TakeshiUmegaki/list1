Imports DefectManagement.clsConst

Public Class DeliveryProjectCountDataAccess

#Region " �[�i�Č����ꗗ�擾 "
    ''' <summary>
    ''' �[�i�Č����ꗗ�擾
    ''' </summary>
    ''' <param name="dicParam">���������󂯓n���p</param>
    ''' <param name="blnSlipDefineList">True�F���[ID���̕\���@False�F�[�i�����̕\��</param>
    ''' <returns>�������ʃf�[�^�e�[�u��</returns>
    ''' <remarks></remarks>
    Public Function GetDeliverySubjectCount(ByVal dicParam As Dictionary(Of String, String), ByVal blnSlipDefineList As Boolean) As DataTable

        ' DB�ڑ����܂�
        Dim objclsDbAccess As New clsDbAccess
        Dim strTargetSlip As String = ConfigurationManager.AppSettings("TARGET_SLIP")

        Call objclsDbAccess.dbOpen()

        Try
            ' �J�n���t���擾
            Dim stbFrom As New StringBuilder(dicParam("RECEIPT_DATE_FROM"))
            stbFrom.Append(" ")
            If dicParam.ContainsKey("RECEIPT_TIME_FROM") Then
                Dim strHH As String = Convert.ToInt32(Split(dicParam("RECEIPT_TIME_FROM"), ":")(0)).ToString("00")
                Dim strMI As String = Convert.ToInt32(Split(dicParam("RECEIPT_TIME_FROM"), ":")(1)).ToString("00")
                stbFrom.Append(strHH & ":" & strMI)
            Else
                stbFrom.Append("00:00")
            End If

            ' �I�����t���擾
            Dim stbTo As New StringBuilder(String.Empty)
            If dicParam.ContainsKey("RECEIPT_DATE_TO") Then
                stbTo.Append(dicParam("RECEIPT_DATE_TO"))
                stbTo.Append(" ")
                If dicParam.ContainsKey("RECEIPT_TIME_TO") Then
                    Dim strHH As String = Convert.ToInt32(Split(dicParam("RECEIPT_TIME_TO"), ":")(0)).ToString("00")
                    Dim strMI As String = Convert.ToInt32(Split(dicParam("RECEIPT_TIME_TO"), ":")(1)).ToString("00")
                    stbTo.Append(strHH & ":" & strMI)
                Else
                    stbTo.Append("23:59")
                End If
            End If

            Dim stbSQL As New StringBuilder(String.Empty)

            stbSQL.AppendLine("SELECT")
            stbSQL.AppendLine("    '�Č���'                   AS DOC_TYPE,")
            stbSQL.AppendLine("    BDAT.RECEIPT_DATE          AS RECEIPT_DATE,")

            ' config�̑Ώے��[�Ɂu641�v���܂܂�Ă���ꍇ�͔�SS�A�܂܂�Ă��Ȃ��ꍇ��SS�Ƃ݂Ȃ�
            If strTargetSlip.Contains(SLIP_DEFINE_ID_NON_SS) Then
                stbSQL.AppendLine("    NVL(SUM(D641.ROW_COUNT),0) +")
                stbSQL.AppendLine("    NVL(SUM(D661.ROW_COUNT),0) AS TOTAL,")
                stbSQL.AppendLine("    NVL(SUM(D641.ROW_COUNT),0) AS TYPE_01,")
                stbSQL.AppendLine("    NVL(SUM(D661.ROW_COUNT),0) AS TYPE_02,")
                stbSQL.AppendLine("    0 AS TYPE_03,")
                stbSQL.AppendLine("    0 AS TYPE_04")
            Else
                stbSQL.AppendLine("    NVL(SUM(D601.ROW_COUNT),0) +")
                stbSQL.AppendLine("    NVL(SUM(D611.ROW_COUNT),0) +")
                stbSQL.AppendLine("    NVL(SUM(D621.ROW_COUNT),0) +")
                stbSQL.AppendLine("    NVL(SUM(D631.ROW_COUNT),0) AS TOTAL,")
                stbSQL.AppendLine("    NVL(SUM(D601.ROW_COUNT),0) AS TYPE_01,")
                stbSQL.AppendLine("    NVL(SUM(D611.ROW_COUNT),0) AS TYPE_02,")
                stbSQL.AppendLine("    NVL(SUM(D621.ROW_COUNT),0) AS TYPE_03,")
                stbSQL.AppendLine("    NVL(SUM(D631.ROW_COUNT),0) AS TYPE_04")
            End If

            stbSQL.AppendLine("FROM")
            stbSQL.AppendLine("    (")
            stbSQL.AppendLine("        SELECT DISTINCT")
            stbSQL.AppendLine("            TO_CHAR(I.CREATE_DATE, 'YYYY/MM/DD') AS RECEIPT_DATE,")
            stbSQL.AppendLine("            I.EXC_SUBJECT_NO                     AS EXC_SUBJECT_NO")
            stbSQL.AppendLine("        FROM")
            stbSQL.AppendLine("            T_JJ_IMAGE I")
            stbSQL.AppendLine("        WHERE")
            stbSQL.AppendLine("            I.DELETE_FLG = '0'")
            stbSQL.AppendLine("            AND")
            stbSQL.AppendLine("            TO_CHAR(I.DELIVERY_DATE, 'YYYY/MM/DD HH24:MI') >= '" & stbFrom.ToString & "'")
            If stbTo.Length > 0 Then
                stbSQL.AppendLine("            AND")
                stbSQL.AppendLine("            TO_CHAR(I.DELIVERY_DATE, 'YYYY/MM/DD HH24:MI') <= '" & stbTo.ToString & "'")
            End If
            stbSQL.AppendLine("            AND SUBSTRB(I.SLIP_DEFINE_ID, 1, 3) IN (" & strTargetSlip & ")")
            stbSQL.AppendLine("    ) BDAT")

            stbSQL.AppendLine("    INNER JOIN (")
            stbSQL.AppendLine("        SELECT")
            stbSQL.AppendLine("            I.EXC_SUBJECT_NO")
            stbSQL.AppendLine("        FROM")
            stbSQL.AppendLine("            (")
            stbSQL.AppendLine("                SELECT DISTINCT")
            stbSQL.AppendLine("                    EXC_SUBJECT_NO")
            stbSQL.AppendLine("                FROM")
            stbSQL.AppendLine("                    T_JJ_IMAGE")
            stbSQL.AppendLine("                WHERE")
            stbSQL.AppendLine("                    DELETE_FLG = '0'")
            stbSQL.AppendLine("            ) I")
            stbSQL.AppendLine("        WHERE")
            stbSQL.AppendLine("            NOT I.EXC_SUBJECT_NO IN (")
            stbSQL.AppendLine("                SELECT DISTINCT")
            stbSQL.AppendLine("                    EXC_SUBJECT_NO")
            stbSQL.AppendLine("                FROM")
            stbSQL.AppendLine("                    T_JJ_IMAGE")
            stbSQL.AppendLine("                WHERE")
            stbSQL.AppendLine("                    DELETE_FLG = '0'")
            stbSQL.AppendLine("                    AND")
            stbSQL.AppendLine("                    NOT IMAGE_STATUS IN (" & dicParam("IMAGE_STATUS") & ")")
            stbSQL.AppendLine("            )")
            stbSQL.AppendLine("        ) DELV")
            stbSQL.AppendLine("        ON")
            stbSQL.AppendLine("        DELV.EXC_SUBJECT_NO = BDAT.EXC_SUBJECT_NO")

            ' config�̑Ώے��[�Ɂu641�v���܂܂�Ă���ꍇ�͔�SS�A�܂܂�Ă��Ȃ��ꍇ��SS�Ƃ݂Ȃ�
            If strTargetSlip.Contains(SLIP_DEFINE_ID_NON_SS) Then
                stbSQL.AppendLine("    LEFT JOIN (")
                stbSQL.AppendLine("            SELECT DISTINCT")
                stbSQL.AppendLine("                1                AS ROW_COUNT,")
                stbSQL.AppendLine("                I.EXC_SUBJECT_NO AS EXC_SUBJECT_NO")
                stbSQL.AppendLine("            FROM")
                stbSQL.AppendLine("                T_JJ_IMAGE I")
                stbSQL.AppendLine("            WHERE")
                stbSQL.AppendLine("                I.DELETE_FLG = '0'")
                stbSQL.AppendLine("                AND")
                stbSQL.AppendLine("                SUBSTR(I.EXC_SUBJECT_NO,14,3) = '641'")
                stbSQL.AppendLine("        ) D641")
                stbSQL.AppendLine("        ON")
                stbSQL.AppendLine("        D641.EXC_SUBJECT_NO = BDAT.EXC_SUBJECT_NO")
                stbSQL.AppendLine("    LEFT JOIN (")
                stbSQL.AppendLine("            SELECT DISTINCT")
                stbSQL.AppendLine("                1                AS ROW_COUNT,")
                stbSQL.AppendLine("                I.EXC_SUBJECT_NO AS EXC_SUBJECT_NO")
                stbSQL.AppendLine("            FROM")
                stbSQL.AppendLine("                T_JJ_IMAGE I")
                stbSQL.AppendLine("            WHERE")
                stbSQL.AppendLine("                I.DELETE_FLG = '0'")
                stbSQL.AppendLine("                AND")
                stbSQL.AppendLine("                SUBSTR(I.EXC_SUBJECT_NO,14,3) = '661'")
                stbSQL.AppendLine("        ) D661")
                stbSQL.AppendLine("        ON")
                stbSQL.AppendLine("        D661.EXC_SUBJECT_NO = BDAT.EXC_SUBJECT_NO")
            Else
                stbSQL.AppendLine("    LEFT JOIN (")
                stbSQL.AppendLine("            SELECT DISTINCT")
                stbSQL.AppendLine("                1                AS ROW_COUNT,")
                stbSQL.AppendLine("                I.EXC_SUBJECT_NO AS EXC_SUBJECT_NO")
                stbSQL.AppendLine("            FROM")
                stbSQL.AppendLine("                T_JJ_IMAGE I")
                stbSQL.AppendLine("            WHERE")
                stbSQL.AppendLine("                I.DELETE_FLG = '0'")
                stbSQL.AppendLine("                AND")
                stbSQL.AppendLine("                SUBSTR(I.EXC_SUBJECT_NO,14,3) = '601'")
                stbSQL.AppendLine("        ) D601")
                stbSQL.AppendLine("        ON")
                stbSQL.AppendLine("        D601.EXC_SUBJECT_NO = BDAT.EXC_SUBJECT_NO")
                stbSQL.AppendLine("    LEFT JOIN (")
                stbSQL.AppendLine("            SELECT DISTINCT")
                stbSQL.AppendLine("                1                AS ROW_COUNT,")
                stbSQL.AppendLine("                I.EXC_SUBJECT_NO AS EXC_SUBJECT_NO")
                stbSQL.AppendLine("            FROM")
                stbSQL.AppendLine("                T_JJ_IMAGE I")
                stbSQL.AppendLine("            WHERE")
                stbSQL.AppendLine("                I.DELETE_FLG = '0'")
                stbSQL.AppendLine("                AND")
                stbSQL.AppendLine("                SUBSTR(I.EXC_SUBJECT_NO,14,3) = '611'")
                stbSQL.AppendLine("        ) D611")
                stbSQL.AppendLine("        ON")
                stbSQL.AppendLine("        D611.EXC_SUBJECT_NO = BDAT.EXC_SUBJECT_NO")
                stbSQL.AppendLine("    LEFT JOIN (")
                stbSQL.AppendLine("            SELECT DISTINCT")
                stbSQL.AppendLine("                1                AS ROW_COUNT,")
                stbSQL.AppendLine("                I.EXC_SUBJECT_NO AS EXC_SUBJECT_NO")
                stbSQL.AppendLine("            FROM")
                stbSQL.AppendLine("                T_JJ_IMAGE I")
                stbSQL.AppendLine("            WHERE")
                stbSQL.AppendLine("                I.DELETE_FLG = '0'")
                stbSQL.AppendLine("                AND")
                stbSQL.AppendLine("                SUBSTR(I.EXC_SUBJECT_NO,14,3) = '621'")
                stbSQL.AppendLine("        ) D621")
                stbSQL.AppendLine("        ON")
                stbSQL.AppendLine("        D621.EXC_SUBJECT_NO = BDAT.EXC_SUBJECT_NO")
                stbSQL.AppendLine("    LEFT JOIN (")
                stbSQL.AppendLine("            SELECT DISTINCT")
                stbSQL.AppendLine("                1                AS ROW_COUNT,")
                stbSQL.AppendLine("                I.EXC_SUBJECT_NO AS EXC_SUBJECT_NO")
                stbSQL.AppendLine("            FROM")
                stbSQL.AppendLine("                T_JJ_IMAGE I")
                stbSQL.AppendLine("            WHERE")
                stbSQL.AppendLine("                I.DELETE_FLG = '0'")
                stbSQL.AppendLine("                AND")
                stbSQL.AppendLine("                SUBSTR(I.EXC_SUBJECT_NO,14,3) = '631'")
                stbSQL.AppendLine("        ) D631")
                stbSQL.AppendLine("        ON")
                stbSQL.AppendLine("        D631.EXC_SUBJECT_NO = BDAT.EXC_SUBJECT_NO")
            End If

            stbSQL.AppendLine("GROUP BY")
            stbSQL.AppendLine("    BDAT.RECEIPT_DATE")
            stbSQL.AppendLine("ORDER BY ")
            stbSQL.AppendLine("    BDAT.RECEIPT_DATE")

            Dim dt As DataTable = objclsDbAccess.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)

            ' SQL���O�o��
            clsUtility.WriteLog(objclsDbAccess.mobjCommonDB.GetInfoMessage, EventLogEntryType.Information)

            '���s
            Return dt

        Finally
            objclsDbAccess.mobjCommonDB.DB_Close()
        End Try

    End Function

#End Region

End Class
