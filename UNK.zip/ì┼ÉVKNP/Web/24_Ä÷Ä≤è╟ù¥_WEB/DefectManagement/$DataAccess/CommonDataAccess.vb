Imports System.Data
Imports Oracle.DataAccess.Client
Imports DefectManagement.clsConst

Public Class CommonDataAccess

#Region " �V�X�e�����t�擾 "
    ''' <summary>
    ''' �V�X�e�����t�擾
    ''' </summary>
    ''' <param name="strFormat">���t�t�H�[�}�b�g 1:yyyy/MM/dd 2:yyyy/MM/dd hh24:mi:ss </param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetSysDate(Optional ByVal strFormat As String = "1") As String

        ' DB�ڑ����܂�
        Dim objclsDbAccess As New clsDbAccess
        Dim dt As DataTable
        Dim strSysDate As String

        Call objclsDbAccess.dbOpen()

        Try

            Dim stbSQL As New StringBuilder(String.Empty)

            ' SQL�쐬
            If strFormat.Equals("1") Then
                stbSQL.AppendLine(" SELECT TO_CHAR(SYSDATE,'yyyy/MM/dd') FROM DUAL ")
            Else
                stbSQL.AppendLine(" SELECT TO_CHAR(SYSDATE,'yyyy/MM/dd hh24:mi:ss') FROM DUAL ")
            End If

            dt = objclsDbAccess.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)

            ' SQL���O�o��
            clsUtility.WriteLog(objclsDbAccess.mobjCommonDB.GetInfoMessage, EventLogEntryType.Information)

            strSysDate = dt.Rows(0)(0).ToString

            ' ���s
            Return strSysDate

        Finally
            objclsDbAccess.mobjCommonDB.DB_Close()
        End Try

    End Function
#End Region

#Region " ��t���ԃh���b�v�_�E�����X�g���ڎ擾 "
    ''' <summary>
    ''' ��t���ԃh���b�v�_�E�����X�g���ڎ擾
    ''' </summary>
    ''' <param name="strSlipDefineId">���[���ID</param>
    ''' <returns>�������ʃf�[�^�e�[�u��</returns>
    ''' <remarks></remarks>
    Public Function GetReceiptPlanDdl(ByVal strSlipDefineId As String) As DataTable

        ' DB�ڑ����܂�
        Dim objclsDbAccess As New clsDbAccess

        Call objclsDbAccess.dbOpen()

        Try

            Dim stbSQL As New StringBuilder(String.Empty)

            ' SQL�쐬
            stbSQL.AppendLine("   SELECT RECEIPT_COUNT, ")
            stbSQL.AppendLine("          SUBSTR(RECEIPT_PLAN,1,2) || ':' || SUBSTR(RECEIPT_PLAN,3,2) || '�i' || RECEIPT_COUNT || '��ځj' AS RECEIPT_COUNT_DISP ")
            stbSQL.AppendLine("     FROM M_CM_DELIVERY ")
            stbSQL.AppendLine("    WHERE SLIP_DEFINE_ID = :SLIP_DEFINE_ID ")
            stbSQL.AppendLine("      AND DELETE_FLG = '0' ")
            stbSQL.AppendLine(" ORDER BY RECEIPT_COUNT ")

            ' �p�����[�^�ݒ�
            Dim oraUpdateParam(0) As OracleParameter
            oraUpdateParam(0) = New OracleParameter("SLIP_DEFINE_ID", OracleDbType.Char)
            oraUpdateParam(0).Value = strSlipDefineId

            Dim dt As DataTable = objclsDbAccess.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString, oraUpdateParam)

            ' SQL���O�o��
            clsUtility.WriteLog(objclsDbAccess.mobjCommonDB.GetInfoMessage, EventLogEntryType.Information)

            ' ���s
            Return dt

        Finally
            objclsDbAccess.mobjCommonDB.DB_Close()
        End Try

    End Function
#End Region

#Region " ���[ID�h���b�v�_�E�����X�g���ڎ擾 "
    ''' <summary>
    ''' ���[ID�h���b�v�_�E�����X�g���ڎ擾
    ''' </summary>
    ''' <param name="blnSapporoFlg">�D�y�t���O True:�D�y�p�i�������̂ݕ\���j False:�ʏ�</param>
    ''' <returns>�������ʃf�[�^�e�[�u��</returns>
    ''' <remarks></remarks>
    Public Function GetSlipDefineIdDdl(Optional ByVal blnSapporoFlg As Boolean = False) As DataTable

        ' DB�ڑ����܂�
        Dim objclsDbAccess As New clsDbAccess

        Call objclsDbAccess.dbOpen()

        Try

            Dim stbSQL As New StringBuilder(String.Empty)

            ' SQL�쐬
            stbSQL.AppendLine("   SELECT SLIP_DEFINE_ID, ")
            stbSQL.AppendLine("          SLIP_DEFINE_ID || '�F' || SLIP_DEFINE_NAME AS SLIP_DEFINE_NAME ")
            stbSQL.AppendLine("     FROM M_SLIP_DEFINE ")
            stbSQL.AppendLine("    WHERE SORT_NO IS NOT NULL ")
            stbSQL.AppendLine("      AND DELETE_FLG = '0' ")

            If blnSapporoFlg Then
                stbSQL.AppendLine("      AND SLIP_DIV = '" & SLIP_DIV_KOUTOU & "' ")
            End If

            stbSQL.AppendLine(" ORDER BY SORT_NO ")

            Dim dt As DataTable = objclsDbAccess.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)

            ' SQL���O�o��
            clsUtility.WriteLog(objclsDbAccess.mobjCommonDB.GetInfoMessage, EventLogEntryType.Information)

            ' ���s
            Return dt

        Finally
            objclsDbAccess.mobjCommonDB.DB_Close()
        End Try

    End Function

    ''' <summary>
    ''' ���[ID�h���b�v�_�E�����X�g���ڎ擾
    ''' </summary>
    ''' <param name="strTargetSlip">�Ώے��[</param>
    ''' <param name="blnSapporoFlg">�D�y�t���O True:�D�y�p�i�������̂ݕ\���j False:�ʏ�</param>
    ''' <returns>�������ʃf�[�^�e�[�u��</returns>
    ''' <remarks></remarks>
    Public Function GetSlipDefineIdDdl2(ByVal strTargetSlip As String, Optional ByVal blnSapporoFlg As Boolean = False) As DataTable

        ' DB�ڑ����܂�
        Dim objclsDbAccess As New clsDbAccess

        Call objclsDbAccess.dbOpen()

        Try

            Dim stbSQL As New StringBuilder(String.Empty)

            ' SQL�쐬
            stbSQL.AppendLine("   SELECT SLIP_DEFINE_ID, ")
            stbSQL.AppendLine("          SLIP_DEFINE_ID || '�F' || SLIP_DEFINE_NAME AS SLIP_DEFINE_NAME ")
            stbSQL.AppendLine("     FROM M_SLIP_DEFINE ")
            stbSQL.AppendLine("    WHERE SORT_NO IS NOT NULL ")
            stbSQL.AppendLine("      AND DELETE_FLG = '0' ")

            If Not String.IsNullOrEmpty(strTargetSlip) Then
                stbSQL.AppendLine("      AND SUBSTRB(SLIP_DEFINE_ID, 1, 3) IN (" & strTargetSlip & ")")
            End If

            If blnSapporoFlg Then
                stbSQL.AppendLine("      AND SLIP_DIV = '" & SLIP_DIV_KOUTOU & "' ")
            End If

            stbSQL.AppendLine(" ORDER BY SORT_NO ")

            Dim dt As DataTable = objclsDbAccess.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)

            ' SQL���O�o��
            clsUtility.WriteLog(objclsDbAccess.mobjCommonDB.GetInfoMessage, EventLogEntryType.Information)

            ' ���s
            Return dt

        Finally
            objclsDbAccess.mobjCommonDB.DB_Close()
        End Try

    End Function
#End Region

#Region " �X�e�[�^�X�h���b�v�_�E�����X�g���ڎ擾 "
    ''' <summary>
    ''' �X�e�[�^�X�h���b�v�_�E�����X�g���ڎ擾
    ''' </summary>
    ''' <param name="strConfigDiv">�ݒ�敪</param>
    ''' <returns>�������ʃf�[�^�e�[�u��</returns>
    ''' <remarks></remarks>
    Public Function GetStatusDdl(ByVal strConfigDiv As String) As DataTable

        ' DB�ڑ����܂�
        Dim objclsDbAccess As New clsDbAccess

        Call objclsDbAccess.dbOpen()

        Try

            Dim stbSQL As New StringBuilder(String.Empty)

            ' SQL�쐬
            stbSQL.AppendLine("   SELECT CONFIG_ID AS STATUS_ID, ")
            stbSQL.AppendLine("          CONFIG_ID || '�F' || CONFIG_VALUE AS STATUS_NAME ")
            stbSQL.AppendLine("     FROM M_CM_CONFIG ")
            stbSQL.AppendLine("    WHERE CONFIG_DIV = :CONFIG_DIV ")
            stbSQL.AppendLine("      AND SORT_NO IS NOT NULL ")
            stbSQL.AppendLine("      AND DELETE_FLG = '0' ")
            stbSQL.AppendLine(" ORDER BY SORT_NO ")

            ' �p�����[�^�ݒ�
            Dim oraUpdateParam(0) As OracleParameter
            oraUpdateParam(0) = New OracleParameter("CONFIG_DIV", OracleDbType.Char)
            oraUpdateParam(0).Value = strConfigDiv

            Dim dt As DataTable = objclsDbAccess.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString, oraUpdateParam)

            ' SQL���O�o��
            clsUtility.WriteLog(objclsDbAccess.mobjCommonDB.GetInfoMessage, EventLogEntryType.Information)

            ' ���s
            Return dt

        Finally
            objclsDbAccess.mobjCommonDB.DB_Close()
        End Try

    End Function
#End Region

#Region " �s���t���O�h���b�v�_�E�����X�g���ڎ擾 "
    ''' <summary>
    ''' �s���t���O�h���b�v�_�E�����X�g���ڎ擾
    ''' </summary>
    ''' <returns>�������ʃf�[�^�e�[�u��</returns>
    ''' <remarks></remarks>
    Public Function GetDefFlgDdl() As DataTable

        ' DB�ڑ����܂�
        Dim objclsDbAccess As New clsDbAccess

        Call objclsDbAccess.dbOpen()

        Try

            Dim stbSQL As New StringBuilder(String.Empty)

            ' SQL�쐬
            stbSQL.AppendLine("   SELECT DEF_FLG_ID, ")
            stbSQL.AppendLine("          DEF_FLG_ID ")
            stbSQL.AppendLine("     FROM M_DEF_FLG ")
            stbSQL.AppendLine("    WHERE SORT_NO IS NOT NULL ")
            stbSQL.AppendLine("      AND DELETE_FLG = '0' ")
            stbSQL.AppendLine(" ORDER BY SORT_NO ")

            Dim dt As DataTable = objclsDbAccess.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)

            ' SQL���O�o��
            clsUtility.WriteLog(objclsDbAccess.mobjCommonDB.GetInfoMessage, EventLogEntryType.Information)

            ' ���s
            Return dt

        Finally
            objclsDbAccess.mobjCommonDB.DB_Close()
        End Try

    End Function
#End Region

#Region " �������SQL "

    ''' <summary>
    ''' �������SQL
    ''' </summary>
    ''' <param name="strUserId">���[�U�[ID</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetSqlAnth(ByVal strUserId As String) As String

        ' DB�ڑ����܂�
        Dim objclsDbAccess As New clsDbAccess
        Call objclsDbAccess.dbOpen()

        Try

            Dim stbSQL As New StringBuilder(String.Empty)

            'SQL�쐬
            stbSQL.AppendLine("SELECT")
            stbSQL.AppendLine("	ROLL_CD")
            stbSQL.AppendLine("FROM")
            stbSQL.AppendLine("	M_CM_USER")
            stbSQL.AppendLine("WHERE")
            stbSQL.AppendLine("	USER_ID	=	:USER_ID")

            '�p�����[�^�ݒ�
            Dim oraUpdateParam(0) As OracleParameter
            oraUpdateParam(0) = New OracleParameter("USER_ID", OracleDbType.Char)
            oraUpdateParam(0).Value = strUserId

            '���s
            Dim dt As DataTable = objclsDbAccess.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString, oraUpdateParam)

            ' SQL���O�o��
            clsUtility.WriteLog(objclsDbAccess.mobjCommonDB.GetInfoMessage, EventLogEntryType.Information)

            Return dt.Rows(0)(0).ToString

        Finally
            objclsDbAccess.mobjCommonDB.DB_Close()
        End Try

    End Function

#End Region

#Region " ���[�U���擾SQL "

    ''' <summary>
    ''' ���[�U���擾SQL
    ''' </summary>
    ''' <param name="strUserId">���[�U�[ID</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetSqlUserNm(ByVal strUserId As String) As String

        ' DB�ڑ����܂�
        Dim objclsDbAccess As New clsDbAccess
        Call objclsDbAccess.dbOpen()

        Try

            Dim stbSQL As New StringBuilder(String.Empty)

            'SQL�쐬
            stbSQL.AppendLine("SELECT")
            stbSQL.AppendLine("	USER_NAME")
            stbSQL.AppendLine("FROM")
            stbSQL.AppendLine("	M_CM_USER")
            stbSQL.AppendLine("WHERE")
            stbSQL.AppendLine("	USER_ID	=	:USER_ID")

            '�p�����[�^�ݒ�
            Dim oraUpdateParam(0) As OracleParameter
            oraUpdateParam(0) = New OracleParameter("USER_ID", OracleDbType.Char)
            oraUpdateParam(0).Value = strUserId

            '���s
            Dim dt As DataTable = objclsDbAccess.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString, oraUpdateParam)

            ' SQL���O�o��
            clsUtility.WriteLog(objclsDbAccess.mobjCommonDB.GetInfoMessage, EventLogEntryType.Information)

            Return dt.Rows(0)(0).ToString

        Finally
            objclsDbAccess.mobjCommonDB.DB_Close()
        End Try

    End Function

#End Region

#Region " ���[�敪�擾 "
    ''' <summary>
    ''' ���[�敪�擾
    ''' </summary>
    ''' <param name="strSlipDefineId">���[ID</param>
    ''' <returns>���[�敪</returns>
    ''' <remarks></remarks>
    Public Function GetSlipDiv(ByVal strSlipDefineId As String) As String

        Dim objclsDbAccess As New clsDbAccess    ' DB�ڑ��N���X

        Call objclsDbAccess.dbOpen()

        Try

            Dim stbSQL As New StringBuilder(String.Empty)

            'SQL�쐬
            stbSQL.AppendLine(" SELECT SLIP_DIV ")
            stbSQL.AppendLine("   FROM M_SLIP_DEFINE ")
            stbSQL.AppendLine("  WHERE SLIP_DEFINE_ID = :SLIP_DEFINE_ID ")

            ' �p�����[�^�ݒ�
            Dim oraUpdateParam(0) As OracleParameter

            ' ���[ID�������ɐݒ�
            oraUpdateParam(0) = New OracleParameter("SLIP_DEFINE_ID", OracleDbType.Char)
            oraUpdateParam(0).Value = strSlipDefineId

            Dim dt As DataTable = objclsDbAccess.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString, oraUpdateParam)

            ' SQL���O�o��
            clsUtility.WriteLog(objclsDbAccess.mobjCommonDB.GetInfoMessage, EventLogEntryType.Information)

            '���s
            Return dt.Rows(0)("SLIP_DIV").ToString

        Finally
            objclsDbAccess.mobjCommonDB.DB_Close()
        End Try

    End Function
#End Region

#Region " �p�X���[�h�L�������擾SQL "

    ''' <summary>
    ''' �p�X���[�h�L�������擾SQL
    ''' </summary>
    ''' <param name="strUserId">���[�U�[ID</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetSqlPassLimit(ByVal strUserId As String) As String

        ' DB�ڑ����܂�
        Dim objclsDbAccess As New clsDbAccess
        Call objclsDbAccess.dbOpen()

        Try

            Dim stbSQL As New StringBuilder(String.Empty)

            'SQL�쐬
            stbSQL.AppendLine("SELECT")
            stbSQL.AppendLine("	PASSWORD_LIMIT_DATE")
            stbSQL.AppendLine("FROM")
            stbSQL.AppendLine("	M_CM_USER")
            stbSQL.AppendLine("WHERE")
            stbSQL.AppendLine("	USER_ID	=	:USER_ID")

            '�p�����[�^�ݒ�
            Dim oraUpdateParam(0) As OracleParameter
            oraUpdateParam(0) = New OracleParameter("USER_ID", OracleDbType.Char)
            oraUpdateParam(0).Value = strUserId

            '���s
            Dim dt As DataTable = objclsDbAccess.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString, oraUpdateParam)

            ' SQL���O�o��
            clsUtility.WriteLog(objclsDbAccess.mobjCommonDB.GetInfoMessage, EventLogEntryType.Information)

            Return dt.Rows(0)(0).ToString

        Finally
            objclsDbAccess.mobjCommonDB.DB_Close()
        End Try

    End Function

#End Region

#Region " ���[���ڃ}�X�^���獀��ID�ϊ��������쐬 "
    Public Function GetFileldMaster() As Dictionary(Of String, String)

        ' DB�ڑ����܂�
        Dim objclsDbAccess As New clsDbAccess

        Call objclsDbAccess.dbOpen()
        Try

            Dim dicField As New Dictionary(Of String, String)

            Dim stbSQL As New StringBuilder(String.Empty)
            stbSQL.AppendLine("SELECT")
            stbSQL.AppendLine("     SLIP_DEFINE_ID||CSV_ID AS KEY_CODE")
            stbSQL.AppendLine("    ,ENTRY_COL_NAME         AS VAL_CODE")
            stbSQL.AppendLine("FROM")
            stbSQL.AppendLine("    M_CM_ITEM")
            stbSQL.AppendLine("WHERE")
            stbSQL.AppendLine("    DELETE_FLG = '0'")
            stbSQL.AppendLine("    AND")
            stbSQL.AppendLine("    CSV_ID IS NOT NULL")

            Dim dtbMst As DataTable = objclsDbAccess.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)
            For Each dr As DataRow In dtbMst.Rows
                Dim strKey As String = Convert.ToString(dr.Item("KEY_CODE"))
                Dim strVal As String = Convert.ToString(dr.Item("VAL_CODE"))
                dicField.Add(strKey, strVal)
            Next

            Return dicField

        Finally

            objclsDbAccess.mobjCommonDB.DB_Close()

        End Try
    End Function
#End Region

End Class
