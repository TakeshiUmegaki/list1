Imports System.Data
Imports System.Collections.Generic
Imports Oracle.DataAccess.Client

Public Class MenuDataAccess
    
#Region "GetSqlInfimation"

    ''' <summary>
    ''' ���m�点���擾SQL
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetSqlInfomation() As DataTable

        ' DB�ڑ����܂�
        Dim objclsDbAccess As New clsDbAccess
        Call objclsDbAccess.dbOpen()

        Try
            Dim stbSQL As New StringBuilder(String.Empty)

            'SQL�쐬
            stbSQL.AppendLine("SELECT")
            stbSQL.AppendLine("  I.SEQ")
            stbSQL.AppendLine(" ,I.TITLE")
            stbSQL.AppendLine(" ,I.INFOMATION")
            stbSQL.AppendLine(" ,I.DELETE_FLG")
            stbSQL.AppendLine(" ,TO_CHAR(I.CREATE_DATE,'YYYY/MM/DD HH24:MI:SS') AS CREATE_DATE")
            stbSQL.AppendLine(" ,I.CREATE_USER")
            stbSQL.AppendLine(" ,I.UPDATE_DATE")
            stbSQL.AppendLine(" ,I.UPDATE_USER")
            stbSQL.AppendLine(" ,NVL(U.USER_NAME,I.CREATE_USER) AS USER_NAME")
            stbSQL.AppendLine(" ,C.CONFIG_VALUE")
            stbSQL.AppendLine("FROM")
            stbSQL.AppendLine("	T_JJ_INFOMATION I")
            stbSQL.AppendLine("     LEFT JOIN  ")
            stbSQL.AppendLine("         M_CM_USER U ")
            stbSQL.AppendLine("         ON U.DELETE_FLG = '0'")
            stbSQL.AppendLine("            AND U.USER_ID = I.CREATE_USER")
            stbSQL.AppendLine("     LEFT JOIN  ")
            stbSQL.AppendLine("         M_CM_CONFIG C ")
            stbSQL.AppendLine("         ON C.DELETE_FLG = '0'")
            stbSQL.AppendLine("            AND C.CONFIG_DIV = '05'")
            stbSQL.AppendLine("            AND C.CONFIG_ID = U.ROLL_CD")
            stbSQL.AppendLine("WHERE")
            stbSQL.AppendLine("  I.DELETE_FLG  =   '0'")
            stbSQL.AppendLine("ORDER BY")
            stbSQL.AppendLine("  I.SEQ DESC")

            Dim dt As DataTable = objclsDbAccess.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)

            ' SQL���O�o��
            clsUtility.WriteLog(objclsDbAccess.mobjCommonDB.GetInfoMessage, EventLogEntryType.Information)

            '���s
            Return dt
        Finally
            objclsDbAccess.mobjCommonDB.DB_Close()
        End Try

    End Function

#End Region

#Region "InsSqlInfomaton"
    ''' <summary>
    ''' ���m�点���o�^
    ''' </summary>
    ''' <param name="Parm">�p�����[�^</param>
    ''' <remarks></remarks>
    Public Function InsSqlInfomaton(ByVal Parm As Dictionary(Of String, String)) As Integer

        ' DB�ڑ�����
        Dim objclsDbAccess As New clsDbAccess
        Call objclsDbAccess.dbOpen()

        Try
            ' �V�[�P���X���炨�m�点���KEY���擾���܂��B
            Dim dtbSEQ As DataTable = objclsDbAccess.mobjCommonDB.DB_ExecuteQuery("SELECT S_JJ_INFOMATION.NEXTVAL FROM DUAL")
            If dtbSEQ Is Nothing OrElse dtbSEQ.Rows.Count <> 1 Then
                Throw New Exception("���m�点����Key���擾�ł��܂���B")
            End If
            Dim strSEQ As String = Convert.ToString(dtbSEQ.Rows(0).Item(0))
            Dim decSEQ As Decimal = Convert.ToInt64(strSEQ)

            Dim stbSQL As New StringBuilder(String.Empty)

            'SQL�쐬
            stbSQL.AppendLine("INSERT INTO T_JJ_INFOMATION")
            stbSQL.AppendLine("    (                ")
            stbSQL.AppendLine("     SEQ        ")
            stbSQL.AppendLine("    ,TITLE      ")
            stbSQL.AppendLine("    ,INFOMATION ")
            stbSQL.AppendLine("    ,DELETE_FLG ")
            stbSQL.AppendLine("    ,CREATE_DATE")
            stbSQL.AppendLine("    ,CREATE_USER")
            stbSQL.AppendLine("    ,UPDATE_DATE")
            stbSQL.AppendLine("    ,UPDATE_USER")
            stbSQL.AppendLine("    )            ")
            stbSQL.AppendLine("VALUES           ")
            stbSQL.AppendLine("    (            ")
            stbSQL.AppendLine("     :Seq        ")
            stbSQL.AppendLine("    ,:Title      ")
            stbSQL.AppendLine("    ,:Infomation ")
            stbSQL.AppendLine("    ,'0'         ")
            stbSQL.AppendLine("    ,sysdate     ")
            stbSQL.AppendLine("    ,:CreateUser ")
            stbSQL.AppendLine("    ,sysdate     ")
            stbSQL.AppendLine("    ,:UpdateUser ")
            stbSQL.AppendLine("    )            ")

            '�p�����[�^�ݒ�
            Dim oraUpdateParam(4) As OracleParameter
            oraUpdateParam(0) = New OracleParameter("Seq", OracleDbType.Decimal)
            oraUpdateParam(1) = New OracleParameter("Title", OracleDbType.Char)
            oraUpdateParam(2) = New OracleParameter("Infomation", OracleDbType.Char)
            oraUpdateParam(3) = New OracleParameter("CreateUser", OracleDbType.Char)
            oraUpdateParam(4) = New OracleParameter("UpdateUser", OracleDbType.Char)
            oraUpdateParam(0).Value = decSEQ
            oraUpdateParam(1).Value = Parm.Item("TITLE")
            oraUpdateParam(2).Value = Parm.Item("INFO")
            oraUpdateParam(3).Value = Parm.Item("USER")
            oraUpdateParam(4).Value = Parm.Item("USER")

            '���s
            Dim intResultCount As Integer = objclsDbAccess.mobjCommonDB.DB_ExecuteNonQuery(stbSQL.ToString, oraUpdateParam)

            ' SQL���O�o��
            clsUtility.WriteLog(objclsDbAccess.mobjCommonDB.GetInfoMessage, EventLogEntryType.Information)

            Return intResultCount
        Finally
            objclsDbAccess.mobjCommonDB.DB_Close()
        End Try

    End Function
#End Region

#Region "UpdSqlInfomation"
    ''' <summary>
    ''' ���m�点���X�V
    ''' </summary>
    ''' <param name="Parm">�p�����[�^</param>
    ''' <remarks></remarks>
    Public Function UpdSqlInfomation(ByVal Parm As Dictionary(Of String, String)) As Integer

        ' DB�ڑ�����
        Dim objclsDbAccess As New clsDbAccess
        Dim intResultCount As Integer

        Call objclsDbAccess.dbOpen()

        Try
            '**********************
            '�X�V����
            '**********************
            Dim stbSQL As New StringBuilder(String.Empty)

            'SQL�쐬
            stbSQL.AppendLine("UPDATE T_JJ_INFOMATION")
            stbSQL.AppendLine("SET")
            stbSQL.AppendLine("	 DELETE_FLG  = '1'")
            stbSQL.AppendLine("	,UPDATE_DATE = SYSDATE")
            stbSQL.AppendLine("	,UPDATE_USER = :UPDATE_USER")
            stbSQL.AppendLine("WHERE")
            stbSQL.AppendLine("	SEQ	=	:SEQ")

            '�p�����[�^�ݒ�
            Dim oraUpdateParam(1) As OracleParameter
            oraUpdateParam(0) = New OracleParameter("SEQ", OracleDbType.Char)
            oraUpdateParam(1) = New OracleParameter("UPDATE_USER", OracleDbType.Char)
            oraUpdateParam(0).Value = Convert.ToInt64(Parm.Item("SEQ"))
            oraUpdateParam(1).Value = Parm.Item("USER")

            '���s
            intResultCount = objclsDbAccess.mobjCommonDB.DB_ExecuteNonQuery(stbSQL.ToString, oraUpdateParam)

            ' SQL���O�o��
            clsUtility.WriteLog(objclsDbAccess.mobjCommonDB.GetInfoMessage, EventLogEntryType.Information)

            Return intResultCount
        Finally
            objclsDbAccess.mobjCommonDB.DB_Close()
        End Try

    End Function
#End Region

#Region " ���[�U���擾SQL "

    ''' <summary>
    ''' ���[�U���擾SQL
    ''' </summary>
    ''' <param name="strUserId">���[�U�[ID</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetSqlUserInfo(ByVal strUserId As String) As DataTable

        ' DB�ڑ����܂�
        Dim objclsDbAccess As New clsDbAccess
        Call objclsDbAccess.dbOpen()

        Try

            Dim stbSQL As New StringBuilder(String.Empty)

            'SQL�쐬
            stbSQL.AppendLine("SELECT")
            stbSQL.AppendLine("	 U.USER_ID")
            stbSQL.AppendLine("	,U.USER_NAME")
            stbSQL.AppendLine("	,C.CONFIG_VALUE")
            stbSQL.AppendLine("FROM")
            stbSQL.AppendLine("	M_CM_USER U")
            stbSQL.AppendLine("     LEFT JOIN  ")
            stbSQL.AppendLine("         M_CM_CONFIG C ")
            stbSQL.AppendLine("         ON C.DELETE_FLG = '0'")
            stbSQL.AppendLine("            AND C.CONFIG_DIV = '05'")
            stbSQL.AppendLine("            AND C.CONFIG_ID = U.ROLL_CD")
            stbSQL.AppendLine("WHERE")
            stbSQL.AppendLine("	U.USER_ID	=	:USER_ID")

            '�p�����[�^�ݒ�
            Dim oraUpdateParam(0) As OracleParameter
            oraUpdateParam(0) = New OracleParameter("USER_ID", OracleDbType.Char)
            oraUpdateParam(0).Value = strUserId

            '���s
            Dim dt As DataTable = objclsDbAccess.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString, oraUpdateParam)

            ' SQL���O�o��
            clsUtility.WriteLog(objclsDbAccess.mobjCommonDB.GetInfoMessage, EventLogEntryType.Information)

            Return dt

        Finally
            objclsDbAccess.mobjCommonDB.DB_Close()
        End Try

    End Function

#End Region

End Class
