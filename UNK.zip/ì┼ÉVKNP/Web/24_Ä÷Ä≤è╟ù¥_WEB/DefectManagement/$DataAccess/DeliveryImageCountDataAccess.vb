Imports System.Data
Imports Oracle.DataAccess.Client
Imports DefectManagement.clsConst

Public Class DeliveryImageCountDataAccess

#Region " ���[��ވꗗ�擾 "
    ''' <summary>
    ''' ���[��ވꗗ�擾
    ''' </summary>
    ''' <returns>�������ʃf�[�^�e�[�u��</returns>
    ''' <remarks></remarks>
    Public Function GetSlipDefineIdList(ByVal strSlipDefineId As String, ByVal strTargetSlip As String) As DataTable

        ' DB�ڑ����܂�
        Dim objclsDbAccess As New clsDbAccess

        Call objclsDbAccess.dbOpen()

        Try

            Dim stbSQL As New StringBuilder(String.Empty)

            ' SQL�쐬
            stbSQL.AppendLine("   SELECT SLIP_DEFINE_ID,  ")
            stbSQL.AppendLine("          PAPER_SIZE, ")
            stbSQL.AppendLine("          SLIP_DEFINE_NAME_ABB, ")
            stbSQL.AppendLine("          SURFACE_PAGE ")
            stbSQL.AppendLine("     FROM M_SLIP_DEFINE ")
            stbSQL.AppendLine("    WHERE SORT_NO IS NOT NULL ")
            stbSQL.AppendLine("      AND ENTRY_TARGET_FLG = '1' ")

            If Not String.IsNullOrEmpty(strSlipDefineId) Then
                stbSQL.AppendLine("      AND SLIP_DEFINE_ID NOT IN (" & strSlipDefineId & ")")
            End If

            If Not String.IsNullOrEmpty(strTargetSlip) Then
                stbSQL.AppendLine("      AND SUBSTRB(SLIP_DEFINE_ID, 1, 3) IN (" & strTargetSlip & ")")
            End If

            stbSQL.AppendLine(" ORDER BY SORT_NO ")

            Dim dt As DataTable = objclsDbAccess.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)

            ' SQL���O�o��
            clsUtility.WriteLog(objclsDbAccess.mobjCommonDB.GetInfoMessage, EventLogEntryType.Information)

            ' ���s
            Return dt

        Finally
            objclsDbAccess.mobjCommonDB.DB_Close()
        End Try

    End Function

#End Region

#Region " ��t�C���[�W�����擾 "
    ''' <summary>
    ''' ��t�C���[�W�����擾
    ''' </summary>
    ''' <param name="dicParam">���������󂯓n���p</param>
    ''' <returns>�������ʃf�[�^�e�[�u��</returns>
    ''' <remarks></remarks>
    Public Function GetReceiptImageCount(ByVal dicParam As Dictionary(Of String, String)) As DataTable

        ' DB�ڑ����܂�
        Dim objclsDbAccess As New clsDbAccess

        Call objclsDbAccess.dbOpen()

        Try

            ' �J�n���t���擾
            Dim stbFrom As New StringBuilder(dicParam("DELIVERY_DATE_FROM"))
            stbFrom.Append(" ")
            If dicParam.ContainsKey("DELIVERY_TIME_FROM") Then
                Dim strHH As String = Convert.ToInt32(Split(dicParam("DELIVERY_TIME_FROM"), ":")(0)).ToString("00")
                Dim strMI As String = Convert.ToInt32(Split(dicParam("DELIVERY_TIME_FROM"), ":")(1)).ToString("00")
                stbFrom.Append(strHH & ":" & strMI)
            Else
                stbFrom.Append("00:00")
            End If

            ' �I�����t���擾
            Dim stbTo As New StringBuilder(String.Empty)
            If dicParam.ContainsKey("DELIVERY_DATE_TO") Then
                stbTo.Append(dicParam("DELIVERY_DATE_TO"))
                stbTo.Append(" ")
                If dicParam.ContainsKey("DELIVERY_TIME_TO") Then
                    Dim strHH As String = Convert.ToInt32(Split(dicParam("DELIVERY_TIME_TO"), ":")(0)).ToString("00")
                    Dim strMI As String = Convert.ToInt32(Split(dicParam("DELIVERY_TIME_TO"), ":")(1)).ToString("00")
                    stbTo.Append(strHH & ":" & strMI)
                Else
                    stbTo.Append("23:59")
                End If
            End If

            Dim stbSQL As New StringBuilder(String.Empty)

            ' SQL�쐬
            stbSQL.AppendLine("   SELECT TO_CHAR(T_JJ_IMAGE.DELIVERY_DATE,'YYYY/MM/DD') AS DELIVERY_DATE, ")
            stbSQL.AppendLine("          T_JJ_IMAGE.SLIP_DEFINE_ID, ")
            stbSQL.AppendLine("          COUNT(*) AS IMAGE_COUNT ")
            stbSQL.AppendLine("     FROM T_JJ_IMAGE ")
            stbSQL.AppendLine("          INNER JOIN M_SLIP_DEFINE ")
            stbSQL.AppendLine("             ON T_JJ_IMAGE.SLIP_DEFINE_ID = M_SLIP_DEFINE.SLIP_DEFINE_ID ")
            stbSQL.AppendLine("    WHERE M_SLIP_DEFINE.SORT_NO IS NOT NULL ")
            stbSQL.AppendLine("      AND M_SLIP_DEFINE.ENTRY_TARGET_FLG = '1' ")

            If Not String.IsNullOrEmpty(dicParam("HIDE_SLIP_DEFINE_ID")) Then
                stbSQL.AppendLine("      AND T_JJ_IMAGE.SLIP_DEFINE_ID NOT IN (" & dicParam("HIDE_SLIP_DEFINE_ID") & ")")
            End If

            If Not String.IsNullOrEmpty(dicParam("TARGET_SLIP")) Then
                stbSQL.AppendLine("      AND SUBSTRB(T_JJ_IMAGE.SLIP_DEFINE_ID, 1, 3) IN (" & dicParam("TARGET_SLIP") & ")")
            End If

            stbSQL.AppendLine("      AND TO_CHAR(T_JJ_IMAGE.DELIVERY_DATE, 'YYYY/MM/DD HH24:MI') >= '" & stbFrom.ToString & "'")

            If stbTo.Length > 0 Then
                stbSQL.AppendLine("      AND TO_CHAR(T_JJ_IMAGE.DELIVERY_DATE, 'YYYY/MM/DD HH24:MI') <= '" & stbTo.ToString & "'")
            End If

            stbSQL.AppendLine(" GROUP BY TO_CHAR(T_JJ_IMAGE.DELIVERY_DATE,'YYYY/MM/DD'), ")
            stbSQL.AppendLine("          T_JJ_IMAGE.SLIP_DEFINE_ID ")
            stbSQL.AppendLine(" ORDER BY DELIVERY_DATE ")

            Dim dt As DataTable = objclsDbAccess.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)

            ' SQL���O�o��
            clsUtility.WriteLog(objclsDbAccess.mobjCommonDB.GetInfoMessage, EventLogEntryType.Information)

            ' ���s
            Return dt

        Finally
            objclsDbAccess.mobjCommonDB.DB_Close()
        End Try

    End Function

#End Region

End Class
