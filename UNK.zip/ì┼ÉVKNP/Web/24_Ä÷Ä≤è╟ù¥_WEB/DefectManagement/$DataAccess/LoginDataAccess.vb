Imports System.Data
Imports System.Collections.Generic
Imports Oracle.DataAccess.Client

Public Class LoginDataAccess

#Region "GetSqlUser"

    ''' <summary>
    ''' ���[�U�[�擾SQL
    ''' </summary>
    ''' <param name="strUserId">���[�U�[ID</param>
    ''' <param name="strPassword">�p�X���[�h</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetSqlUser(ByVal strUserId As String, ByVal strPassword As String) As DataTable

        ' DB�ڑ�����
        Dim objclsDbAccess As New clsDbAccess
        Call objclsDbAccess.dbOpen()
        Try
            Dim stbSQL As New StringBuilder(String.Empty)

            'SQL�쐬
            stbSQL.AppendLine("SELECT")
            stbSQL.AppendLine(" USER_ID")
            stbSQL.AppendLine("FROM")
            stbSQL.AppendLine("	M_CM_USER")
            stbSQL.AppendLine("WHERE")
            stbSQL.AppendLine("	    USER_ID     =	:USER_ID")
            stbSQL.AppendLine("	AND PASSWORD	=	:PASSWORD")
            stbSQL.AppendLine(" AND DELETE_FLG  =   '0'")

            '�p�����[�^�ݒ�
            Dim oraUpdateParam(1) As OracleParameter
            oraUpdateParam(0) = New OracleParameter("USER_ID", OracleDbType.Char)
            oraUpdateParam(1) = New OracleParameter("PASSWORD", OracleDbType.Char)
            oraUpdateParam(0).Value = strUserId
            oraUpdateParam(1).Value = strPassword

            Dim dt As DataTable = objclsDbAccess.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString, oraUpdateParam)

            ' SQL���O�o��
            clsUtility.WriteLog(objclsDbAccess.mobjCommonDB.GetInfoMessage, EventLogEntryType.Information)

            '���s
            Return dt
        Finally
            objclsDbAccess.mobjCommonDB.DB_Close()
        End Try

    End Function

#End Region

#Region "UpdSqlMCmUserUpdateDate"
    ''' <summary>
    ''' ���[�U�}�X�^�̍X�V�����X�V
    ''' </summary>
    ''' <param name="Parm">�p�����[�^</param>
    ''' <remarks></remarks>
    Public Function UpdSqlMCmUserUpdateDate(ByVal Parm As Dictionary(Of String, String)) As Integer

        ' DB�ڑ�����
        Dim objclsDbAccess As New clsDbAccess
        Call objclsDbAccess.dbOpen()
        Try
            '�p�����[�^�ݒ�
            Dim oraUpdateParam(0) As OracleParameter
            oraUpdateParam(0) = New OracleParameter("USER_ID", OracleDbType.Char)
            oraUpdateParam(0).Value = Parm.Item("USER_ID")

            ' SQL���O�o��
            clsUtility.WriteLog(objclsDbAccess.mobjCommonDB.GetInfoMessage, EventLogEntryType.Information)

            '**********************
            '�X�V����
            '**********************
            Dim stbSQL As New StringBuilder(String.Empty)

            'SQL�쐬
            stbSQL.AppendLine("UPDATE M_CM_USER")
            stbSQL.AppendLine("SET")
            stbSQL.AppendLine("	 UPDATE_DATE	= SYSDATE")
            stbSQL.AppendLine("	,UPDATE_USER	= :USER_ID")
            stbSQL.AppendLine("WHERE")
            stbSQL.AppendLine("	USER_ID	         =	:USER_ID")

            '���s
            Dim intResultCount As Integer = objclsDbAccess.mobjCommonDB.DB_ExecuteNonQuery(stbSQL.ToString, oraUpdateParam)

            ' SQL���O�o��
            clsUtility.WriteLog(objclsDbAccess.mobjCommonDB.GetInfoMessage, EventLogEntryType.Information)

            Return intResultCount
        Finally
            objclsDbAccess.mobjCommonDB.DB_Close()
        End Try

    End Function
#End Region

End Class
