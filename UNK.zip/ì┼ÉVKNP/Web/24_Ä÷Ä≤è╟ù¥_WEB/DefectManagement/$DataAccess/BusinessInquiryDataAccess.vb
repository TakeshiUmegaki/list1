Imports System.Data
Imports Oracle.DataAccess.Client
Imports DefectManagement.clsConst

Public Class BusinessInquiryDataAccess

#Region " �Ɩ��󋵏Ɖ�i��tID�P�ʁj�ꗗ�擾 "
    ''' <summary>
    ''' �Ɩ��󋵏Ɖ�i��tID�P�ʁj�ꗗ�擾
    ''' </summary>
    ''' <param name="dicParam">���������󂯓n���p</param>
    ''' <returns>�������ʃf�[�^�e�[�u��</returns>
    ''' <remarks></remarks>
    Public Function GetReceiptIdList(ByVal dicParam As Dictionary(Of String, String)) As DataTable

        ' DB�ڑ����܂�
        Dim objclsDbAccess As New clsDbAccess
        Dim strTargetSlip As String = ConfigurationManager.AppSettings("TARGET_SLIP")

        Call objclsDbAccess.dbOpen()

        Try

            Dim stbSQL As New StringBuilder(String.Empty)

            'SQL�쐬
            stbSQL.AppendLine(" SELECT  ")
            stbSQL.AppendLine("        LPAD(T_JJ_RECEIPT.RECEIPT_ID,11,'0') AS RECEIPT_ID, ")
            stbSQL.AppendLine("        CASE MAX(SUBSTRB(T_JJ_IMAGE.SLIP_DEFINE_ID, 1, 3)) ")
            stbSQL.AppendLine("             WHEN '601' THEN '���a�蓖��' ")
            stbSQL.AppendLine("             WHEN '611' THEN '�o�Y�蓖��' ")
            stbSQL.AppendLine("             WHEN '621' THEN '�o�Y�玙�ꎞ��' ")
            stbSQL.AppendLine("             WHEN '631' THEN '������' ")
            stbSQL.AppendLine("             WHEN '641' THEN '���z�×{��' ")
            stbSQL.AppendLine("             WHEN '661' THEN '�×{��' ")
            stbSQL.AppendLine("             ELSE '���̑�' ")
            stbSQL.AppendLine("         END AS SLIP_NAME, ")
            stbSQL.AppendLine("        CASE MAX(T_JJ_IMAGE.EXC_IMAGE_KEY01) ")
            stbSQL.AppendLine("             WHEN 'PE' THEN '��' ")
            stbSQL.AppendLine("             WHEN 'PW' THEN '��' ")
            stbSQL.AppendLine("             ELSE '��' ")
            stbSQL.AppendLine("         END AS EAST_AND_WEST, ")
            stbSQL.AppendLine("        T_JJ_RECEIPT.RECEIPT_COUNT, ")
            stbSQL.AppendLine("        TO_CHAR(T_JJ_RECEIPT.RECEIPT_DATE,'YYYY/MM/DD')||'<BR/>'||TO_CHAR(T_JJ_RECEIPT.RECEIPT_DATE,'HH24:MI:SS') AS RECEIPT_DATE_2, ")
            stbSQL.AppendLine("        T_JJ_RECEIPT.DELIVERY_PLAN_TIME, ")
            stbSQL.AppendLine("        ROUND((SYSDATE - TO_DATE(T_JJ_RECEIPT.DELIVERY_PLAN_TIME || '00','YYYY-MM-DD HH24:MI:SS')) * 24 * 60) * -1 AS TIME_LIMIT, ")
            stbSQL.AppendLine("        T_JJ_RECEIPT.RECEIPT_DATE, ")
            stbSQL.AppendLine("        T_JJ_RECEIPT.RECEIPT_STATUS, ")
            stbSQL.AppendLine("        M_CM_CONFIG.CONFIG_VALUE AS RECEIPT_STATUS_NAME, ")
            stbSQL.AppendLine("        CASE T_JJ_RECEIPT.RECEIPT_STATUS  WHEN '" & RECEIPT_STR_0700 & "' THEN TO_CHAR(MAX(T_JJ_IMAGE.DELIVERY_DATE),'YYYY/MM/DD')||'<BR/>'|| TO_CHAR(MAX(T_JJ_IMAGE.DELIVERY_DATE),'HH24:MI:SS') ELSE NULL END AS DELIVERY_DATE, ")
            stbSQL.AppendLine("        SUM(CASE T_JJ_IMAGE.IMAGE_ID WHEN NULL THEN 0 ELSE 1 END) AS RECEIPT_CNT, ")
            stbSQL.AppendLine("        NVL(T_RECEIPT_PROJECT_CNT.RECEIPT_CNT,0) AS RECEIPT_PROJECT_CNT, ")
            stbSQL.AppendLine("        NVL(T_DELIVERY_PROJECT_CNT.RECEIPT_CNT,0) AS DELIVERY_PROJECT_CNT, ")
            stbSQL.AppendLine("        CASE NVL(T_RECEIPT_PROJECT_CNT.RECEIPT_CNT,0) WHEN NVL(T_DELIVERY_PROJECT_CNT.RECEIPT_CNT,0) THEN '�[�i����' ELSE '' END AS DELIVERY_COMPLETE, ")
            stbSQL.AppendLine("        MAX(T_JJ_IMAGE.EXC_IMAGE_KEY01) AS MAX_EXC_IMAGE_KEY01 ")

            ' ���R�����̍쐬
            For idx As Integer = 1 To 20 Step 1
                ' ���p�L���t���O�̒l��"!"�Ȃ炻�̍��v�l���擾
                Dim strUseKey As String = "BIZ_USE_" & idx.ToString("00")
                Dim strUseVal As String = ConfigurationManager.AppSettings(strUseKey)
                Dim strFreeColmn As String = "Free" & idx.ToString("00")
                If strUseVal.Equals("1") Then
                    Dim strStsKey As String = "BIZ_STS_" & idx.ToString("00")
                    Dim strStsVal As String = ConfigurationManager.AppSettings(strStsKey)
                    stbSQL.AppendLine("        ,TO_CHAR(NVL(T_FREE_TABLE.__FREE_CNT__,0)) || '/' || TO_CHAR(SUM(CASE WHEN IMAGE_STATUS IN (" & strStsVal & ") THEN 1 ELSE 0 END)) AS __FREE_CNT__")
                    stbSQL.Replace("__FREE_CNT__", strFreeColmn)
                Else
                    stbSQL.AppendLine("        ,0 AS __FREE_CNT__")
                    stbSQL.Replace("__FREE_CNT__", strFreeColmn)
                End If
            Next

            stbSQL.AppendLine("   FROM T_JJ_RECEIPT ")
            stbSQL.AppendLine("        INNER JOIN T_JJ_IMAGE ")
            stbSQL.AppendLine("           ON T_JJ_RECEIPT.RECEIPT_ID = T_JJ_IMAGE.RECEIPT_ID ")

            ' ��t�Č���
            stbSQL.AppendLine("         LEFT JOIN (  ")
            stbSQL.AppendLine("                       SELECT RECEIPT_ID,  ")
            stbSQL.AppendLine("                              COUNT(*) AS RECEIPT_CNT  ")
            stbSQL.AppendLine("                         FROM ( ")

            stbSQL.AppendLine("                               SELECT DISTINCT ")
            stbSQL.AppendLine("                                      T_JJ_IMAGE.RECEIPT_ID, ")
            stbSQL.AppendLine("                                      T_JJ_IMAGE.EXC_SUBJECT_NO AS IMAGE_FILE_NAME ")
            stbSQL.AppendLine("                                 FROM T_JJ_RECEIPT  ")
            stbSQL.AppendLine("                                      INNER JOIN T_JJ_IMAGE  ")
            stbSQL.AppendLine("                                         ON T_JJ_RECEIPT.RECEIPT_ID = T_JJ_IMAGE.RECEIPT_ID  ")
            stbSQL.AppendLine("                                WHERE TO_CHAR(T_JJ_RECEIPT.RECEIPT_DATE,'YYYY/MM/DD HH24:MI:SS') BETWEEN :RECEIPT_DATE_FROM AND :RECEIPT_DATE_TO   ")

            ' config�̑Ώے��[�Ɂu641�v���܂܂�Ă���ꍇ�͔�SS�A�܂܂�Ă��Ȃ��ꍇ��SS�Ƃ݂Ȃ�
            If strTargetSlip.Contains(SLIP_DEFINE_ID_NON_SS) Then
                stbSQL.AppendLine("                                  AND (  ")
                stbSQL.AppendLine("                                          T_JJ_IMAGE.SLIP_DEFINE_ID LIKE '641%'  ")
                stbSQL.AppendLine("                                       OR T_JJ_IMAGE.SLIP_DEFINE_ID LIKE '661%'  ")
                stbSQL.AppendLine("                                      )  ")
            Else
                stbSQL.AppendLine("                                  AND (  ")
                stbSQL.AppendLine("                                          T_JJ_IMAGE.SLIP_DEFINE_ID LIKE '601%'  ")
                stbSQL.AppendLine("                                       OR T_JJ_IMAGE.SLIP_DEFINE_ID LIKE '611%'  ")
                stbSQL.AppendLine("                                       OR T_JJ_IMAGE.SLIP_DEFINE_ID LIKE '621%'  ")
                stbSQL.AppendLine("                                       OR T_JJ_IMAGE.SLIP_DEFINE_ID LIKE '631%'  ")
                stbSQL.AppendLine("                                      )  ")
            End If

            stbSQL.AppendLine("                                  AND T_JJ_IMAGE.DELETE_FLG = '0'  ")
            stbSQL.AppendLine("                              ) T_IMAGE_FILE_NAME ")
            stbSQL.AppendLine("                     GROUP BY RECEIPT_ID  ")
            stbSQL.AppendLine("                    ) T_RECEIPT_PROJECT_CNT  ")
            stbSQL.AppendLine("            ON T_JJ_IMAGE.RECEIPT_ID = T_RECEIPT_PROJECT_CNT.RECEIPT_ID  ")

            ' �[�i�Č���
            stbSQL.AppendLine("         LEFT JOIN (  ")
            stbSQL.AppendLine("                       SELECT RECEIPT_ID,  ")
            stbSQL.AppendLine("                              COUNT(*) AS RECEIPT_CNT  ")
            stbSQL.AppendLine("                         FROM ( ")

            stbSQL.AppendLine("                               SELECT DISTINCT ")
            stbSQL.AppendLine("                                      T_JJ_IMAGE.RECEIPT_ID, ")
            stbSQL.AppendLine("                                      T_JJ_IMAGE.EXC_SUBJECT_NO AS IMAGE_FILE_NAME ")
            stbSQL.AppendLine("                                 FROM T_JJ_RECEIPT  ")
            stbSQL.AppendLine("                                      INNER JOIN T_JJ_IMAGE  ")
            stbSQL.AppendLine("                                         ON T_JJ_RECEIPT.RECEIPT_ID = T_JJ_IMAGE.RECEIPT_ID  ")
            stbSQL.AppendLine("                                WHERE TO_CHAR(T_JJ_RECEIPT.RECEIPT_DATE,'YYYY/MM/DD HH24:MI:SS') BETWEEN :RECEIPT_DATE_FROM AND :RECEIPT_DATE_TO   ")

            ' config�̑Ώے��[�Ɂu641�v���܂܂�Ă���ꍇ�͔�SS�A�܂܂�Ă��Ȃ��ꍇ��SS�Ƃ݂Ȃ�
            If strTargetSlip.Contains(SLIP_DEFINE_ID_NON_SS) Then
                stbSQL.AppendLine("                                  AND (  ")
                stbSQL.AppendLine("                                          T_JJ_IMAGE.SLIP_DEFINE_ID LIKE '641%'  ")
                stbSQL.AppendLine("                                       OR T_JJ_IMAGE.SLIP_DEFINE_ID LIKE '661%'  ")
                stbSQL.AppendLine("                                      )  ")
            Else
                stbSQL.AppendLine("                                  AND (  ")
                stbSQL.AppendLine("                                          T_JJ_IMAGE.SLIP_DEFINE_ID LIKE '601%'  ")
                stbSQL.AppendLine("                                       OR T_JJ_IMAGE.SLIP_DEFINE_ID LIKE '611%'  ")
                stbSQL.AppendLine("                                       OR T_JJ_IMAGE.SLIP_DEFINE_ID LIKE '621%'  ")
                stbSQL.AppendLine("                                       OR T_JJ_IMAGE.SLIP_DEFINE_ID LIKE '631%'  ")
                stbSQL.AppendLine("                                      )  ")
            End If

            stbSQL.AppendLine("                                  AND T_JJ_IMAGE.IMAGE_STATUS IN (" & ConfigurationManager.AppSettings("DELETE_COMPLETE_IMAGE_STATUS") & ")  ")
            stbSQL.AppendLine("                                  AND T_JJ_IMAGE.DELETE_FLG = '0'  ")
            stbSQL.AppendLine("                              ) T_IMAGE_FILE_NAME_2 ")
            stbSQL.AppendLine("                     GROUP BY RECEIPT_ID  ")
            stbSQL.AppendLine("                    ) T_DELIVERY_PROJECT_CNT  ")
            stbSQL.AppendLine("            ON T_JJ_IMAGE.RECEIPT_ID = T_DELIVERY_PROJECT_CNT.RECEIPT_ID  ")

            stbSQL.AppendLine("        LEFT JOIN ( ")
            stbSQL.AppendLine("                      SELECT RECEIPT_ID ")

            ' ���R�����̍쐬
            For idx As Integer = 1 To 20 Step 1
                ' ���p�L���t���O�̒l��"!"�Ȃ炻�̍��v�l���擾
                Dim strUseKey As String = "BIZ_USE_" & idx.ToString("00")
                Dim strUseVal As String = ConfigurationManager.AppSettings(strUseKey)
                Dim strFreeColmn As String = "Free" & idx.ToString("00")

                If strUseVal.Equals("1") Then
                    Dim strStsKey As String = "BIZ_STS_" & idx.ToString("00")
                    Dim strStsVal As String = ConfigurationManager.AppSettings(strStsKey)

                    stbSQL.AppendLine("        ,SUM(CASE WHEN MIN_IMAGE_STATUS IN (" & strStsVal & ") THEN 1 ELSE 0 END) AS __FREE_CNT__")
                    stbSQL.Replace("__FREE_CNT__", strFreeColmn)
                End If
            Next

            stbSQL.AppendLine("                          FROM ( ")

            stbSQL.AppendLine("                                  SELECT T_JJ_IMAGE.RECEIPT_ID, ")
            stbSQL.AppendLine("                                         T_JJ_IMAGE.EXC_SUBJECT_NO AS IMAGE_FILE_NAME, ")
            stbSQL.AppendLine("                                         MIN(T_JJ_IMAGE.IMAGE_STATUS) AS MIN_IMAGE_STATUS ")
            stbSQL.AppendLine("                                    FROM T_JJ_RECEIPT  ")
            stbSQL.AppendLine("                                         INNER JOIN T_JJ_IMAGE  ")
            stbSQL.AppendLine("                                            ON T_JJ_RECEIPT.RECEIPT_ID = T_JJ_IMAGE.RECEIPT_ID  ")
            stbSQL.AppendLine("                                   WHERE TO_CHAR(T_JJ_RECEIPT.RECEIPT_DATE,'YYYY/MM/DD HH24:MI:SS') BETWEEN :RECEIPT_DATE_FROM AND :RECEIPT_DATE_TO   ")

            ' config�̑Ώے��[�Ɂu641�v���܂܂�Ă���ꍇ�͔�SS�A�܂܂�Ă��Ȃ��ꍇ��SS�Ƃ݂Ȃ�
            If strTargetSlip.Contains(SLIP_DEFINE_ID_NON_SS) Then
                stbSQL.AppendLine("                                  AND (  ")
                stbSQL.AppendLine("                                          T_JJ_IMAGE.SLIP_DEFINE_ID LIKE '641%'  ")
                stbSQL.AppendLine("                                       OR T_JJ_IMAGE.SLIP_DEFINE_ID LIKE '661%'  ")
                stbSQL.AppendLine("                                      )  ")
            Else
                stbSQL.AppendLine("                                  AND (  ")
                stbSQL.AppendLine("                                          T_JJ_IMAGE.SLIP_DEFINE_ID LIKE '601%'  ")
                stbSQL.AppendLine("                                       OR T_JJ_IMAGE.SLIP_DEFINE_ID LIKE '611%'  ")
                stbSQL.AppendLine("                                       OR T_JJ_IMAGE.SLIP_DEFINE_ID LIKE '621%'  ")
                stbSQL.AppendLine("                                       OR T_JJ_IMAGE.SLIP_DEFINE_ID LIKE '631%'  ")
                stbSQL.AppendLine("                                      )  ")
            End If

            stbSQL.AppendLine("                                  AND T_JJ_IMAGE.DELETE_FLG = '0'  ")
            stbSQL.AppendLine("                                GROUP BY T_JJ_IMAGE.RECEIPT_ID, ")
            stbSQL.AppendLine("                                         T_JJ_IMAGE.EXC_SUBJECT_NO ")
            stbSQL.AppendLine("                               ) FreeTable ")
            stbSQL.AppendLine("                      GROUP BY RECEIPT_ID ")
            stbSQL.AppendLine("                     ) T_FREE_TABLE ")
            stbSQL.AppendLine("             ON T_JJ_IMAGE.RECEIPT_ID = T_FREE_TABLE.RECEIPT_ID ")

            stbSQL.AppendLine("         LEFT JOIN M_CM_CONFIG ")
            stbSQL.AppendLine("           ON T_JJ_RECEIPT.RECEIPT_STATUS = M_CM_CONFIG.CONFIG_ID ")
            stbSQL.AppendLine("          AND M_CM_CONFIG.CONFIG_DIV = '" & CONFIG_DIV_RECEIPT_STATUS & "' ")

            ' �p�����[�^�ݒ�
            Dim oraUpdateParam(dicParam.Count - 3) As OracleParameter
            Dim i As Integer = 0

            stbSQL.AppendLine("  WHERE  TO_CHAR(T_JJ_RECEIPT.RECEIPT_DATE,'YYYY/MM/DD HH24:MI:SS') BETWEEN :RECEIPT_DATE_FROM AND :RECEIPT_DATE_TO ")

            ' ��t��From + ��t����From
            oraUpdateParam(i) = New OracleParameter("RECEIPT_DATE_FROM", OracleDbType.Char)
            oraUpdateParam(i).Value = dicParam.Item("RECEIPT_DATE_FROM") & " " & dicParam.Item("RECEIPT_TIME_FROM")

            i = i + 1

            ' ��t��To + ��t����To
            oraUpdateParam(i) = New OracleParameter("RECEIPT_DATE_TO", OracleDbType.Char)
            oraUpdateParam(i).Value = dicParam.Item("RECEIPT_DATE_TO") & " " & dicParam.Item("RECEIPT_TIME_TO")

            i = i + 1

            ' �X�e�[�^�X�����������Ɏw�肳��Ă���ꍇ
            If dicParam.ContainsKey("RECEIPT_STATUS") Then
                ' �X�e�[�^�X�������ɐݒ�
                stbSQL.AppendLine("  AND  T_JJ_RECEIPT.RECEIPT_STATUS = :RECEIPT_STATUS ")

                oraUpdateParam(i) = New OracleParameter("RECEIPT_STATUS", OracleDbType.Char)
                oraUpdateParam(i).Value = dicParam.Item("RECEIPT_STATUS")

                i = i + 1
            End If

            ' config�̑Ώے��[�Ɂu641�v���܂܂�Ă���ꍇ�͔�SS�A�܂܂�Ă��Ȃ��ꍇ��SS�Ƃ݂Ȃ�
            If strTargetSlip.Contains(SLIP_DEFINE_ID_NON_SS) Then
                stbSQL.AppendLine("      AND ( ")
                stbSQL.AppendLine("              T_JJ_IMAGE.SLIP_DEFINE_ID LIKE '641%' ")
                stbSQL.AppendLine("           OR T_JJ_IMAGE.SLIP_DEFINE_ID LIKE '661%' ")
                stbSQL.AppendLine("          ) ")
            Else
                stbSQL.AppendLine("      AND ( ")
                stbSQL.AppendLine("              T_JJ_IMAGE.SLIP_DEFINE_ID LIKE '601%' ")
                stbSQL.AppendLine("           OR T_JJ_IMAGE.SLIP_DEFINE_ID LIKE '611%' ")
                stbSQL.AppendLine("           OR T_JJ_IMAGE.SLIP_DEFINE_ID LIKE '621%' ")
                stbSQL.AppendLine("           OR T_JJ_IMAGE.SLIP_DEFINE_ID LIKE '631%' ")
                stbSQL.AppendLine("          ) ")
            End If

            ' GROUP BY
            stbSQL.AppendLine("  GROUP BY ")
            stbSQL.AppendLine("         LPAD(T_JJ_RECEIPT.RECEIPT_ID,11,'0'),  ")
            stbSQL.AppendLine("         T_JJ_RECEIPT.RECEIPT_COUNT,  ")
            stbSQL.AppendLine("         T_JJ_RECEIPT.RECEIPT_DATE,  ")
            stbSQL.AppendLine("         T_JJ_RECEIPT.DELIVERY_PLAN_TIME,  ")
            stbSQL.AppendLine("         T_JJ_RECEIPT.RECEIPT_STATUS,  ")
            stbSQL.AppendLine("         M_CM_CONFIG.CONFIG_VALUE ,  ")
            stbSQL.AppendLine("         NVL(T_RECEIPT_PROJECT_CNT.RECEIPT_CNT,0), ")
            stbSQL.AppendLine("         NVL(T_DELIVERY_PROJECT_CNT.RECEIPT_CNT,0) ")

            ' ���R�����̍쐬
            For idx As Integer = 1 To 20 Step 1
                ' ���p�L���t���O�̒l��"!"�Ȃ炻�̍��v�l���擾
                Dim strUseKey As String = "BIZ_USE_" & idx.ToString("00")
                Dim strUseVal As String = ConfigurationManager.AppSettings(strUseKey)
                Dim strFreeColmn As String = "Free" & idx.ToString("00")
                If strUseVal.Equals("1") Then
                    stbSQL.AppendLine("         ,NVL(T_FREE_TABLE.__FREE_CNT__,0)")
                    stbSQL.Replace("__FREE_CNT__", strFreeColmn)
                End If
            Next

            ' �\�[�g��
            stbSQL.AppendLine(" ORDER BY RECEIPT_ID DESC ")

            Dim dt As DataTable = objclsDbAccess.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString, oraUpdateParam)

            ' SQL���O�o��
            clsUtility.WriteLog(objclsDbAccess.mobjCommonDB.GetInfoMessage, EventLogEntryType.Information)

            Dim strPlan As String
            Dim stbPlan As New StringBuilder(String.Empty)
            For Each dr As DataRow In dt.Rows
                strPlan = Convert.ToString(dr.Item("DELIVERY_PLAN_TIME"))
                stbPlan.Length = 0
                stbPlan.Append(strPlan.Substring(0, 4))
                stbPlan.Append("/")
                stbPlan.Append(strPlan.Substring(4, 2))
                stbPlan.Append("/")
                stbPlan.Append(strPlan.Substring(6, 2))
                stbPlan.Append("<BR/>")
                stbPlan.Append(strPlan.Substring(8, 2))
                stbPlan.Append(":")
                stbPlan.Append(strPlan.Substring(10, 2))
                dr.Item("DELIVERY_PLAN_TIME") = stbPlan.ToString
            Next

            '���s
            Return dt

        Finally
            objclsDbAccess.mobjCommonDB.DB_Close()
        End Try

    End Function

#End Region

#Region " �Ɩ��󋵏Ɖ�i�C���[�WID�P�ʁj�ꗗ�擾 "
    ''' <summary>
    ''' �Ɩ��󋵏Ɖ�i�C���[�WID�P�ʁj�ꗗ�擾
    ''' </summary>
    ''' <param name="strReceiptId">��tID</param>
    ''' <returns>�������ʃf�[�^�e�[�u��</returns>
    ''' <remarks></remarks>
    Public Function GetImageIdList(ByVal strReceiptId As String, _
                                   Optional ByVal strImgStatus As String = "", _
                                   Optional ByVal strSlipId As String = "", _
                                   Optional ByVal strSlipDiv As String = "") As DataTable

        ' DB�ڑ����܂�
        Dim objclsDbAccess As New clsDbAccess

        Call objclsDbAccess.dbOpen()

        Try
            Dim stbSQL As New StringBuilder(String.Empty)

            'SQL�쐬
            stbSQL.AppendLine("   SELECT T_JJ_IMAGE.IMAGE_ID, ")
            stbSQL.AppendLine("          TRIM(T_JJ_IMAGE.IMAGE_FILE_NAME) AS IMAGE_FILE_NAME, ")
            stbSQL.AppendLine("          T_JJ_IMAGE.SLIP_DEFINE_ID || '�F' || M_SLIP_DEFINE.SLIP_DEFINE_NAME AS SLIP_DEFINE, ")
            stbSQL.AppendLine("          T_JJ_IMAGE.SLIP_DEFINE_ID, ")
            stbSQL.AppendLine("          T_JJ_IMAGE.IMAGE_STATUS || '�F' || M_CM_CONFIG_1.CONFIG_VALUE AS IMAGE_STATUS, ")
            stbSQL.AppendLine("          T_JJ_IMAGE.EXC_SUBJECT_NO, ")
            stbSQL.AppendLine("          T_JJ_IMAGE.EXC_IMAGE_NO, ")
            stbSQL.AppendLine("          T_JJ_IMAGE.DELIVERY_DATE, ")
            stbSQL.AppendLine("          T_JJ_IMAGE.PRIORITY, ")
            stbSQL.AppendLine("          T_JJ_RECEIPT.RECEIPT_DATE, ")
            stbSQL.AppendLine("          ROUND((SYSDATE - TO_DATE(T_JJ_RECEIPT.DELIVERY_PLAN_TIME || '00','YYYY-MM-DD HH24:MI:SS')) * 24 * 60) * -1 AS TIME_LIMIT, ")
            '            stbSQL.AppendLine("          ROUND((SYSDATE - TO_DATE(T_JJ_IMAGE.EXC_IMAGE_KEY07 || '00','YYYY-MM-DD HH24:MI:SS')) * 24 * 60) * -1 AS TIME_LIMIT_2, ")
            stbSQL.AppendLine("          T_JJ_IMAGE.EXC_IMAGE_KEY01 ")
            stbSQL.AppendLine("     FROM T_JJ_IMAGE ")
            stbSQL.AppendLine("          LEFT JOIN M_CM_CONFIG M_CM_CONFIG_1 ")
            stbSQL.AppendLine("            ON T_JJ_IMAGE.IMAGE_STATUS = M_CM_CONFIG_1.CONFIG_ID ")
            stbSQL.AppendLine("           AND M_CM_CONFIG_1.CONFIG_DIV = :CONFIG_DIV_1 ")
            stbSQL.AppendLine("          LEFT JOIN M_SLIP_DEFINE M_SLIP_DEFINE ")
            stbSQL.AppendLine("             ON T_JJ_IMAGE.SLIP_DEFINE_ID = M_SLIP_DEFINE.SLIP_DEFINE_ID ")
            stbSQL.AppendLine("          INNER JOIN T_JJ_RECEIPT ")
            stbSQL.AppendLine("             ON T_JJ_IMAGE.RECEIPT_ID = T_JJ_RECEIPT.RECEIPT_ID ")

            stbSQL.AppendLine("    WHERE T_JJ_IMAGE.RECEIPT_ID = :RECEIPT_ID ")

            If Not strImgStatus.Equals(String.Empty) Then
                stbSQL.AppendLine("    AND T_JJ_IMAGE.IMAGE_STATUS  = '" & strImgStatus & "' ")
            End If

            If Not strSlipId.Equals(String.Empty) Then
                stbSQL.AppendLine("    AND T_JJ_IMAGE.SLIP_DEFINE_ID  = '" & strSlipId & "' ")
            End If

            If Not strSlipDiv.Equals(String.Empty) Then
                stbSQL.AppendLine("    AND M_SLIP_DEFINE.SLIP_DIV  = '" & strSlipDiv & "' ")
            End If

            stbSQL.AppendLine(" ORDER BY T_JJ_IMAGE.IMAGE_ID ")

            '�p�����[�^�ݒ�
            Dim oraUpdateParam(1) As OracleParameter
            oraUpdateParam(0) = New OracleParameter("RECEIPT_ID", OracleDbType.Int64)
            oraUpdateParam(0).Value = strReceiptId
            oraUpdateParam(1) = New OracleParameter("CONFIG_DIV_1", OracleDbType.Int64)
            oraUpdateParam(1).Value = clsConst.CONFIG_DIV_IMAGE_STATUS

            Dim dt As DataTable = objclsDbAccess.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString, oraUpdateParam)

            ' SQL���O�o��
            clsUtility.WriteLog(objclsDbAccess.mobjCommonDB.GetInfoMessage, EventLogEntryType.Information)

            '���s
            Return dt

        Finally
            objclsDbAccess.mobjCommonDB.DB_Close()
        End Try

    End Function

#End Region

#Region " �Ɩ��Ɖ�i�G���g���[�󋵁j�w�b�_�[�擾 "
    ''' <summary>
    ''' �Ɩ��Ɖ�i�G���g���[�󋵁j�w�b�_�[�擾
    ''' </summary>
    ''' <param name="strImageId">�C���[�WID</param>
    ''' <returns>�������ʃf�[�^�e�[�u��</returns>
    ''' <remarks></remarks>
    Public Function GetEntryStateHeader(ByVal strImageId As String) As DataTable

        ' DB�ڑ����܂�
        Dim objclsDbAccess As New clsDbAccess

        Call objclsDbAccess.dbOpen()

        Try
            Dim stbSQL As New StringBuilder(String.Empty)

            'SQL�쐬
            stbSQL.AppendLine(" SELECT T_JJ_IMAGE.IMAGE_ID")    '--�C���[�WID
            stbSQL.AppendLine(",TRIM(T_JJ_IMAGE.IMAGE_FILE_NAME) AS IMAGE_FILE_NAME")    '--�C���[�W�t�@�C����
            stbSQL.AppendLine(",T_JJ_IMAGE.SLIP_DEFINE_ID  || '�F' || M_SLIP_DEFINE.SLIP_DEFINE_NAME AS SLIP_DEFINE_ID") '--���[���ID�F���[��ޖ�
            stbSQL.AppendLine(",T_JJ_RECEIPT.RECEIPT_DATE")     '--��t����
            stbSQL.AppendLine(",T_JJ_IMAGE.DEF_REV_COUNT")      '--�s��������
            stbSQL.AppendLine(" FROM T_JJ_IMAGE")
            stbSQL.AppendLine("	LEFT JOIN M_SLIP_DEFINE")       '--���[��ރ}�X�^
            stbSQL.AppendLine("		ON T_JJ_IMAGE.SLIP_DEFINE_ID = M_SLIP_DEFINE.SLIP_DEFINE_ID")
            stbSQL.AppendLine("	LEFT JOIN T_JJ_RECEIPT")        '--��t�e�[�u��
            stbSQL.AppendLine("		ON T_JJ_IMAGE.RECEIPT_ID = T_JJ_RECEIPT.RECEIPT_ID")
            stbSQL.AppendLine(" WHERE T_JJ_IMAGE.IMAGE_ID = :IMAGE_ID")

            '�p�����[�^�ݒ�
            Dim oraUpdateParam(0) As OracleParameter
            oraUpdateParam(0) = New OracleParameter("IMAGE_ID", OracleDbType.Int64)
            oraUpdateParam(0).Value = strImageId

            Dim dt As DataTable = objclsDbAccess.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString, oraUpdateParam)

            ' SQL���O�o��
            clsUtility.WriteLog(objclsDbAccess.mobjCommonDB.GetInfoMessage, EventLogEntryType.Information)

            '���s
            Return dt

        Finally
            objclsDbAccess.mobjCommonDB.DB_Close()
        End Try

    End Function

#End Region

#Region " �Ɩ��Ɖ�i�G���g���[�󋵁j�ꗗ�擾 "
    ''' <summary>
    ''' �Ɩ��Ɖ�i�G���g���[�󋵁j�ꗗ�擾
    ''' </summary>
    ''' <param name="strImageId">�C���[�WID</param>
    ''' <returns>�������ʃf�[�^�e�[�u��</returns>
    ''' <remarks></remarks>
    Public Function GetEntryStateList(ByVal strImageId As String) As DataTable

        ' DB�ڑ����܂�
        Dim objclsDbAccess As New clsDbAccess

        Call objclsDbAccess.dbOpen()

        Try
            Dim stbSQL As New StringBuilder(String.Empty)

            'SQL�쐬
            stbSQL.AppendLine("   SELECT MEP.PROJECT_ID, ")
            stbSQL.AppendLine("          MEP.PROJECT_NAME, ")
            stbSQL.AppendLine("          MEP.WORK_LEVEL, ")
            stbSQL.AppendLine("          MCC.CONFIG_VALUE AS DIVIDE_FLG, ")
            stbSQL.AppendLine("          EPL.START_TIME, ")
            stbSQL.AppendLine("          EPL.END_TIME, ")
            stbSQL.AppendLine("          EPL.PROCESS_SEC, ")
            stbSQL.AppendLine("          EPL.OPER_ID ")
            stbSQL.AppendLine("     FROM M_CM_ENTRY_PROC MEP ")
            stbSQL.AppendLine("          LEFT JOIN T_JJ_IMAGE IMG ")
            stbSQL.AppendLine("            ON IMG.SLIP_DEFINE_ID  = MEP.SLIP_DEFINE_ID ")
            stbSQL.AppendLine("           AND IMG.EXC_IMAGE_KEY06 = MEP.COOP_DIV ")
            stbSQL.AppendLine("          LEFT JOIN M_SLIP_DEFINE MSD ")
            stbSQL.AppendLine("            ON MSD.SLIP_DEFINE_ID = MEP.SLIP_DEFINE_ID ")
            stbSQL.AppendLine("          LEFT JOIN T_JJ_ENTRY_PROC_LOG EPL ")
            stbSQL.AppendLine("            ON EPL.IMAGE_ID   = IMG.IMAGE_ID ")
            stbSQL.AppendLine("           AND EPL.PROJECT_ID = MEP.PROJECT_ID ")
            stbSQL.AppendLine("           AND EPL.WORK_LEVEL = MEP.WORK_LEVEL ")
            stbSQL.AppendLine("           AND EPL.DELETE_FLG = '0' ")
            stbSQL.AppendLine("          LEFT JOIN M_CM_CONFIG MCC ")
            stbSQL.AppendLine("            ON MCC.CONFIG_ID  = MEP.DIVIDE_FLG ")
            stbSQL.AppendLine("           AND MCC.CONFIG_DIV = '15' ")
            stbSQL.AppendLine("    WHERE IMG.IMAGE_ID = :IMAGE_ID ")
            stbSQL.AppendLine(" ORDER BY MEP.SORT_NO ")

            '�p�����[�^�ݒ�
            Dim oraUpdateParam(0) As OracleParameter
            oraUpdateParam(0) = New OracleParameter("IMAGE_ID", OracleDbType.Int64)
            oraUpdateParam(0).Value = strImageId

            Dim dt As DataTable = objclsDbAccess.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString, oraUpdateParam)

            ' SQL���O�o��
            clsUtility.WriteLog(objclsDbAccess.mobjCommonDB.GetInfoMessage, EventLogEntryType.Information)

            '���s
            Return dt

        Finally
            objclsDbAccess.mobjCommonDB.DB_Close()
        End Try

    End Function

#End Region

End Class
