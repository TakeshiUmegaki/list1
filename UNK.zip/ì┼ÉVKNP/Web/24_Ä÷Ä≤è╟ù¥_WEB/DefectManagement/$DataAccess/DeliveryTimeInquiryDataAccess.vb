Imports System.Data
Imports Oracle.DataAccess.Client
Imports DefectManagement.clsConst

Public Class DeliveryTimeInquiryDataAccess

    Public Function GetList(ByVal dicParam As Dictionary(Of String, String)) As DataTable

        ' DB�ڑ����܂�
        Dim objclsDbAccess As New clsDbAccess
        Dim strTargetSlip As String = ConfigurationManager.AppSettings("TARGET_SLIP")

        Call objclsDbAccess.dbOpen()

        Try
            Dim stbSQL As New StringBuilder(String.Empty)

            'SQL�쐬
            stbSQL.AppendLine("   SELECT T_JJ_RECEIPT.RECEIPT_DATE, ")

            ' config�̑Ώے��[�Ɂu641�v���܂܂�Ă���ꍇ�͔�SS�A�܂܂�Ă��Ȃ��ꍇ��SS�Ƃ݂Ȃ�
            If strTargetSlip.Contains(SLIP_DEFINE_ID_NON_SS) Then
                stbSQL.AppendLine("          SUM(CASE TO_CHAR(T_JJ_IMAGE.DELIVERY_DATE, 'HH24:MI') WHEN '19:00' THEN 1 ELSE 0 END) AS ""TIME_01"", ")
                stbSQL.AppendLine("          0 AS ""TIME_02"", ")
                stbSQL.AppendLine("          0 AS ""TIME_03"", ")
                stbSQL.AppendLine("          0 AS ""TIME_04"", ")
                stbSQL.AppendLine("          0 AS ""TIME_05"", ")
                stbSQL.AppendLine("          0 AS ""TIME_06"", ")
                stbSQL.AppendLine("          0 AS ""TIME_07"", ")
                stbSQL.AppendLine("          0 AS ""TIME_08"", ")
                stbSQL.AppendLine("          0 AS ""TIME_09"", ")
                stbSQL.AppendLine("          0 AS ""TIME_10"", ")
                stbSQL.AppendLine("          0 AS ""TIME_11"" ")
            Else
                stbSQL.AppendLine("          SUM(CASE TO_CHAR(T_JJ_IMAGE.DELIVERY_DATE, 'HH24:MI') WHEN '08:40' THEN 1 ELSE 0 END) AS ""TIME_01"", ")
                stbSQL.AppendLine("          SUM(CASE TO_CHAR(T_JJ_IMAGE.DELIVERY_DATE, 'HH24:MI') WHEN '09:40' THEN 1 ELSE 0 END) AS ""TIME_02"", ")
                stbSQL.AppendLine("          SUM(CASE TO_CHAR(T_JJ_IMAGE.DELIVERY_DATE, 'HH24:MI') WHEN '10:40' THEN 1 ELSE 0 END) AS ""TIME_03"", ")
                stbSQL.AppendLine("          SUM(CASE TO_CHAR(T_JJ_IMAGE.DELIVERY_DATE, 'HH24:MI') WHEN '11:40' THEN 1 ELSE 0 END) AS ""TIME_04"", ")
                stbSQL.AppendLine("          SUM(CASE TO_CHAR(T_JJ_IMAGE.DELIVERY_DATE, 'HH24:MI') WHEN '12:40' THEN 1 ELSE 0 END) AS ""TIME_05"", ")
                stbSQL.AppendLine("          SUM(CASE TO_CHAR(T_JJ_IMAGE.DELIVERY_DATE, 'HH24:MI') WHEN '13:40' THEN 1 ELSE 0 END) AS ""TIME_06"", ")
                stbSQL.AppendLine("          SUM(CASE TO_CHAR(T_JJ_IMAGE.DELIVERY_DATE, 'HH24:MI') WHEN '14:40' THEN 1 ELSE 0 END) AS ""TIME_07"", ")
                stbSQL.AppendLine("          SUM(CASE TO_CHAR(T_JJ_IMAGE.DELIVERY_DATE, 'HH24:MI') WHEN '15:40' THEN 1 ELSE 0 END) AS ""TIME_08"", ")
                stbSQL.AppendLine("          SUM(CASE TO_CHAR(T_JJ_IMAGE.DELIVERY_DATE, 'HH24:MI') WHEN '16:40' THEN 1 ELSE 0 END) AS ""TIME_09"", ")
                stbSQL.AppendLine("          SUM(CASE TO_CHAR(T_JJ_IMAGE.DELIVERY_DATE, 'HH24:MI') WHEN '17:40' THEN 1 ELSE 0 END) AS ""TIME_10"", ")
                stbSQL.AppendLine("          SUM(CASE TO_CHAR(T_JJ_IMAGE.DELIVERY_DATE, 'HH24:MI') WHEN '18:40' THEN 1 ELSE 0 END) AS ""TIME_11"" ")
            End If

            stbSQL.AppendLine("     FROM T_JJ_RECEIPT ")
            stbSQL.AppendLine("            INNER JOIN T_JJ_IMAGE ")
            stbSQL.AppendLine("               ON T_JJ_RECEIPT.RECEIPT_ID = T_JJ_IMAGE.RECEIPT_ID ")

            ' �p�����[�^�ݒ�
            Dim oraUpdateParam(dicParam.Count - 1) As OracleParameter
            Dim i As Integer = 0

            stbSQL.AppendLine("    WHERE TO_CHAR(T_JJ_IMAGE.DELIVERY_DATE,'YYYY/MM/DD') = :DELIVERY_DATE ")

            ' ��t��From + ��t����From
            oraUpdateParam(i) = New OracleParameter("DELIVERY_DATE", OracleDbType.Char)
            oraUpdateParam(i).Value = dicParam.Item("DELIVERY_DATE")

            i = i + 1

            stbSQL.AppendLine("      AND SUBSTRB(T_JJ_IMAGE.SLIP_DEFINE_ID, 1, 3)  IN (" & strTargetSlip & ")")

            ' GROUP BY
            stbSQL.AppendLine(" GROUP BY T_JJ_RECEIPT.RECEIPT_DATE ")

            ' �\�[�g��
            stbSQL.AppendLine(" ORDER BY T_JJ_RECEIPT.RECEIPT_DATE DESC ")

            Dim dt As DataTable = objclsDbAccess.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString, oraUpdateParam)

            ' SQL���O�o��
            clsUtility.WriteLog(objclsDbAccess.mobjCommonDB.GetInfoMessage, EventLogEntryType.Information)

            '���s
            Return dt

        Finally
            objclsDbAccess.mobjCommonDB.DB_Close()
        End Try

    End Function


End Class
