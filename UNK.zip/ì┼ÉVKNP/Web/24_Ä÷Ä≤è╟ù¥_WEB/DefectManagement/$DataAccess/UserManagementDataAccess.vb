Imports System.Data
Imports System.Collections.Generic
Imports Oracle.DataAccess.Client

Public Class UserManagementDataAccess

#Region "GetSqlAnthDdl"

    ''' <summary>
    ''' �����h���b�v�_�E���擾SQL
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetSqlAnthDdl() As DataTable

        ' DB�ڑ����܂�
        Dim objclsDbAccess As New clsDbAccess
        Call objclsDbAccess.dbOpen()

        Try
            Dim stbSQL As New StringBuilder(String.Empty)

            'SQL�쐬
            stbSQL.AppendLine("  SELECT CONFIG_ID AS STATUS_ID,")
            stbSQL.AppendLine("         CONFIG_VALUE AS STATUS_NAME")
            stbSQL.AppendLine("    FROM M_CM_CONFIG")
            stbSQL.AppendLine("   WHERE CONFIG_DIV = '" & clsConst.CONFIG_DIV_AUTHORITY & "'")
            stbSQL.AppendLine("     AND SORT_NO IS NOT NULL")
            stbSQL.AppendLine("     AND DELETE_FLG = '0'")
            stbSQL.AppendLine("ORDER BY SORT_NO ")

            Dim dt As DataTable = objclsDbAccess.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)

            ' SQL���O�o��
            clsUtility.WriteLog(objclsDbAccess.mobjCommonDB.GetInfoMessage, EventLogEntryType.Information)

            ' ���s
            Return dt
        Finally
            objclsDbAccess.mobjCommonDB.DB_Close()
        End Try

    End Function

#End Region

#Region "GetSqlMCmUser"

    ''' <summary>
    ''' ���[�U�[���擾SQL
    ''' </summary>
    ''' <param name="Parm">�p�����[�^�[</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetSqlMCmUser(ByVal Parm As Dictionary(Of String, String)) As DataTable

        ' DB�ڑ����܂�
        Dim objclsDbAccess As New clsDbAccess
        Call objclsDbAccess.dbOpen()

        Try
            Dim stbSQL As New StringBuilder(String.Empty)

            'SQL�쐬
            stbSQL.AppendLine("SELECT")
            stbSQL.AppendLine("  USER_ID")
            stbSQL.AppendLine(" ,PASSWORD")
            stbSQL.AppendLine(" ,PASSWORD_LIMIT_DATE")
            stbSQL.AppendLine(" ,USER_NAME")
            stbSQL.AppendLine(" ,USER_NAME_KANA")
            stbSQL.AppendLine(" ,ROLL_CD")
            stbSQL.AppendLine(" ,CONFIG_VALUE AS ROLL_NM")
            stbSQL.AppendLine(" ,TO_CHAR(UPDATE_DATE,'YYYY/MM/DD HH24:MI:SS') AS UPDATE_DATE")
            stbSQL.AppendLine("FROM")
            stbSQL.AppendLine("	M_CM_USER")
            stbSQL.AppendLine("     LEFT JOIN  ")
            stbSQL.AppendLine("         (SELECT CONFIG_ID,CONFIG_VALUE ")
            stbSQL.AppendLine("            FROM M_CM_CONFIG ")
            stbSQL.AppendLine("           WHERE CONFIG_DIV  = '05') CFG05 ")
            stbSQL.AppendLine("         ON M_CM_USER.ROLL_CD =   CFG05.CONFIG_ID ")
            stbSQL.AppendLine("WHERE")
            stbSQL.AppendLine("  DELETE_FLG  =   '0'")

            '�p�����[�^�ݒ�
            Dim oraUpdateParam(Parm.Count - 1) As OracleParameter
            Dim i As Integer

            ' ���[�UID�����������Ɏw�肳��Ă���ꍇ
            If Parm.ContainsKey("USER_ID") AndAlso Not String.IsNullOrEmpty(Parm.Item("USER_ID")) Then
                stbSQL.AppendLine(" AND USER_ID     =	:USER_ID")

                oraUpdateParam(i) = New OracleParameter("USER_ID", OracleDbType.Char)
                oraUpdateParam(i).Value = Parm.Item("USER_ID")

                i = i + 1

            End If

            ' ���[�U�������������Ɏw�肳��Ă���ꍇ
            If Parm.ContainsKey("USER_NAME") AndAlso Not String.IsNullOrEmpty(Parm.Item("USER_NAME")) Then
                stbSQL.AppendLine(" AND USER_NAME     =	:USER_NAME")

                oraUpdateParam(i) = New OracleParameter("USER_NAME", OracleDbType.Char)
                oraUpdateParam(i).Value = Parm.Item("USER_NAME")

                i = i + 1

            End If

            ' ���[�U���J�i�����������Ɏw�肳��Ă���ꍇ
            If Parm.ContainsKey("USER_NAME_KANA") AndAlso Not String.IsNullOrEmpty(Parm.Item("USER_NAME_KANA")) Then
                stbSQL.AppendLine(" AND USER_NAME_KANA     =	:USER_NAME_KANA")

                oraUpdateParam(i) = New OracleParameter("USER_NAME_KANA", OracleDbType.Char)
                oraUpdateParam(i).Value = Parm.Item("USER_NAME_KANA")

                i = i + 1

            End If

            ' ���[�U���������������Ɏw�肳��Ă���ꍇ
            If Parm.ContainsKey("ROLL_CD") AndAlso Not String.IsNullOrEmpty(Parm.Item("ROLL_CD")) Then
                stbSQL.AppendLine(" AND ROLL_CD     =	:ROLL_CD")

                oraUpdateParam(i) = New OracleParameter("ROLL_CD", OracleDbType.Char)
                oraUpdateParam(i).Value = Parm.Item("ROLL_CD")
            End If

            Dim dt As DataTable = objclsDbAccess.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString, oraUpdateParam)

            ' SQL���O�o��
            clsUtility.WriteLog(objclsDbAccess.mobjCommonDB.GetInfoMessage, EventLogEntryType.Information)

            '���s
            Return dt
        Finally
            objclsDbAccess.mobjCommonDB.DB_Close()
        End Try

    End Function

#End Region

#Region "InsSqlMCmUser"
    ''' <summary>
    ''' ���[�U�}�X�^�o�^
    ''' </summary>
    ''' <param name="Parm">�p�����[�^</param>
    ''' <remarks></remarks>
    Public Function InsSqlMCmUser(ByVal Parm As Dictionary(Of String, String)) As Integer

        ' DB�ڑ�����
        Dim objclsDbAccess As New clsDbAccess
        Call objclsDbAccess.dbOpen()

        Try
            Dim stbSQL As New StringBuilder(String.Empty)

            'SQL�쐬
            stbSQL.AppendLine("INSERT INTO M_CM_USER")
            stbSQL.AppendLine("    (                ")
            stbSQL.AppendLine("     USER_ID         ")
            stbSQL.AppendLine("    ,USER_NAME       ")
            stbSQL.AppendLine("    ,USER_NAME_KANA  ")
            stbSQL.AppendLine("    ,ROLL_CD         ")
            stbSQL.AppendLine("    ,PASSWORD        ")
            stbSQL.AppendLine("    ,LOGIN_DATE      ")
            stbSQL.AppendLine("    ,LOGOUT_DATE     ")
            stbSQL.AppendLine("    ,DELETE_FLG      ")
            stbSQL.AppendLine("    ,CREATE_DATE     ")
            stbSQL.AppendLine("    ,CREATE_USER     ")
            stbSQL.AppendLine("    ,UPDATE_DATE     ")
            stbSQL.AppendLine("    ,UPDATE_USER     ")
            stbSQL.AppendLine("    )                ")
            stbSQL.AppendLine("VALUES               ")
            stbSQL.AppendLine("    (                ")
            stbSQL.AppendLine("     :UserId         ")
            stbSQL.AppendLine("    ,:UserName       ")
            stbSQL.AppendLine("    ,:UserNameKana   ")
            stbSQL.AppendLine("    ,:RollCd         ")
            stbSQL.AppendLine("    ,:Password       ")
            stbSQL.AppendLine("    ,null            ")
            stbSQL.AppendLine("    ,null            ")
            stbSQL.AppendLine("    ,'0'             ")
            stbSQL.AppendLine("    ,sysdate         ")
            stbSQL.AppendLine("    ,:CreateUser     ")
            stbSQL.AppendLine("    ,sysdate         ")
            stbSQL.AppendLine("    ,:UpdateUser     ")
            stbSQL.AppendLine("    )                ")

            '�p�����[�^�ݒ�
            Dim oraUpdateParam(6) As OracleParameter
            oraUpdateParam(0) = New OracleParameter("UserId", OracleDbType.Char)
            oraUpdateParam(1) = New OracleParameter("UserName", OracleDbType.Char)
            oraUpdateParam(2) = New OracleParameter("UserNameKana", OracleDbType.Char)
            oraUpdateParam(3) = New OracleParameter("RollCd", OracleDbType.Char)
            oraUpdateParam(4) = New OracleParameter("Password", OracleDbType.Char)
            oraUpdateParam(5) = New OracleParameter("CreateUser", OracleDbType.Char)
            oraUpdateParam(6) = New OracleParameter("UpdateUser", OracleDbType.Char)
            oraUpdateParam(0).Value = Parm.Item("USER_ID")
            oraUpdateParam(1).Value = Parm.Item("USER_NAME")
            oraUpdateParam(2).Value = Parm.Item("USER_NAME_KANA")
            oraUpdateParam(3).Value = Parm.Item("ROLL_CD")
            oraUpdateParam(4).Value = Parm.Item("PASSWORD")
            oraUpdateParam(5).Value = Parm.Item("CREATE_USER")
            oraUpdateParam(6).Value = Parm.Item("UPDATE_USER")

            '���s
            Dim intResultCount As Integer = objclsDbAccess.mobjCommonDB.DB_ExecuteNonQuery(stbSQL.ToString, oraUpdateParam)

            ' SQL���O�o��
            clsUtility.WriteLog(objclsDbAccess.mobjCommonDB.GetInfoMessage, EventLogEntryType.Information)

            Return intResultCount
        Finally
            objclsDbAccess.mobjCommonDB.DB_Close()
        End Try

    End Function
#End Region

#Region "UpdSqlMCmUser"
    ''' <summary>
    ''' ���[�U�}�X�^�X�V
    ''' </summary>
    ''' <param name="Parm">�p�����[�^</param>
    ''' <remarks></remarks>
    Public Function UpdSqlMCmUser(ByVal Parm As Dictionary(Of String, String)) As Integer

        ' DB�ڑ�����
        Dim objclsDbAccess As New clsDbAccess
        Dim intResultCount As Integer

        Call objclsDbAccess.dbOpen()

        Try
            '�p�����[�^�ݒ�
            Dim oraExclusionParam(0) As OracleParameter
            oraExclusionParam(0) = New OracleParameter("USER_ID", OracleDbType.Char)
            oraExclusionParam(0).Value = Parm.Item("USER_ID")

            '**********************
            '�r������
            '**********************
            Dim stbSQLForUpdate As New StringBuilder(String.Empty)

            'SQL�쐬
            stbSQLForUpdate.AppendLine("SELECT USER_ID")
            stbSQLForUpdate.AppendLine("  FROM M_CM_USER")
            stbSQLForUpdate.AppendLine(" WHERE USER_ID	  =	:USER_ID")
            stbSQLForUpdate.AppendLine("   AND DELETE_FLG = '0'")
            stbSQLForUpdate.AppendLine("FOR UPDATE WAIT ")
            stbSQLForUpdate.AppendLine(clsConst.FOR_UPDATE_WAIT)

            Try
                '�r������
                objclsDbAccess.mobjCommonDB.DB_ExecuteQuery(stbSQLForUpdate.ToString, oraExclusionParam)

            Catch ex As OracleException
                Return -1
            Finally
                ' SQL���O�o��
                clsUtility.WriteLog(objclsDbAccess.mobjCommonDB.GetInfoMessage, EventLogEntryType.Information)
            End Try

            '**********************
            '�X�V����
            '**********************
            Dim stbSQL As New StringBuilder(String.Empty)

            'SQL�쐬
            stbSQL.AppendLine("UPDATE M_CM_USER")
            stbSQL.AppendLine("SET")
            stbSQL.AppendLine("  USER_ID		= :USER_ID")
            stbSQL.AppendLine("	,USER_NAME		= :USER_NAME")
            stbSQL.AppendLine("	,USER_NAME_KANA	= :USER_NAME_KANA")
            stbSQL.AppendLine("	,ROLL_CD		= :ROLL_CD")
            stbSQL.AppendLine("	,PASSWORD		= :PASSWORD")
            stbSQL.AppendLine("	,PASSWORD_LIMIT_DATE = :LIMIT")
            stbSQL.AppendLine("	,UPDATE_DATE	= SYSDATE")
            stbSQL.AppendLine("	,UPDATE_USER	= :UPDATE_USER")
            stbSQL.AppendLine("WHERE")
            stbSQL.AppendLine("	USER_ID	=	: USER_ID")

            '�p�����[�^�ݒ�
            Dim oraUpdateParam(6) As OracleParameter
            oraUpdateParam(0) = New OracleParameter("USER_ID", OracleDbType.Char)
            oraUpdateParam(1) = New OracleParameter("USER_NAME", OracleDbType.Char)
            oraUpdateParam(2) = New OracleParameter("USER_NAME_KANA", OracleDbType.Char)
            oraUpdateParam(3) = New OracleParameter("ROLL_CD", OracleDbType.Char)
            oraUpdateParam(4) = New OracleParameter("PASSWORD", OracleDbType.Char)
            oraUpdateParam(5) = New OracleParameter("UPDATE_USER", OracleDbType.Char)
            oraUpdateParam(6) = New OracleParameter("LIMIT", OracleDbType.Char)
            oraUpdateParam(0).Value = Parm.Item("USER_ID")
            oraUpdateParam(1).Value = Parm.Item("USER_NAME")
            oraUpdateParam(2).Value = Parm.Item("USER_NAME_KANA")
            oraUpdateParam(3).Value = Parm.Item("ROLL_CD")
            oraUpdateParam(4).Value = Parm.Item("PASSWORD")
            oraUpdateParam(5).Value = Parm.Item("UPDATE_USER")
            oraUpdateParam(6).Value = Parm.Item("LIMIT")

            '���s
            intResultCount = objclsDbAccess.mobjCommonDB.DB_ExecuteNonQuery(stbSQL.ToString, oraUpdateParam)

            ' SQL���O�o��
            clsUtility.WriteLog(objclsDbAccess.mobjCommonDB.GetInfoMessage, EventLogEntryType.Information)

            Return intResultCount
        Finally
            objclsDbAccess.mobjCommonDB.DB_Close()
        End Try

    End Function
#End Region

#Region "DelSqlMCmUser"
    ''' <summary>
    ''' ���[�U�}�X�^�폜
    ''' </summary>
    ''' <param name="Parm">�p�����[�^</param>
    ''' <remarks></remarks>
    Public Function DelSqlMCmUser(ByVal Parm As Dictionary(Of String, String)) As Integer

        ' DB�ڑ�����
        Dim objclsDbAccess As New clsDbAccess
        Call objclsDbAccess.dbOpen()

        Try
            '�p�����[�^�ݒ�
            Dim oraUpdateParam(0) As OracleParameter
            oraUpdateParam(0) = New OracleParameter("USER_ID", OracleDbType.Char)
            oraUpdateParam(0).Value = Parm.Item("USER_ID")

            '**********************
            '�폜����
            '**********************
            Dim stbSQL As New StringBuilder(String.Empty)

            'SQL�쐬
            stbSQL.AppendLine("DELETE FROM M_CM_USER")
            stbSQL.AppendLine("WHERE")
            stbSQL.AppendLine("	USER_ID	=	: USER_ID")

            '���s
            Dim intResultCount As Integer = objclsDbAccess.mobjCommonDB.DB_ExecuteNonQuery(stbSQL.ToString, oraUpdateParam)

            ' SQL���O�o��
            clsUtility.WriteLog(objclsDbAccess.mobjCommonDB.GetInfoMessage, EventLogEntryType.Information)

            Return intResultCount
        Finally
            objclsDbAccess.mobjCommonDB.DB_Close()
        End Try

    End Function
#End Region

#Region "UpdSqlMCmUser"
    ''' <summary>
    ''' ���[�U�}�X�^�X�V
    ''' </summary>
    ''' <param name="Parm">�p�����[�^</param>
    ''' <remarks></remarks>
    Public Function UpdSqlMCmUserPassword(ByVal Parm As Dictionary(Of String, String)) As Integer

        ' DB�ڑ�����
        Dim objclsDbAccess As New clsDbAccess
        Dim intResultCount As Integer

        Call objclsDbAccess.dbOpen()

        Try
            '�p�����[�^�ݒ�
            Dim oraExclusionParam(0) As OracleParameter
            oraExclusionParam(0) = New OracleParameter("USER_ID", OracleDbType.Char)
            oraExclusionParam(0).Value = Parm.Item("USER_ID")

            '**********************
            '�r������
            '**********************
            Dim stbSQLForUpdate As New StringBuilder(String.Empty)

            'SQL�쐬
            stbSQLForUpdate.AppendLine("SELECT USER_ID")
            stbSQLForUpdate.AppendLine("  FROM M_CM_USER")
            stbSQLForUpdate.AppendLine(" WHERE USER_ID	  =	:USER_ID")
            stbSQLForUpdate.AppendLine("   AND DELETE_FLG = '0'")
            stbSQLForUpdate.AppendLine("FOR UPDATE WAIT ")
            stbSQLForUpdate.AppendLine(clsConst.FOR_UPDATE_WAIT)

            Try
                '�r������
                objclsDbAccess.mobjCommonDB.DB_ExecuteQuery(stbSQLForUpdate.ToString, oraExclusionParam)

            Catch ex As OracleException
                Return -1
            Finally
                ' SQL���O�o��
                clsUtility.WriteLog(objclsDbAccess.mobjCommonDB.GetInfoMessage, EventLogEntryType.Information)
            End Try

            '**********************
            '�X�V����
            '**********************
            Dim stbSQL As New StringBuilder(String.Empty)

            'SQL�쐬
            stbSQL.AppendLine("UPDATE M_CM_USER")
            stbSQL.AppendLine("SET")
            stbSQL.AppendLine("	 PASSWORD            = :PASSWORD")
            stbSQL.AppendLine("	,PASSWORD_LIMIT_DATE = :LIMIT")
            stbSQL.AppendLine("	,UPDATE_DATE	     = SYSDATE")
            stbSQL.AppendLine("	,UPDATE_USER	     = :UPDATE_USER")
            stbSQL.AppendLine("WHERE")
            stbSQL.AppendLine("	USER_ID	=	: USER_ID")

            '�p�����[�^�ݒ�
            Dim oraUpdateParam(3) As OracleParameter
            oraUpdateParam(0) = New OracleParameter("USER_ID", OracleDbType.Char)
            oraUpdateParam(1) = New OracleParameter("PASSWORD", OracleDbType.Char)
            oraUpdateParam(2) = New OracleParameter("UPDATE_USER", OracleDbType.Char)
            oraUpdateParam(3) = New OracleParameter("LIMIT", OracleDbType.Char)
            oraUpdateParam(0).Value = Parm.Item("USER_ID")
            oraUpdateParam(1).Value = Parm.Item("PASSWORD")
            oraUpdateParam(2).Value = Parm.Item("UPDATE_USER")
            oraUpdateParam(3).Value = Parm.Item("LIMIT")

            '���s
            intResultCount = objclsDbAccess.mobjCommonDB.DB_ExecuteNonQuery(stbSQL.ToString, oraUpdateParam)

            ' SQL���O�o��
            clsUtility.WriteLog(objclsDbAccess.mobjCommonDB.GetInfoMessage, EventLogEntryType.Information)

            Return intResultCount
        Finally
            objclsDbAccess.mobjCommonDB.DB_Close()
        End Try

    End Function
#End Region

End Class
