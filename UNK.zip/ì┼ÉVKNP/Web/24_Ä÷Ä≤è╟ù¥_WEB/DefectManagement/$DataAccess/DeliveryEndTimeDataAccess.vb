Imports System.Data
Imports Oracle.DataAccess.Client
Imports DefectManagement.clsConst

Public Class DeliveryEndTimeDataAccess

    Public Function GetList(ByVal dicParam As Dictionary(Of String, String)) As DataTable

        ' DB�ڑ����܂�
        Dim objclsDbAccess As New clsDbAccess

        Call objclsDbAccess.dbOpen()

        Try
            Dim strFrom As String = dicParam("RECEIPT_DATE_FROM")
            Dim strTo As String = GetDateTo(objclsDbAccess, dicParam)
            Dim dtCal As DataTable = GetCalender(objclsDbAccess, strFrom, strTo)
            Dim strTargetSlip As String = String.Empty

            If Not String.IsNullOrEmpty(dicParam.ContainsKey("TARGET_SLIP")) Then
                strTargetSlip = dicParam("TARGET_SLIP")
            End If

            Dim dtImage As DataTable = GetImageData(objclsDbAccess, strFrom, strTo, strTargetSlip)
            Dim lstDate As New List(Of String)
            Dim dicDate As New Dictionary(Of String, String())
            For Each dr As DataRow In dtImage.Rows

                Dim strRcp() As String = Split(Convert.ToString(dr.Item("CREATE_DATE")), " ")
                If strRcp(1) < "09:30" Then
                    strRcp(0) = GetPrevDate(dtCal, strRcp(0))
                    strRcp(1) = "18:30"
                End If

                If Not dicDate.ContainsKey(strRcp(0)) Then
                    Dim strTime(9) As String
                    For i As Integer = 0 To strTime.Length - 1 Step 1
                        strTime(i) = String.Empty
                    Next
                    dicDate.Add(strRcp(0), strTime)
                    lstDate.Add(strRcp(0))
                End If

                Dim intIndex As Integer = 0
                Select Case strRcp(1)
                    Case "09:30" To "10:29"
                        intIndex = 0
                    Case "10:30" To "11:29"
                        intIndex = 1
                    Case "11:30" To "12:29"
                        intIndex = 2
                    Case "12:30" To "13:29"
                        intIndex = 3
                    Case "13:30" To "14:29"
                        intIndex = 4
                    Case "14:30" To "15:29"
                        intIndex = 5
                    Case "15:30" To "16:29"
                        intIndex = 6
                    Case "16:30" To "17:29"
                        intIndex = 7
                    Case "17:30" To "18:29"
                        intIndex = 8
                    Case Else
                        intIndex = 9
                End Select

                Dim strDelv As String = Convert.ToString(dr.Item("DELIVERY_DATE"))
                If dicDate(strRcp(0))(intIndex) < strDelv Then
                    dicDate(strRcp(0))(intIndex) = strDelv
                End If
            Next

            Dim dtRslt As DataTable = MakeResultTable()
            For Each strRcpDate As String In lstDate
                Dim strTemp() As String = Split(strRcpDate, "/")
                Dim strDate As String = strTemp(1) & "��" & strTemp(2) & "��"

                Dim dr1 As DataRow = dtRslt.NewRow
                dr1.Item(0) = strDate
                dr1.Item(1) = "������"

                Dim dr2 As DataRow = dtRslt.NewRow
                dr2.Item(0) = strDate
                dr2.Item(1) = "��������"

                For i As Integer = 0 To 9 Step 1
                    If dicDate(strRcpDate)(i).Length = 0 Then
                        dr1.Item(2 + i) = "-"
                        dr2.Item(2 + i) = "-"
                        Continue For
                    End If
                    Dim strDelv() As String = Split(dicDate(strRcpDate)(i), " ")
                    dr1.Item(2 + i) = GetDelvDate(dtCal, dicDate(strRcpDate)(i))
                    dr2.Item(2 + i) = GetDelvTime(strDelv(1))
                Next

                dtRslt.Rows.Add(dr1)
                dtRslt.Rows.Add(dr2)
            Next

            Return dtRslt

        Finally
            objclsDbAccess.mobjCommonDB.DB_Close()
        End Try
    End Function

    Private Function MakeResultTable() As DataTable
        Dim dtRslt As New DataTable
        dtRslt.Columns.Add("RECEIPT_DATE", GetType(System.String))
        dtRslt.Columns.Add("TITLE", GetType(System.String))
        dtRslt.Columns.Add("ITEM_0930", GetType(System.String))
        dtRslt.Columns.Add("ITEM_1030", GetType(System.String))
        dtRslt.Columns.Add("ITEM_1130", GetType(System.String))
        dtRslt.Columns.Add("ITEM_1230", GetType(System.String))
        dtRslt.Columns.Add("ITEM_1330", GetType(System.String))
        dtRslt.Columns.Add("ITEM_1430", GetType(System.String))
        dtRslt.Columns.Add("ITEM_1530", GetType(System.String))
        dtRslt.Columns.Add("ITEM_1630", GetType(System.String))
        dtRslt.Columns.Add("ITEM_1730", GetType(System.String))
        dtRslt.Columns.Add("ITEM_1830", GetType(System.String))

        Return dtRslt
    End Function

    Private Function GetDateTo(ByVal objclsDbAccess As clsDbAccess, ByVal dicParam As Dictionary(Of String, String)) As String
        Dim stbSQL As New StringBuilder(String.Empty)
        stbSQL.AppendLine("SELECT")
        stbSQL.AppendLine("    MIN(YYYYMMDD)")
        stbSQL.AppendLine("FROM")
        stbSQL.AppendLine("    M_CM_HOLIDAY")
        stbSQL.AppendLine("WHERE")
        stbSQL.AppendLine("    YYYYMMDD > '%DateTo%'")
        stbSQL.AppendLine("    AND")
        stbSQL.AppendLine("    HOLIDAY = '0'")
        stbSQL.Replace("%DateTo%", dicParam("RECEIPT_DATE_TO").Replace("/", String.Empty))

        Dim dtCal As DataTable = objclsDbAccess.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)
        Dim strCal As String = Convert.ToString(dtCal.Rows(0).Item(0))

        Return strCal.Substring(0, 4) & "/" & _
               strCal.Substring(4, 2) & "/" & _
               strCal.Substring(6, 2)
    End Function

    Private Function GetCalender(ByVal objclsDbAccess As clsDbAccess, ByVal strDateFrom As String, ByVal strDateTo As String) As DataTable

        Dim stbSQL As New StringBuilder(String.Empty)
        stbSQL.AppendLine("SELECT")
        stbSQL.AppendLine("    YYYYMMDD")
        stbSQL.AppendLine("FROM")
        stbSQL.AppendLine("    M_CM_HOLIDAY")
        stbSQL.AppendLine("WHERE")
        stbSQL.AppendLine("    YYYYMMDD >= '%DateFrom%'")
        'stbSQL.AppendLine("    AND")
        'stbSQL.AppendLine("    YYYYMMDD <= '%DateTo%'")
        stbSQL.AppendLine("    AND")
        stbSQL.AppendLine("    HOLIDAY = '0'")
        stbSQL.AppendLine("ORDER BY")
        stbSQL.AppendLine("    YYYYMMDD")
        stbSQL.Replace("%DateFrom%", strDateFrom.Replace("/", String.Empty))
        stbSQL.Replace("%DateTo%", strDateTo.Replace("/", String.Empty))

        Dim dtCal As DataTable = objclsDbAccess.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)

        Return dtCal
    End Function

    Private Function GetImageData(ByVal objclsDbAccess As clsDbAccess, ByVal strDateFrom As String, ByVal strDateTo As String, ByVal strTargetSlip As String) As DataTable

        Dim stbSQL As New StringBuilder(String.Empty)
        stbSQL.AppendLine("SELECT")
        stbSQL.AppendLine("    TO_CHAR(CREATE_DATE,  'YYYY/MM/DD HH24:MI') AS CREATE_DATE,")
        stbSQL.AppendLine("    TO_CHAR(DELIVERY_DATE,'YYYY/MM/DD HH24:MI') AS DELIVERY_DATE")
        stbSQL.AppendLine("FROM")
        stbSQL.AppendLine("    T_JJ_IMAGE")
        stbSQL.AppendLine("WHERE")
        stbSQL.AppendLine("    DELETE_FLG = '0'")
        stbSQL.AppendLine("    AND")
        stbSQL.AppendLine("    DELIVERY_DATE IS NOT NULL")
        stbSQL.AppendLine("    AND")
        stbSQL.AppendLine("    TO_CHAR(CREATE_DATE,'YYYY/MM/DD HH24:MI') >  '%DateFrom% 09:30'")
        stbSQL.AppendLine("    AND")
        stbSQL.AppendLine("    TO_CHAR(CREATE_DATE,'YYYY/MM/DD HH24:MI') <= '%DateTo% 18:29'")
        If Not String.IsNullOrEmpty(strTargetSlip) Then
            stbSQL.AppendLine("      AND SUBSTRB(SLIP_DEFINE_ID, 1, 3) IN (" & strTargetSlip & ")")
        End If
        stbSQL.AppendLine("ORDER BY")
        stbSQL.AppendLine("    CREATE_DATE")

        stbSQL.Replace("%DateFrom%", strDateFrom)
        stbSQL.Replace("%DateTo%", strDateTo)

        Dim dtRslt As DataTable = objclsDbAccess.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)

        Return dtRslt

    End Function

    Private Function GetPrevDate(ByVal dtCal As DataTable, ByVal strDate As String) As String

        Dim strNow As String = strDate.Replace("/", String.Empty)
        Dim strPrv As String = strNow
        For Each dr As DataRow In dtCal.Rows
            Dim strCal As String = Convert.ToString(dr.Item(0))
            If strCal >= strNow Then
                Return strPrv.Substring(0, 4) & "/" & _
                       strPrv.Substring(4, 2) & "/" & _
                       strPrv.Substring(6, 2)
            End If
            strPrv = strCal
        Next

        Return strDate

    End Function

    Private Function GetNextDate(ByVal dtCal As DataTable, ByVal strDate As String) As String

        Dim strNow As String = strDate.Replace("/", String.Empty)
        For Each dr As DataRow In dtCal.Rows
            Dim strCal As String = Convert.ToString(dr.Item(0))
            If strCal > strNow Then
                Return strCal.Substring(0, 4) & "/" & _
                       strCal.Substring(4, 2) & "/" & _
                       strCal.Substring(6, 2)
            End If
        Next

        Return strDate

    End Function

    Private Function GetDelvDate(ByVal dtCal As DataTable, ByVal strDate As String) As String
        If strDate.Length = 0 Then
            Return String.Empty
        End If
        Dim strTemp() As String = Split(strDate, " ")
        Select Case strTemp(1)
            Case "00:00" To "18:29"
                Dim strD() As String = Split(strTemp(0), "/")
                Return strD(1) & "/" & strD(2)
        End Select

        Dim strNext As String = GetNextDate(dtCal, strTemp(0))
        Dim strN() As String = Split(strNext, "/")
        Return strN(1) & "/" & strN(2)
    End Function

    Private Function GetDelvTime(ByVal strTime As String) As String
        If strTime.Length = 0 Then
            Return String.Empty
        End If
        Select Case strTime
            Case "00:00" To "08:29"
                Return "08:30"
            Case "08:30" To "09:29"
                Return "09:30"
            Case "09:30" To "10:29"
                Return "10:30"
            Case "10:30" To "11:29"
                Return "11:30"
            Case "11:30" To "12:29"
                Return "12:30"
            Case "12:30" To "13:29"
                Return "13:30"
            Case "13:30" To "14:29"
                Return "14:30"
            Case "14:30" To "15:29"
                Return "15:30"
            Case "15:30" To "16:29"
                Return "16:30"
            Case "16:30" To "17:29"
                Return "17:30"
            Case "17:30" To "18:29"
                Return "18:30"
        End Select

        Return "08:30"

    End Function

End Class
