﻿Imports System
Imports System.Text
Imports System.Windows
Imports System.Windows.Forms
Imports CommonSystem

''' <summary>
''' 共通ログイン画面
''' </summary>
''' <remarks></remarks>
Public Class frmLoginBase

    ''' <summary>
    ''' DB接続情報
    ''' </summary>
    ''' <remarks></remarks>
    Public Shared comDB As CommonDB

    ''' <summary>
    ''' 外部定義情報
    ''' </summary>
    ''' <remarks></remarks>
    Public Shared mdicConfug As Dictionary(Of String, String)


#Region "ログインボタン処理"
    ''' <summary>
    ''' ログインボタン処理
    ''' </summary>
    ''' <param name="sender">イベント発生元オブジェクト</param>
    ''' <param name="e">イベントパラメータ</param>
    ''' <remarks>ログインボタンがクリックされたときの処理です。</remarks>
    Private Sub btnLogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLogin.Click
        Try
            ' ユーザマスタから指定されたユーザＩＤ＋パスワードのデータを取得します。
            Dim stbSQL As New StringBuilder(String.Empty)
            stbSQL.AppendLine("SELECT")
            stbSQL.AppendLine("    USER_NAME")
            stbSQL.AppendLine("FROM")
            stbSQL.AppendLine("    M_CM_USER")
            stbSQL.AppendLine("WHERE")
            stbSQL.AppendLine("    USER_ID    = '%USERID%'")
            stbSQL.AppendLine("    AND")
            stbSQL.AppendLine("    PASSWORD   = '%PASSWD%'")
            stbSQL.AppendLine("    AND")
            stbSQL.AppendLine("    DELETE_FLG = '0'")
            stbSQL.Replace("%USERID%", Me.txtUserID.Text.Trim)
            stbSQL.Replace("%PASSWD%", Me.txtPassword.Text.Trim)

            Dim dt As DataTable = comDB.DB_ExecuteQuery(stbSQL.ToString)

            ' 取得できなかった場合はエラーとします。
            If dt Is Nothing OrElse dt.Rows.Count = 0 Then
                MessageBox.Show("ユーザIDまたはパスワードが違います。", "ログインエラー", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Return
            End If

            ' ユーザ名を取得します。
            Dim strName As String = Convert.ToString(dt.Rows(0).Item("USER_NAME"))

            ' ログイン画面を非表示にします。
            Me.Hide()
            Application.DoEvents()

            ' ログイン処理
            Call Login(Me.txtUserID.Text.Trim, strName)

            ' 画面をクローズします。
            Me.Close()

        Catch ex As Exception
            MessageBox.Show("ログイン処理でエラーが発生しました。", "ログインエラー", MessageBoxButtons.OK, MessageBoxIcon.Error)
            ' ログにエラーメッセージとエラー内容を出力します。
            CommonLog.WriteLog("ログイン処理でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            ' 画面をクローズします。
            Me.Close()
        End Try
    End Sub
#End Region

#Region "キャンセルボタン処理"
    ''' <summary>
    ''' キャンセルボタン処理
    ''' </summary>
    ''' <param name="sender">イベント発生元オブジェクト</param>
    ''' <param name="e">イベントパラメータ</param>
    ''' <remarks>画面を閉じます。</remarks>
    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Try
            ' 画面をクローズします。
            Me.Close()
        Catch ex As Exception
            MessageBox.Show("ログイン処理でエラーが発生しました。", "ログインエラー", MessageBoxButtons.OK, MessageBoxIcon.Error)
            ' ログにエラーメッセージとエラー内容を出力します。
            CommonLog.WriteLog("ログイン処理でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            ' 画面をクローズします。
            Me.Close()
        End Try
    End Sub
#End Region

#Region "ログイン処理（ダミー）"
    ''' <summary>
    ''' ログイン処理（ダミー）
    ''' </summary>
    ''' <remarks>ログインが正常に行われた場合の処理を継承先で
    ''' 記述するためのダミー処理です。</remarks>
    Protected Overridable Sub Login(ByVal strID As String, ByVal strName As String)
    End Sub
#End Region

End Class