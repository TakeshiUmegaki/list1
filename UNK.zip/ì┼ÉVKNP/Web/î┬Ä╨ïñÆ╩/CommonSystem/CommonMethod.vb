'================================================================================
'�a�o�r����
'�Ɩ����ʃ��O�N���X�FCommonSystem/CommonMethod
'Rev00 2008/06/23
'================================================================================
Option Explicit On 
Option Strict On

Imports System
Imports System.Runtime.InteropServices

Public Class CommonMethod

    '************************************************************
    '�R���X�g���N�^
    '�m�@�\�n
    '************************************************************
    Public Sub New()

    End Sub

    '************************************************************
    '���l�`�F�b�N����:IsNumeric(Function)
    '�m�@�@�\�n
    '�m�����P�n�`�F�b�N�Ώۂ̕�����
    '�m�߂�l�nTrue�F���l�^False�F���l�ȊO�̕���
    '************************************************************
    Public Shared Function IsNumeric(ByVal strCheckParam As String) As Boolean

        Dim boolCheck As Boolean

        Try
            ' �����̐��l�`�F�b�N
            boolCheck = Double.TryParse(strCheckParam, Globalization.NumberStyles.Any, Nothing, 0.0#)

            Return boolCheck

        Catch ex As Exception
            Throw ex
        Finally

        End Try

    End Function

    '************************************************************
    '���l�`�F�b�N����:IsNumber(Function)
    '�m�@�@�\�n
    '�m�����P�n�`�F�b�N�Ώۂ̕�����
    '�m�߂�l�nTrue�F���l�^False�F���l�ȊO�̕���
    '************************************************************
    Public Shared Function IsNumber(ByVal strCheckParam As String) As Boolean

        Dim boolCheck As Boolean

        Try
            ' �����̐��l�`�F�b�N
            Dim intResult As Integer = 0
            boolCheck = Integer.TryParse(strCheckParam, Globalization.NumberStyles.None, Nothing, intResult)

            Return boolCheck

        Catch ex As Exception
            Throw ex
        Finally

        End Try

    End Function

    '************************************************************
    '���t�`�F�b�N�����E����:IsDate(Function)
    '�m�@�@�\�n
    '�m�����P�n�`�F�b�N�Ώۂ̐��l(�N)
    '�m�����Q�n�`�F�b�N�Ώۂ̐��l(��)
    '�m�����R�n�`�F�b�N�Ώۂ̐��l(��)
    '�m�߂�l�nTrue�F���t�^False�F���t�O
    '************************************************************
    Public Shared Function IsDate(ByVal intYear As Integer, ByVal intMonth As Integer, ByVal intDay As Integer) As Boolean

        ' 2008/09/09 del naruse start VS2005�ڍs�ɔ������C
        'Dim boolCheck As Boolean
        ' 2008/09/09 del naruse end

        Try

            ' �N�̃`�F�b�N
            If (DateTime.MinValue.Year > intYear) OrElse (intYear > DateTime.MaxValue.Year) Then
                Return False
            End If

            ' ���̃`�F�b�N
            If (DateTime.MinValue.Month > intMonth) OrElse (intMonth > DateTime.MaxValue.Month) Then
                Return False
            End If

            ' ���̃`�F�b�N
            Dim lastDay As Integer = DateTime.DaysInMonth(intYear, intMonth)
            If (DateTime.MinValue.Day > intDay) OrElse (intDay > lastDay) Then
                Return False
            End If

            Return True

        Catch ex As Exception
            Throw ex
        Finally

        End Try

    End Function

    '************************************************************
    '�`�F�b�N�f�W�b�g�쐬�i���W�����X�P�O�E�F�C�g�R�j:MakeCdMod10Wait3(String)
    '�m�@�@�\�n
    '�m�����P�n���̃R�[�h
    '�m�߂�l�n�`�F�b�N�f�W�b�g�l
    '************************************************************
    Public Shared Function MakeCdMod10Wait3(ByVal strBaseCode As String) As String

        Dim lngLen As Int64         '* ������
        Dim intCNT As Int32         '* ����
        Dim intVal As Int32         '* ���l
        Dim intSum As Int32         '* ���v�l
        Dim intCD As Int32          '* �����޼ޯ�

        '* ���l�ȊO�͏����I��
        If IsNumeric(strBaseCode) = False Then
            Return String.Empty
        End If

        lngLen = strBaseCode.Length     '* �����񒷂��擾����
        intSum = 0                      '* ���v�l��������

        For intCNT = 0 To CInt(lngLen) - 1
            intVal = CInt(Mid(strBaseCode, CInt(lngLen) - intCNT, 1))
            If intCNT Mod 2 = 0 Then
                intVal = intVal * 3
            Else
                intVal = intVal * 1
            End If
            intSum = intSum + intVal
        Next intCNT

        '* ���v�l �� �P�O�̗]������߂�
        intCD = intSum Mod 10

        '* �`�F�b�N�f�W�b�g��Ԃ�
        If intCD.Equals(0) Then
            Return "0"
        Else
            intCD = 10 - intCD
            Return intCD.ToString
        End If

    End Function

    '************************************************************
    '�`�F�b�N�f�W�b�g�쐬�i���W�����X�P�O�R�j:MakeCdMod103(String)
    '�m�@�@�\�n
    '�m�����P�n���̃R�[�h
    '�m�߂�l�n�`�F�b�N�f�W�b�g�l
    '************************************************************
    Public Shared Function MakeCdMod103(ByVal strBaseCode As String, ByVal CodeSetType As Mod103CodeSetType) As String

        Dim intCodeNumberSum As Integer
        Dim intCodeNumberSumMod As Integer

        Select Case CodeSetType
            Case Mod103CodeSetType.CodeA
                '���R�[�h�`��
                '�X�^�[�g�R�[�h�iA:103�j
                intCodeNumberSum = 103 * 1

                For i As Integer = 0 To strBaseCode.Length - 1
                    '�R�[�h���Z���l�̉��Z�i�R�[�h���Z���l�~�d�݁i1�`�j�j
                    intCodeNumberSum = intCodeNumberSum + Mod103CodeNumberListA(strBaseCode.Substring(i, 1)) * i + 1
                Next

                intCodeNumberSumMod = intCodeNumberSum Mod 103

                Return Mod103CodeListA(intCodeNumberSumMod)

            Case Mod103CodeSetType.CodeB
                '���R�[�h�a��
                '�X�^�[�g�R�[�h�iB:104�j
                intCodeNumberSum = 104 * 1

                For i As Integer = 0 To strBaseCode.Length - 1
                    '�R�[�h���Z���l�̉��Z�i�R�[�h���Z���l�~�d�݁i1�`�j�j
                    intCodeNumberSum = intCodeNumberSum + Mod103CodeNumberListB(strBaseCode.Substring(i, 1)) * i + 1
                Next

                intCodeNumberSumMod = intCodeNumberSum Mod 103

                Return Mod103CodeListB(intCodeNumberSumMod)

            Case Mod103CodeSetType.CodeC
                '���R�[�h�b��
                '�X�^�[�g�R�[�h�iC:105�j
                intCodeNumberSum = 105 * 1

                For i As Integer = 0 To strBaseCode.Length - 1
                    '�R�[�h���Z���l�̉��Z�i�R�[�h���Z���l�~�d�݁i1�`�j�j
                    intCodeNumberSum = intCodeNumberSum + Mod103CodeNumberListC(strBaseCode.Substring(i, 1)) * i + 1
                Next

                intCodeNumberSumMod = intCodeNumberSum Mod 103

                Return Mod103CodeListC(intCodeNumberSumMod)

            Case Else
                Return String.Empty

        End Select

    End Function

    Public Enum Mod103CodeSetType
        CodeA = 0
        CodeB = 1
        CodeC = 2
    End Enum

#Region "�yMod103CodeList�z"

    Private Shared Function Mod103CodeListA(ByVal intBaseCodeNumber As Integer) As String

        Dim strCode As String = String.Empty

        Select Case intBaseCodeNumber
            Case 0
                strCode = " "
            Case 1
                strCode = "!"
            Case 2
                strCode = """"
            Case 3
                strCode = "#"
            Case 4
                strCode = "$"
            Case 5
                strCode = "%"
            Case 6
                strCode = "&"
            Case 7
                strCode = "'"
            Case 8
                strCode = "("
            Case 9
                strCode = ")"
            Case 10
                strCode = "*"
            Case 11
                strCode = "+"
            Case 12
                strCode = ","
            Case 13
                strCode = "-"
            Case 14
                strCode = "."
            Case 15
                strCode = "/"
            Case 16
                strCode = "0"
            Case 17
                strCode = "1"
            Case 18
                strCode = "2"
            Case 19
                strCode = "3"
            Case 20
                strCode = "4"
            Case 21
                strCode = "5"
            Case 22
                strCode = "6"
            Case 23
                strCode = "7"
            Case 24
                strCode = "8"
            Case 25
                strCode = "9"
            Case 26
                strCode = ":"
            Case 27
                strCode = ";"
            Case 28
                strCode = "<"
            Case 29
                strCode = "="
            Case 30
                strCode = ">"
            Case 31
                strCode = "?"
            Case 32
                strCode = "@"
            Case 33
                strCode = "A"
            Case 34
                strCode = "B"
            Case 35
                strCode = "C"
            Case 36
                strCode = "D"
            Case 37
                strCode = "E"
            Case 38
                strCode = "F"
            Case 39
                strCode = "G"
            Case 40
                strCode = "H"
            Case 41
                strCode = "I"
            Case 42
                strCode = "J"
            Case 43
                strCode = "K"
            Case 44
                strCode = "L"
            Case 45
                strCode = "M"
            Case 46
                strCode = "N"
            Case 47
                strCode = "O"
            Case 48
                strCode = "P"
            Case 49
                strCode = "Q"
            Case 50
                strCode = "R"
            Case 51
                strCode = "S"
            Case 52
                strCode = "T"
            Case 53
                strCode = "U"
            Case 54
                strCode = "V"
            Case 55
                strCode = "W"
            Case 56
                strCode = "X"
            Case 57
                strCode = "Y"
            Case 58
                strCode = "Z"
            Case 59
                strCode = "["
            Case 60
                strCode = "\"
            Case 61
                strCode = "]"
            Case 62
                strCode = "^"
            Case 63
                strCode = "_"
            Case 64
                strCode = "NUL"
            Case 65
                strCode = "SOH"
            Case 66
                strCode = "STX"
            Case 67
                strCode = "ETX"
            Case 68
                strCode = "EOT"
            Case 69
                strCode = "ENQ"
            Case 70
                strCode = "ACK"
            Case 71
                strCode = "BEL"
            Case 72
                strCode = "BS"
            Case 73
                strCode = "HT"
            Case 74
                strCode = "LF"
            Case 75
                strCode = "VT"
            Case 76
                strCode = "FF"
            Case 77
                strCode = "CR"
            Case 78
                strCode = "SO"
            Case 79
                strCode = "SI"
            Case 80
                strCode = "DEL"
            Case 81
                strCode = "DC1"
            Case 82
                strCode = "DC2"
            Case 83
                strCode = "DC3"
            Case 84
                strCode = "DC4"
            Case 85
                strCode = "NAK"
            Case 86
                strCode = "SYN"
            Case 87
                strCode = "ETB"
            Case 88
                strCode = "CAN"
            Case 89
                strCode = "EM"
            Case 90
                strCode = "SUB"
            Case 91
                strCode = "ESC"
            Case 92
                strCode = "FS"
            Case 93
                strCode = "GS"
            Case 94
                strCode = "RS"
            Case 95
                strCode = "US"
            Case 96
                strCode = "FNC 3"
            Case 97
                strCode = "FNC 2"
            Case 98
                strCode = "SHIFT"
            Case 99
                strCode = "CODE C"
            Case 100
                strCode = "CODE B"
            Case 101
                strCode = "FNC 4"
            Case 102
                strCode = "FNC 1"
        End Select

        Return strCode

    End Function

    Private Shared Function Mod103CodeListB(ByVal intBaseCodeNumber As Integer) As String

        Dim strCode As String = String.Empty

        Select Case intBaseCodeNumber
            Case 0
                strCode = " "
            Case 1
                strCode = "!"
            Case 2
                strCode = """"
            Case 3
                strCode = "#"
            Case 4
                strCode = "$"
            Case 5
                strCode = "%"
            Case 6
                strCode = "&"
            Case 7
                strCode = "'"
            Case 8
                strCode = "("
            Case 9
                strCode = ")"
            Case 10
                strCode = "*"
            Case 11
                strCode = "+"
            Case 12
                strCode = ","
            Case 13
                strCode = "-"
            Case 14
                strCode = "."
            Case 15
                strCode = "/"
            Case 16
                strCode = "0"
            Case 17
                strCode = "1"
            Case 18
                strCode = "2"
            Case 19
                strCode = "3"
            Case 20
                strCode = "4"
            Case 21
                strCode = "5"
            Case 22
                strCode = "6"
            Case 23
                strCode = "7"
            Case 24
                strCode = "8"
            Case 25
                strCode = "9"
            Case 26
                strCode = ":"
            Case 27
                strCode = ";"
            Case 28
                strCode = "<"
            Case 29
                strCode = "="
            Case 30
                strCode = ">"
            Case 31
                strCode = "?"
            Case 32
                strCode = "@"
            Case 33
                strCode = "A"
            Case 34
                strCode = "B"
            Case 35
                strCode = "C"
            Case 36
                strCode = "D"
            Case 37
                strCode = "E"
            Case 38
                strCode = "F"
            Case 39
                strCode = "G"
            Case 40
                strCode = "H"
            Case 41
                strCode = "I"
            Case 42
                strCode = "j"
            Case 43
                strCode = "K"
            Case 44
                strCode = "L"
            Case 45
                strCode = "M"
            Case 46
                strCode = "N"
            Case 47
                strCode = "O"
            Case 48
                strCode = "P"
            Case 49
                strCode = "Q"
            Case 50
                strCode = "R"
            Case 51
                strCode = "S"
            Case 52
                strCode = "T"
            Case 53
                strCode = "U"
            Case 54
                strCode = "V"
            Case 55
                strCode = "W"
            Case 56
                strCode = "X"
            Case 57
                strCode = "Y"
            Case 58
                strCode = "Z"
            Case 59
                strCode = "["
            Case 60
                strCode = "\"
            Case 61
                strCode = "]"
            Case 62
                strCode = "^"
            Case 63
                strCode = "_"
            Case 64
                strCode = "�e"
            Case 65
                strCode = "a"
            Case 66
                strCode = "b"
            Case 67
                strCode = "c"
            Case 68
                strCode = "d"
            Case 69
                strCode = "e"
            Case 70
                strCode = "f"
            Case 71
                strCode = "g"
            Case 72
                strCode = "h"
            Case 73
                strCode = "i"
            Case 74
                strCode = "j"
            Case 75
                strCode = "k"
            Case 76
                strCode = "l"
            Case 77
                strCode = "m"
            Case 78
                strCode = "n"
            Case 79
                strCode = "o"
            Case 80
                strCode = "p"
            Case 81
                strCode = "q"
            Case 82
                strCode = "r"
            Case 83
                strCode = "s"
            Case 84
                strCode = "t"
            Case 85
                strCode = "u"
            Case 86
                strCode = "v"
            Case 87
                strCode = "w"
            Case 88
                strCode = "x"
            Case 89
                strCode = "y"
            Case 90
                strCode = "z"
            Case 91
                strCode = "{"
            Case 92
                strCode = "|"
            Case 93
                strCode = "}"
            Case 94
                strCode = "~"
            Case 95
                strCode = "DEL"
            Case 96
                strCode = "FNC 3"
            Case 97
                strCode = "FNC 2"
            Case 98
                strCode = "SHIFT"
            Case 99
                strCode = "CODE C"
            Case 100
                strCode = "FNC 4"
            Case 101
                strCode = "CODE A"
            Case 102
                strCode = "FNC 1"
        End Select

        Return strCode

    End Function

    Private Shared Function Mod103CodeListC(ByVal intBaseCodeNumber As Integer) As String

        Dim strCode As String = String.Empty

        Select Case intBaseCodeNumber
            Case 0
                strCode = "00"
            Case 1
                strCode = "01"
            Case 2
                strCode = "02"
            Case 3
                strCode = "03"
            Case 4
                strCode = "04"
            Case 5
                strCode = "05"
            Case 6
                strCode = "06"
            Case 7
                strCode = "07"
            Case 8
                strCode = "08"
            Case 9
                strCode = "09"
            Case 10
                strCode = "10"
            Case 11
                strCode = "11"
            Case 12
                strCode = "12"
            Case 13
                strCode = "13"
            Case 14
                strCode = "14"
            Case 15
                strCode = "15"
            Case 16
                strCode = "16"
            Case 17
                strCode = "17"
            Case 18
                strCode = "18"
            Case 19
                strCode = "19"
            Case 20
                strCode = "20"
            Case 21
                strCode = "21"
            Case 22
                strCode = "22"
            Case 23
                strCode = "23"
            Case 24
                strCode = "24"
            Case 25
                strCode = "25"
            Case 26
                strCode = "26"
            Case 27
                strCode = "27"
            Case 28
                strCode = "28"
            Case 29
                strCode = "29"
            Case 30
                strCode = "30"
            Case 31
                strCode = "31"
            Case 32
                strCode = "32"
            Case 33
                strCode = "33"
            Case 34
                strCode = "34"
            Case 35
                strCode = "35"
            Case 36
                strCode = "36"
            Case 37
                strCode = "37"
            Case 38
                strCode = "38"
            Case 39
                strCode = "39"
            Case 40
                strCode = "40"
            Case 41
                strCode = "41"
            Case 42
                strCode = "42"
            Case 43
                strCode = "43"
            Case 44
                strCode = "44"
            Case 45
                strCode = "45"
            Case 46
                strCode = "46"
            Case 47
                strCode = "47"
            Case 48
                strCode = "48"
            Case 49
                strCode = "49"
            Case 50
                strCode = "50"
            Case 51
                strCode = "51"
            Case 52
                strCode = "52"
            Case 53
                strCode = "53"
            Case 54
                strCode = "54"
            Case 55
                strCode = "55"
            Case 56
                strCode = "56"
            Case 57
                strCode = "57"
            Case 58
                strCode = "58"
            Case 59
                strCode = "59"
            Case 60
                strCode = "60"
            Case 61
                strCode = "61"
            Case 62
                strCode = "62"
            Case 63
                strCode = "63"
            Case 64
                strCode = "64"
            Case 65
                strCode = "65"
            Case 66
                strCode = "66"
            Case 67
                strCode = "67"
            Case 68
                strCode = "68"
            Case 69
                strCode = "69"
            Case 70
                strCode = "70"
            Case 71
                strCode = "71"
            Case 72
                strCode = "72"
            Case 73
                strCode = "73"
            Case 74
                strCode = "74"
            Case 75
                strCode = "75"
            Case 76
                strCode = "76"
            Case 77
                strCode = "77"
            Case 78
                strCode = "78"
            Case 79
                strCode = "79"
            Case 80
                strCode = "80"
            Case 81
                strCode = "81"
            Case 82
                strCode = "82"
            Case 83
                strCode = "83"
            Case 84
                strCode = "84"
            Case 85
                strCode = "85"
            Case 86
                strCode = "86"
            Case 87
                strCode = "87"
            Case 88
                strCode = "88"
            Case 89
                strCode = "89"
            Case 90
                strCode = "90"
            Case 91
                strCode = "91"
            Case 92
                strCode = "92"
            Case 93
                strCode = "93"
            Case 94
                strCode = "94"
            Case 95
                strCode = "95"
            Case 96
                strCode = "96"
            Case 97
                strCode = "97"
            Case 98
                strCode = "98"
            Case 99
                strCode = "99"
            Case 100
                strCode = "CODE B"
            Case 101
                strCode = "CODE A"
            Case 102
                strCode = "FNC 1"
        End Select

        Return strCode

    End Function

#End Region

#Region "�yMod103CodeNumberList�z"

    Private Shared Function Mod103CodeNumberListA(ByVal strBaseCode As String) As Integer

        Dim intCodeNumber As Integer

        Select Case strBaseCode
            Case " "
                intCodeNumber = 0
            Case "!"
                intCodeNumber = 1
            Case """"
                intCodeNumber = 2
            Case "#"
                intCodeNumber = 3
            Case "$"
                intCodeNumber = 4
            Case "%"
                intCodeNumber = 5
            Case "&"
                intCodeNumber = 6
            Case "'"
                intCodeNumber = 7
            Case "("
                intCodeNumber = 8
            Case ")"
                intCodeNumber = 9
            Case "*"
                intCodeNumber = 10
            Case "+"
                intCodeNumber = 11
            Case ","
                intCodeNumber = 12
            Case "-"
                intCodeNumber = 13
            Case "."
                intCodeNumber = 14
            Case "/"
                intCodeNumber = 15
            Case "0"
                intCodeNumber = 16
            Case "1"
                intCodeNumber = 17
            Case "2"
                intCodeNumber = 18
            Case "3"
                intCodeNumber = 19
            Case "4"
                intCodeNumber = 20
            Case "5"
                intCodeNumber = 21
            Case "6"
                intCodeNumber = 22
            Case "7"
                intCodeNumber = 23
            Case "8"
                intCodeNumber = 24
            Case "9"
                intCodeNumber = 25
            Case ":"
                intCodeNumber = 26
            Case ";"
                intCodeNumber = 27
            Case "<"
                intCodeNumber = 28
            Case "="
                intCodeNumber = 29
            Case ">"
                intCodeNumber = 30
            Case "?"
                intCodeNumber = 31
            Case "@"
                intCodeNumber = 32
            Case "A"
                intCodeNumber = 33
            Case "B"
                intCodeNumber = 34
            Case "C"
                intCodeNumber = 35
            Case "D"
                intCodeNumber = 36
            Case "E"
                intCodeNumber = 37
            Case "F"
                intCodeNumber = 38
            Case "G"
                intCodeNumber = 39
            Case "H"
                intCodeNumber = 40
            Case "I"
                intCodeNumber = 41
            Case "J"
                intCodeNumber = 42
            Case "K"
                intCodeNumber = 43
            Case "L"
                intCodeNumber = 44
            Case "M"
                intCodeNumber = 45
            Case "N"
                intCodeNumber = 46
            Case "O"
                intCodeNumber = 47
            Case "P"
                intCodeNumber = 48
            Case "Q"
                intCodeNumber = 49
            Case "R"
                intCodeNumber = 50
            Case "S"
                intCodeNumber = 51
            Case "T"
                intCodeNumber = 52
            Case "U"
                intCodeNumber = 53
            Case "V"
                intCodeNumber = 54
            Case "W"
                intCodeNumber = 55
            Case "X"
                intCodeNumber = 56
            Case "Y"
                intCodeNumber = 57
            Case "Z"
                intCodeNumber = 58
            Case "["
                intCodeNumber = 59
            Case "\"
                intCodeNumber = 60
            Case "]"
                intCodeNumber = 61
            Case "^"
                intCodeNumber = 62
            Case "_"
                intCodeNumber = 63
            Case "NUL"
                intCodeNumber = 64
            Case "SOH"
                intCodeNumber = 65
            Case "STX"
                intCodeNumber = 66
            Case "ETX"
                intCodeNumber = 67
            Case "EOT"
                intCodeNumber = 68
            Case "ENQ"
                intCodeNumber = 69
            Case "ACK"
                intCodeNumber = 70
            Case "BEL"
                intCodeNumber = 71
            Case "BS"
                intCodeNumber = 72
            Case "HT"
                intCodeNumber = 73
            Case "LF"
                intCodeNumber = 74
            Case "VT"
                intCodeNumber = 75
            Case "FF"
                intCodeNumber = 76
            Case "CR"
                intCodeNumber = 77
            Case "SO"
                intCodeNumber = 78
            Case "SI"
                intCodeNumber = 79
            Case "DEL"
                intCodeNumber = 80
            Case "DC1"
                intCodeNumber = 81
            Case "DC2"
                intCodeNumber = 82
            Case "DC3"
                intCodeNumber = 83
            Case "DC4"
                intCodeNumber = 84
            Case "NAK"
                intCodeNumber = 85
            Case "SYN"
                intCodeNumber = 86
            Case "ETB"
                intCodeNumber = 87
            Case "CAN"
                intCodeNumber = 88
            Case "EM"
                intCodeNumber = 89
            Case "SUB"
                intCodeNumber = 90
            Case "ESC"
                intCodeNumber = 91
            Case "FS"
                intCodeNumber = 92
            Case "GS"
                intCodeNumber = 93
            Case "RS"
                intCodeNumber = 94
            Case "US"
                intCodeNumber = 95
            Case "FNC 3"
                intCodeNumber = 96
            Case "FNC 2"
                intCodeNumber = 97
            Case "SHIFT"
                intCodeNumber = 98
            Case "CODE C"
                intCodeNumber = 99
            Case "CODE B"
                intCodeNumber = 100
            Case "FNC 4"
                intCodeNumber = 101
            Case "FNC 1"
                intCodeNumber = 102
        End Select

        Return intCodeNumber

    End Function

    Private Shared Function Mod103CodeNumberListB(ByVal strBaseCode As String) As Integer

        Dim intCodeNumber As Integer

        Select Case strBaseCode
            Case " "
                intCodeNumber = 0
            Case "!"
                intCodeNumber = 1
            Case """"
                intCodeNumber = 2
            Case "#"
                intCodeNumber = 3
            Case "$"
                intCodeNumber = 4
            Case "%"
                intCodeNumber = 5
            Case "&"
                intCodeNumber = 6
            Case "'"
                intCodeNumber = 7
            Case "("
                intCodeNumber = 8
            Case ")"
                intCodeNumber = 9
            Case "*"
                intCodeNumber = 10
            Case "+"
                intCodeNumber = 11
            Case ","
                intCodeNumber = 12
            Case "-"
                intCodeNumber = 13
            Case "."
                intCodeNumber = 14
            Case "/"
                intCodeNumber = 15
            Case "0"
                intCodeNumber = 16
            Case "1"
                intCodeNumber = 17
            Case "2"
                intCodeNumber = 18
            Case "3"
                intCodeNumber = 19
            Case "4"
                intCodeNumber = 20
            Case "5"
                intCodeNumber = 21
            Case "6"
                intCodeNumber = 22
            Case "7"
                intCodeNumber = 23
            Case "8"
                intCodeNumber = 24
            Case "9"
                intCodeNumber = 25
            Case ":"
                intCodeNumber = 26
            Case ";"
                intCodeNumber = 27
            Case "<"
                intCodeNumber = 28
            Case "="
                intCodeNumber = 29
            Case ">"
                intCodeNumber = 30
            Case "?"
                intCodeNumber = 31
            Case "@"
                intCodeNumber = 32
            Case "A"
                intCodeNumber = 33
            Case "B"
                intCodeNumber = 34
            Case "C"
                intCodeNumber = 35
            Case "D"
                intCodeNumber = 36
            Case "E"
                intCodeNumber = 37
            Case "F"
                intCodeNumber = 38
            Case "G"
                intCodeNumber = 39
            Case "H"
                intCodeNumber = 40
            Case "I"
                intCodeNumber = 41
            Case "j"
                intCodeNumber = 42
            Case "K"
                intCodeNumber = 43
            Case "L"
                intCodeNumber = 44
            Case "M"
                intCodeNumber = 45
            Case "N"
                intCodeNumber = 46
            Case "O"
                intCodeNumber = 47
            Case "P"
                intCodeNumber = 48
            Case "Q"
                intCodeNumber = 49
            Case "R"
                intCodeNumber = 50
            Case "S"
                intCodeNumber = 51
            Case "T"
                intCodeNumber = 52
            Case "U"
                intCodeNumber = 53
            Case "V"
                intCodeNumber = 54
            Case "W"
                intCodeNumber = 55
            Case "X"
                intCodeNumber = 56
            Case "Y"
                intCodeNumber = 57
            Case "Z"
                intCodeNumber = 58
            Case "["
                intCodeNumber = 59
            Case "\"
                intCodeNumber = 60
            Case "]"
                intCodeNumber = 61
            Case "^"
                intCodeNumber = 62
            Case "_"
                intCodeNumber = 63
            Case "`"
                intCodeNumber = 64
            Case "a"
                intCodeNumber = 65
            Case "b"
                intCodeNumber = 66
            Case "c"
                intCodeNumber = 67
            Case "d"
                intCodeNumber = 68
            Case "e"
                intCodeNumber = 69
            Case "f"
                intCodeNumber = 70
            Case "g"
                intCodeNumber = 71
            Case "h"
                intCodeNumber = 72
            Case "i"
                intCodeNumber = 73
            Case "j"
                intCodeNumber = 74
            Case "k"
                intCodeNumber = 75
            Case "l"
                intCodeNumber = 76
            Case "m"
                intCodeNumber = 77
            Case "n"
                intCodeNumber = 78
            Case "o"
                intCodeNumber = 79
            Case "p"
                intCodeNumber = 80
            Case "q"
                intCodeNumber = 81
            Case "r"
                intCodeNumber = 82
            Case "s"
                intCodeNumber = 83
            Case "t"
                intCodeNumber = 84
            Case "u"
                intCodeNumber = 85
            Case "v"
                intCodeNumber = 86
            Case "w"
                intCodeNumber = 87
            Case "x"
                intCodeNumber = 88
            Case "y"
                intCodeNumber = 89
            Case "z"
                intCodeNumber = 90
            Case "{"
                intCodeNumber = 91
            Case "|"
                intCodeNumber = 92
            Case "}"
                intCodeNumber = 93
            Case "~"
                intCodeNumber = 94
            Case "DEL"
                intCodeNumber = 95
            Case "FNC 3"
                intCodeNumber = 96
            Case "FNC 2"
                intCodeNumber = 97
            Case "SHIFT"
                intCodeNumber = 98
            Case "CODE C"
                intCodeNumber = 99
            Case "FNC 4"
                intCodeNumber = 100
            Case "CODE A"
                intCodeNumber = 101
            Case "FNC 1"
                intCodeNumber = 102
        End Select

        Return intCodeNumber

    End Function

    Private Shared Function Mod103CodeNumberListC(ByVal strBaseCode As String) As Integer

        Dim intCodeNumber As Integer

        Select Case strBaseCode
            Case "00"
                intCodeNumber = 0
            Case "01"
                intCodeNumber = 1
            Case "02"
                intCodeNumber = 2
            Case "03"
                intCodeNumber = 3
            Case "04"
                intCodeNumber = 4
            Case "05"
                intCodeNumber = 5
            Case "06"
                intCodeNumber = 6
            Case "07"
                intCodeNumber = 7
            Case "08"
                intCodeNumber = 8
            Case "09"
                intCodeNumber = 9
            Case "10"
                intCodeNumber = 10
            Case "11"
                intCodeNumber = 11
            Case "12"
                intCodeNumber = 12
            Case "13"
                intCodeNumber = 13
            Case "14"
                intCodeNumber = 14
            Case "15"
                intCodeNumber = 15
            Case "16"
                intCodeNumber = 16
            Case "17"
                intCodeNumber = 17
            Case "18"
                intCodeNumber = 18
            Case "19"
                intCodeNumber = 19
            Case "20"
                intCodeNumber = 20
            Case "21"
                intCodeNumber = 21
            Case "22"
                intCodeNumber = 22
            Case "23"
                intCodeNumber = 23
            Case "24"
                intCodeNumber = 24
            Case "25"
                intCodeNumber = 25
            Case "26"
                intCodeNumber = 26
            Case "27"
                intCodeNumber = 27
            Case "28"
                intCodeNumber = 28
            Case "29"
                intCodeNumber = 29
            Case "30"
                intCodeNumber = 30
            Case "31"
                intCodeNumber = 31
            Case "32"
                intCodeNumber = 32
            Case "33"
                intCodeNumber = 33
            Case "34"
                intCodeNumber = 34
            Case "35"
                intCodeNumber = 35
            Case "36"
                intCodeNumber = 36
            Case "37"
                intCodeNumber = 37
            Case "38"
                intCodeNumber = 38
            Case "39"
                intCodeNumber = 39
            Case "40"
                intCodeNumber = 40
            Case "41"
                intCodeNumber = 41
            Case "42"
                intCodeNumber = 42
            Case "43"
                intCodeNumber = 43
            Case "44"
                intCodeNumber = 44
            Case "45"
                intCodeNumber = 45
            Case "46"
                intCodeNumber = 46
            Case "47"
                intCodeNumber = 47
            Case "48"
                intCodeNumber = 48
            Case "49"
                intCodeNumber = 49
            Case "50"
                intCodeNumber = 50
            Case "51"
                intCodeNumber = 51
            Case "52"
                intCodeNumber = 52
            Case "53"
                intCodeNumber = 53
            Case "54"
                intCodeNumber = 54
            Case "55"
                intCodeNumber = 55
            Case "56"
                intCodeNumber = 56
            Case "57"
                intCodeNumber = 57
            Case "58"
                intCodeNumber = 58
            Case "59"
                intCodeNumber = 59
            Case "60"
                intCodeNumber = 60
            Case "61"
                intCodeNumber = 61
            Case "62"
                intCodeNumber = 62
            Case "63"
                intCodeNumber = 63
            Case "64"
                intCodeNumber = 64
            Case "65"
                intCodeNumber = 65
            Case "66"
                intCodeNumber = 66
            Case "67"
                intCodeNumber = 67
            Case "68"
                intCodeNumber = 68
            Case "69"
                intCodeNumber = 69
            Case "70"
                intCodeNumber = 70
            Case "71"
                intCodeNumber = 71
            Case "72"
                intCodeNumber = 72
            Case "73"
                intCodeNumber = 73
            Case "74"
                intCodeNumber = 74
            Case "75"
                intCodeNumber = 75
            Case "76"
                intCodeNumber = 76
            Case "77"
                intCodeNumber = 77
            Case "78"
                intCodeNumber = 78
            Case "79"
                intCodeNumber = 79
            Case "80"
                intCodeNumber = 80
            Case "81"
                intCodeNumber = 81
            Case "82"
                intCodeNumber = 82
            Case "83"
                intCodeNumber = 83
            Case "84"
                intCodeNumber = 84
            Case "85"
                intCodeNumber = 85
            Case "86"
                intCodeNumber = 86
            Case "87"
                intCodeNumber = 87
            Case "88"
                intCodeNumber = 88
            Case "89"
                intCodeNumber = 89
            Case "90"
                intCodeNumber = 90
            Case "91"
                intCodeNumber = 91
            Case "92"
                intCodeNumber = 92
            Case "93"
                intCodeNumber = 93
            Case "94"
                intCodeNumber = 94
            Case "95"
                intCodeNumber = 95
            Case "96"
                intCodeNumber = 96
            Case "97"
                intCodeNumber = 97
            Case "98"
                intCodeNumber = 98
            Case "99"
                intCodeNumber = 99
            Case "CODE B"
                intCodeNumber = 100
            Case "CODE A"
                intCodeNumber = 101
            Case "FNC 1"
                intCodeNumber = 102
        End Select

        Return intCodeNumber

    End Function

#End Region

    <DllImport("imm32.dll")> _
    Public Shared Function ImmGetDefaultIMEWnd(ByVal ptWnd As IntPtr) As IntPtr
    End Function

    <DllImport("user32.dll")> _
    Public Shared Function RegisterWindowMessage(ByVal strRwm As String) As Integer
    End Function

    <DllImport("user32.dll")> _
    Public Shared Function SendMessage(ByVal ptWnd As IntPtr, _
                                       ByVal intMsg As Integer, _
                                       ByVal ptParam As IntPtr, _
                                       ByRef objParam As Object) As Integer
    End Function

    ''' <summary>
    ''' IME�p�b�h�\��
    ''' </summary>
    ''' <param name="objForm">�ďo���t�H�[��</param>
    ''' <remarks>IME�p�b�h��\�����܂��B</remarks>
    Public Shared Sub ShowIMEPad(ByVal objForm As Windows.Forms.Form)

        Dim ptIme As IntPtr
        Dim intParam As Integer
        Dim lngRef As Long = 0

        ' imm32.dll���擾
        ptIme = ImmGetDefaultIMEWnd(objForm.Handle)

        ' user32.dll��Window���b�Z�[�W��ݒ�
        intParam = RegisterWindowMessage("MSIMEShowImePad")

        ' ���b�Z�[�W�𑗂�
        SendMessage(ptIme, intParam, CType(0, IntPtr), CType(lngRef, Object))

    End Sub

End Class
