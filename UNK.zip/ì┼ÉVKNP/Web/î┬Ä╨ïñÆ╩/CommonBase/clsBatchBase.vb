﻿Imports CommonSystem
Imports System
Imports System.Text

''' ======================================================================
''' クラス名：clsBatchBase
''' <summary>
''' 継承元クラス
''' </summary>
''' <remarks>
''' 処理の初期化処理等々
''' 
'''   
''' </remarks>
''' ======================================================================
''' 更新履歴
''' 項番    更新日付    担当者  更新内容
''' 0001    2009/07/27  TCT川崎 新規作成
''' ======================================================================
Public MustInherit Class clsBatchBase

#Region "変数域"

    ''' <summary>
    ''' DBアクセスクラス
    ''' </summary>
    ''' <remarks></remarks>
    Protected mobjCommonDB As CommonDB

    ''' <summary>
    ''' DB接続設定PreFix
    ''' </summary>
    ''' <remarks></remarks>
    Protected mstrCompanyCode As String


    ''' <summary>
    ''' 起動引数
    ''' </summary>
    ''' <remarks></remarks>
    Protected mstrArgs() As String

    ''' <summary>
    ''' App構成ファイル
    ''' </summary>
    ''' <remarks></remarks>
    Protected mdicConfig As New Dictionary(Of String, String)


#End Region

#Region "[Execute]"

    ''' ======================================================================
    ''' メソッド名：Execute
    ''' <summary>
    ''' メイン処理
    ''' </summary>
    ''' <remarks></remarks>
    ''' ======================================================================
    Protected MustOverride Sub Execute()

#End Region

#Region "初期処理[Run]"

    ''' ======================================================================
    ''' メソッド名：Run
    ''' <summary>
    ''' 継承元初期処理
    ''' </summary>
    ''' <remarks></remarks>
    ''' ======================================================================
    Protected Overridable Overloads Function Run() As Integer

        Try

            If CommonProcess.ProcessExecCheck = False Then
                Return 0
            End If

            ' コマンドライン引数取得
            Call setCommandLine()

            ' App構成ファイル情報取得
            Call setConfig()

            ' DB接続
            Call setDataBase()

            ' ログ情報設定
            Call setLogOutput()

            ' タスク実行管理テーブルチェック
            If Not ExecuteCheck() Then
                Return 0
            End If

            WriteLog("★処理開始★", EventLogEntryType.SuccessAudit)

            ' 各メソッド毎の処理を行う
            Call Execute()

            WriteLog("★処理終了★", EventLogEntryType.SuccessAudit)

            Return 0

        Catch ex As Exception
            ' イベントログ出力処理
            WriteLog(ex.Message, EventLogEntryType.Error)
            WriteLog(ex.StackTrace, EventLogEntryType.Error)
            Return 1
        End Try

    End Function

#End Region

#Region "初期処理[Run]"

    ''' ======================================================================
    ''' メソッド名：Run
    ''' <summary>
    ''' 継承元初期処理
    ''' </summary>
    ''' <remarks></remarks>
    ''' ======================================================================
    Protected Overridable Overloads Function Run(ByVal intRun As Boolean) As Integer

        Try

            If CommonProcess.ProcessExecCheck = False Then
                Return 0
            End If

            '' コマンドライン引数取得
            'Call setCommandLine()

            ' App構成ファイル情報取得
            Call setConfig()

            ' ログ情報設定
            Call setLogOutput()

            WriteLog("☆処理開始☆", EventLogEntryType.SuccessAudit)

            ' 各メソッド毎の処理を行う
            Call Execute()

            WriteLog("☆処理終了☆", EventLogEntryType.SuccessAudit)

            Return 0

        Catch ex As Exception
            ' イベントログ出力処理
            WriteLog(ex.Message, EventLogEntryType.Error)
            WriteLog(ex.StackTrace, EventLogEntryType.Error)
            Return 1
        End Try

    End Function

#End Region

#Region "コマンドライン取得[setCommandLine]"

    ''' ======================================================================
    ''' メソッド名：setCommandLine
    ''' <summary>
    ''' コマンドライン取得処理
    ''' </summary>
    ''' <remarks></remarks>
    ''' ======================================================================
    Protected Overridable Overloads Sub setCommandLine()

        'コマンドラインを配列で取得する
        mstrArgs = System.Environment.GetCommandLineArgs()

        '' コマンドライン引数チェック
        'If mstrArgs.Length <> getArgSize() Then
        '    Throw New Exception("コマンドライン引数が[" & mstrArgs.Length.ToString & "]件です。")
        'End If

    End Sub

#End Region

#Region "App構成ファイル情報取得[setConfig]"
    ''' ======================================================================
    ''' メソッド名：setConfig
    ''' <summary>
    ''' DB接続処理
    ''' </summary>
    ''' <remarks>不要時はオーバーライドし、空メソッド作成してね</remarks>
    ''' ======================================================================

    Protected Overridable Overloads Sub setConfig()

        Dim key As String

        For Each key In System.Configuration.ConfigurationManager.AppSettings.AllKeys
            mdicConfig.Add(key, System.Configuration.ConfigurationManager.AppSettings(key))
        Next

    End Sub

#End Region


#Region "データベース接続[setDataBase]"

    ''' ======================================================================
    ''' メソッド名：setDataBase
    ''' <summary>
    ''' DB接続処理
    ''' </summary>
    ''' <remarks>DB非接続時はオーバーライドし、空メソッド作成してね</remarks>
    ''' ======================================================================
    Protected Overridable Overloads Sub setDataBase()

        mobjCommonDB = New CommonDB

        If mobjCommonDB.DB_Open(mdicConfig(clsConst.CONF_DB_CONFIG_PREFIX)) = False Then
            Throw New Exception("DB接続に失敗しました")
        End If

    End Sub

#End Region

#Region "データベース接続[setDataBase]"

    ''' ======================================================================
    ''' メソッド名：getArgSize
    ''' <summary>
    ''' DB接続処理
    ''' </summary>
    ''' <remarks>起動引数の数を返す</remarks>
    ''' ======================================================================
    Protected Overridable Overloads Function getArgSize() As Integer

        Return 1

    End Function

#End Region

#Region "ログ出力モード設定"

    ''' ======================================================================
    ''' メソッド名：setLogOutput
    ''' <summary>
    ''' Log出力モード設定処理
    ''' </summary>
    ''' <remarks></remarks>
    ''' ======================================================================
    Private Sub setLogOutput()

        'ログ出力レベル設定
        If mdicConfig.ContainsKey(clsConst.CONF_LOG_OUTPUT_LEVEL) Then
            CommonLog.SetLogOutputMode = System.Int32.Parse(mdicConfig(clsConst.CONF_LOG_OUTPUT_LEVEL))
        Else
            CommonLog.SetLogOutputMode = CommonLog.LogOutputMode.Silent
        End If

        'ログ日時分割出力モード設定
        If mdicConfig.ContainsKey(clsConst.CONF_LOG_DIVIDE_MODE) Then
            CommonLog.SetLogDateHourDivideMode = System.Int32.Parse(mdicConfig(clsConst.CONF_LOG_DIVIDE_MODE))
        Else
            CommonLog.SetLogDateHourDivideMode = CommonLog.LogDateHourDivideMode.Normal
        End If

        ' 2011/02/02 shinohara
        ' ログの出力先を実行ファイルPath＋"LOG"にします。
        Dim strExecutePath As String = IO.Path.GetDirectoryName(Windows.Forms.Application.ExecutablePath)
        Dim strLogOutputPath As String = IO.Path.Combine(strExecutePath, "log")
        CommonLog.SetLogFileOutputPath = strLogOutputPath

        ' 2011/02/02 shinohara
        ' コンフィグに削除期間が指定されている場合は該当期間のログファイルを削除します。
        If mdicConfig.ContainsKey(clsConst.CONF_LOG_KEEP_DAYS_CODE) Then
            Dim intDays As Integer = Convert.ToInt32(mdicConfig(clsConst.CONF_LOG_KEEP_DAYS_CODE))
            CommonLog.DeleteLogFile(intDays)
        End If


    End Sub

#End Region


    Protected Sub WriteLog(ByVal strMessage As String, ByVal EntryType As Diagnostics.EventLogEntryType)

        CommonLog.WriteLog(strMessage, EntryType)
        If EntryType = EventLogEntryType.Error Or EntryType = EventLogEntryType.Warning Then
            WriteEventLog(strMessage, EntryType)
        End If

    End Sub


#Region "イベントログ書き込み処理[WriteEventLog]"
    ''' ======================================================================
    ''' メソッド名：WriteEventLog
    ''' <summary>
    ''' イベントログに書き込む
    ''' </summary>
    ''' <remarks></remarks>
    ''' ======================================================================
    Protected Sub WriteEventLog(ByVal strMsg As String, ByVal EntryType As Diagnostics.EventLogEntryType)

        Dim sbEvent As New System.Text.StringBuilder
        Call sbEvent.AppendLine("処理区分：[COMPANY=" & mdicConfig(clsConst.CONF_COMPANY_CODE) & "]")
        Call sbEvent.AppendLine("機能名：[" & Me.GetType.Assembly.GetName.Name & "]")
        Call sbEvent.AppendLine("通知内容：" & strMsg & "")
        'アプリケーションログに出力する
        Call Diagnostics.EventLog.WriteEntry(mdicConfig(clsConst.CONF_COMPANY_CODE), sbEvent.ToString, EntryType)

    End Sub

#End Region

#Region "実行チェック"
    Private Function ExecuteCheck() As Boolean

        ' 引数が存在しない場合はそのまま処理を実行します。
        If mstrArgs.Length < 2 Then
            Return True
        End If

        ' 引数からタスクIDを取得します。
        Dim strTaskID As String = mstrArgs(1)
        If strTaskID.Equals("9999") Then
            ' タスクIDが「9999」の場合はそのまま処理を実行させます・
            Return True
        End If

        ' タスクIDから実行フラグを取得します。
        Dim stbSel As New StringBuilder("SELECT EXE_FLG FROM M_CM_TASK WHERE TASK_ID = '%TASK%'")
        stbSel.Replace("%TASK%", strTaskID)
        Dim dt As DataTable = mobjCommonDB.DB_ExecuteQuery(stbSel.ToString)
        If dt Is Nothing OrElse dt.Rows.Count = 0 Then
            WriteLog("存在しないタスクIDが引数に指定されました。", EventLogEntryType.Error)
            Return False
        End If

        ' 実行フラグをチェックします。
        Dim strExeFlg As String = Convert.ToString(dt.Rows(0).Item(0))
        If strExeFlg.Equals("0") Then
            WriteLog("タスクID[" & strTaskID & "]に対応する実行フラグが「0」のため処理を終了します。", EventLogEntryType.Information)
            Return False
        End If

        mobjCommonDB.DB_Transaction()
        Try
            Dim stbUpd As New StringBuilder("UPDATE M_CM_TASK SET EXE_FLG = '0' WHERE TASK_ID = '%TASK%'")
            stbUpd.Replace("%TASK%", strTaskID)
            mobjCommonDB.DB_ExecuteNonQuery(stbUpd.ToString)

            mobjCommonDB.DB_Commit()

        Catch ex As Exception
            mobjCommonDB.DB_Rollback()
            WriteLog("タスクID[" & strTaskID & "]に対応する実行フラグのリセットに失敗しました。", EventLogEntryType.Information)
            Return False
        End Try

        Return True

    End Function
#End Region


End Class
