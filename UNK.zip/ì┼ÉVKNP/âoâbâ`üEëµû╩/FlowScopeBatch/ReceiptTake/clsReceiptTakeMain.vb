﻿Imports CommonSystem
Imports CommonBase
Imports System
Imports System.IO
Imports System.Text
Imports Oracle.DataAccess.Client

Public Class clsReceiptTakeMain
    Inherits clsBatchBase

#Region "共通変数"

    ''' <summary>
    ''' 自端末処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Shared mainProc As clsReceiptTakeMain

#End Region

#Region "外部定義（コンフィグ）取得用定数"

    ' *************************************
    ' ステータス関連
    ' *************************************

    ''' <summary>
    ''' DB登録する受付ステータス
    ''' </summary>
    ''' <remarks></remarks>
    Private Const CONF_RECEIPT_SATTUS As String = "OUTPUT_RECEIPT_STATUS"

    ''' <summary>
    ''' DB登録するイメージステータス
    ''' </summary>
    ''' <remarks></remarks>
    Private Const CONF_IMAGE_STATUS As String = "OUTPUT_IMAGE_STATUS"


    ' *************************************
    ' 取得ファイル情報関連
    ' *************************************

    ''' <summary>
    ''' 結果ファイル取得先ルートフォルダ
    ''' </summary>
    ''' <remarks></remarks>
    Private Const CONF_RECEIVE_PATH As String = "RECEIVE_PATH"

    ''' <summary>
    ''' トリガーファイル名
    ''' </summary>
    ''' <remarks></remarks>
    Private Const CONF_TRIGGER_FILE As String = "TRIGGER_FILE"

    ''' <summary>
    ''' NG結果ファイル移動先ルートフォルダ
    ''' </summary>
    ''' <remarks></remarks>
    Private Const CONF_NG_PATH As String = "NG_PATH"

    ''' <summary>
    ''' OK結果ファイル移動先ルートフォルダ
    ''' </summary>
    ''' <remarks></remarks>
    Private Const CONF_OK_PATH As String = "OK_PATH"

    ''' <summary>
    ''' 擬似OCR結果作成用バッファ
    ''' </summary>
    ''' <remarks></remarks>
    Private mdicOcrResult As New Dictionary(Of String, Integer)

#End Region

#Region "内部変数定義"

    ''' <summary>
    ''' 受信フォルダの名前の年月日時分秒
    ''' </summary>
    ''' <remarks></remarks>
    Private mstrFolderDateTime As String = String.Empty

    ''' <summary>
    ''' 日付の連番
    ''' </summary>
    ''' <remarks></remarks>
    Private mintDateNumber As Integer = 0

    ''' <summary>
    ''' 受信回数
    ''' </summary>
    ''' <remarks></remarks>
    Private mintReceiveCount As Integer = 0

    ''' <summary>
    ''' イメージIDの連番部分
    ''' </summary>
    ''' <remarks></remarks>
    Private mintImageIdSeq As Integer = 0

    ''' <summary>
    ''' 擬似OCR結果登録用案件ID格納領域
    ''' </summary>
    ''' <remarks></remarks>
    Private mdicSubject As New Dictionary(Of String, String)

#End Region




#Region "メイン処理[Main]"

    ''' ======================================================================
    ''' メソッド名：Main
    ''' <summary>
    ''' メイン処理
    ''' </summary>
    ''' <remarks></remarks>
    ''' ======================================================================
    Shared Function Main(ByVal CmdArgs() As String) As Integer

        mainProc = New clsReceiptTakeMain

        ' 処理の戻り値を返却
        Return mainProc.Run()

    End Function

#End Region

#Region "バッチ処理本体"
    ''' ======================================================================
    ''' メソッド名：Execute
    ''' <summary>
    ''' バッチ処理本体
    ''' </summary>
    ''' <remarks></remarks>
    ''' ======================================================================
    Protected Overrides Sub Execute()

        Try

            ' 外部定義（コンフィグ）から定義内容を取得します。
            Dim strNGRootFolder As String = mdicConfig(CONF_NG_PATH) 'NGフォルダ移動先ルートフォルダ
            Dim strOKRootFolder As String = mdicConfig(CONF_OK_PATH) 'OKフォルダ移動先ルートフォルダ


            ' 取得対象データの存在するフォルダのリストを取得します。
            Dim strFolders As List(Of String) = GetTargetFolders()

            ' リストにあるフォルダを一つずつ処理します。
            For Each strFolder As String In strFolders

                ' 擬似OCR結果作成用バッファを初期化します
                mdicOcrResult.Clear()

                ' 受信した結果ファイルの格納されているフォルダ名を取得しておきます。（処理後の移動or削除のため）
                Dim strFolderName As String = Path.GetFileName(strFolder)

                ' フォルダ名の先頭１４桁（YYYYMMDDHHMMSS）を記憶します。（イメージ更新時に利用します）
                mstrFolderDateTime = strFolderName.Substring(0, 14)

                ' 納品予定テーブルを検索します
                Dim drPlan As DataRow = GetDeliveryPlan(mstrFolderDateTime)
                If drPlan Is Nothing Then
                    ' 処理対象のフォルダをNGフォルダ内に移動します。
                    Dim strNgFolderName As String = Path.GetFileName(strFolder)
                    Dim strNGFolder As String = Path.Combine(strNGRootFolder, strNgFolderName)
                    Directory.Move(strFolder, strNGFolder)

                    MyBase.WriteEventLog(strFolder & "は受信時刻が不正です", EventLogEntryType.Error)
                    Continue For
                End If

                ' 閏年を考慮するため西暦は2000年の固定として月日を元に元日からの日数を算出します
                Dim strDate1 As String = "2000/01/01"
                Dim strDate2 As String = "2000/" & mstrFolderDateTime.Substring(4, 2) & "/" & mstrFolderDateTime.Substring(6, 2)
                Dim D1 As Date = CDate(strDate1)
                Dim D2 As Date = CDate(strDate2)
                mintDateNumber = DateDiff(DateInterval.Day, D1, D2) + 1


                ' DBトランザクションを開始します。
                MyBase.mobjCommonDB.DB_Transaction()

                ' イメージID生成の準備を行います
                mintReceiveCount = Convert.ToInt32(drPlan.Item("RECEIPT_COUNT"))
                mintImageIdSeq = ReadyToImageID(mintDateNumber, mintReceiveCount)

                Try

                    ' *************************************************************************
                    ' イメージをDBに登録します。（戻り値は登録したイメージ数です。）
                    ' *************************************************************************
                    Dim intImageCount As Integer = Receive(strFolder, drPlan)

                    ' OCR結果を取り込みを行います
                    Dim intOcrCount As Integer = 0
                    If mdicConfig("OCR_FILE_MODE").Equals("1") Then
                        ' 本当のOCR結果取込
                        intOcrCount = ReceiveOcrResult(strFolder)
                    Else
                        ' 擬似OCR結果登録
                        intOcrCount = MakeOcrResult(mdicOcrResult)
                    End If
                    If intOcrCount < 0 Then
                        intImageCount = -1
                    End If

                    If intImageCount < 0 Then

                        ' 処理対象のフォルダをNGフォルダ内に移動します。
                        Dim strNGFolder As String = Path.Combine(strNGRootFolder, strFolderName)
                        Directory.Move(strFolder, strNGFolder)

                        ' 登録イメージ数がゼロ未満ならトランザクションを巻き戻します。
                        MyBase.mobjCommonDB.DB_Rollback()

                    Else

                        If strOKRootFolder.Trim.Equals(String.Empty) Then

                            ' 外部定義（コンフィグ）にOKフォルダの移動先が定義されていない場合はOKフォルダを削除します。
                            Directory.Delete(strFolder, True)

                        Else

                            ' 処理対象のフォルダをOKフォルダ内に移動します。
                            Dim strOKFolder As String = Path.Combine(strOKRootFolder, strFolderName.Substring(0, 10))
                            If Not Directory.Exists(strOKFolder) Then
                                Directory.CreateDirectory(strOKFolder)
                            End If
                            strOKFolder = Path.Combine(strOKFolder, strFolderName)
                            Directory.Move(strFolder, strOKFolder)

                        End If

                    End If

                    ' イメージID生成情報を更新します
                    Call UpdateImageID()

                    ' トランザクションを完了します。
                    MyBase.mobjCommonDB.DB_Commit()

                Catch ex As Exception

                    ' トランザクションを巻き戻します。
                    MyBase.mobjCommonDB.DB_Rollback()

                    ' エラー検知時の処理対象フォルダーがまだ存在するかチェックします。
                    If Directory.Exists(strFolder) Then
                        ' 処理対象のフォルダをNGフォルダ内に移動します。
                        Dim strNgFolderName As String = Path.GetFileName(strFolder)
                        Dim strNGFolder As String = Path.Combine(strNGRootFolder, strNgFolderName)
                        Directory.Move(strFolder, strNGFolder)
                    End If

                    Throw New Exception("受信データ取込中にエラーを検出しました。")

                End Try
            Next

        Catch ex As Exception

            MyBase.WriteLog(ex.ToString, EventLogEntryType.Error)

        Finally

        End Try

    End Sub
#End Region

#Region "処理対象フォルダのリスト作成"
    ''' ======================================================================
    ''' メソッド名：GetTargetFolders
    ''' <summary>
    ''' 処理対象フォルダのリスト作成
    ''' </summary>
    ''' <returns>作成したヘ処理対象フォルダのリスト</returns>
    ''' <remarks></remarks>
    ''' ======================================================================
    Private Function GetTargetFolders() As List(Of String)

        ' 外部定義（コンフィグ）から定義内容を取得します。
        Dim strRootFolder As String = mdicConfig(CONF_RECEIVE_PATH) 'ルートフォルダ
        Dim strTrigger As String = mdicConfig(CONF_TRIGGER_FILE)    'トリガーファイルの名前

        Dim FolderList As New List(Of String)

        ' ルートフォルダの直下にあるフォルダ名を全て取得します。
        Dim strFolders() As String = Directory.GetDirectories(strRootFolder)

        ' 取得したフォルダ名を一つずつ精査します。
        For Each strFolder As String In strFolders

            ' トリガーファイルPathを作成します。
            Dim strTRG As String = Path.Combine(strFolder, strTrigger)

            ' 取得したフォルダ内にトリガーファイルが存在する場合に
            ' そのフォルダを処理対象フォルダのリストに追加します。
            If File.Exists(strTRG) Then
                FolderList.Add(strFolder)
            End If

        Next

        ' 全ての処理対象フォルダがリストに登録されたらフォルダ名で整列します。
        FolderList.Sort()

        Return FolderList

    End Function
#End Region

#Region "フォルダ単位のデータ取得"
    ''' ======================================================================
    ''' メソッド名：Receive
    ''' <summary>
    ''' フォルダ単位のデータ取得
    ''' </summary>
    ''' <param name="strFolder">処理対象フォルダ</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    ''' ======================================================================
    Private Function Receive(ByVal strFolder As String, drPlan As DataRow) As Integer

        Dim strDowload As String = Path.Combine(strFolder, clsConst.CNST_DOWNLOAD_FILE)
        If Not File.Exists(strDowload) Then
            Return -1
        End If

        Dim strPriority As String = String.Empty    ' 優先度
        Dim strFileDate As String = String.Empty    ' ファイル作成システム日付

        ' 新規の受付番号を取得します。
        Dim strReceiptID As String = getReceiptID()

        Dim intImageCount As Integer = 0
        Using sr As New StreamReader(strDowload, Encoding.GetEncoding(clsConst.CNST_ENCODING_SHIFT_JIS))

            Try

                Do While sr.Peek() >= 0

                    Dim strLine As String = sr.ReadLine()
                    Dim strItem() As String = Split(strLine, ","c)

                    'レコード種別によって処理を分岐します。
                    Select Case strItem(0)

                        Case "1", "3", "4", "9"
                            ' レコード種別が、"1", "2", "3", "4", "9"の場合は処理はありません。

                        Case "2"
                            ' ヘッダレコードからの優先度、ファイル作成日、受信ファイル名を取得します。
                            strPriority = strItem(1)    ' 優先度
                            strFileDate = strItem(2)    ' ファイル作成日

                        Case "5"    ' データレコード
                            ' 受信時間帯(受信回数で判断）と帳票IDの組合せが正常であるかを精査します
                            Dim strCount As String = Convert.ToString(drPlan.Item("RECEIPT_COUNT"))
                            Select Case strItem(5).Substring(0, 3)
                                Case "601", "611", "621", "631"
                                    If strCount.Equals("51") Then
                                        MyBase.WriteEventLog("受信時間帯と帳票IDが一致しません(SS)", EventLogEntryType.Error)
                                        Return -1
                                    End If
                                Case "641", "661"
                                    If Not strCount.Equals("51") Then
                                        MyBase.WriteEventLog("受信時間帯と帳票IDが一致しません(非SS)", EventLogEntryType.Error)
                                        Return -1
                                    End If
                                Case Else
                                    MyBase.WriteEventLog("不明な帳票IDを検出しました。", EventLogEntryType.Error)
                                    Return -1
                            End Select

                            Dim intOcrColmn As Integer = 0
                            Select Case strItem(5).Substring(0, 3)
                                Case "601"
                                    intOcrColmn = 342
                                Case "611"
                                    intOcrColmn = 273
                                Case "621"
                                    intOcrColmn = 64
                                Case "631"
                                    intOcrColmn = 58
                                Case "641"
                                    intOcrColmn = 70
                                Case "661"
                                    intOcrColmn = 51
                            End Select
                            If Not mdicOcrResult.ContainsKey(strItem(7)) Then
                                mdicOcrResult.Add(strItem(7), intOcrColmn)
                            End If

                            ' 登録イメージ数を加算します。
                            intImageCount += 1

                            ' イメージIDを取得します
                            Dim strImageID As String = getImageID()
                            ' 帳票IDがCSV出力タイプとイメージタイプとで初期登録するイメージIDを変更します。
                            Dim strImageStatus As String = mdicConfig("OUTPUT_IMAGE_STATUS")

                            ' イメージテーブルにデータを１件登録します。
                            Call InsertImage(strImageID, _
                                             strReceiptID, _
                                             strPriority, _
                                             strImageStatus, _
                                             strItem)
                            ' イメージ履歴を登録します。
                            Call InsertImageHistory(strImageID, strImageStatus)

                        Case Else
                            MyBase.WriteLog("Download.txtの内容が不正です。", EventLogEntryType.Error)
                            CommonLog.WriteLog("対象ディレクトリ:" & strFolder, EventLogEntryType.Error)
                            Return -1

                    End Select

                Loop

                ' 受付テーブルを登録します。
                Call InsertReceipt(strReceiptID, intImageCount, drPlan)
                ' 受付履歴をを登録します
                Call InsertReceiptHistory(strReceiptID)

            Catch ex As Exception

                MyBase.WriteLog("処理不能なエラーを検知しました。", EventLogEntryType.Error)
                CommonLog.WriteLog(ex.ToString, EventLogEntryType.Error)
                Return -1

            End Try

        End Using

        Return intImageCount

    End Function
#End Region

#Region "受付IDの作成"
    Private Function getReceiptID() As String
        ' シーケンスから新規受付IDを取得します。
        Dim dtbReceipt As DataTable = mobjCommonDB.DB_ExecuteQuery("SELECT S_JJ_RECEIPT.NEXTVAL FROM DUAL")
        If dtbReceipt Is Nothing OrElse dtbReceipt.Rows.Count <> 1 Then
            Throw New Exception("新規受付IDを生成できません。")
        End If
        Dim strReceiptNo As String = Convert.ToString(dtbReceipt.Rows(0).Item(0))
        Return strReceiptNo
    End Function
#End Region

#Region "イメージIDの作成"
    Private Function getImageID() As String
        '' シーケンスから新規イメージIDを取得します。
        'Dim dtbImage As DataTable = mobjCommonDB.DB_ExecuteQuery("SELECT S_JJ_IMAGE.NEXTVAL FROM DUAL")
        'If dtbImage Is Nothing OrElse dtbImage.Rows.Count <> 1 Then
        '    Throw New Exception("新規イメージIDを生成できません。")
        'End If
        'Dim strImageID As String = Convert.ToString(dtbImage.Rows(0).Item(0))
        'Return strImageID

        mintImageIdSeq += 1
        Dim strImageID As String = mintDateNumber.ToString & mintReceiveCount.ToString("00") & mintImageIdSeq.ToString("00000")
        Return strImageID
    End Function
#End Region

#Region "イメージテーブルの登録"
    Private Sub InsertImage(ByVal strImageID As String, _
                            ByVal strReceiptID As String, _
                            ByVal strPriority As String, _
                            ByVal strImageStatus As String, _
                            ByVal strItem() As String)

        ' イメージテーブル登録用のSQLを作成します。
        Dim stbSQL As New StringBuilder(String.Empty)
        stbSQL.AppendLine("INSERT INTO T_JJ_IMAGE (  ")
        stbSQL.AppendLine("     IMAGE_ID             ")
        stbSQL.AppendLine("    ,RECEIPT_ID           ")
        stbSQL.AppendLine("    ,IMAGE_STATUS         ")
        stbSQL.AppendLine("    ,IMAGE_FILE_NAME      ")
        stbSQL.AppendLine("    ,IMAGE_FILE_PATH      ")
        stbSQL.AppendLine("    ,SLIP_DEFINE_ID       ")
        stbSQL.AppendLine("    ,BUSINESS_DATE        ")
        stbSQL.AppendLine("    ,PRIORITY             ")
        stbSQL.AppendLine("    ,EXC_IMAGE_NO         ")
        stbSQL.AppendLine("    ,EXC_SUBJECT_NO       ")
        stbSQL.AppendLine("    ,DELETE_FLG           ")
        stbSQL.AppendLine("    ,CREATE_DATE          ")
        stbSQL.AppendLine("    ,CREATE_USER          ")
        stbSQL.AppendLine("    ,UPDATE_DATE          ")
        stbSQL.AppendLine("    ,UPDATE_USER          ")

        For i As Integer = 1 To 30 Step 1
            stbSQL.AppendLine("    ,EXC_IMAGE_KEY" & i.ToString("00"))
        Next

        stbSQL.AppendLine(") VALUES (                ")
        stbSQL.AppendLine("     __IMAGE_ID__         ")
        stbSQL.AppendLine("    ,__RECEIPT_ID__       ")
        stbSQL.AppendLine("    ,'__IMAGE_STATUS__'   ")
        stbSQL.AppendLine("    ,'__IMAGE_FILE_NAME__'")
        stbSQL.AppendLine("    ,'__IMAGE_FILE_PATH__'")
        stbSQL.AppendLine("    ,'__SLIP_DEFINE_ID__' ")
        stbSQL.AppendLine("    ,'__BUSINESS_DATE__'  ")
        stbSQL.AppendLine("    ,'__PRIORITY__'       ")
        stbSQL.AppendLine("    ,'__EXC_IMAGE_NO__'   ")
        stbSQL.AppendLine("    ,'__EXC_SUBJECT_NO__' ")
        stbSQL.AppendLine("    ,'0'                  ")
        stbSQL.AppendLine("    ,SYSDATE              ")
        stbSQL.AppendLine("    ,'ReceiptTake'        ")
        stbSQL.AppendLine("    ,SYSDATE              ")
        stbSQL.AppendLine("    ,'ReceiptTake'        ")

        For i As Integer = 8 To 37 Step 1
            stbSQL.AppendLine("    ,'" & strItem(i) & "'")
        Next

        stbSQL.AppendLine(")                         ")

        stbSQL.Replace("__IMAGE_ID__", strImageID)
        stbSQL.Replace("__RECEIPT_ID__", strReceiptID)
        stbSQL.Replace("__IMAGE_STATUS__", strImageStatus)
        stbSQL.Replace("__IMAGE_FILE_NAME__", Path.GetFileName(strItem(3)))
        stbSQL.Replace("__IMAGE_FILE_PATH__", Path.GetDirectoryName(strItem(3)))
        stbSQL.Replace("__SLIP_DEFINE_ID__", strItem(5))
        stbSQL.Replace("__BUSINESS_DATE__", strItem(4))
        stbSQL.Replace("__PRIORITY__", strPriority)
        stbSQL.Replace("__EXC_IMAGE_NO__", strItem(2))
        stbSQL.Replace("__EXC_SUBJECT_NO__", strItem(7))

        ' 作成したSQLを実行してイメージテーブルに１件登録します。
        Dim intRet As Integer = mobjCommonDB.DB_ExecuteNonQuery(stbSQL.ToString)

    End Sub
#End Region

#Region "イメージ履歴登録"
    Private Sub InsertImageHistory(ByVal strImageID As String, ByVal strImageStatusas As String)

        Dim stbInsertSQL As New System.Text.StringBuilder(String.Empty)

        ' イメージ状態履歴登録用SQLを作成します。
        stbInsertSQL.AppendLine("INSERT INTO T_JJ_IMAGE_HISTORY (")
        stbInsertSQL.AppendLine("     IMAGE_ID")
        stbInsertSQL.AppendLine("    ,IMAGE_STATUS")
        stbInsertSQL.AppendLine("    ,CREATE_DATE")
        stbInsertSQL.AppendLine("    ,CREATE_USER")
        stbInsertSQL.AppendLine(") VALUES (")
        stbInsertSQL.AppendLine("     :ImageID")
        stbInsertSQL.AppendLine("    ,:OutStatus")
        stbInsertSQL.AppendLine("    ,SYSTIMESTAMP")
        stbInsertSQL.AppendLine("    ,'ReceiptTake'")
        stbInsertSQL.AppendLine(")")

        ' イメージ状態履歴登録用パラメータ宣言
        Dim oraInsertParam(1) As OracleParameter
        oraInsertParam(0) = New OracleParameter("ImageID", OracleDbType.Decimal)
        oraInsertParam(0).Value = Convert.ToInt64(strImageID)
        oraInsertParam(1) = New OracleParameter("OutStatus", OracleDbType.Char)
        oraInsertParam(1).Value = strImageStatusas

        ' イメージ状態履歴を登録します。
        Dim intInsertRet As Integer = MyBase.mobjCommonDB.DB_ExecuteNonQuery(stbInsertSQL.ToString, oraInsertParam)
        If Not intInsertRet = 1 Then
            Throw New Exception("イメージ状態履歴の登録に失敗しました。")
        End If

    End Sub
#End Region

#Region "受付テーブルの登録"
    Private Sub InsertReceipt(ByVal strReceiptID As String, _
                              ByVal intImageCount As Integer, _
                              ByVal drPlan As DataRow)

        Dim strCount As String = Convert.ToString(drPlan.Item("RECEIPT_COUNT"))
        Dim strReceiptDate As String = mstrFolderDateTime.Substring(0, 8) & Convert.ToString(drPlan.Item("RECEIPT_TIME"))

        ' 受付テーブル登録用のSQLを作成します。
        Dim stbSQL As New StringBuilder(String.Empty)
        stbSQL.AppendLine("INSERT INTO T_JJ_RECEIPT (   ")
        stbSQL.AppendLine("     RECEIPT_ID              ")
        stbSQL.AppendLine("    ,RECEIPT_STATUS          ")
        stbSQL.AppendLine("    ,IMAGE_COUNT             ")
        stbSQL.AppendLine("    ,RECEIPT_DATE            ")
        stbSQL.AppendLine("    ,RECEIPT_COUNT           ")
        stbSQL.AppendLine("    ,DELIVERY_PLAN_TIME      ")
        stbSQL.AppendLine("    ,RECEIPT_DATE_REAL       ")
        stbSQL.AppendLine("    ,DELETE_FLG              ")
        stbSQL.AppendLine("    ,CREATE_DATE             ")
        stbSQL.AppendLine("    ,CREATE_USER             ")
        stbSQL.AppendLine("    ,UPDATE_DATE             ")
        stbSQL.AppendLine("    ,UPDATE_USER             ")
        stbSQL.AppendLine(") VALUES (                   ")
        stbSQL.AppendLine("      __RECEIPT_ID__         ")
        stbSQL.AppendLine("    ,'__RECEIPT_STATUS__'    ")
        stbSQL.AppendLine("    , __IMAGE_COUNT__        ")
        stbSQL.AppendLine("    ,TO_DATE('__RECEIPT_DATE__', 'YYYYMMDDHH24MISS')")
        stbSQL.AppendLine("    , __RECEIPT_COUNT__      ")
        stbSQL.AppendLine(("    ,'" & Me.GetDeliveryDate(drPlan) & "'"))
        stbSQL.AppendLine("    ,TO_DATE('__RECEIPT_DATE_REAL__', 'YYYYMMDDHH24MISS')")
        stbSQL.AppendLine("    ,'0'                     ")
        stbSQL.AppendLine("    ,SYSDATE                 ")
        stbSQL.AppendLine("    ,'ReceiptTake'           ")
        stbSQL.AppendLine("    ,SYSDATE                 ")
        stbSQL.AppendLine("    ,'ReceiptTake'           ")
        stbSQL.AppendLine(")                            ")

        stbSQL.Replace("__RECEIPT_ID__", strReceiptID)
        stbSQL.Replace("__RECEIPT_STATUS__", mdicConfig("OUTPUT_RECEIPT_STATUS"))
        stbSQL.Replace("__IMAGE_COUNT__", intImageCount.ToString)
        stbSQL.Replace("__RECEIPT_DATE__", strReceiptDate)
        stbSQL.Replace("__RECEIPT_COUNT__", strCount)
        stbSQL.Replace("__RECEIPT_DATE_REAL__", mstrFolderDateTime)

        ' 作成したSQLを実行して受付テーブルに１件登録します。
        Dim intRet As Integer = mobjCommonDB.DB_ExecuteNonQuery(stbSQL.ToString)

    End Sub
#End Region

#Region "受付履歴登録"
    Private Sub InsertReceiptHistory(ByVal strReceiptID As String)

        Dim stbInsertSQL As New System.Text.StringBuilder(String.Empty)

        ' 受付状態履歴登録用SQLを作成します。
        stbInsertSQL.AppendLine("INSERT INTO T_JJ_RECEIPT_HISTORY (")
        stbInsertSQL.AppendLine("     RECEIPT_ID")
        stbInsertSQL.AppendLine("    ,RECEIPT_STATUS")
        stbInsertSQL.AppendLine("    ,CREATE_DATE")
        stbInsertSQL.AppendLine("    ,CREATE_USER")
        stbInsertSQL.AppendLine(") VALUES (")
        stbInsertSQL.AppendLine("     :ReceiptID")
        stbInsertSQL.AppendLine("    ,:OutStatus")
        stbInsertSQL.AppendLine("    ,SYSTIMESTAMP")
        stbInsertSQL.AppendLine("    ,'ReceiptTake'")
        stbInsertSQL.AppendLine(")")

        ' 受付状態履歴登録用パラメータ宣言
        Dim oraInsertParam(1) As OracleParameter
        oraInsertParam(0) = New OracleParameter("ReceiptID", OracleDbType.Decimal)
        oraInsertParam(0).Value = Convert.ToInt64(strReceiptID)
        oraInsertParam(1) = New OracleParameter("OutStatus", OracleDbType.Char)
        oraInsertParam(1).Value = mdicConfig("OUTPUT_RECEIPT_STATUS")

        ' 受付状態履歴を登録します。
        Dim intInsertRet As Integer = MyBase.mobjCommonDB.DB_ExecuteNonQuery(stbInsertSQL.ToString, oraInsertParam)
        If Not intInsertRet = 1 Then
            Throw New Exception("受付状態履歴の登録に失敗しました。")
        End If

    End Sub
#End Region

#Region "納品予定日の算出"
    Private Function GetDeliveryDate(drPlan As DataRow) As String
        Dim strDate As String = mstrFolderDateTime.Substring(0, 8)
        Dim intDays As Integer = Convert.ToInt32(drPlan.Item("DELIVERY_DAYS"))
        If intDays > 0 Then
            Dim stbSQL As New StringBuilder("SELECT MIN(YYYYMMDD) FROM M_CM_HOLIDAY WHERE HOLIDAY = '0' AND YYYYMMDD > '%DATE%'")
            stbSQL.Replace("%DATE%", strDate)
            Dim dt As DataTable = mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)
            strDate = Convert.ToString(dt.Rows(0).Item(0))
        End If

        Dim strDlvDate As String = strDate & Convert.ToString(drPlan.Item("DELIVERY_PLAN"))

        'Dim stbSQL As New StringBuilder("SELECT TO_CHAR(SYSDATE,'YYYYMMDDHH24MI') FROM DUAL")
        'Dim dt As DataTable = mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)
        'Dim strDate As String = Convert.ToString(dt.Rows(0).Item(0))
        'Dim strYMD As String = strDate.Substring(0, 8)
        'Dim strTime As String = strDate.Substring(8, 4)
        'If strTime > mdicConfig("WORK_END_TIME") Then
        '    strTime = mdicConfig("WORK_START_TIME")
        '    stbSQL.Length = 0
        '    stbSQL.AppendLine("SELECT MIN(YYYYMMDD) FROM M_CM_HOLIDAY WHERE HOLIDAY = '0' AND YYYYMMDD > '%DATE%'")
        '    stbSQL.Replace("%DATE%", strYMD)
        '    dt = mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)
        '    strYMD = Convert.ToString(dt.Rows(0).Item(0))
        'End If

        'Dim intYea As Integer = Convert.ToInt32(strYMD.Substring(0, 4))
        'Dim intMon As Integer = Convert.ToInt32(strYMD.Substring(4, 2))
        'Dim intDay As Integer = Convert.ToInt32(strYMD.Substring(6, 2))
        'Dim intHou As Integer = Convert.ToInt32(strTime.Substring(0, 2))
        'Dim intMin As Integer = Convert.ToInt32(strTime.Substring(2, 2))

        'Dim datDlvDate As New Date(intYea, intMon, intDay, intHou, intMin, 0)
        'datDlvDate = datDlvDate.AddMinutes(Convert.ToDouble(mdicConfig("DELIVERY_PLAN")))

        'Dim strDlvDate As String = datDlvDate.ToString("yyyyMMddHHmm")

        Return strDlvDate
    End Function
#End Region

#Region "OCR結果ファイルの取込"
    Private Function ReceiveOcrResult(strFolder As String)
        Try
            Dim strFilePath As String = Path.Combine(strFolder, mdicConfig("OCR_FILE_NAME"))
            Dim intRecordCount As Integer = 0
            Using sr As New StreamReader(strFilePath, Encoding.GetEncoding("shift-jis"))
                Do Until sr.EndOfStream
                    Dim strLine As String = sr.ReadLine
                    Dim strItems() As String = strLine.Split(",")
                    Dim lst As New List(Of String)
                    For i As Integer = 0 To strItems.Length - 1 Step 1
                        Dim strVal As String = strItems(i)
                        If strVal.StartsWith("""") Then
                            strVal = strVal.Substring(1, strVal.Length - 2)
                        End If
                        lst.Add(strVal)
                    Next
                    Call InsertOcrResult(lst)
                    intRecordCount += 1
                Loop
            End Using

            Return intRecordCount
        Catch ex As Exception
            MyBase.WriteLog("処理不能なエラーを検知しました。(OCR結果取込)", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.ToString, EventLogEntryType.Error)
            Return -1
        End Try
    End Function
#End Region

#Region "OCR結果ファイルの取込"
    Private Function MakeOcrResult(dicOcr As Dictionary(Of String, Integer))
        Try
            Dim intRecordCount As Integer = 0
            For Each strKey As String In dicOcr.Keys
                Dim lst As New List(Of String)
                For i As Integer = 0 To dicOcr(strKey) - 1 Step 1
                    If i = 3 Then
                        lst.Add(strKey.Replace("-", String.Empty))
                    Else
                        lst.Add(String.Empty)
                    End If
                Next
                Call InsertOcrResult(lst)
                intRecordCount += 1
            Next

            Return intRecordCount
        Catch ex As Exception
            MyBase.WriteLog("処理不能なエラーを検知しました。(擬似OCR結果登録)", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.ToString, EventLogEntryType.Error)
            Return -1
        End Try
    End Function
#End Region

#Region "OCR結果中間テーブルの登録処理"
    Private Sub InsertOcrResult(lst As List(Of String))
        Dim stbSQL As New StringBuilder(String.Empty)
        Try
            stbSQL.AppendLine("INSERT INTO T_JJ_OCR_RESULT (")
            stbSQL.AppendLine("    DELETE_FLG")
            stbSQL.AppendLine("   ,CREATE_USER")
            stbSQL.AppendLine("   ,CREATE_DATE")
            stbSQL.AppendLine("   ,UPDATE_USER")
            stbSQL.AppendLine("   ,UPDATE_DATE")
            For i As Integer = 1 To lst.Count Step 1
                stbSQL.AppendLine("   ,ITEM_" & i.ToString("000"))
            Next
            stbSQL.AppendLine("   ,ITEM_" & (lst.Count + 1).ToString("000"))
            stbSQL.AppendLine(") VALUES (")
            stbSQL.AppendLine("    '0'")
            stbSQL.AppendLine("   ,'ReceiptTake'")
            stbSQL.AppendLine("   ,SYSDATE")
            stbSQL.AppendLine("   ,'ReceiptTake'")
            stbSQL.AppendLine("   ,SYSDATE")
            For i As Integer = 1 To lst.Count Step 1
                stbSQL.AppendLine("   ,'" & lst(i - 1) & "'")
            Next
            stbSQL.AppendLine("   ,'#END'")
            stbSQL.AppendLine(")")

            ' 作成したSQLを実行してテーブルに１件登録します。
            Dim intRet As Integer = mobjCommonDB.DB_ExecuteNonQuery(stbSQL.ToString)

        Catch ex As Exception
            CommonLog.WriteLog("OCR結果中間テーブルの登録に失敗しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(stbSQL.ToString, EventLogEntryType.Error)
            Throw ex
        End Try
    End Sub
#End Region

#Region "納品時間マスタの取得"
    Private Function GetDeliveryPlan(strDate As String) As DataRow
        Dim stbSQL As New StringBuilder(String.Empty)
        Try
            Dim strHHMM As String = strDate.Substring(8, 4)
            stbSQL.AppendLine("SELECT")
            stbSQL.AppendLine("    *")
            stbSQL.AppendLine("FROM")
            stbSQL.AppendLine("    M_CM_DELIVERY_PLAN")
            stbSQL.AppendLine("WHERE")
            stbSQL.AppendLine("    RECEIPT_TIME_START <= '%DATE%'")
            stbSQL.AppendLine("    AND")
            stbSQL.AppendLine("    RECEIPT_TIME_END   >= '%DATE%'")
            stbSQL.Replace("%DATE%", strHHMM)

            Dim dt As DataTable = mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)
            If dt Is Nothing OrElse dt.Rows.Count <> 1 Then
                Return Nothing
            End If

            Return dt.Rows(0)

        Catch ex As Exception
            CommonLog.WriteLog("OCR結果中間テーブルの登録に失敗しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(stbSQL.ToString, EventLogEntryType.Error)
            Throw ex
        End Try
    End Function
#End Region

#Region "イメージID生成用の情報を取得"
    Private Function ReadyToImageID(intDate As Integer, intCount As Integer) As Integer
        Dim stbSQL As New StringBuilder(String.Empty)
        Dim intSeq As Integer = 0
        Try

            ' イメージIDテーブルの排他を行います
            ' 本件のイメージIDは日付連番(1～3桁)＋受付回数(2桁)＋当日の連番(5桁)で作成されます。
            ' 日付連番は元日を1として閏年を考慮して１２月３１日を366とした連番とします
            ' 受付回数は01～10、51の何れかをとります
            ' 例えば１月１日の５回目の最初のイメージIDは　10500001となります
            stbSQL.Length = 0
            stbSQL.AppendLine("SELECT * FROM T_JJ_IMAGE_ID WHERE DATE_NUM = %DATE% AND RECEIVE_COUNT = %COUNT% FOR UPDATE NOWAIT")
            stbSQL.Replace("%DATE%", intDate.ToString)
            stbSQL.Replace("%COUNT%", intCount.ToString)
            Dim dt As DataTable = Nothing
            Do
                Try
                    dt = mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)
                    Exit Do
                Catch ex As Oracle.DataAccess.Client.OracleException
                    If ex.Number = 54 Then
                        System.Threading.Thread.Sleep(1000)
                        Continue Do
                    Else
                        Throw ex
                    End If
                Catch ex As Exception
                    Throw ex
                End Try
            Loop

            ' レコードが存在しなかった場合は登録します
            If dt Is Nothing OrElse dt.Rows.Count = 0 Then
                stbSQL.Length = 0
                stbSQL.AppendLine("INSERT INTO T_JJ_IMAGE_ID ( ")
                stbSQL.AppendLine("     DATE_NUM    ")
                stbSQL.AppendLine("    ,RECEIVE_COUNT")
                stbSQL.AppendLine("    ,IMAGE_ID_NUM")
                stbSQL.AppendLine("    ,DELETE_FLG  ")
                stbSQL.AppendLine("    ,CREATE_DATE ")
                stbSQL.AppendLine("    ,CREATE_USER ")
                stbSQL.AppendLine("    ,UPDATE_DATE ")
                stbSQL.AppendLine("    ,UPDATE_USER ")
                stbSQL.AppendLine(") VALUES ( ")
                stbSQL.AppendLine("    " & intDate.ToString)
                stbSQL.AppendLine("    ," & intCount.ToString)
                stbSQL.AppendLine("    ,0")
                stbSQL.AppendLine("    ,'0'")
                stbSQL.AppendLine("    ,SYSDATE")
                stbSQL.AppendLine("    ,'ReceiptTake'")
                stbSQL.AppendLine("    ,SYSDATE")
                stbSQL.AppendLine("    ,'ReceiptTake'")
                stbSQL.AppendLine(")")
                mobjCommonDB.DB_ExecuteNonQuery(stbSQL.ToString)
                intSeq = 0
            Else
                intSeq = Convert.ToInt32(dt.Rows(0).Item("IMAGE_ID_NUM"))
            End If

            Return intSeq

        Catch ex As Exception
            CommonLog.WriteLog("イメージID生成の準備に失敗しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(stbSQL.ToString, EventLogEntryType.Error)
            Throw ex
        End Try
    End Function
#End Region

#Region "イメージID生成用の情報を更新"
    Private Sub UpdateImageID()
        Dim stbSQL As New StringBuilder(String.Empty)
        Try
            stbSQL.AppendLine("UPDATE T_JJ_IMAGE_ID")
            stbSQL.AppendLine("SET")
            stbSQL.AppendLine("    IMAGE_ID_NUM = " & mintImageIdSeq.ToString)
            stbSQL.AppendLine("   ,UPDATE_DATE  = SYSDATE")
            stbSQL.AppendLine("   ,UPDATE_USER  = 'ReceiptTake'")
            stbSQL.AppendLine("WHERE")
            stbSQL.AppendLine("    DATE_NUM = " & mintDateNumber.ToString)
            stbSQL.AppendLine("    AND")
            stbSQL.AppendLine("    RECEIVE_COUNT =" & mintReceiveCount.ToString)

            mobjCommonDB.DB_ExecuteNonQuery(stbSQL.ToString)
        Catch ex As Exception
            CommonLog.WriteLog("イメージID情報の更新に失敗しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(stbSQL.ToString, EventLogEntryType.Error)
            Throw ex
        End Try
    End Sub
#End Region

End Class

