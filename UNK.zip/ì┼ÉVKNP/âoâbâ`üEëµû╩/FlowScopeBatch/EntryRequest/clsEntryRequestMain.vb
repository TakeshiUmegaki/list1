﻿Imports CommonSystem
Imports CommonBase
Imports System
Imports System.IO
Imports System.Text
Imports Oracle.DataAccess.Client


Public Class clsRequestEntry
    Inherits clsBatchBase

#Region "共通変数"

    ''' <summary>
    ''' 自端末処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Shared mainProc As clsRequestEntry

#End Region

#Region "外部定義（config情報）取得用定数"

    ' 本クラスで利用する定数を記述します。

    ''' <summary>
    ''' 依頼する最大イメージ数
    ''' </summary>
    ''' <remarks></remarks>
    Private Const CONF_MAX_ENTRY_COUNT As String = "MAX_ENTRY_COUNT"

    ''' <summary>
    ''' １フォルダで発行する依頼イメージ上限数
    ''' </summary>
    ''' <remarks></remarks>
    Private Const CONF_ENTRY_UNIT_COUNT As String = "ENTRY_UNIT_COUNT"

    ''' <summary>
    ''' １回のDB抽出で取得するイメージ上限数
    ''' </summary>
    ''' <remarks></remarks>
    Private Const CONF_MAX_SELECT_COUNT As String = "MAX_SELECT_COUNT"


    ''' <summary>
    ''' 抽出対象イメージ状態
    ''' </summary>
    ''' <remarks></remarks>
    Private Const CONF_INPUT_IMAGE_STATUS As String = "INPUT_IMAGE_STATUS"


    ''' <summary>
    ''' 抽出対象TARGET_COMPANY
    ''' </summary>
    ''' <remarks></remarks>
    Private Const CONF_INPUT_TARGET_COMPANY As String = "INPUT_TARGET_COMPANY"




    ''' <summary>
    ''' 依頼ファイル出力先ルートフォルダ
    ''' </summary>
    ''' <remarks></remarks>
    Private Const CONF_REQUEST_PATH As String = "REQUEST_PATH"

    ''' <summary>
    ''' 依頼ファイルヘッダレコード ファイルID
    ''' </summary>
    ''' <remarks></remarks>
    Private Const CONF_FILE_ID As String = "FILE_ID"

    ''' <summary>
    ''' トリガーファイル名
    ''' </summary>
    ''' <remarks></remarks>
    Private Const CONF_TRIGGER_FILE As String = "TRIGGER_FILE"

    ''' <summary>
    ''' 依頼ファイル作成後のT_JJ_IMAGEの状態
    ''' </summary>
    ''' <remarks></remarks>
    Private Const CONF_OUTPUT_IMAGE_STATUS As String = "OUTPUT_IMAGE_STATUS"

    ''' <summary>
    ''' 依頼ファイル作成後のT_RECEIPT_IMAGEの状態
    ''' </summary>
    ''' <remarks></remarks>
    Private Const CONF_OUTPUT_PROC_FLG As String = "OUTPUT_PROC_FLG"

    ''' <summary>
    ''' 依頼ファイル作成後のT_RECEIPT_MNGの状態
    ''' </summary>
    ''' <remarks></remarks>
    Private Const CONF_OUTPUT_ALL9_STATUS As String = "OUTPUT_ALL9_STATUS"

#End Region

#Region "メイン処理[Main]"

    ''' ======================================================================
    ''' メソッド名：Main
    ''' <summary>
    ''' メイン処理
    ''' </summary>
    ''' <remarks></remarks>
    ''' ======================================================================
    Shared Function Main(ByVal CmdArgs() As String) As Integer

        mainProc = New clsRequestEntry

        ' 処理の戻り値を返却
        Return mainProc.Run()

    End Function

#End Region

#Region "バッチ処理本体"
    Protected Overrides Sub Execute()
        Try

            ' 処理開始前に依頼最大件数に達していたら処理を終了します。
            If IsMaxRecordCount() Then
                Exit Sub
            End If

            ' １フォルダあたりの依頼可能な最大イメージ数を取得します。
            Dim intEntryCount As Integer = Convert.ToInt32(mdicConfig(CONF_ENTRY_UNIT_COUNT))

            Do

                ' 依頼対象となるイメージデータを取得します。
                Dim dtbAllImage As DataTable = GetImageData()
                If dtbAllImage Is Nothing OrElse dtbAllImage.Rows.Count = 0 Then
                    '依頼対象となるデータが取得できない場合は処理を終了します。
                    Exit Do
                End If

                ' 一部の帳票IDを変換します。
                Call ConvertSlipDefineID(dtbAllImage)

                ' 優先度でテーブルを分割します。
                Dim dtbImages As List(Of DataTable) = DivideTable(dtbAllImage)

                ' 優先度で分割されたテーブルを１つずつ処理します。
                For Each dtbImage As DataTable In dtbImages

                    ' 最大依頼イメージ数単位でループをまわしながらエントリ依頼ファイルを作成します。
                    For intIndex As Integer = 0 To dtbImage.Rows.Count - 1 Step intEntryCount

                        ' 依頼最大件数に達したら処理を終了します。
                        If IsMaxRecordCount() Then
                            Exit Do
                        End If

                        'エントリ依頼出力フォルダPathを生成します。
                        Dim strRequestFolder As String = CreateRequestDir(dtbImage.Rows(intIndex))

                        'DBトランザクションを開始します。
                        MyBase.mobjCommonDB.DB_Transaction()
                        Try

                            ' エントリ依頼ファイルを作成します。
                            Call CreateEntryRequest(strRequestFolder, dtbImage, intIndex, intEntryCount)

                            ' トリガーファイルを作成します。
                            Call CreateTrigerFile(strRequestFolder)

                            ' DBのイメージ情報を更新します。
                            Call UpdateImage(dtbImage, intIndex, intEntryCount)

                            ' DBの依頼件数を更新します。
                            Call UpdateEntReqManage(dtbImage, intIndex, intEntryCount)

                            'DBトランザクションを完了します。
                            MyBase.mobjCommonDB.DB_Commit()

                        Catch ex As Exception

                            'DBトランザクションをまき戻します。
                            MyBase.mobjCommonDB.DB_Rollback()
                            '生成していたエントリ依頼出力フォルダを削除します。
                            Directory.Delete(strRequestFolder, True)
                            'エラー内容をログに出力します。
                            WriteLog(ex.ToString, EventLogEntryType.Error)

                            Throw New Exception("エントリファイル作成中にエラーを検出しました。")

                        End Try

                    Next

                Next

            Loop

        Catch ex As Exception

            MyBase.WriteLog("エントリ依頼作成中にエラーを検出しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.ToString, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)

        Finally

        End Try
    End Sub
#End Region

#Region "依頼件数チェック"
    ''' ======================================================================
    ''' メソッド名：IsMaxRecordCount
    ''' <summary>
    ''' 依頼件数チェック
    ''' </summary>
    ''' <remarks></remarks>
    ''' ======================================================================
    Private Function IsMaxRecordCount() As Boolean

        ' 現在の依頼中総件数を取得するためのSQLを作成します。
        Dim stbSQL As New StringBuilder(String.Empty)
        stbSQL.AppendLine("SELECT")
        stbSQL.AppendLine("    REQUEST_COUNT")
        stbSQL.AppendLine("FROM")
        stbSQL.AppendLine("    T_JJ_ENT_REQ_MANAGE")

        ' OracleDBに作成したSQLを送信して結果を得ます。
        Dim dtbReq As DataTable = MyBase.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)

        ' 取得した結果から現在の依頼中件数を取得します。
        Dim intNow As Integer = Convert.ToInt32(dtbReq.Rows(0).Item("REQUEST_COUNT"))

        ' コンフィグで指定された最大依頼中件数を取得します。
        Dim intMax As Integer = Convert.ToInt32(mdicConfig(CONF_MAX_ENTRY_COUNT))

        '件数を比較して依頼中件数が最大依頼中件数を超えていた場合はFalseを返します。
        If intNow < intMax Then
            Return False
        End If

        Return True

    End Function
#End Region

#Region "依頼対象イメージデータの取得"
    ''' ======================================================================
    ''' メソッド名：GetImageData
    ''' <summary>
    ''' 依頼対象イメージデータの取得
    ''' </summary>
    ''' <remarks></remarks>
    ''' ======================================================================
    Private Function GetImageData() As DataTable

        ' 依頼対象データを抽出するためのSQLを作成します。
        Dim stbSQL As New StringBuilder(String.Empty)
        stbSQL.AppendLine("SELECT")
        stbSQL.AppendLine("    A.*")
        stbSQL.AppendLine("FROM")
        stbSQL.AppendLine("    (")
        stbSQL.AppendLine("        SELECT")
        stbSQL.AppendLine("             I.IMAGE_ID")
        stbSQL.AppendLine("            ,I.IMAGE_STATUS")
        stbSQL.AppendLine("            ,I.IMAGE_FILE_NAME")
        stbSQL.AppendLine("            ,I.IMAGE_FILE_PATH")
        stbSQL.AppendLine("            ,I.SLIP_DEFINE_ID")
        stbSQL.AppendLine("            ,I.PRIORITY")
        stbSQL.AppendLine("            ,I.DELETE_FLG")
        stbSQL.AppendLine("            ,I.BUSINESS_DATE")
        stbSQL.AppendLine("            ,I.EXC_SUBJECT_NO")
        stbSQL.AppendLine("            ,I.EXC_IMAGE_KEY09")
        stbSQL.AppendLine("            ,R.ITEM_001")
        stbSQL.AppendLine("            ,R.ITEM_002")
        stbSQL.AppendLine("        FROM")
        stbSQL.AppendLine("            T_JJ_IMAGE I")
        stbSQL.AppendLine("            LEFT JOIN T_JJ_OCR_RESULT R")
        stbSQL.AppendLine("                ON")
        stbSQL.AppendLine("                R.DELETE_FLG = 0")
        stbSQL.AppendLine("                AND")
        stbSQL.AppendLine("                R.ITEM_004 = REPLACE(I.EXC_SUBJECT_NO, '-')")
        stbSQL.AppendLine("        WHERE")
        stbSQL.AppendLine("            I.DELETE_FLG     = '0'")
        stbSQL.AppendLine("            AND")
        stbSQL.AppendLine("            I.IMAGE_STATUS   = '%I_STATUS%'")
        stbSQL.AppendLine("        ORDER BY")
        stbSQL.AppendLine("             I.PRIORITY")
        stbSQL.AppendLine("            ,I.SLIP_DEFINE_ID")
        stbSQL.AppendLine("            ,I.IMAGE_ID")
        stbSQL.AppendLine("    ) A")
        stbSQL.AppendLine("WHERE")
        stbSQL.AppendLine("    ROWNUM <= %RANK%")

        ' 作成したSQLの抽出条件部分をコンフィグから取得した値に置換します。
        stbSQL.Replace("%I_STATUS%", mdicConfig(CONF_INPUT_IMAGE_STATUS))
        stbSQL.Replace("%RANK%", mdicConfig(CONF_MAX_SELECT_COUNT))

        ' OracleDBに作成したSQLを送信して結果を得ます。
        Return MyBase.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)

    End Function
#End Region

#Region "優先順位毎のテーブル仕分け処理"
    ''' ======================================================================
    ''' メソッド名：DivideTable
    ''' <summary>
    ''' 優先順位毎のテーブル仕分け処理
    ''' </summary>
    ''' <param name="dtbImage">依頼対象データレコード</param>
    ''' <returns>仕分けの完了したテーブルのリスト</returns>
    ''' <remarks></remarks>
    ''' ======================================================================
    Private Function DivideTable(ByVal dtbImage As DataTable) As List(Of DataTable)

        ' テーブルリストの作成
        Dim dtbImages As New List(Of DataTable)

        ' 一つ前の優先度
        Dim strPrvPriority As String = String.Empty

        ' 一つ前の書類コード
        Dim strPrvDocument As String = String.Empty


        ' 優先度毎のデータテーブル
        Dim dtbNewImage As DataTable = Nothing


        Dim dtbSameImage As DataTable = Nothing     ' 同じイメージ名を持つ二つ目以降のデータ
        Dim hshSameImage As New Hashtable           ' イメージ名重複チェック用ハッシュ


        ' 依頼対象イメージデータを一件ずつ精査します。
        For Each dr As DataRow In dtbImage.Rows

            ' 優先度を取得します。
            Dim strNowPriority As String = Convert.ToString(dr.Item("PRIORITY"))
            ' 書類コードを取得します。
            Dim strNowDocument As String = Convert.ToString(dr.Item("SLIP_DEFINE_ID"))

            ' 一つ前の優先度、書類コードと異なる場合
            If Not strNowPriority.Equals(strPrvPriority) OrElse _
               Not strNowDocument.Equals(strPrvDocument) Then

                ' 同じイメージをもつ二つ目以降のデータがあるかチェックします。
                If Not dtbSameImage Is Nothing AndAlso dtbSameImage.Rows.Count > 0 Then

                    ' 二つ目以降のデータがある場合は自身を再帰的に呼び出してデータをリスト化します。
                    Dim subList As List(Of DataTable) = DivideTable(dtbSameImage)

                    ' リスト化されたデータをメインのリストの末尾に追加します。
                    For Each dtb As DataTable In subList
                        dtbImages.Add(dtb)
                    Next
                End If
                hshSameImage.Clear()            ' イメージ名重複チェック用ハッシュをリセット
                dtbSameImage = dtbImage.Clone   ' 重複データ格納領域をリセット


                ' 新しい優先度用のデータテーブルを作成してテーブルリストに追加します。
                dtbNewImage = dtbImage.Clone
                dtbImages.Add(dtbNewImage)


                ' 一つ前の優先度を最新の優先度で置換します。
                strPrvPriority = strNowPriority
                ' 一つ前の書類コードを最新の書類コードで置換します。
                strPrvDocument = strNowDocument

            End If


            Dim strImage As String = Convert.ToString(dr.Item("IMAGE_FILE_NAME"))
            If hshSameImage.ContainsKey(strImage) Then

                ' 既に登録されているイメージ名と同じイメージ名をもつデータの場合は別領域に記憶しておきます。
                Dim drwNew As DataRow = dtbSameImage.NewRow
                For Each cl As DataColumn In dtbSameImage.Columns
                    drwNew.Item(cl.ColumnName) = dr.Item(cl.ColumnName)
                Next
                dtbSameImage.Rows.Add(drwNew)

            Else

                ' イメージ名を重複チェック用ハッシュに登録します。
                hshSameImage.Add(strImage, dr)

                ' 現在の優先度のテーブルに依頼対象イメージを一件転送します。
                Dim drwNew As DataRow = dtbNewImage.NewRow
                For Each cl As DataColumn In dtbNewImage.Columns
                    drwNew.Item(cl.ColumnName) = dr.Item(cl.ColumnName)
                Next
                dtbNewImage.Rows.Add(drwNew)

            End If


        Next


        ' 同じイメージをもつ二つ目以降のデータがあるかチェックします。
        If Not dtbSameImage Is Nothing AndAlso dtbSameImage.Rows.Count > 0 Then

            ' 二つ目以降のデータがある場合は自身を再帰的に呼び出してデータを
            ' リスト化します。
            Dim subList As List(Of DataTable) = DivideTable(dtbSameImage)

            ' リスト化されたデータをメインのリストの末尾に追加します。
            For Each dtb As DataTable In subList
                dtbImages.Add(dtb)
            Next
        End If
        hshSameImage.Clear()            ' イメージ名重複チェック用ハッシュをリセット
        dtbSameImage = dtbImage.Clone   ' 重複データ格納領域をリセット


        ' 完成したテーブルリストを返します。
        Return dtbImages

    End Function
#End Region

#Region "エントリー依頼用ディレクトリ作成[CreateRequestDir]"
    ''' ======================================================================
    ''' メソッド名：CreateRequestDir
    ''' <summary>
    ''' エントリー依頼用ディレクトリ作成
    ''' </summary>
    ''' <param name="drwImage">依頼対象データレコード（パラレルKey取得用）</param>
    ''' <returns>生成したフォルダへのフルパス</returns>
    ''' <remarks></remarks>
    ''' ======================================================================
    Private Function CreateRequestDir(ByVal drwImage As DataRow) As String

        Dim strRequestDir As String
        For i As Integer = 0 To 1000

            ' 現在日付のフォルダを作成
            strRequestDir = Path.Combine(mdicConfig(CONF_REQUEST_PATH), Now.ToString("yyyyMMddHHmmss"))

            If Directory.Exists(strRequestDir) Then
                System.Threading.Thread.Sleep(1000)
                Continue For
            End If

            Try
                Directory.CreateDirectory(strRequestDir)
            Catch ex As IOException
                System.Threading.Thread.Sleep(1000)
                Continue For
            End Try

            ' 作成したディレクトリを返却
            Return strRequestDir

        Next

        ' ここまで来た場合、exception発行
        Throw New Exception("エントリ配信用ディレクトリの作成に失敗しました。")

    End Function

#End Region

#Region "エントリ依頼ファイルの作成"
    ''' ======================================================================
    ''' メソッド名：CreateEntryRequest
    ''' <summary>
    ''' エントリ依頼ファイルの作成
    ''' </summary>
    ''' <param name="strRequestPath">エントリ依頼ファイル出力先フォルダPath</param>
    ''' <param name="dtbImage">エントリ依頼対象イメージデータ</param>
    ''' <param name="intIndex">エントリ依頼対象イメージデータ内の依頼開始位置</param>
    ''' <param name="intEntryCount">最大依頼イメージ数</param>
    ''' <remarks>エントリ依頼ファイルを１件作成します。</remarks>
    ''' ======================================================================
    Private Sub CreateEntryRequest(ByVal strRequestPath As String, _
                                   ByVal dtbImage As DataTable, _
                                   ByVal intIndex As Integer, _
                                   ByVal intEntryCount As Integer)

        '現在のシステム日時を取得します。
        Dim datSendDate As Date = DateTime.Now

        Dim sbRequestRecord As New StringBuilder

        ' ヘッダーレコード作成
        sbRequestRecord.Append(getHeaderRecord(dtbImage.Rows(intIndex), datSendDate))

        ' 明細行作成
        Dim intRecordCount As Integer = 0
        For i As Integer = intIndex To (intIndex + intEntryCount - 1) Step 1

            If i >= dtbImage.Rows.Count Then
                Exit For
            End If

            ' 明細行作成
            sbRequestRecord.Append(getDetailRecord(dtbImage.Rows(i), intRecordCount + 1))

            intRecordCount += 1
        Next

        ' フッター行作成
        sbRequestRecord.Append(getFotterRecord(intRecordCount, datSendDate))

        ' ファイル作成
        Using sw As New StreamWriter(Path.Combine(strRequestPath, clsConst.CNST_DOWNLOAD_FILE), False, Encoding.GetEncoding(clsConst.CNST_ENCODING_SHIFT_JIS))
            ' 書き込み処理
            sw.Write(sbRequestRecord.ToString)
        End Using

    End Sub
#End Region

#Region "ヘッダーレコード作成[getHeaderRecord]"
    ''' ======================================================================
    ''' メソッド名：getHeaderRecord
    ''' <summary>
    ''' ヘッダーレコード作成
    ''' </summary>
    ''' <param name="drwImage">依頼対象イメージデータの先頭行データ</param>
    ''' <param name="datSendDate">システム日付</param>
    ''' <returns>作成したヘッダレコード</returns>
    ''' <remarks>エントリ依頼ファイルのヘッダレコード（レコード種別１～４）を作成します。</remarks>
    ''' ======================================================================
    Private Function getHeaderRecord(ByVal drwImage As DataRow, ByVal datSendDate As Date) As String

        Dim sbRet As New StringBuilder

        ' レコード種別
        sbRet.Append("1")
        sbRet.Append(",")
        ' 予備
        sbRet.Append("")
        sbRet.Append(",")
        ' 予備
        sbRet.Append("")
        sbRet.Append(",")
        ' 送信日時
        sbRet.Append(datSendDate.ToString("yyyyMMdd HHmmss"))
        sbRet.Append(",")
        ' ファイルID
        sbRet.Append(mdicConfig(CONF_FILE_ID))
        sbRet.AppendLine("")


        ' レコード種別
        sbRet.Append("2")
        sbRet.Append(",")
        ' 優先度フラグ
        sbRet.Append(drwImage.Item("PRIORITY").ToString)
        sbRet.Append(",")
        ' 処理日時
        sbRet.Append(datSendDate.ToString("yyyyMMdd"))
        sbRet.Append(",")
        '連係情報１ 抽出更新コード
        sbRet.Append("")
        sbRet.Append(",")
        '連携情報２
        sbRet.Append("")
        sbRet.Append(",")
        '連係情報３
        sbRet.Append("")
        sbRet.Append(",")
        '連係情報４
        sbRet.Append("")
        sbRet.Append(",")
        '連係情報５
        sbRet.Append("")
        sbRet.AppendLine("")

        ' レコード種別
        sbRet.Append("4")
        sbRet.Append(",")
        ' 予備
        sbRet.Append("")
        sbRet.Append(",")
        ' 予備
        sbRet.Append("")
        sbRet.Append(",")
        ' 予備
        sbRet.Append("")
        sbRet.AppendLine("")

        Return sbRet.ToString

    End Function
#End Region

#Region "明細レコード作成[getDetailRecord]"
    ''' ======================================================================
    ''' メソッド名：getDetailRecord
    ''' <summary>
    ''' 明細レコード作成
    ''' </summary>
    ''' <param name="drwImage">依頼対象イメージデータ</param>
    ''' <returns>作成した明細レコード</returns>
    ''' <remarks></remarks>
    ''' ======================================================================
    Private Function getDetailRecord(ByVal drwImage As DataRow, ByVal intSeq As Integer) As String

        Dim sbRet As New StringBuilder

        ' レコード種別
        sbRet.Append("5")
        sbRet.Append(",")
        ' 通し番号
        sbRet.Append(String.Format("{0:D9}", intSeq))
        sbRet.Append(",")
        ' 受付番号
        sbRet.Append(Convert.ToInt64(drwImage.Item("IMAGE_ID")).ToString("000000000000000"))
        sbRet.Append(",")
        ' イメージファイルパス
        Dim strImageFilePath As String = String.Empty
        strImageFilePath = Convert.ToString(drwImage.Item("IMAGE_FILE_PATH"))

        ' イメージファイル名を付加
        strImageFilePath = Path.Combine(strImageFilePath, Convert.ToString(drwImage.Item("IMAGE_FILE_NAME")))
        sbRet.Append(strImageFilePath.Trim)
        sbRet.Append(",")
        ' 業務日付
        sbRet.Append(Convert.ToString(drwImage.Item("BUSINESS_DATE")).Substring(0, 8))
        sbRet.Append(",")
        ' 書類コード
        sbRet.Append(Convert.ToString(drwImage.Item("SLIP_DEFINE_ID")))
        sbRet.Append(",")
        ' 予備
        sbRet.Append("01")
        sbRet.Append(",")
        ' 案件ID（今回は１案件１イメージなのでイメージIDを設定）
        sbRet.Append(Convert.ToString(drwImage.Item("IMAGE_ID")).PadLeft(15, "0"))
        sbRet.AppendLine("")

        Return sbRet.ToString

    End Function

#End Region

#Region "フッターレコード作成[getFotterRecord]"

    ''' ======================================================================
    ''' メソッド名：getFotterRecord
    ''' <summary>
    ''' フッターレコード作成
    ''' </summary>
    ''' <remarks></remarks>
    ''' ======================================================================
    Private Function getFotterRecord(ByVal intCreateCount As Integer, ByVal datSendDate As Date) As String

        Dim sbRet As New StringBuilder

        ' レコード種別
        sbRet.Append("9")
        sbRet.Append(",")
        ' データ件数
        sbRet.Append(intCreateCount.ToString)
        sbRet.Append(",")
        ' 処理結果メッセージ(送信時のシステム日時)
        sbRet.Append(datSendDate.ToString("yyyyMMdd HHmmss"))
        sbRet.AppendLine("")

        Return sbRet.ToString

    End Function
#End Region

#Region "トリガーファイル作成[CreateTrigerFile]"
    ''' ======================================================================
    ''' メソッド名：CreateTrigerFile
    ''' <summary>
    ''' トリガーファイル作成
    ''' </summary>
    ''' <param name="strRequestDir">作成ディレクトリ</param>
    ''' <remarks></remarks>
    ''' ======================================================================
    Private Sub CreateTrigerFile(ByVal strRequestDir As String)

        Dim strTrigger As String = mdicConfig(CONF_TRIGGER_FILE)

        ' トリガーファイル作成
        Using fs As FileStream = File.Create(Path.Combine(strRequestDir, strTrigger))
            If Not (fs Is Nothing) Then
                fs.Close()
            End If
        End Using

    End Sub
#End Region

#Region "イメージデータの状態更新"
    ''' ======================================================================
    ''' メソッド名：UpdateImage
    ''' <summary>
    ''' イメージデータ更新処理
    ''' </summary>
    ''' <param name="dtbImage">エントリ依頼対象イメージデータ</param>
    ''' <param name="intIndex">エントリ依頼対象イメージデータ内の依頼開始位置</param>
    ''' <param name="intEntryCount">最大依頼イメージ数</param>
    ''' <remarks></remarks>
    ''' ======================================================================
    Private Sub UpdateImage(ByVal dtbImage As DataTable, _
                            ByVal intIndex As Integer, _
                            ByVal intEntryCount As Integer)

        Dim stbUpdateSQL As New System.Text.StringBuilder(String.Empty)
        Dim stbMngUpdSQL As New System.Text.StringBuilder(String.Empty)
        Dim stbInsertSQL As New System.Text.StringBuilder(String.Empty)

        Try

            ' イメージ状態更新用SQLを作成します。
            stbUpdateSQL.AppendLine("UPDATE")
            stbUpdateSQL.AppendLine("  T_JJ_IMAGE")
            stbUpdateSQL.AppendLine("SET")
            stbUpdateSQL.AppendLine("   IMAGE_STATUS    =:Status ")
            stbUpdateSQL.AppendLine("  ,EXC_IMAGE_KEY09 =:Exc09 ")
            stbUpdateSQL.AppendLine("  ,UPDATE_USER    = 'EntryRequest'")
            stbUpdateSQL.AppendLine("  ,UPDATE_DATE    = SYSDATE")
            stbUpdateSQL.AppendLine("WHERE")
            stbUpdateSQL.AppendLine("  IMAGE_ID = :DocumentId")


            ' イメージ状態履歴登録用SQLを作成します。
            stbInsertSQL.AppendLine("INSERT INTO T_JJ_IMAGE_HISTORY (")
            stbInsertSQL.AppendLine("     IMAGE_ID")
            stbInsertSQL.AppendLine("    ,IMAGE_STATUS")
            stbInsertSQL.AppendLine("    ,CREATE_DATE")
            stbInsertSQL.AppendLine("    ,CREATE_USER")
            stbInsertSQL.AppendLine(") VALUES (")
            stbInsertSQL.AppendLine("     :DocumentId")
            stbInsertSQL.AppendLine("    ,:OutStatus")
            stbInsertSQL.AppendLine("    ,SYSTIMESTAMP")
            stbInsertSQL.AppendLine("    ,'EntryRequest'")
            stbInsertSQL.AppendLine(")")

            For i As Integer = intIndex To (intIndex + intEntryCount - 1) Step 1

                If i >= dtbImage.Rows.Count Then
                    Exit For
                End If


                ' イメージ状態更新用パラメータ宣言
                Dim oraUpdateParam(2) As OracleParameter
                oraUpdateParam(0) = New OracleParameter("DocumentId", OracleDbType.Decimal)
                oraUpdateParam(0).Value = Convert.ToInt64(dtbImage.Rows(i).Item("IMAGE_ID"))
                oraUpdateParam(1) = New OracleParameter("Status", OracleDbType.Char)
                oraUpdateParam(1).Value = mdicConfig(CONF_OUTPUT_IMAGE_STATUS)
                oraUpdateParam(2) = New OracleParameter("Exc09", OracleDbType.Char)
                oraUpdateParam(2).Value = Convert.ToString(dtbImage.Rows(i).Item("EXC_IMAGE_KEY09"))
                ' イメージ状態を更新します。
                Dim intUpdateRet As Integer = MyBase.mobjCommonDB.DB_ExecuteNonQuery(stbUpdateSQL.ToString, oraUpdateParam)
                If Not intUpdateRet = 1 Then
                    Throw New Exception("イメージテーブルの更新に失敗しました。")
                End If


                ' イメージ状態履歴登録用パラメータ宣言
                Dim oraInsertParam(1) As OracleParameter
                oraInsertParam(0) = New OracleParameter("DocumentId", OracleDbType.Decimal)
                oraInsertParam(0).Value = Convert.ToInt64(dtbImage.Rows(i).Item("IMAGE_ID"))
                oraInsertParam(1) = New OracleParameter("OutStatus", OracleDbType.Char)
                oraInsertParam(1).Value = mdicConfig(CONF_OUTPUT_IMAGE_STATUS)
                ' イメージ状態履歴を登録します。
                Dim intInsertRet As Integer = MyBase.mobjCommonDB.DB_ExecuteNonQuery(stbInsertSQL.ToString, oraInsertParam)
                If Not intInsertRet = 1 Then
                    Throw New Exception("イメージ状態履歴の登録に失敗しました。")
                End If

            Next

        Catch ex As Exception

            CommonLog.WriteLog(MyBase.mobjCommonDB.GetInfoMessage, EventLogEntryType.Error)
            Throw ex

        End Try

    End Sub
#End Region

#Region "依頼件数管理情報の依頼数更新"
    ''' ======================================================================
    ''' メソッド名：UpdateImage
    ''' <summary>
    ''' 依頼件数管理情報の依頼数更新
    ''' </summary>
    ''' <param name="dtbImage">エントリ依頼対象イメージデータ</param>
    ''' <param name="intIndex">エントリ依頼対象イメージデータ内の依頼開始位置</param>
    ''' <param name="intEntryCount">最大依頼イメージ数</param>
    ''' <remarks></remarks>
    ''' ======================================================================
    Private Sub UpdateEntReqManage(ByVal dtbImage As DataTable, _
                                   ByVal intIndex As Integer, _
                                   ByVal intEntryCount As Integer)
        Try

            Dim intCount As Integer = intEntryCount
            If (intIndex + intEntryCount) > dtbImage.Rows.Count Then
                intCount = dtbImage.Rows.Count - intIndex
            End If

            ' エントリ依頼件管理テーブル更新用SQLを作成します。
            Dim stbUpdateSQL As New System.Text.StringBuilder(String.Empty)
            stbUpdateSQL.AppendLine("UPDATE")
            stbUpdateSQL.AppendLine("  T_JJ_ENT_REQ_MANAGE")
            stbUpdateSQL.AppendLine("SET")
            stbUpdateSQL.AppendLine("  REQUEST_COUNT = REQUEST_COUNT + __COUNT__ ")
            stbUpdateSQL.AppendLine(" ,UPDATE_USER   = 'EntryRequest'")
            stbUpdateSQL.AppendLine(" ,UPDATE_DATE   = SYSDATE")

            ' 作成したSQLの更新条件部分をコンフィグから取得した値に置換します。
            stbUpdateSQL.Replace("__COUNT__", intCount.ToString)

            ' エントリ依頼件管理テーブルの依頼数を更新します。
            Dim intUpdateRet As Integer = MyBase.mobjCommonDB.DB_ExecuteNonQuery(stbUpdateSQL.ToString)
            If Not intUpdateRet = 1 Then
                Throw New Exception("依頼件数管理情報の依頼数の更新に失敗しました。")
            End If

        Catch ex As Exception

            CommonLog.WriteLog(MyBase.mobjCommonDB.GetInfoMessage, EventLogEntryType.Error)
            Throw ex

        End Try

    End Sub
#End Region

#Region "帳票ID変換"
    Private Sub ConvertSlipDefineID(dtbImage As DataTable)

        For Each dr As DataRow In dtbImage.Rows

            ' 申請書識別コードを取得します。
            Dim strSlipSkbt As String = Convert.ToString(dr.Item("ITEM_001"))
            ' 申請書種類コードを取得します。
            Dim strSlipSrui As String = Convert.ToString(dr.Item("ITEM_002"))
            ' 帳票IDを取得します。
            Dim strSlipID As String = Convert.ToString(dr.Item("SLIP_DEFINE_ID"))
            ' 新しい帳票IDを格納する領域を初期化します。
            Dim strNewSlipID As String = String.Empty

            ' 申請書識別コードが"4"の場合高額療養費のTA分の判定を行います。
            If strSlipSkbt.Equals("4") Then
                Select Case strSlipID
                    Case "641128"
                        strNewSlipID = "641T28"
                    Case "641227"
                        strNewSlipID = "641T27"
                    Case "641173"
                        strNewSlipID = "641T73"
                    Case "641272"
                        strNewSlipID = "641T72"
                End Select
            End If

            ' 申請書種類コードが"062"の場合療養費の治療用装具の判定を行います。
            If strSlipSrui.Equals("062") Then
                Select Case strSlipID
                    Case "661119"
                        strNewSlipID = "661T19"
                    Case "661218"
                        strNewSlipID = "661T18"
                    Case "661126"
                        strNewSlipID = "661T26"
                    Case "661225"
                        strNewSlipID = "661T25"
                End Select
            End If

            ' 新しい帳票IDが設定されなかった場合は次のレコードに進みます。
            If strNewSlipID.Length = 0 Then
                Continue For
            End If

            ' 新しい帳票IDをレコードに設定します。
            dr.Item("SLIP_DEFINE_ID") = strNewSlipID
            ' TAフラグをONにします。
            dr.Item("EXC_IMAGE_KEY09") = "1"
        Next

    End Sub
#End Region

End Class
