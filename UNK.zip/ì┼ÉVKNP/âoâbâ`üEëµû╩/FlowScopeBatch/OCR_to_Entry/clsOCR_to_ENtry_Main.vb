﻿Imports CommonSystem
Imports CommonBase
Imports System
Imports System.Configuration
Imports System.IO
Imports System.Text
Imports System.Reflection

Public Class clsOCR_to_ENtry_Main
    Inherits clsBatchBase

#Region "共通変数"

    ''' <summary>
    ''' 自端末処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Shared mainProc As clsOCR_to_ENtry_Main

#End Region

#Region "内部変数定義"

    ''' <summary>
    ''' 元号の開始年月日
    ''' </summary>
    ''' <remarks>元号ごとの開始年月日(YYYYMMDD)</remarks>
    Enum Gengo_StartDate
        MEIJI = 18680125      ' 明治
        TAISYOU = 19120730    ' 大正
        SYOUWA = 19261225     ' 昭和
        HEISEI = 19890108     ' 平成
        REIWA = 20190501      ' 令和
    End Enum

    ''' <summary>
    ''' 元号の終了年月日
    ''' </summary>
    ''' <remarks>元号ごとの終了年月日(YYYYMMDD)</remarks>
    Enum Gengo_EndDate
        MEIJI = 19120730      ' 明治
        TAISYOU = 19261225    ' 大正
        SYOUWA = 19890107     ' 昭和
        HEISEI = 20190431     ' 平成
        REIWA = 99991231      ' 令和
    End Enum

#End Region

#Region "メイン処理[Main]"
    ''' ======================================================================
    ''' メソッド名：Main
    ''' <summary>
    ''' メイン処理
    ''' </summary>
    ''' <remarks></remarks>
    ''' ======================================================================
    Shared Function Main(ByVal CmdArgs() As String) As Integer

        mainProc = New clsOCR_to_ENtry_Main

        ' 処理の戻り値を返却
        Return mainProc.Run()

    End Function

#End Region

#Region "バッチ処理本体"
    ''' <summary>
    ''' バッチ処理本体
    ''' </summary>
    ''' <remarks></remarks>
    Protected Overrides Sub Execute()
        Try

            ' 処理対象となるイメージデータを取得します。
            Dim dtbAllImage As DataTable = GetImageData()
            If dtbAllImage Is Nothing OrElse dtbAllImage.Rows.Count = 0 Then
                Return
            End If

            ' 処理対象となるイメージデータと関連するOCR結果データを取得します。
            Dim dtbAllOcr As DataTable = GetOcrData()
            If dtbAllOcr Is Nothing OrElse dtbAllOcr.Rows.Count = 0 Then
                Return
            End If

            ' OCRデータのENTRY転送にエラーデータがなかったかのフラグ
            Dim blnResult As Boolean = True

            ' DBのトランザクションを開始します。
            mobjCommonDB.DB_Transaction()
            Try
                ' 処理対象イメージデータを１件ずつ精査します。
                For Each drImg As DataRow In dtbAllImage.Rows

                    ' イメージデータの案件番号を取得します。
                    Dim strExcSubjectNo As String = Convert.ToString(drImg.Item("EXC_SUBJECT_NO")).Replace("-", String.Empty)
                    ' 案件番号に関連つけられたOCRデータを取得します。
                    Dim drOcr() As DataRow = dtbAllOcr.Select("ITEM_004 = '" & strExcSubjectNo & "'")

                    If drOcr.Length = 1 Then
                        ' OCRデータが正常に取得できた場合はR/Wに連携するためのテーブルに転送を試みます
                        If Not OcrToEntryMain(drImg, drOcr(0)) Then
                            blnResult = False
                        End If
                    ElseIf drOcr.Length = 0 Then
                        ' OCRデータが存在しない場合はイメージステータスの更新のみを行います
                        Dim strImageID As String = Convert.ToString(drImg.Item("IMAGE_ID"))
                        Call UpdateImageData(strImageID, mdicConfig("OUTPUT_STATUS"))
                        Call InsertHistory(strImageID, mdicConfig("OUTPUT_STATUS"))
                    Else
                        ' OCRデータが特定できない場合はエラーとします
                        Dim strImageID As String = Convert.ToString(drImg.Item("IMAGE_ID"))
                        CommonLog.WriteLog("OCRデータが特定できません。IMAGE_ID =[" & strImageID & "]", EventLogEntryType.Error)
                        blnResult = False
                    End If

                Next

                ' トランザクションを確定します
                mobjCommonDB.DB_Commit()
            Catch ex As Exception
                ' トランザクションを破棄します
                mobjCommonDB.DB_Rollback()
                Throw ex
            End Try


            ' OCRデータのENTRY転送にエラーがあった場合
            If Not blnResult Then
                MyBase.WriteLog("OCRデータ転送でエラーが発生しています。", EventLogEntryType.Error)
            End If


        Catch ex As Exception

            ' イベントログを出力します。
            MyBase.WriteLog("OCRデータをエントリ結果に移送中にエラーを検出しました。", EventLogEntryType.Error)
            ' ログファイルにエラー内容を出力します。
            CommonLog.WriteLog(ex.ToString, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)

        Finally
        End Try
    End Sub
#End Region

#Region "OCRデータ転送"
    Private Function OcrToEntryMain(drImg As DataRow, drOcr As DataRow) As Boolean
        Try
            Dim blnResult As Boolean = True
            Dim strImageID As String = Convert.ToString(drImg.Item("IMAGE_ID"))
            Dim strSlipID As String = Convert.ToString(drImg.Item("SLIP_DEFINE_ID"))
            Dim strExcImageKey09 As String = Convert.ToString(drImg.Item("EXC_IMAGE_KEY09"))
            Dim lstOcr As New List(Of String)
            Dim intItemCount As Integer = 0
            For i As Integer = 1 To 500 Step 1

                Dim strItemName As String = "ITEM_" & i.ToString("000")
                Dim strValue As String = Convert.ToString(drOcr.Item(strItemName))
                If strValue.Equals("#END") Then
                    intItemCount = i - 1
                    Exit For
                End If

                lstOcr.Add(strValue)
            Next

            Dim strStatus As String = mdicConfig("OUTPUT_STATUS")
            'If Not CheckCountOCR(strSlipID, intItemCount) Then
            '    strStatus = mdicConfig("OUTPUT_STATUS_ERROR")
            '    blnResult = False
            '    CommonLog.WriteLog("OCR項目数が不正です。IMAGE_ID=[" & strImageID & "]", EventLogEntryType.Error)
            'End If

            If strSlipID.StartsWith("641") AndAlso strExcImageKey09.Equals("1") Then
                Call UpdateEntry(strImageID, strSlipID, lstOcr.ToArray)
            End If

            Call UpdateImageData(strImageID, strStatus)

            Call InsertHistory(strImageID, strStatus)

            Return blnResult

        Catch ex As Exception
            CommonLog.WriteLog(MethodBase.GetCurrentMethod.Name & "でエラーを検地しました", EventLogEntryType.Error)
            Throw ex
        End Try
    End Function
#End Region

    '#Region "OCRデータ項目数判定"
    '    Private Function CheckCountOCR(strSlipID As String, intItemNo As Integer) As Boolean
    '        Try
    '            Dim intCount As Integer = 0
    '            Select Case strSlipID
    '                Case "601115", "601214", "601313", "601412", "601146", "601245", "601139", "601238"
    '                    ' 傷病手当金
    '                    intCount = 342

    '                Case "611114", "611213", "611312", "611145", "611244", "611138", "611237"
    '                    ' 出産手当金
    '                    intCount = 273

    '                Case "621113", "621212", "621120", "621229", "621113", "621212", "621120", "621229"
    '                    ' '出産育児一時金
    '                    intCount = 64

    '                Case "631112", "631211", "631129", "631228"
    '                    ' 埋葬料
    '                    intCount = 58

    '                Case "601160", "601269", "601368", "601467", "601191", "601290", "601184", "601283"
    '                    ' 傷病手当金(新)
    '                    intCount = 342

    '                Case "611169", "611268", "611367", "611190", "611299", "611183", "611282"
    '                    ' 出産手当金(新)
    '                    intCount = 273

    '                Case "621168", "621267", "621175", "621274", "621168", "621267", "621175", "621274"
    '                    ' '出産育児一時金(新)
    '                    intCount = 64

    '                Case "621519"
    '                    ' 出産育児一時金(新)頭紙
    '                    intCount = 64

    '                Case "631167", "631266", "631174", "631273"
    '                    ' 埋葬料(新)
    '                    intCount = 58

    '                Case "641166", "641265", "641173", "641272", "641173", "641272", "641012", "641067"
    '                    ' 高額療養費
    '                    intCount = 51

    '                Case "641517"
    '                    ' 高額療養費(頭紙)
    '                    intCount = 51

    '                Case "661164", "661263", "661171", "661270", "661669", "661768", "661676", "661775", "661010", "661065"
    '                    ' 療養費
    '                    intCount = 70

    '                Case "661515"
    '                    ' 療養費(頭紙)
    '                    intCount = 70

    '            End Select

    '            If intCount <> intItemNo Then
    '                Return False
    '            End If

    '            Return True

    '        Catch ex As Exception
    '            CommonLog.WriteLog(MethodBase.GetCurrentMethod.Name & "でエラーを検地しました", EventLogEntryType.Error)
    '            Throw ex
    '        End Try
    '    End Function
    '#End Region

#Region "依頼対象イメージデータの取得"
    ''' ======================================================================
    ''' メソッド名：GetImageData
    ''' <summary>
    ''' 依頼対象イメージデータの取得
    ''' </summary>
    ''' <remarks></remarks>
    ''' ======================================================================
    Private Function GetImageData() As DataTable

        ' 依頼対象データを抽出するためのSQLを作成します。
        Dim stbSQL As New StringBuilder(String.Empty)
        stbSQL.AppendLine("SELECT")
        stbSQL.AppendLine("     I.IMAGE_ID")
        stbSQL.AppendLine("    ,I.IMAGE_STATUS")
        stbSQL.AppendLine("    ,I.IMAGE_FILE_NAME")
        stbSQL.AppendLine("    ,I.IMAGE_FILE_PATH")
        stbSQL.AppendLine("    ,I.SLIP_DEFINE_ID")
        stbSQL.AppendLine("    ,I.EXC_SUBJECT_NO")
        stbSQL.AppendLine("    ,I.PRIORITY")
        stbSQL.AppendLine("    ,I.DELETE_FLG")
        stbSQL.AppendLine("    ,I.BUSINESS_DATE")
        stbSQL.AppendLine("    ,I.EXC_IMAGE_KEY09")
        stbSQL.AppendLine("FROM")
        stbSQL.AppendLine("    T_JJ_IMAGE I")
        stbSQL.AppendLine("WHERE")
        stbSQL.AppendLine("    I.DELETE_FLG     = '0'")
        stbSQL.AppendLine("    AND")
        stbSQL.AppendLine("    I.IMAGE_STATUS   = '%I_STATUS%'")
        stbSQL.AppendLine("ORDER BY")
        stbSQL.AppendLine("     I.PRIORITY")
        stbSQL.AppendLine("    ,I.SLIP_DEFINE_ID")
        stbSQL.AppendLine("    ,I.IMAGE_ID")

        ' 作成したSQLの抽出条件部分をコンフィグから取得した値に置換します。
        stbSQL.Replace("%I_STATUS%", mdicConfig("INPUT_STATUS"))
        'stbSQL.Replace("%RANK%", mdicConfig(""))

        ' OracleDBに作成したSQLを送信して結果を得ます。
        Return MyBase.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)

    End Function
#End Region

#Region "依頼対象OCRデータの取得"
    ''' ======================================================================
    ''' メソッド名：GetOcrData
    ''' <summary>
    ''' 依頼対象OCRデータの取得
    ''' </summary>
    ''' <remarks></remarks>
    ''' ======================================================================
    Private Function GetOcrData() As DataTable

        ' 依頼対象データを抽出するためのSQLを作成します。
        Dim stbSQL As New StringBuilder(String.Empty)
        stbSQL.AppendLine("SELECT")
        stbSQL.AppendLine("    *")
        stbSQL.AppendLine("FROM")
        stbSQL.AppendLine("    T_JJ_OCR_RESULT")
        stbSQL.AppendLine("WHERE")
        stbSQL.AppendLine("    ITEM_004 IN (")
        stbSQL.AppendLine("        SELECT DISTINCT")
        stbSQL.AppendLine("            REPLACE(EXC_SUBJECT_NO,'-')")
        stbSQL.AppendLine("        FROM")
        stbSQL.AppendLine("            T_JJ_IMAGE")
        stbSQL.AppendLine("        WHERE")
        stbSQL.AppendLine("            DELETE_FLG     = '0'")
        stbSQL.AppendLine("            AND")
        stbSQL.AppendLine("            IMAGE_STATUS   = '%I_STATUS%'")
        stbSQL.AppendLine("    )")
        'stbSQL.AppendLine("    AND")
        'stbSQL.AppendLine("    ITEM_001 = '4'")

        ' 作成したSQLの抽出条件部分をコンフィグから取得した値に置換します。
        stbSQL.Replace("%I_STATUS%", mdicConfig("INPUT_STATUS"))

        ' OracleDBに作成したSQLを送信して結果を得ます。
        Return MyBase.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)

    End Function
#End Region

#Region "T_JJ_IMAGEの更新"
    Private Sub UpdateImageData(ByVal strImageID As String, ByVal strStatus As String)
        Dim stbSQL As New StringBuilder(String.Empty)
        Try
            stbSQL.AppendLine("UPDATE")
            stbSQL.AppendLine("    T_JJ_IMAGE")
            stbSQL.AppendLine("SET")
            stbSQL.AppendLine("     IMAGE_STATUS = '__IMAGE_STATUS__'")
            stbSQL.AppendLine("    ,UPDATE_USER  = 'OcrDataImport'")
            stbSQL.AppendLine("    ,UPDATE_DATE  = SYSDATE")
            stbSQL.AppendLine("WHERE")
            stbSQL.AppendLine("    IMAGE_ID = __IMAGE_ID__")

            ' 作成したSQLの設定値の部分を実際の値に置換します。
            stbSQL.Replace("__IMAGE_STATUS__", strStatus)
            stbSQL.Replace("__IMAGE_ID__", strImageID)

            ' 作成したSQLを実行してT_RECEIPT_IMAGEを更新します。
            Dim intInsertRet As Integer = MyBase.mobjCommonDB.DB_ExecuteNonQuery(stbSQL.ToString)
            If Not intInsertRet = 1 Then
                Throw New Exception("イメージデータの更新に失敗しました。")
            End If

        Catch ex As Exception
            CommonLog.WriteLog(MethodBase.GetCurrentMethod.Name & "でエラーを検地しました", EventLogEntryType.Error)
            CommonLog.WriteLog(stbSQL.ToString, EventLogEntryType.Error)
            Throw ex
        End Try
    End Sub
#End Region

#Region "T_STATUS_HISTORYの登録"
    Private Sub InsertHistory(ByVal strImageID As String, ByVal strStatus As String)
        Dim stbSQL As New StringBuilder(String.Empty)
        Try
            ' イメージ状態履歴登録用SQLを作成します。
            stbSQL.AppendLine("INSERT INTO T_JJ_IMAGE_HISTORY (")
            stbSQL.AppendLine("     IMAGE_ID")
            stbSQL.AppendLine("    ,IMAGE_STATUS")
            stbSQL.AppendLine("    ,CREATE_DATE")
            stbSQL.AppendLine("    ,CREATE_USER")
            stbSQL.AppendLine(") VALUES (")
            stbSQL.AppendLine("     __IMAGE_ID__")
            stbSQL.AppendLine("    ,__IMAGE_STATUS__")
            stbSQL.AppendLine("    ,SYSTIMESTAMP")
            stbSQL.AppendLine("    ,'OcrDataImport'")
            stbSQL.AppendLine(")")

            ' 作成したSQLの設定値の部分を実際の値に置換します。
            stbSQL.Replace("__IMAGE_STATUS__", strStatus)
            stbSQL.Replace("__IMAGE_ID__", strImageID)

            ' イメージ状態履歴を登録します。
            Dim intInsertRet As Integer = MyBase.mobjCommonDB.DB_ExecuteNonQuery(stbSQL.ToString)
            If Not intInsertRet = 1 Then
                Throw New Exception("イメージ履歴の登録に失敗しました。")
            End If

        Catch ex As Exception
            CommonLog.WriteLog(MethodBase.GetCurrentMethod.Name & "でエラーを検地しました", EventLogEntryType.Error)
            CommonLog.WriteLog(stbSQL.ToString, EventLogEntryType.Error)
            Throw ex
        End Try

    End Sub
#End Region

#Region "OCRテーブル登録"
    Private Sub UpdateEntry(strImageID As String, strSlipID As String, strOcr As String())
        Dim strOldSlip() As String = {"641173", "641272"}
        Dim str1stSlip() As String = {"641128", "641173"}
        Dim stbSQL As New StringBuilder(String.Empty)
        Try
            stbSQL.AppendLine("UPDATE T_JJ_ENTRY_CORRECTION SET")

            If str1stSlip.Contains(strSlipID) Then

                ' 被保険者証記号
                stbSQL.AppendLine("    ITEM_001 = '" & strOcr(4) & "'")
                ' 被保険者証番号
                stbSQL.AppendLine("   ,ITEM_002 = '" & strOcr(5) & "'")

                ' 被保険者生年月日
                Dim strDate1() As String = ConvDate(strOcr(6))
                stbSQL.AppendLine("   ,ITEM_003 = '" & strDate1(0) & "'")
                stbSQL.AppendLine("   ,ITEM_004 = '" & strDate1(1) & "'")
                stbSQL.AppendLine("   ,ITEM_005 = '" & strDate1(2) & "'")
                stbSQL.AppendLine("   ,ITEM_006 = '" & strDate1(3) & "'")

                ' 被保険者郵便番号
                stbSQL.AppendLine("   ,ITEM_008 = '" & strOcr(8) & "'")
                ' 被保険者電話番号
                stbSQL.AppendLine("   ,ITEM_015 = '" & strOcr(9) & "'")

            Else

                ' 診療年月
                Dim strDate2() As String = ConvDate(strOcr(28))
                stbSQL.AppendLine("    ITEM_074 = '" & strDate2(0) & "'")
                stbSQL.AppendLine("   ,ITEM_063 = '" & strDate2(1) & "'")
                stbSQL.AppendLine("   ,ITEM_064 = '" & strDate2(2) & "'")

                ' 受診者区分１
                stbSQL.AppendLine("   ,ITEM_065 = '" & strOcr(29) & "'")

                ' 受診者生年月日１
                Dim strDate3() As String = ConvDate(strOcr(31))
                stbSQL.AppendLine("   ,ITEM_022 = '" & strDate3(0) & "'")
                stbSQL.AppendLine("   ,ITEM_023 = '" & strDate3(1) & "'")
                stbSQL.AppendLine("   ,ITEM_024 = '" & strDate3(2) & "'")
                stbSQL.AppendLine("   ,ITEM_025 = '" & strDate3(3) & "'")

                ' 受診者区分2
                stbSQL.AppendLine("   ,ITEM_066 = '" & strOcr(32) & "'")

                ' 受診者生年月日2
                Dim strDate4() As String = ConvDate(strOcr(34))
                stbSQL.AppendLine("   ,ITEM_027 = '" & strDate4(0) & "'")
                stbSQL.AppendLine("   ,ITEM_028 = '" & strDate4(1) & "'")
                stbSQL.AppendLine("   ,ITEM_029 = '" & strDate4(2) & "'")
                stbSQL.AppendLine("   ,ITEM_030 = '" & strDate4(3) & "'")

                ' 受診者区分3
                stbSQL.AppendLine("   ,ITEM_067 = '" & strOcr(35) & "'")

                ' 受診者生年月日3
                Dim strDate5() As String = ConvDate(strOcr(37))
                stbSQL.AppendLine("   ,ITEM_032 = '" & strDate5(0) & "'")
                stbSQL.AppendLine("   ,ITEM_033 = '" & strDate5(1) & "'")
                stbSQL.AppendLine("   ,ITEM_034 = '" & strDate5(2) & "'")
                stbSQL.AppendLine("   ,ITEM_035 = '" & strDate5(3) & "'")

                '' 療養期間（自）１
                'Dim strDate6() As String = ConvDate(strOcr(44))
                'If strOldSlip.Contains(strSlipID) Then
                '    stbSQL.AppendLine("   ,ITEM_036 = '" & strDate6(0) & "'")
                'Else
                '    Select Case strDate6(0)
                '        Case "4"
                '            stbSQL.AppendLine("   ,ITEM_036 = '1'")
                '        Case "5"
                '            stbSQL.AppendLine("   ,ITEM_036 = '2'")
                '        Case Else
                '            stbSQL.AppendLine("   ,ITEM_036 = '?'")
                '    End Select
                'End If
                'stbSQL.AppendLine("   ,ITEM_037 = '" & strDate6(1) & "'")
                'stbSQL.AppendLine("   ,ITEM_038 = '" & strDate6(2) & "'")
                'stbSQL.AppendLine("   ,ITEM_039 = '" & strDate6(3) & "'")

                '' 療養期間（至）１
                'stbSQL.AppendLine("   ,ITEM_040 = '" & strDate6(0) & "'")
                'stbSQL.AppendLine("   ,ITEM_041 = '" & strDate6(1) & "'")
                'stbSQL.AppendLine("   ,ITEM_042 = '" & strDate6(2) & "'")
                'stbSQL.AppendLine("   ,ITEM_043 = '" & strOcr(45) & "'")

                ' 入院通院の別１
                stbSQL.AppendLine("   ,ITEM_068 = '" & strOcr(46) & "'")

                '' 療養期間（自）2
                'Dim strDate7() As String = ConvDate(strOcr(47))
                'If strOldSlip.Contains(strSlipID) Then
                '    stbSQL.AppendLine("   ,ITEM_044 = '" & strDate7(0) & "'")
                'Else
                '    Select Case strDate7(0)
                '        Case "4"
                '            stbSQL.AppendLine("   ,ITEM_044 = '1'")
                '        Case "5"
                '            stbSQL.AppendLine("   ,ITEM_044 = '2'")
                '        Case Else
                '            stbSQL.AppendLine("   ,ITEM_044 = '?'")
                '    End Select
                'End If
                'stbSQL.AppendLine("   ,ITEM_045 = '" & strDate7(1) & "'")
                'stbSQL.AppendLine("   ,ITEM_046 = '" & strDate7(2) & "'")
                'stbSQL.AppendLine("   ,ITEM_047 = '" & strDate7(3) & "'")

                '' 療養期間（至）2
                'stbSQL.AppendLine("   ,ITEM_048 = '" & strDate7(0) & "'")
                'stbSQL.AppendLine("   ,ITEM_049 = '" & strDate7(1) & "'")
                'stbSQL.AppendLine("   ,ITEM_050 = '" & strDate7(2) & "'")
                'stbSQL.AppendLine("   ,ITEM_051 = '" & strOcr(48) & "'")

                ' 入院通院の別2
                stbSQL.AppendLine("   ,ITEM_069 = '" & strOcr(49) & "'")


                '' 療養期間（自）3
                'Dim strDate8() As String = ConvDate(strOcr(50))
                'If strOldSlip.Contains(strSlipID) Then
                '    stbSQL.AppendLine("   ,ITEM_052 = '" & strDate8(0) & "'")
                'Else
                '    Select Case strDate8(0)
                '        Case "4"
                '            stbSQL.AppendLine("   ,ITEM_052 = '1'")
                '        Case "5"
                '            stbSQL.AppendLine("   ,ITEM_052 = '2'")
                '        Case Else
                '            stbSQL.AppendLine("   ,ITEM_052 = '?'")
                '    End Select
                'End If
                'stbSQL.AppendLine("   ,ITEM_053 = '" & strDate8(1) & "'")
                'stbSQL.AppendLine("   ,ITEM_054 = '" & strDate8(2) & "'")
                'stbSQL.AppendLine("   ,ITEM_055 = '" & strDate8(3) & "'")

                '' 療養期間（至）3
                'stbSQL.AppendLine("   ,ITEM_056 = '" & strDate8(0) & "'")
                'stbSQL.AppendLine("   ,ITEM_057 = '" & strDate8(1) & "'")
                'stbSQL.AppendLine("   ,ITEM_058 = '" & strDate8(2) & "'")
                'stbSQL.AppendLine("   ,ITEM_059 = '" & strOcr(51) & "'")

                ' 入院通院の別3
                stbSQL.AppendLine("   ,ITEM_070 = '" & strOcr(52) & "'")

                ' 自己負担額１
                stbSQL.AppendLine("   ,ITEM_060 = '" & strOcr(53) & "'")
                ' 自己負担額２
                stbSQL.AppendLine("   ,ITEM_061 = '" & strOcr(54) & "'")
                ' 自己負担額３
                stbSQL.AppendLine("   ,ITEM_062 = '" & strOcr(55) & "'")

                '' 支払総額１
                'stbSQL.AppendLine("   ,ITEM_071 = '" & strOcr(56) & "'")
                '' 支払総額２
                'stbSQL.AppendLine("   ,ITEM_072 = '" & strOcr(57) & "'")
                '' 支払総額３
                'stbSQL.AppendLine("   ,ITEM_073 = '" & strOcr(58) & "'")

                ' 非課税年度
                Dim strDate9() As String = ConvDate(strOcr(68))
                stbSQL.AppendLine("   ,ITEM_075 = '" & strDate9(0) & "'")
                stbSQL.AppendLine("   ,ITEM_017 = '" & strDate9(1) & "'")

            End If

            stbSQL.AppendLine("   ,UPDATE_USER = 'OCR_To_Entry'")
            stbSQL.AppendLine("   ,UPDATE_DATE = SYSDATE")

            stbSQL.AppendLine("WHERE")
            stbSQL.AppendLine("    IMAGE_ID = " & strImageID)

            mobjCommonDB.DB_ExecuteNonQuery(stbSQL.ToString)
        Catch ex As Exception
            CommonLog.WriteLog(MethodBase.GetCurrentMethod.Name & "でエラーを検地しました", EventLogEntryType.Error)
            CommonLog.WriteLog(stbSQL.ToString, EventLogEntryType.Error)
            Throw ex
        End Try
    End Sub
#End Region

#Region "日付変換1(明大昭平令) YYMMDD"
    Private Function ConvDateX(strValue As String) As String()
        Try
            Dim strResult() As String = {String.Empty, String.Empty, String.Empty, String.Empty}
            If strValue.Length <> 4 AndAlso strValue.Length <> 6 AndAlso strValue.Length <> 8 Then
                Return strResult
            End If
            If strValue.Contains("#") Then
                Return strResult
            End If

            Dim strYear As String = strValue.Substring(0, 4)
            If Not strYear.Contains("#") Then
                Dim intYear As Integer = Convert.ToInt32(strValue.Substring(0, 4))
                Dim intBaseYear As Integer = 0

                Dim intDate As Integer = Convert.ToInt32(strValue)
                If strValue.Length = 6 Then
                    If strValue.Contains("#") Then
                        intDate = Convert.ToInt32(strYear & "1231")
                    Else
                        intDate = Convert.ToInt32(strValue & "31")
                    End If
                End If
                If strValue.Length = 4 Then
                    intDate = Convert.ToInt32(strValue & "1231")
                End If

                If intDate < Gengo_StartDate.MEIJI Then
                    Return strResult
                ElseIf intDate < Gengo_StartDate.TAISYOU Then
                    strResult(0) = "1"
                    intBaseYear = Gengo_StartDate.MEIJI / 10000
                ElseIf intDate < Gengo_StartDate.SYOUWA Then
                    strResult(0) = "2"
                    intBaseYear = Gengo_StartDate.TAISYOU / 10000
                ElseIf intDate < Gengo_StartDate.HEISEI Then
                    strResult(0) = "3"
                    intBaseYear = Gengo_StartDate.SYOUWA / 10000
                ElseIf intDate < Gengo_StartDate.REIWA Then
                    strResult(0) = "4"
                    intBaseYear = Gengo_StartDate.HEISEI / 10000
                Else
                    strResult(0) = "5"
                    intBaseYear = Gengo_StartDate.REIWA / 10000
                End If

                strResult(1) = (intYear - intBaseYear + 1).ToString("00")

            Else
                strResult(0) = "?"
                strResult(1) = "?"
            End If

            If strValue.Length = 4 Then
                Return strResult
            End If

            strResult(2) = strValue.Substring(4, 2).Replace("#", "?")
            If strValue.Length = 6 Then
                Return strResult
            End If

            strResult(3) = strValue.Substring(6, 2).Replace("#", "?")

            Return strResult
        Catch ex As Exception
            CommonLog.WriteLog(MethodBase.GetCurrentMethod.Name & "でエラーを検地しました", EventLogEntryType.Error)
            Throw ex
        End Try
    End Function
#End Region

#Region "日付変換1(明大昭平令) YYMMDD"
    Private Function ConvDate(strValue As String) As String()
        Try
            Dim strResult() As String = {String.Empty, String.Empty, String.Empty, String.Empty}

            If strValue.Length > 6 Then
                strResult(3) = strValue.Substring(6)
                strValue = strValue.Substring(0, 6)
            End If

            If strValue.Length > 4 Then
                strResult(2) = strValue.Substring(4)
                strValue = strValue.Substring(0, 4)
            End If

            If strValue.Length > 0 Then
                strResult(1) = strValue
                strResult(0) = "9"
            End If

            Return strResult

        Catch ex As Exception
            CommonLog.WriteLog(MethodBase.GetCurrentMethod.Name & "でエラーを検地しました", EventLogEntryType.Error)
            Throw ex
        End Try
    End Function
#End Region

End Class
