﻿Imports CommonSystem
Imports CommonBase
Imports System
Imports System.Configuration
Imports System.IO
Imports System.Text
Imports Oracle.DataAccess.Client
Imports MakeDelivery

Public Class clsMakeDelivery2Main
    Inherits clsBatchBase

#Region "共通変数"

    ''' <summary>
    ''' 自端末処理
    ''' 帳票出力上限数を東西４種(計８種)追加  *** [2015/06/24] 追加 ***
    ''' </summary>
    ''' <remarks></remarks>
    Private Shared mainProc As clsMakeDelivery2Main

#End Region

#Region "内部変数定義"

    Private mstrDeliveryDate As String = String.Empty

#End Region

#Region "クラス変数"
    '*** [2015/04/16 修正 Kuwahara] ***
    Public _strConvObj As clsComStringConw

    Public mlstFilter641 As New List(Of Integer)
    Public mlstFilter661 As New List(Of Integer)
    Public mlstAddress641 As New List(Of Integer)
    Public mlstAddress661 As New List(Of Integer)

#End Region

#Region "メイン処理[Main]"
    ''' ======================================================================
    ''' メソッド名：Main
    ''' <summary>
    ''' メイン処理
    ''' </summary>
    ''' <remarks></remarks>
    ''' ======================================================================
    Shared Function Main(ByVal CmdArgs() As String) As Integer

        mainProc = New clsMakeDelivery2Main

        ' 処理の戻り値を返却
        Return mainProc.Run()

    End Function

#End Region

#Region "バッチ処理本体"
    ''' <summary>
    ''' バッチ処理本体
    ''' </summary>
    ''' <remarks></remarks>
    Protected Overrides Sub Execute()

        ' 納品ファイル出力先（東西）ルートパス
        Dim strRootPathEast As String = String.Empty
        Dim strRootPathWest As String = String.Empty

        Try
            '変換文字ファイルを取得する *** [2015/04/16 修正 Kuwahara] ***
            Dim _OutSideMappingFile As String = mdicConfig("OUTSIDE_MAPPING_FILE")
            '文字列変換用オブジェクト生成
            _strConvObj = New clsComStringConw
            With _strConvObj
                .OutputKanjiSet = KanjiSet.UNICODE20
                .OutputKanjiEncoding = KanjiEncoding.UTF_8
                '.OutputKanjiSet = KanjiSet.JISX0208
                '.OutputKanjiEncoding = KanjiEncoding.Shift_JIS
                .MappingTableFileName = _OutSideMappingFile
                '.OutBoundChar = CChar(_OutSideConvStr)
            End With

            Dim strFilter641() As String = mdicConfig("FILTER_ITEM_641").Split(",")
            For Each s As String In strFilter641
                mlstFilter641.Add(Convert.ToInt32(s))
            Next

            Dim strFilter661() As String = mdicConfig("FILTER_ITEM_661").Split(",")
            For Each s As String In strFilter661
                mlstFilter661.Add(Convert.ToInt32(s))
            Next

            Dim strAddress641() As String = mdicConfig("ADDRESS_ITEM_641").Split(",")
            For Each s As String In strAddress641
                mlstAddress641.Add(Convert.ToInt32(s))
            Next

            Dim strAddress661() As String = mdicConfig("ADDRESS_ITEM_661").Split(",")
            For Each s As String In strAddress661
                mlstAddress661.Add(Convert.ToInt32(s))
            Next

            ' 納品日時を取得します
            mstrDeliveryDate = GetDeliveryDate()

            ' イメージテーブルステータスを更新する為の関連帳票番号リスト(OUT) *** [2015/06/24] 追加 ***</param>
            Dim strExcSubjectNumArrayList As New ArrayList

            ' 処理対象となるイメージデータを取得します。
            Dim isDataNothing As Boolean = False
            Dim dtbAllImage As DataTable = GetImageData()
            If dtbAllImage Is Nothing OrElse dtbAllImage.Rows.Count = 0 Then
                CommonLog.WriteLog("作成する納品データ対象データが存在しません", EventLogEntryType.Warning)
                isDataNothing = True
            End If

            ' 準備されている納品準備データを取得する
            Dim dtbAllDelivery As DataTable = GetDeliveryData()
            If dtbAllDelivery Is Nothing OrElse dtbAllImage.Rows.Count = 0 Then
                CommonLog.WriteLog("作成する納品データ対象準備データが存在しません", EventLogEntryType.Warning)
                isDataNothing = True
            End If

            ' 編集・出力クラスのインスタンス生成（帳票ごと）を生成し、ディクショナリに格納
            Dim editOutputMap As New Dictionary(Of String, clsEditOutput)
            editOutputMap.Add(mdicConfig("prefix_ryouyou"), New clsEditOutput(mdicConfig))      ' 療養費支給申請書
            editOutputMap.Add(mdicConfig("prefix_kougaku"), New clsEditOutput(mdicConfig))      ' 高額療養費支給申請書

            '対象データなしの場合は0件データファイルを作成する  *** 2015/01/13 追加 ***
            If isDataNothing Then
                ' 納品フォルダの作成
                strRootPathEast = CreateDeliveryDir(mdicConfig("DELIVERY_PATH_EAST"))
                strRootPathWest = CreateDeliveryDir(mdicConfig("DELIVERY_PATH_WEST"))
                Directory.CreateDirectory(strRootPathEast)
                Directory.CreateDirectory(strRootPathWest)

                ' 納品データファイル出力
                execOutput(strRootPathEast, strRootPathWest, strExcSubjectNumArrayList, editOutputMap) ' *** [2015/06/24] 追加 ***

                ' トリガーファイルの作成
                OutputTrigger(strRootPathEast, mdicConfig("TRIGGER_FILE_EAST"))
                OutputTrigger(strRootPathWest, mdicConfig("TRIGGER_FILE_WEST"))

                Return
            End If

            ' ブレイク処理用ファイル名
            Dim breakFileName As String = Left(GetValue(dtbAllImage.Rows(0), "IMAGE_FILE_NAME"), 23)

            ' 繰り返し処理用  編集・出力クラス変数
            Dim slipKindObj As clsEditOutput
            ' レコードオブジェクト(DataRow)のコレクション
            Dim records As New List(Of DataRow)
            ' イメージファイル名
            Dim strFileName As String = String.Empty

            '帳票IDの取得
            Dim strSlipID As String = GetValue(dtbAllImage.Rows(0), "SLIP_DEFINE_ID")
            ' 案件IDの取得
            Dim strSubject As String = GetValue(dtbAllImage.Rows(0), "EXC_SUBJECT_NO")

            ' エントリデータがない帳票IDの識別情報の取得
            ' getEditMethodListにて使用している為、ここでは除外
            ' Dim distSlipId() As String = Split(mdicConfig("DIST_SLIP_ID"), ",")

            ' 納品対象データを１件ずつ処理します。
            For Each dr As DataRow In dtbAllImage.Rows
                ' イメージファイル名の取得
                strFileName = GetValue(dr, "IMAGE_FILE_NAME").Trim
                ' 取得したファイル名が異なった場合
                If breakFileName <> Left(strFileName, 23) Then

                    ' 帳票IDより処理する帳票のインスタンスを決定
                    slipKindObj = getEditOutput(strSlipID, editOutputMap)

                    ' 出力用レコードを作成
                    Dim drwSetup() As DataRow = dtbAllDelivery.Select("EXC_SUBJECT_NO = '" & strSubject & "'")
                    If drwSetup.Length = 1 Then
                        Dim srtLst As SortedList(Of Integer, String) = MakeSortList(strSlipID, drwSetup(0))
                        ' 東西情報の取得
                        Dim ewKbn As String = Convert.ToString(records(0).Item("EXC_IMAGE_KEY01"))
                        Select Case ewKbn
                            Case "PE"
                                slipKindObj.seqNoEast += 1
                                srtLst.Add(0, slipKindObj.seqNoEast.ToString("000000"))
                                slipKindObj.OutputListEast.Add(srtLst)
                            Case "PW"
                                slipKindObj.seqNoWest += 1
                                srtLst.Add(0, slipKindObj.seqNoWest.ToString("000000"))
                                slipKindObj.OutputListWest.Add(srtLst)
                        End Select
                    End If

                    ' ブレイク用ファイル名の更新
                    breakFileName = Left(strFileName, 23)
                    ' DataRowオブジェクトのクリア
                    records.Clear()
                End If
                ' 帳票IDの取得
                strSlipID = GetValue(dr, "SLIP_DEFINE_ID")
                ' 案件IDの取得
                strSubject = GetValue(dr, "EXC_SUBJECT_NO")
                ' 現在のDataRowオブジェクトをリストに設定
                records.Add(dr)
            Next

            ' 最後の1件分の処理を実施
            If records.Count > 0 Then

                ' 帳票IDより処理する帳票のインスタンスを決定
                slipKindObj = getEditOutput(strSlipID, editOutputMap)

                ' 出力用レコードを作成
                Dim drwSetup() As DataRow = dtbAllDelivery.Select("EXC_SUBJECT_NO = '" & strSubject & "'")
                If drwSetup.Length = 1 Then
                    Dim srtLst As SortedList(Of Integer, String) = MakeSortList(strSlipID, drwSetup(0))
                    ' 東西情報の取得
                    Dim ewKbn As String = Convert.ToString(records(0).Item("EXC_IMAGE_KEY01"))
                    Select Case ewKbn
                        Case "PE"
                            slipKindObj.seqNoEast += 1
                            srtLst.Add(0, slipKindObj.seqNoEast.ToString("000000"))
                            slipKindObj.OutputListEast.Add(srtLst)
                        Case "PW"
                            slipKindObj.seqNoWest += 1
                            srtLst.Add(0, slipKindObj.seqNoWest.ToString("000000"))
                            slipKindObj.OutputListWest.Add(srtLst)
                    End Select
                End If

            End If

            ' 納品フォルダの作成
            strRootPathEast = CreateDeliveryDir(mdicConfig("DELIVERY_PATH_EAST"))
            strRootPathWest = CreateDeliveryDir(mdicConfig("DELIVERY_PATH_WEST"))
            Directory.CreateDirectory(strRootPathEast)
            Directory.CreateDirectory(strRootPathWest)

            ' 納品データファイル出力
            execOutput(strRootPathEast, strRootPathWest, strExcSubjectNumArrayList, editOutputMap) ' *** [2015/06/24] 追加 ***

            Try
                ' DBトランザクションの開始
                mobjCommonDB.DB_Transaction()

                'イメージステータス関連DB更新処理  *** [2015/06/24] 追加 ***
                updateImageStatus(strExcSubjectNumArrayList)

                ' トリガーファイルの作成
                OutputTrigger(strRootPathEast, mdicConfig("TRIGGER_FILE_EAST"))
                OutputTrigger(strRootPathWest, mdicConfig("TRIGGER_FILE_WEST"))

                ' トランザクションを確定
                mobjCommonDB.DB_Commit()

            Catch ex As Exception
                Try
                    ' トランザクションロールバック
                    mobjCommonDB.DB_Rollback()
                Catch nfex As NullReferenceException
                    CommonLog.WriteLog("ロールバック実施時のNull Reference Exceptionが発生", EventLogEntryType.Error)
                    CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
                End Try
                Throw ex
            End Try

        Catch ex As Exception

            ' イベントログを出力します。
            MyBase.WriteLog("納品ファイル作成中にエラーを検出しました。", EventLogEntryType.Error)
            ' ログファイルにエラー内容を出力します。
            CommonLog.WriteLog(ex.ToString, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)

            ' 納品フォルダが出力されていれば削除します。
            If Not strRootPathEast.Equals(String.Empty) AndAlso Directory.Exists(strRootPathEast) Then
                Directory.Delete(strRootPathEast, True)
            End If
            If Not strRootPathWest.Equals(String.Empty) AndAlso Directory.Exists(strRootPathWest) Then
                Directory.Delete(strRootPathWest, True)
            End If
        Finally
            If Not IsNothing(mobjCommonDB) AndAlso Not IsDBNull(mobjCommonDB) Then
                ' データベース接続クローズ
                mobjCommonDB.DB_Close()
            End If
        End Try
    End Sub

#End Region

#Region "納品データ出力"
    ''' <summary>
    ''' execOutput
    ''' </summary>
    ''' <param name="outPathEast">東の出力先パス</param>
    ''' <param name="outPathWest">西の出力先パス</param>
    ''' <param name="strExcSubjectNumArrayList">イメージテーブルステータスを更新する為の関連帳票番号リスト(OUT) *** [2015/06/24] 追加 ***</param>
    ''' <param name="editOutputMap">出力レコードバッファのコレクション</param>
    ''' <remarks>編集後の出力バッファよりcsvファイルへ出力を行う</remarks>
    Public Sub execOutput(ByVal outPathEast As String, _
                          ByVal outPathWest As String, _
                          ByRef strExcSubjectNumArrayList As ArrayList, _
                          ByVal editOutputMap As Dictionary(Of String, clsEditOutput) _
                         )
        ' 帳票編集オブジェクト
        Dim editOutputObj As clsEditOutput
        ' 帳票出力用バッファ（東）取得
        Dim outPutListEast As List(Of SortedList(Of Integer, String))
        ' 帳票出力用バッファ（西）取得
        Dim outPutListWest As List(Of SortedList(Of Integer, String))
        ' 出力ファイル名
        Dim fileNameDeliverEast As String           ' 送達ファイル（東）
        Dim fileNameDeliverWest As String           ' 送達ファイル（西）
        Dim fileNamePunchEast As String             ' エントリーファイル（東）
        Dim fileNamePunchWest As String             ' エントリーファイル（西）
        Dim outLimitCount As Integer                ' 帳票出力上限数 *** [2015/06/24] 追加 ***

        Try
            '《療養費支給申請書の出力》
            editOutputObj = editOutputMap.Item(mdicConfig("prefix_ryouyou"))
            outPutListEast = editOutputObj.OutputListEast
            outPutListWest = editOutputObj.OutputListWest
            '【東】
            fileNameDeliverEast = getOutputFileName(outPathEast, mdicConfig("PNAME_PREFIX_RYOUYOU"), mdicConfig("DELIVERY_EAST"))
            fileNamePunchEast = getOutputFileName(outPathEast, mdicConfig("PNAME_PREFIX_RYOUYOU"), mdicConfig("PUNCH_EAST"))
            outLimitCount = mdicConfig("OUT_LIMIT_COUNT_EAST_RYOUYOU")
            writeRecords(fileNameDeliverEast, fileNamePunchEast, outLimitCount, outPutListEast, strExcSubjectNumArrayList)
            '【西】
            fileNameDeliverWest = getOutputFileName(outPathWest, mdicConfig("PNAME_PREFIX_RYOUYOU"), mdicConfig("DELIVERY_WEST"))
            fileNamePunchWest = getOutputFileName(outPathWest, mdicConfig("PNAME_PREFIX_RYOUYOU"), mdicConfig("PUNCH_WEST"))
            outLimitCount = mdicConfig("OUT_LIMIT_COUNT_WEST_RYOUYOU")
            writeRecords(fileNameDeliverWest, fileNamePunchWest, outLimitCount, outPutListWest, strExcSubjectNumArrayList)

            '《高額療養費支給申請書の出力》
            editOutputObj = editOutputMap.Item(mdicConfig("prefix_kougaku"))
            outPutListEast = editOutputObj.OutputListEast
            outPutListWest = editOutputObj.OutputListWest
            '【東】
            fileNameDeliverEast = getOutputFileName(outPathEast, mdicConfig("PNAME_PREFIX_KOUGAKU"), mdicConfig("DELIVERY_EAST"))
            fileNamePunchEast = getOutputFileName(outPathEast, mdicConfig("PNAME_PREFIX_KOUGAKU"), mdicConfig("PUNCH_EAST"))
            outLimitCount = mdicConfig("OUT_LIMIT_COUNT_EAST_KOUGAKKU")
            writeRecords(fileNameDeliverEast, fileNamePunchEast, outLimitCount, outPutListEast, strExcSubjectNumArrayList)
            '【西】
            fileNameDeliverWest = getOutputFileName(outPathWest, mdicConfig("PNAME_PREFIX_KOUGAKU"), mdicConfig("DELIVERY_WEST"))
            fileNamePunchWest = getOutputFileName(outPathWest, mdicConfig("PNAME_PREFIX_KOUGAKU"), mdicConfig("PUNCH_WEST"))
            outLimitCount = mdicConfig("OUT_LIMIT_COUNT_WEST_KOUGAKU")
            writeRecords(fileNameDeliverWest, fileNamePunchWest, outLimitCount, outPutListWest, strExcSubjectNumArrayList)


        Catch ex As Exception
            CommonLog.WriteLog("execOutput（納品データ出力）でエラーが発生しました", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            Throw ex
        End Try

    End Sub
#End Region

#Region "ファイル出力処理"
    ''' <summary>
    ''' writeRecords
    ''' <para name="dlvFileName">送達ファイル名</para>
    ''' <para name="pchFileName">エントリーファイル名</para>
    ''' <para name="outLimitCount">帳票出力上限数</para>
    ''' <para name="outputList">各帳票別の出力レコードのコレクション</para>
    ''' <para name="strExcSubjectNumArrayList">イメージテーブルステータスを更新する為の関連帳票番号リスト(OUT) *** [2015/06/24] 追加 ***</para>
    ''' </summary>
    ''' <remarks>コレクションにある出力レコードからcsvファイルへ出力を行う</remarks>
    Public Sub writeRecords(ByVal dlvFileName As String, _
                            ByVal pchFileName As String, _
                            ByVal outLimitCount As Integer, _
                            ByVal outputList As List(Of SortedList(Of Integer, String)), _
                            ByRef strExcSubjectNumArrayList As ArrayList)
        '                            ByVal outputList As List(Of SortedList(Of Integer, String)))   ' *** [2015/06/24] 削除 ***

        ' 出力レコードカウント
        Dim outRecCount As Integer = 0

        Try

            ' 出力ストリームの取得
            Dim writerDlv As StreamWriter = File.CreateText(dlvFileName)    '送達ファイル
            Dim writerPch As StreamWriter = File.CreateText(pchFileName)    'エントリーファイル

            '            ' 帳票出力上限数                                             ' *** [2015/06/24] 削除 ***
            '            Dim outLimitCount As Integer = mdicConfig("OUT_LIMIT_COUNT") ' *** [2015/06/24] 削除 ***
            ' 出力リストの反復子の取得
            Dim outListEnum As List(Of SortedList(Of Integer, String)).Enumerator = outputList.GetEnumerator()
            ' 出力情報コレクション（マップ）
            Dim outInfoList As SortedList(Of Integer, String)
            ' 出力レコードキーパートの反復子の取得
            Dim recKeys As IList(Of Integer)
            Dim seqNoEnum As IEnumerator(Of Integer)
            ' 出力レコードキー（シーケンスNo）
            Dim seqNo As Integer
            ' 出力レコードバッファ（送達）
            Dim outRecDerivery(2) As String
            ' 出力レコードバッファ（エントリー）
            Dim outRecPunch() As String = Nothing

            ' ************************************
            ' *** エントリーデータ出力編集処理 ***
            ' ************************************
            ' 出力レコード数分繰り返し処理を実施
            While outListEnum.MoveNext()
                '件数カウント
                outRecCount += 1
                If outRecCount > outLimitCount Then
                    outRecCount = outLimitCount
                    '上限数に達したレコードは出力しない
                    Exit While
                End If
                '1件分のデータ取得
                outInfoList = outListEnum.Current
                'エントリーデータ出力レコードバッファの要素数決定
                ReDim outRecPunch(outInfoList.Count - 1)
                'キー（シーケンスNo）のコレクション取得
                recKeys = outInfoList.Keys
                'キー（シーケンスNo）の反復子取得
                seqNoEnum = recKeys.GetEnumerator
                '配列用カウンタ初期化
                Dim i As Integer = 0
                '項目数分繰り返し処理を実行
                While seqNoEnum.MoveNext()
                    seqNo = seqNoEnum.Current
                    '項目取得を取得し、エントリーレコードに追加()
                    outRecPunch(i) = """" & outInfoList.Item(seqNo) & """"
                    i += 1
                End While

                ' *** [2015/06/24] 追加 ***
                ' イメージテーブルステータスを更新する為の関連帳票番号
                excSubjectNumCsvAdd(outInfoList.Item(2), strExcSubjectNumArrayList)

                ' エントリーのレコードを出力
                writerPch.WriteLine(Join(outRecPunch, ","))
                writerPch.Flush()
            End While
            ' ******************************
            ' *** 送達データ出力編集処理 ***
            ' ******************************
            Dim fileInfo As New System.IO.FileInfo(pchFileName)
            Dim fileLen = fileInfo.Length
            outRecDerivery(0) = Path.GetFileName(pchFileName)
            outRecDerivery(1) = fileLen
            'outRecDerivery(2) = outputList.Count    [2015/1/17] 出力件数をオブジェクトの要素数から出力したレコード件数へ変更
            outRecDerivery(2) = outRecCount
            ' 送達レコードの出力
            writerDlv.WriteLine(Join(outRecDerivery, ","))

            ' ストリームのクローズ
            writerDlv.Close() : writerPch.Close()
        Catch ex As Exception
            CommonLog.WriteLog("writeRecords（ファイル出力処理）でエラーが発生しました", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog("送達ファイル名 -> " & dlvFileName, EventLogEntryType.Error)
            CommonLog.WriteLog("エントリーファイル名 -> " & pchFileName, EventLogEntryType.Error)
            CommonLog.WriteLog("出力レコード件数 -> " & outputList.Count, EventLogEntryType.Error)
            CommonLog.WriteLog("処理行 -> " & outRecCount, EventLogEntryType.Error)
            Throw ex
        End Try

    End Sub
#End Region

    ' *** [2015/06/24] 追加ここから ***
#Region "イメージステータス関連DB更新処理"
    ''' <summary>
    ''' updateImageStatus
    ''' <param name="strExcSubjectNumArrayList">イメージテーブルステータスを更新する為の関連帳票番号リスト(IN)</param>
    ''' </summary>
    ''' <remarks>イメージステータスの更新とイメージステータス履歴の登録を行う。</remarks>
    Public Sub updateImageStatus(ByVal strExcSubjectNumArrayList As ArrayList)

        Try
            For Each strExcSubjectNum As String In strExcSubjectNumArrayList

#If DEBUG Then
                CommonLog.WriteLog("EXC_SUBJECT_NO -> " & strExcSubjectNum, EventLogEntryType.Warning)
#End If

                ' イメージステータスを更新するイメージIDリストを取得する
                Dim stbSQL As New StringBuilder("SELECT IMAGE_ID FROM T_JJ_IMAGE WHERE IMAGE_STATUS = __IMGSTS__ AND EXC_SUBJECT_NO IN(__EXC_SUBJECT_NO_LIST__)")
                stbSQL.Replace("__IMGSTS__", mdicConfig("INPUT_STATUS"))
                stbSQL.Replace("__EXC_SUBJECT_NO_LIST__", strExcSubjectNum)
                ' SQL実行
                Dim dt As System.Data.DataTable = mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)
                ' 更新対象のイメージIDリスト
                Dim aryImageId As New ArrayList
                ' 取得したイメージIDをリストに格納
                For Each dr As DataRow In dt.Rows
                    aryImageId.Add(Convert.ToString(dr.Item("IMAGE_ID")))
                Next
                dt.Dispose()
                ' 取得したイメージIDからイメージステータスを更新する
                For Each updImageId As String In aryImageId

#If DEBUG Then
                    CommonLog.WriteLog("IMAGE_ID -> " & updImageId, EventLogEntryType.Warning)
#End If

                    ' イメージステータスの更新
                    UpdateImageData(updImageId, mdicConfig("OUTPUT_STATUS"))
                    ' イメージステータス履歴の登録
                    InsertHistory(updImageId, mdicConfig("OUTPUT_STATUS"))
                Next
            Next
        Catch ex As Exception
            CommonLog.WriteLog("updateImageStatus（イメージステータス関連DB更新処理）でエラーが発生しました", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            Throw ex
        End Try



    End Sub
#End Region
    ' *** [2015/06/24] 追加ここまで ***

#Region "出力ファイル名取得"
    ''' <summary>
    ''' getOutputFileName
    ''' </summary>
    ''' <param name="ouDir">出力先パス</param>
    ''' <param name="fileKind1">帳票名のプリフィックス</param>
    ''' <param name="fileKind2">ファイルの種類情報</param>
    ''' <returns>編集後の出力ファイル名</returns>
    ''' <remarks></remarks>
    Public Shared Function getOutputFileName(ByVal ouDir As String, ByVal fileKind1 As String, ByVal fileKind2 As String) As String
        Return Path.Combine(ouDir, fileKind1 & fileKind2 & "DTR_99_" & Now.ToString("yyyyMMddHHmmssf") & ".csv")
    End Function
#End Region

#Region "メソッド編集オブジェクト取得"
    ''' <summary>
    ''' getEditOutput
    ''' </summary>
    ''' <returns>メソッド編集オブジェクトのインスタンス</returns>
    ''' <remarks>帳票IDから該当する帳票のメソッド編集オブジェクトのインスタンスを戻す</remarks>
    Public Function getEditOutput(ByVal slipId As String, ByVal edtOuputDic As Dictionary(Of String, clsEditOutput)) As clsEditOutput
        Dim retDic As clsEditOutput = Nothing
        ' 帳票IDより処理する帳票のインスタンスを決定
        Select Case Left(slipId, 3)
            Case mdicConfig("pid_ryouyou")  '"661"
                retDic = edtOuputDic(mdicConfig("prefix_ryouyou"))
            Case mdicConfig("pid_kougaku")   '"641"
                retDic = edtOuputDic(mdicConfig("prefix_kougaku"))
        End Select

        Return retDic

    End Function
#End Region

#Region "メソッド定義オブジェクトリストの取得"
    ''' <summary>
    ''' getEditMethodList
    ''' </summary>
    ''' <returns>該当するメソッド定義オブジェクトのリスト</returns>
    ''' <remarks>帳票IDから該当する帳票のメソッド定義オブジェクトリストのインスタンスを戻す</remarks>
    Public Function getEditMethodList(ByVal arySlipID As ArrayList, ByVal SlipID As String, _
                                      ByVal editMethodMap As Dictionary(Of String, List(Of clsMethodDef))) As List(Of clsMethodDef)
        'リターン値
        Dim methodDefList As List(Of clsMethodDef) = Nothing
        '' エントリデータがない帳票IDの識別情報の取得
        'Dim distSlipId() As String = Split(mdicConfig("DIST_SLIP_ID"), ",")

        'If Right(SlipID, 3) = distSlipId(0) _
        'OrElse Right(SlipID, 3) = distSlipId(1) _
        'OrElse Right(SlipID, 3) = distSlipId(2) _
        'OrElse Right(SlipID, 3) = distSlipId(3) _
        'OrElse Right(SlipID, 3) = distSlipId(4) Then

        '    ' 編集メソッドリスト取得(デフォルト用)
        '    methodDefList = editMethodMap(Left(SlipID, 3) & mdicConfig("DIST_SLIP_SUFFIX"))
        'Else
        '    ' 編集メソッドリスト取得
        '    methodDefList = editMethodMap(mdicConfig("S" & SlipID))
        'End If

        'エントリーデータ用帳票ID識別情報
        Dim EditSlipId() As String = Split(mdicConfig("EDIT_ID"), ",")

        For i As Integer = 0 To arySlipID.Count - 1
            For j As Integer = 0 To EditSlipId.Length - 1
                If arySlipID(i).ToString = EditSlipId(j) Then
                    methodDefList = editMethodMap(mdicConfig("S" & arySlipID(i)))
                End If
            Next
        Next

        If methodDefList Is Nothing Then
            methodDefList = editMethodMap(Left(SlipID, 3) & mdicConfig("DIST_SLIP_SUFFIX"))
        End If


        Return methodDefList

    End Function
#End Region

#Region "納品対象データの取得[GetImageData]"
    ''' ======================================================================
    ''' メソッド名：GetImageData
    ''' <summary>
    ''' 納品対象データの取得
    ''' </summary>
    ''' <remarks>イメージテーブル、イメージ補正テーブルより納品対象データを取得する</remarks>
    ''' ======================================================================
    Private Function GetImageData() As DataTable

        Try
            ' 納品対象データを抽出するためのSQLを作成します。
            Dim stbSQL As New StringBuilder(String.Empty)
            With stbSQL
                .AppendLine("SELECT")
                .AppendLine("    I.IMAGE_ID,")
                .AppendLine("    I.IMAGE_STATUS,")
                .AppendLine("    I.SLIP_DEFINE_ID,")
                .AppendLine("    I.IMAGE_FILE_NAME,")
                .AppendLine("    I.EXC_IMAGE_KEY01,")
                .AppendLine("    I.EXC_SUBJECT_NO,")
                .AppendLine("    E.*")
                .AppendLine("FROM")
                .AppendLine("    T_JJ_IMAGE I")
                .AppendLine("LEFT OUTER JOIN")
                .AppendLine("    T_JJ_ENTRY_CORRECTION E")
                .AppendLine("ON  I.IMAGE_ID = E.IMAGE_ID")
                .AppendLine("INNER JOIN")
                .AppendLine("    (")
                .AppendLine("        SELECT")
                .AppendLine("            A.EXC_SUBJECT_NO")
                .AppendLine("        FROM")
                .AppendLine("        (")
                .AppendLine("           SELECT EXC_SUBJECT_NO")
                .AppendLine("           FROM T_JJ_IMAGE")
                .AppendLine("           WHERE DELETE_FLG = '0'")
                .AppendLine("           GROUP BY EXC_SUBJECT_NO")
                .AppendLine("           HAVING MIN(IMAGE_STATUS) = %IMGSTS% ")
                .AppendLine("        ) A,")
                .AppendLine("        (")
                .AppendLine("           SELECT EXC_SUBJECT_NO")
                .AppendLine("           FROM T_JJ_IMAGE")
                .AppendLine("           WHERE DELETE_FLG = '0'")
                .AppendLine("           AND SLIP_DEFINE_ID IN (%SLIPID%) ")
                .AppendLine("           AND IMAGE_STATUS = %IMGSTS%")
                .AppendLine("           GROUP BY EXC_SUBJECT_NO")
                .AppendLine("        ) B")
                .AppendLine("        WHERE A.EXC_SUBJECT_NO = B.EXC_SUBJECT_NO")
                .AppendLine("    ) C")
                .AppendLine("ON  I.EXC_SUBJECT_NO = C.EXC_SUBJECT_NO")
                .AppendLine("WHERE I.DELETE_FLG = '0'")
                .AppendLine("ORDER BY")
                .AppendLine("    I.IMAGE_FILE_NAME,")
                .AppendLine("    I.EXC_IMAGE_KEY01,")
                .AppendLine("    I.SLIP_DEFINE_ID")
                ''MOD 2015.11.17 速度改善 ↑

            End With

            ' 抽出条件部分をコンフィギュレーションファイルから取得した値に置換します。
            stbSQL.Replace("%IMGSTS%", mdicConfig("INPUT_STATUS"))
            stbSQL.Replace("%SLIPID%", mdicConfig("SLIP_ID"))

#If DEBUG Then
            CommonLog.WriteLog("納品対象データの取得SQL：" & stbSQL.ToString, EventLogEntryType.Information)
#End If
            ' SQLステートメントを実行し、結果を返却する。
            Return MyBase.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)

        Catch ex As Exception
            ' ログファイルにエラー内容を出力します。
            CommonLog.WriteLog("納品データの対象データ抽出処理でエラーが発生しました", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            Throw ex
        End Try
    End Function
#End Region

#Region "納品用ディレクトリ作成[CreateDeliveryDir]"
    ''' ======================================================================
    ''' メソッド名：CreateDeliveryDir
    ''' <summary>
    ''' 納品用ディレクトリ作成
    ''' </summary>
    ''' <param name="deliveryPath">納品ファイルの出力フォルダ</param>''' 
    ''' <returns>生成したフォルダへのフルパス</returns>
    ''' <remarks></remarks>
    ''' ======================================================================
    Private Function CreateDeliveryDir(ByVal deliveryPath As String) As String

        Dim strRequestDir As String
        For i As Integer = 0 To 1000

            Dim strDate As String = Now.ToString("yyMMddHHmmssfff")
            ' 現在日付のフォルダを作成
            strRequestDir = Path.Combine(deliveryPath, strDate)

            If Directory.Exists(strRequestDir) Then
                System.Threading.Thread.Sleep(1000)
                Continue For
            End If

            Try
                Directory.CreateDirectory(strRequestDir)
            Catch ex As IOException
                System.Threading.Thread.Sleep(1000)
                Continue For
            End Try

            ' 作成したディレクトリを返却
            Return strRequestDir

        Next

        ' ここまで来た場合、exception発行
        Throw New Exception("納品用ディレクトリの作成に失敗しました。")

    End Function
#End Region

#Region "トリガファイルの出力"
    ''' <summary>
    ''' トリガファイルの出力
    ''' </summary>
    ''' <param name="strRootPath">トリガファイル出力先フォルダパス</param>
    ''' <param name="triggerFile">トリガファイル名</param>
    ''' <remarks></remarks>
    Private Sub OutputTrigger(ByVal strRootPath As String, ByVal triggerFile As String)
        Try
            ' 外部定義にトリガファイルの名前が定義されていない場合は出力しません。
            If triggerFile.Trim.Length = 0 Then
                Return
            End If

            ' トリガファイルの作成
            Dim strPath As String = Path.Combine(strRootPath, triggerFile)
            Using sw As New StreamWriter(strPath, False, Encoding.GetEncoding("shift_jis"))
            End Using

        Catch ex As Exception
            ' ログファイルにエラー内容を出力します。
            CommonLog.WriteLog("トリガファイル出力失敗", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            Throw ex

        End Try
    End Sub
#End Region

#Region "エントリ内容を項目IDから取得"
    ''' <summary>
    ''' エントリ内容を項目IDから取得
    ''' </summary>
    ''' <param name="dr">エントリ結果レコード</param>
    ''' <param name="id">取得対象の項目ID</param>
    ''' <returns>エントリ結果</returns>
    ''' <remarks></remarks>
    Public Shared Function GetValue(ByVal dr As DataRow, ByVal id As String) As String
        Try

            Return Convert.ToString(dr.Item(id))

        Catch ex As Exception
            ' ログファイルにエラー内容を出力します。
            CommonLog.WriteLog("エントリ内容の取得に失敗", EventLogEntryType.Error)
            CommonLog.WriteLog("項目ID:「" & id & "」", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            Throw ex
        End Try
    End Function
#End Region

#Region "T_JJ_IMAGEの更新"
    ''' <summary>
    ''' T_JJ_IMAGEの更新
    ''' </summary>
    ''' <param name="strImageID">イメージID</param>
    ''' <param name="strStatus">イメージステータス</param>
    ''' <remarks>2015.11.17 速度改善のため、パラメータ使用</remarks>
    Private Sub UpdateImageData(ByVal strImageID As String, _
                                ByVal strStatus As String)
        Try

            ' T_JJ_IMAGE更新用SQLを作成します。
            Dim stbUpdateSQL As New StringBuilder(String.Empty)
            stbUpdateSQL.AppendLine("UPDATE")
            stbUpdateSQL.AppendLine("    T_JJ_IMAGE")
            stbUpdateSQL.AppendLine("SET")
            ''MOD 2015.11.17 速度改善 ↓
            'stbUpdateSQL.AppendLine("     IMAGE_STATUS   = '__IMAGE_STATUS__'")
            stbUpdateSQL.AppendLine("     IMAGE_STATUS   = :OutStatus")
            ''MOD 2015.11.17 速度改善 ↑
            stbUpdateSQL.AppendLine("    ,DELIVERY_DATE       = TO_DATE('" & mstrDeliveryDate & "','YYYYMMDDHH24MISS') ")
            stbUpdateSQL.AppendLine("    ,DELIVERY_DATE_REAL  = SYSDATE ")
            stbUpdateSQL.AppendLine("    ,UPDATE_USER    = 'MakeDelivery2'")
            stbUpdateSQL.AppendLine("    ,UPDATE_DATE    = SYSDATE")
            stbUpdateSQL.AppendLine("WHERE")
            ''MOD 2015.11.17 速度改善 ↓
            'stbUpdateSQL.AppendLine("    IMAGE_ID = __IMAGE_ID__")
            stbUpdateSQL.AppendLine("    IMAGE_ID = :DocumentID")
            ''MOD 2015.11.17 速度改善 ↑


            ''MOD 2015.11.17 速度改善 ↓
            ' 作成したSQLの設定値の部分を実際の値に置換します。
            'stbUpdateSQL.Replace("__IMAGE_STATUS__", strStatus)
            'stbUpdateSQL.Replace("__IMAGE_ID__", strImageID)

            ' イメージ状態更新用パラメータ宣言
            Dim oraUpdateParam(1) As OracleParameter
            oraUpdateParam(0) = New OracleParameter(":DocumentID", OracleDbType.Decimal)
            oraUpdateParam(0).Value = Convert.ToInt64(strImageID)
            oraUpdateParam(1) = New OracleParameter(":OutStatus", OracleDbType.Char)
            oraUpdateParam(1).Value = strStatus

            '' 作成したSQLを実行してT_JJ_IMAGEを更新します。
            'Dim intInsertRet As Integer = MyBase.mobjCommonDB.DB_ExecuteNonQuery(stbUpdateSQL.ToString)
            Dim intInsertRet As Integer = MyBase.mobjCommonDB.DB_ExecuteNonQuery(stbUpdateSQL.ToString, oraUpdateParam)
            ''MOD 2015.11.17 速度改善 ↑

            If Not intInsertRet = 1 Then
                Throw New Exception("イメージデータの更新に失敗しました。")
            End If

        Catch ex As Exception
            ' ログファイルにエラー内容を出力します。
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(MyBase.mobjCommonDB.GetInfoMessage, EventLogEntryType.Error)
            Throw ex
        End Try
    End Sub
#End Region

#Region "T_JJ_IMAGE_HISTORYの登録"
    ''' ======================================================================
    ''' メソッド名：InsertHistory
    ''' <summary>
    ''' T_JJ_IMAGE_HISTORYの登録
    ''' </summary>
    ''' <param name="strDocumentId">書類ID</param>
    ''' <remarks></remarks>
    ''' ======================================================================
    Private Sub InsertHistory(ByVal strDocumentId As String, ByVal strStatus As String)

        Try
            Dim strUpdateStatus As String = strStatus

            ' イメージ状態履歴登録用SQLを作成します。
            Dim stbInsertSQL As New System.Text.StringBuilder(String.Empty)
            stbInsertSQL.AppendLine("INSERT INTO T_JJ_IMAGE_HISTORY (")
            stbInsertSQL.AppendLine("     IMAGE_ID")
            stbInsertSQL.AppendLine("    ,IMAGE_STATUS")
            stbInsertSQL.AppendLine("    ,CREATE_DATE")
            stbInsertSQL.AppendLine("    ,CREATE_USER")
            stbInsertSQL.AppendLine(") VALUES (")
            stbInsertSQL.AppendLine("     :DocumentID")
            stbInsertSQL.AppendLine("    ,:OutStatus")
            stbInsertSQL.AppendLine("    ,SYSDATE")
            stbInsertSQL.AppendLine("    ,'MakeDelivery2'")
            stbInsertSQL.AppendLine(")")

            ' イメージ状態履歴登録用パラメータ宣言
            Dim oraInsertParam(1) As OracleParameter
            oraInsertParam(0) = New OracleParameter(":DocumentID", OracleDbType.Decimal)
            oraInsertParam(0).Value = Convert.ToInt64(strDocumentId)
            oraInsertParam(1) = New OracleParameter(":OutStatus", OracleDbType.Char)
            oraInsertParam(1).Value = strUpdateStatus
            ' イメージ状態履歴を登録します。
            Dim intInsertRet As Integer = MyBase.mobjCommonDB.DB_ExecuteNonQuery(stbInsertSQL.ToString, oraInsertParam)
            If Not intInsertRet = 1 Then
                Throw New Exception("イメージ履歴の登録に失敗しました。")
            End If

        Catch ex As Exception
            ' ログファイルにエラー内容を出力します。
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(MyBase.mobjCommonDB.GetInfoMessage, EventLogEntryType.Error)
            Throw ex
        End Try

    End Sub
#End Region

#Region "イメージテーブルステータス更新連帳票番号追加"
    ''' <summary>
    ''' excSubjectNumCsvAdd
    ''' <para name="excSubjectNum">帳票番号(IN)</para>
    ''' <para name="strExcSubjectNumArrayList">イメージテーブルステータスを更新する為の関連帳票番号リスト</para>
    ''' </summary>
    ''' <remarks>イメージテーブルステータスを更新する為の関連帳票番号を19桁から23桁にしてCSV形式で追加</remarks>
    Private Sub excSubjectNumCsvAdd(ByVal excSubjectNum As String, _
                                    ByRef strExcSubjectNumArrayList As ArrayList)
        Dim SEPARATOR As String = "-"
        '対象が19桁の文字列の時のみ
        If excSubjectNum <> "" And Len(excSubjectNum) = 19 Then
            '19桁から23桁へ
            excSubjectNum = excSubjectNum.Substring(0, 2) & SEPARATOR & _
                            excSubjectNum.Substring(2, 2) & SEPARATOR & _
                            excSubjectNum.Substring(4, 6) & SEPARATOR & _
                            excSubjectNum.Substring(10, 3) & SEPARATOR & _
                            excSubjectNum.Substring(13, 6)
            strExcSubjectNumArrayList.Add("'" & excSubjectNum & "'")
        End If

    End Sub
#End Region

#Region "納品対象データの取得[GetDeliveryData]"
    ''' ======================================================================
    ''' メソッド名：GetDeliveryData
    ''' <summary>
    ''' 納品データの取得
    ''' </summary>
    ''' <remarks>イメージテーブル、納品準備テーブルより納品対象データを取得する</remarks>
    ''' ======================================================================
    Private Function GetDeliveryData() As DataTable
        Dim stbSQL As New StringBuilder(String.Empty)
        Try
            ' 納品対象データを抽出するためのSQLを作成します。
            stbSQL.AppendLine("SELECT")
            stbSQL.AppendLine("    S.*")
            stbSQL.AppendLine("FROM")
            stbSQL.AppendLine("    T_JJ_DELIVERY_SETUP S")
            stbSQL.AppendLine("WHERE")
            stbSQL.AppendLine("    S.EXC_SUBJECT_NO IN (")
            stbSQL.AppendLine("        SELECT")
            stbSQL.AppendLine("            A.EXC_SUBJECT_NO")
            stbSQL.AppendLine("        FROM")
            stbSQL.AppendLine("        (")
            stbSQL.AppendLine("           SELECT EXC_SUBJECT_NO")
            stbSQL.AppendLine("           FROM T_JJ_IMAGE")
            stbSQL.AppendLine("           WHERE DELETE_FLG = '0'")
            stbSQL.AppendLine("           GROUP BY EXC_SUBJECT_NO")
            stbSQL.AppendLine("           HAVING MIN(IMAGE_STATUS) = %IMGSTS% ")
            stbSQL.AppendLine("        ) A,")
            stbSQL.AppendLine("        (")
            stbSQL.AppendLine("           SELECT EXC_SUBJECT_NO")
            stbSQL.AppendLine("           FROM T_JJ_IMAGE")
            stbSQL.AppendLine("           WHERE DELETE_FLG = '0'")
            stbSQL.AppendLine("           AND SLIP_DEFINE_ID IN (%SLIPID%) ")
            stbSQL.AppendLine("           AND IMAGE_STATUS = %IMGSTS%")
            stbSQL.AppendLine("           GROUP BY EXC_SUBJECT_NO")
            stbSQL.AppendLine("        ) B")
            stbSQL.AppendLine("        WHERE A.EXC_SUBJECT_NO = B.EXC_SUBJECT_NO")
            stbSQL.AppendLine("    )")

            ' 抽出条件部分をコンフィギュレーションファイルから取得した値に置換します。
            stbSQL.Replace("%IMGSTS%", mdicConfig("INPUT_STATUS"))
            stbSQL.Replace("%SLIPID%", mdicConfig("SLIP_ID"))

            ' SQLステートメントを実行し、結果を返却する。
            Return MyBase.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)

        Catch ex As Exception
            ' ログファイルにエラー内容を出力します。
            CommonLog.WriteLog("納品データ抽出処理でエラーが発生しました", EventLogEntryType.Error)
            CommonLog.WriteLog(stbSQL.ToString, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            Throw ex
        End Try
    End Function
#End Region

#Region "納品時刻の取得"
    Private Function GetDeliveryDate() As String
        Dim stbSQL As New StringBuilder(String.Empty)
        Try
            Dim dtNow As DataTable = mobjCommonDB.DB_ExecuteQuery("SELECT TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS') FROM DUAL")
            Dim strNow As String = Convert.ToString(dtNow.Rows(0).Item(0))

            Dim dtDlv As DataTable = mobjCommonDB.DB_ExecuteQuery("SELECT * FROM M_CM_DELIVERY_DATE WHERE TO_CHAR(SYSDATE,'HH24MI') BETWEEN DELIVERY_TIME_START AND DELIVERY_TIME_END")
            If dtDlv Is Nothing OrElse dtDlv.Rows.Count = 0 Then
                Return strNow
            Else
                strNow = strNow.Substring(0, 8) & Convert.ToString(dtDlv.Rows(0).Item("DELIVERY_TIME"))
            End If

            Return strNow
        Catch ex As Exception
            ' ログファイルにエラー内容を出力します。
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(MyBase.mobjCommonDB.GetInfoMessage, EventLogEntryType.Error)
            Throw ex
        End Try
    End Function
#End Region

#Region ""
    Private Function MakeSortList(strSlipID As String, drw As DataRow) As SortedList(Of Integer, String)
        Try
            Dim srtLst As New SortedList(Of Integer, String)
            For i As Integer = 2 To 500 Step 1
                Dim strItem As String = Convert.ToString(drw.Item("ITEM_" & i.ToString("000")))
                If strItem.Equals("#END") Then
                    Exit For
                End If
                If strSlipID.StartsWith("641") Then
                    If mlstFilter641.Contains(i) Then
                        Dim filterBytes As Byte() = _strConvObj.Filter(strItem)
                        Dim retStr As String = System.Text.Encoding.GetEncoding("UTF-8").GetString(filterBytes)
                        srtLst.Add(i, clsEditOutput.RemoveHalfByteChr(retStr))
                    ElseIf mlstAddress641.Contains(i) Then
                        For j As Integer = 0 To mlstAddress641.Count - 1 Step 1
                            If mlstAddress641(j) = i Then
                                srtLst.Add(i, D213(strItem, (j Mod 3)))
                                Exit For
                            End If
                        Next
                    Else
                        srtLst.Add(i, strItem)
                    End If
                ElseIf strSlipID.StartsWith("661") Then
                    If mlstFilter661.Contains(i) Then
                        Dim filterBytes As Byte() = _strConvObj.Filter(strItem)
                        Dim retStr As String = System.Text.Encoding.GetEncoding("UTF-8").GetString(filterBytes)
                        srtLst.Add(i, clsEditOutput.RemoveHalfByteChr(retStr))
                    ElseIf mlstAddress661.Contains(i) Then
                        For j As Integer = 0 To mlstAddress661.Count - 1 Step 1
                            If mlstAddress661(j) = i Then
                                srtLst.Add(i, D213(strItem, (j Mod 3)))
                                Exit For
                            End If
                        Next
                    Else
                        srtLst.Add(i, strItem)
                    End If
                Else
                    srtLst.Add(i, strItem)
                End If
            Next

            Return srtLst
        Catch ex As Exception
            ' ログファイルにエラー内容を出力します。
            CommonLog.WriteLog("納品データの対象データ変換処理でエラーが発生しました", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            Throw ex
        End Try
    End Function
#End Region

#Region "住所の編集メソッド"
    Public Function D213(ByVal itemValue As String, ByVal intValue As Integer) As String
        ' 編集後の文字列
        Dim retStr As String = String.Empty
        '住所文字列一時保管用
        Dim tmpStr As String = String.Empty
        Try


            Dim strAddrLen As Integer = itemValue.Length            ' 住所項目文字列の長さを取得
            Dim strTmp As String                                    '住所文字列編集用
            Dim strAddress As String
            Dim filterBytes As Byte() = _strConvObj.Filter(itemValue)
            strAddress = System.Text.Encoding.GetEncoding("UTF-8").GetString(filterBytes)

            '1. 文字列から13文字分を「住所1」に設定()
            Dim address1 As String = Left(strAddress, 13).TrimEnd()  ' 住所1の設定

            '2. 1で設定した以降の文字列を13文字分「住所2」に設定
            Dim address2 As String = String.Empty                ' 住所2の設定
            strTmp = Mid(strAddress, 14)
            If strTmp.Length > 0 Then
                '先頭がスペースなら削除する
                If Left(strTmp, 1) = "　" Then
                    strTmp = Mid(strTmp, 2)
                End If
                address2 = Left(strTmp, 13).TrimEnd()
            End If

            '3. 2で設定した以降の文字列を13文字分「住所3」に設定
            Dim address3 As String = String.Empty                ' 住所3の設定
            strTmp = Mid(strTmp, 14)
            If strTmp.Length > 0 Then
                '先頭がスペースなら削除する
                If Left(strTmp, 1) = "　" Then
                    strTmp = Mid(strTmp, 2)
                End If
                address3 = Left(strTmp, 13).TrimEnd()
            End If

            '4. 不正文字の置き換え（"〓" ⇒ "★"）
            address1 = address1.Replace("〓", "★")
            address2 = address2.Replace("〓", "★")
            address3 = address3.Replace("〓", "★")

            '5. 半角文字の削除
            address1 = clsEditOutput.RemoveHalfByteChr(address1)
            address2 = clsEditOutput.RemoveHalfByteChr(address2)
            address3 = clsEditOutput.RemoveHalfByteChr(address3)

            '6. 住所項目が39文字を超える場合、住所3の最終文字を"★"（不備）に置き換える
            '  （住所3の先頭が全角空白の場合は40文字を超える場合）
            If Mid(itemValue, 37, 1) = "　" AndAlso strAddrLen > 40 Then
                address3 = clsEditOutput.LastReplaceString(address3, "★")
            ElseIf strAddrLen > 39 Then
                address3 = clsEditOutput.LastReplaceString(address3, "★")
            End If

            ' 引数によって、設定を分岐
            Select Case intValue
                Case 0
                    retStr = address1       ' パラメータ=1の時、住所1を設定
                Case 1
                    retStr = address2       ' パラメータ=2の時、住所2を設定
                Case 2
                    retStr = address3       ' パラメータ=3の時、住所3を設定
            End Select

            Return retStr

        Catch ex As Exception
            ' ログファイルにエラー内容を出力します。
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(MyBase.mobjCommonDB.GetInfoMessage, EventLogEntryType.Error)
            Throw ex
        End Try

    End Function
#End Region

End Class
