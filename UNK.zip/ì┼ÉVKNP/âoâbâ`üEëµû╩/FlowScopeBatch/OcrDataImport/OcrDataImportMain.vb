﻿Imports CommonSystem
Imports CommonBase
Imports System
Imports System.IO
Imports System.Text
Imports System.Reflection

Public Class OcrDataImportMain
    Inherits clsBatchBase

#Region "共通変数"

    ''' <summary>
    ''' 自端末処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Shared mainProc As OcrDataImportMain

#End Region

#Region "内部変数定義"

    ''' <summary>
    ''' 元号の開始年月日
    ''' </summary>
    ''' <remarks>元号ごとの開始年月日(YYYYMMDD)</remarks>
    Enum Gengo_StartDate
        MEIJI = 18680125      ' 明治
        TAISYOU = 19120730    ' 大正
        SYOUWA = 19261225     ' 昭和
        HEISEI = 19890108     ' 平成
        REIWA = 20190501      ' 令和
    End Enum

    ''' <summary>
    ''' 元号の終了年月日
    ''' </summary>
    ''' <remarks>元号ごとの終了年月日(YYYYMMDD)</remarks>
    Enum Gengo_EndDate
        MEIJI = 19120730      ' 明治
        TAISYOU = 19261225    ' 大正
        SYOUWA = 19890107     ' 昭和
        HEISEI = 20190431     ' 平成
        REIWA = 99991231      ' 令和
    End Enum

#End Region

#Region "メイン処理[Main]"

    ''' ======================================================================
    ''' メソッド名：Main
    ''' <summary>
    ''' メイン処理
    ''' </summary>
    ''' <remarks></remarks>
    ''' ======================================================================
    Shared Function Main(ByVal CmdArgs() As String) As Integer

        mainProc = New OcrDataImportMain

        ' 処理の戻り値を返却
        Return mainProc.Run()

    End Function

#End Region

#Region "バッチ処理本体"
    ''' ======================================================================
    ''' メソッド名：Execute
    ''' <summary>
    ''' バッチ処理本体
    ''' </summary>
    ''' <remarks></remarks>
    ''' ======================================================================
    Protected Overrides Sub Execute()
        Try

            ' 処理対象となるイメージデータを取得します。
            Dim dtbAllImage As DataTable = GetImageData()
            If dtbAllImage Is Nothing OrElse dtbAllImage.Rows.Count = 0 Then
                Return
            End If

            ' 処理対象となるイメージデータと関連するOCR結果データを取得します。
            Dim dtbAllOcr As DataTable = GetOcrData()
            If dtbAllOcr Is Nothing OrElse dtbAllOcr.Rows.Count = 0 Then
                Return
            End If

            ' OCRデータのR/W連携結果にエラーデータがなかったかのフラグ
            Dim blnResult As Boolean = True

            ' DBのトランザクションを開始します。
            mobjCommonDB.DB_Transaction()
            Try
                ' 処理対象イメージデータを１件ずつ精査します。
                For Each drImg As DataRow In dtbAllImage.Rows

                    ' イメージデータの案件番号を取得します。
                    Dim strExcSubjectNo As String = Convert.ToString(drImg.Item("EXC_SUBJECT_NO"))
                    ' 案件番号に関連つけられたOCRデータを取得します。
                    Dim drOcr() As DataRow = dtbAllOcr.Select("ITEM_004 = '" & strExcSubjectNo & "'")

                    If drOcr.Length = 1 Then
                        ' OCRデータが正常に取得できた場合はR/Wに連携するためのテーブルに転送を試みます
                        If Not OcrImportsMain(drImg, drOcr(0)) Then
                            blnResult = False
                        End If
                    ElseIf drOcr.Length = 0 Then
                        ' OCRデータが存在しない場合はイメージステータスの更新のみを行います
                        Dim strImageID As String = Convert.ToString(drImg.Item("IMAGE_ID"))
                        Call UpdateImageData(strImageID, mdicConfig("OUTPUT_STATUS"))
                        Call InsertHistory(strImageID, mdicConfig("OUTPUT_STATUS"))
                    Else
                        ' OCRデータが特定できない場合はエラーとします
                        Dim strImageID As String = Convert.ToString(drImg.Item("IMAGE_ID"))
                        CommonLog.WriteLog("OCRデータが特定できません。IMAGE_ID =[" & strImageID & "]", EventLogEntryType.Error)
                        blnResult = False
                    End If

                Next

                ' トランザクションを確定します
                mobjCommonDB.DB_Commit()
            Catch ex As Exception
                ' トランザクションを破棄します
                mobjCommonDB.DB_Rollback()
                Throw ex
            End Try

            ' OCRデータのR/W連携にエラーがあった場合
            If Not blnResult Then
                MyBase.WriteLog("OCRデータ転送でエラーが発生しています。", EventLogEntryType.Error)
            End If

        Catch ex As Exception

            MyBase.WriteLog(ex.ToString, EventLogEntryType.Error)

        Finally

        End Try
    End Sub
#End Region

#Region "依頼対象イメージデータの取得"
    ''' ======================================================================
    ''' メソッド名：GetImageData
    ''' <summary>
    ''' 依頼対象イメージデータの取得
    ''' </summary>
    ''' <remarks></remarks>
    ''' ======================================================================
    Private Function GetImageData() As DataTable

        ' 依頼対象データを抽出するためのSQLを作成します。
        Dim stbSQL As New StringBuilder(String.Empty)
        stbSQL.AppendLine("SELECT")
        stbSQL.AppendLine("     I.IMAGE_ID")
        stbSQL.AppendLine("    ,I.IMAGE_STATUS")
        stbSQL.AppendLine("    ,I.IMAGE_FILE_NAME")
        stbSQL.AppendLine("    ,I.IMAGE_FILE_PATH")
        stbSQL.AppendLine("    ,I.SLIP_DEFINE_ID")
        stbSQL.AppendLine("    ,REPLACE(I.EXC_SUBJECT_NO,'-','') AS EXC_SUBJECT_NO")
        stbSQL.AppendLine("    ,I.PRIORITY")
        stbSQL.AppendLine("    ,I.DELETE_FLG")
        stbSQL.AppendLine("    ,I.BUSINESS_DATE")
        stbSQL.AppendLine("FROM")
        stbSQL.AppendLine("    T_JJ_IMAGE I")
        stbSQL.AppendLine("WHERE")
        stbSQL.AppendLine("    I.DELETE_FLG     = '0'")
        stbSQL.AppendLine("    AND")
        stbSQL.AppendLine("    I.IMAGE_STATUS   = '%I_STATUS%'")
        stbSQL.AppendLine("ORDER BY")
        stbSQL.AppendLine("     I.PRIORITY")
        stbSQL.AppendLine("    ,I.SLIP_DEFINE_ID")
        stbSQL.AppendLine("    ,I.IMAGE_ID")

        ' 作成したSQLの抽出条件部分をコンフィグから取得した値に置換します。
        stbSQL.Replace("%I_STATUS%", mdicConfig("INPUT_STATUS"))

        ' OracleDBに作成したSQLを送信して結果を得ます。
        Return MyBase.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)

    End Function
#End Region

#Region "依頼対象OCRデータの取得"
    ''' ======================================================================
    ''' メソッド名：GetOcrData
    ''' <summary>
    ''' 依頼対象OCRデータの取得
    ''' </summary>
    ''' <remarks></remarks>
    ''' ======================================================================
    Private Function GetOcrData() As DataTable

        ' 依頼対象データを抽出するためのSQLを作成します。
        Dim stbSQL As New StringBuilder(String.Empty)
        stbSQL.AppendLine("SELECT")
        stbSQL.AppendLine("    *")
        stbSQL.AppendLine("FROM")
        stbSQL.AppendLine("    T_JJ_OCR_RESULT")
        stbSQL.AppendLine("WHERE")
        stbSQL.AppendLine("    ITEM_004 IN (")
        stbSQL.AppendLine("        SELECT DISTINCT")
        stbSQL.AppendLine("            REPLACE(EXC_SUBJECT_NO,'-','')")
        stbSQL.AppendLine("        FROM")
        stbSQL.AppendLine("            T_JJ_IMAGE")
        stbSQL.AppendLine("        WHERE")
        stbSQL.AppendLine("            DELETE_FLG     = '0'")
        stbSQL.AppendLine("            AND")
        stbSQL.AppendLine("            IMAGE_STATUS   = '%I_STATUS%'")
        stbSQL.AppendLine("    )")

        ' 作成したSQLの抽出条件部分をコンフィグから取得した値に置換します。
        stbSQL.Replace("%I_STATUS%", mdicConfig("INPUT_STATUS"))

        ' OracleDBに作成したSQLを送信して結果を得ます。
        Return MyBase.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)

    End Function
#End Region

#Region "OCRデータ転送"
    Private Function OcrImportsMain(drImg As DataRow, drOcr As DataRow) As Boolean
        Try
            Dim blnResult As Boolean = True
            Dim strImageID As String = Convert.ToString(drImg.Item("IMAGE_ID"))
            Dim strSlipID As String = Convert.ToString(drImg.Item("SLIP_DEFINE_ID"))
            Dim lstOcr As New List(Of String)
            Dim intItemCount As Integer = 0
            For i As Integer = 1 To 500 Step 1
                Dim strItemName As String = "ITEM_" & i.ToString("000")
                Dim strValue As String = Convert.ToString(drOcr.Item(strItemName))
                If strValue.Equals("#END") Then
                    intItemCount = i - 1
                    Exit For
                End If

                Dim intType As Integer = ConvertOCR(strSlipID, i)
                Select Case intType
                    Case 1
                        Dim strVal() As String = ConvDate1(strValue)
                        lstOcr.Add(strVal(0))
                        lstOcr.Add(strVal(1))
                        lstOcr.Add(strVal(2))
                        lstOcr.Add(strVal(3))
                    Case 2
                        Dim strVal() As String = ConvDate2(strValue)
                        lstOcr.Add(strVal(0))
                        lstOcr.Add(strVal(1))
                        lstOcr.Add(strVal(2))
                        lstOcr.Add(strVal(3))
                    Case 3
                        Dim strVal() As String = ConvDate3(strValue)
                        lstOcr.Add(strVal(0))
                        lstOcr.Add(strVal(1))
                        lstOcr.Add(strVal(2))
                        lstOcr.Add(strVal(3))
                    Case 4
                        Dim strVal() As String = ConvDate4(strValue)
                        lstOcr.Add(strVal(0))
                        lstOcr.Add(strVal(1))
                        lstOcr.Add(strVal(2))
                    Case 5
                        Dim strVal() As String = ConvDate5(strValue)
                        lstOcr.Add(strVal(0))
                        lstOcr.Add(strVal(1))
                        lstOcr.Add(strVal(2))
                    Case 6
                        Dim strVal() As String = ConvDate6(strValue)
                        lstOcr.Add(strVal(0))
                        lstOcr.Add(strVal(1))
                    Case 7
                        Dim strVal() As String = ConvDate7(strValue)
                        lstOcr.Add(strVal(0))
                        lstOcr.Add(strVal(1))
                        lstOcr.Add(strVal(2))
                        lstOcr.Add(strVal(3))
                    Case Else
                        lstOcr.Add(strValue.Replace("★", "〓").Replace("#", "?"))
                End Select

            Next

            Dim strStatus As String = mdicConfig("OUTPUT_STATUS")
            If Not CheckCountOCR(strSlipID, intItemCount) Then
                strStatus = mdicConfig("OUTPUT_STATUS_ERROR")
                blnResult = False
                CommonLog.WriteLog("OCR項目数が不正です。IMAGE_ID=[" & strImageID & "]", EventLogEntryType.Error)
            End If

            Call UpdateImageData(strImageID, strStatus)

            Call InsertHistory(strImageID, strStatus)

            If Not blnResult Then
                Return blnResult
            End If

            Call InsertOcrTable(strImageID, lstOcr)

            Return blnResult

        Catch ex As Exception
            CommonLog.WriteLog(MethodBase.GetCurrentMethod.Name & "でエラーを検地しました", EventLogEntryType.Error)
            Throw ex
        End Try
    End Function
#End Region

#Region "OCRテーブル登録"
    Private Sub InsertOcrTable(strImageID As String, lstOcr As List(Of String))
        Dim stbSQL As New StringBuilder(String.Empty)
        Try
            ' 念のため削除を試みておきます
            mobjCommonDB.DB_ExecuteNonQuery("DELETE FROM T_JJ_OCR WHERE IMAGE_ID = " & strImageID)

            stbSQL.AppendLine("INSERT INTO T_JJ_OCR (")
            stbSQL.AppendLine("    IMAGE_ID")
            For i As Integer = 1 To lstOcr.Count Step 1
                stbSQL.AppendLine("    ,ITEM_" & i.ToString("000"))
            Next
            stbSQL.AppendLine(") VALUES (")
            stbSQL.AppendLine("    " & strImageID)
            For i As Integer = 1 To lstOcr.Count Step 1
                Dim strItemName As String = "ITEM_" & i.ToString("000")
                stbSQL.AppendLine("    ,'" & lstOcr(i - 1) & "'")
            Next
            stbSQL.AppendLine(")")

            mobjCommonDB.DB_ExecuteNonQuery(stbSQL.ToString)
        Catch ex As Exception
            CommonLog.WriteLog(MethodBase.GetCurrentMethod.Name & "でエラーを検地しました", EventLogEntryType.Error)
            CommonLog.WriteLog(stbSQL.ToString, EventLogEntryType.Error)
            Throw ex
        End Try
    End Sub
#End Region

#Region "T_JJ_IMAGEの更新"
    Private Sub UpdateImageData(ByVal strImageID As String, ByVal strStatus As String)
        Dim stbSQL As New StringBuilder(String.Empty)
        Try
            stbSQL.AppendLine("UPDATE")
            stbSQL.AppendLine("    T_JJ_IMAGE")
            stbSQL.AppendLine("SET")
            stbSQL.AppendLine("     IMAGE_STATUS = '__IMAGE_STATUS__'")
            stbSQL.AppendLine("    ,UPDATE_USER  = 'OcrDataImport'")
            stbSQL.AppendLine("    ,UPDATE_DATE  = SYSDATE")
            stbSQL.AppendLine("WHERE")
            stbSQL.AppendLine("    IMAGE_ID = __IMAGE_ID__")

            ' 作成したSQLの設定値の部分を実際の値に置換します。
            stbSQL.Replace("__IMAGE_STATUS__", strStatus)
            stbSQL.Replace("__IMAGE_ID__", strImageID)

            ' 作成したSQLを実行してT_RECEIPT_IMAGEを更新します。
            Dim intInsertRet As Integer = MyBase.mobjCommonDB.DB_ExecuteNonQuery(stbSQL.ToString)
            If Not intInsertRet = 1 Then
                Throw New Exception("イメージデータの更新に失敗しました。")
            End If

        Catch ex As Exception
            CommonLog.WriteLog(MethodBase.GetCurrentMethod.Name & "でエラーを検地しました", EventLogEntryType.Error)
            CommonLog.WriteLog(stbSQL.ToString, EventLogEntryType.Error)
            Throw ex
        End Try
    End Sub
#End Region

#Region "T_STATUS_HISTORYの登録"
    Private Sub InsertHistory(ByVal strImageID As String, ByVal strStatus As String)
        Dim stbSQL As New StringBuilder(String.Empty)
        Try
            ' イメージ状態履歴登録用SQLを作成します。
            stbSQL.AppendLine("INSERT INTO T_JJ_IMAGE_HISTORY (")
            stbSQL.AppendLine("     IMAGE_ID")
            stbSQL.AppendLine("    ,IMAGE_STATUS")
            stbSQL.AppendLine("    ,CREATE_DATE")
            stbSQL.AppendLine("    ,CREATE_USER")
            stbSQL.AppendLine(") VALUES (")
            stbSQL.AppendLine("     __IMAGE_ID__")
            stbSQL.AppendLine("    ,'__IMAGE_STATUS__'")
            stbSQL.AppendLine("    ,SYSTIMESTAMP")
            stbSQL.AppendLine("    ,'OcrDataImport'")
            stbSQL.AppendLine(")")

            ' 作成したSQLの設定値の部分を実際の値に置換します。
            stbSQL.Replace("__IMAGE_STATUS__", strStatus)
            stbSQL.Replace("__IMAGE_ID__", strImageID)

            ' イメージ状態履歴を登録します。
            Dim intInsertRet As Integer = MyBase.mobjCommonDB.DB_ExecuteNonQuery(stbSQL.ToString)
            If Not intInsertRet = 1 Then
                Throw New Exception("イメージ履歴の登録に失敗しました。")
            End If

        Catch ex As Exception
            CommonLog.WriteLog(MethodBase.GetCurrentMethod.Name & "でエラーを検地しました", EventLogEntryType.Error)
            CommonLog.WriteLog(stbSQL.ToString, EventLogEntryType.Error)
            Throw ex
        End Try

    End Sub
#End Region

#Region "OCRデータ転送方法判定"
    Private Function ConvertOCR(strSlipID As String, intItemNo As Integer) As Integer
        Try
            Select Case strSlipID
                Case "601115", "601214", "601313", "601412", "601146", "601245", "601139", "601238"
                    ' 傷病手当金
                    Select Case intItemNo
                        Case 7, 20, 32, 33, 34, 37, 38, 42, 43, 50, 207, 217, 218, 219, 220, 223, 224, 226, 227, 330, 331, 334, 337
                            Return 1
                        Case 59, 93, 127
                            Return 4
                        Case 175, 176, 185, 186, 195, 196
                            Return 7
                        Case Else
                            Return 0
                    End Select

                Case "611114", "611213", "611312", "611145", "611244", "611138", "611237"
                    ' 出産手当金
                    Select Case intItemNo
                        Case 7, 20, 30, 31, 32, 33, 36, 37, 40, 41, 46, 268
                            Return 1
                        Case 52, 86, 120, 154, 188
                            Return 4
                        Case 236, 237, 246, 247, 256, 257
                            Return 7
                        Case Else
                            Return 0
                    End Select

                Case "621113", "621212", "621120", "621229", "621113", "621212", "621120", "621229"
                    ' '出産育児一時金
                    Select Case intItemNo
                        Case 7, 20, 31, 32, 46, 51, 60, 61
                            Return 1
                        Case Else
                            Return 0
                    End Select

                Case "631112", "631211", "631129", "631228"
                    ' 埋葬料
                    Select Case intItemNo
                        Case 7, 20, 29, 33, 41, 52, 53
                            Return 1
                        Case Else
                            Return 0
                    End Select



                Case "601160", "601269", "601368", "601467", "601191", "601290", "601184", "601283"
                    ' 傷病手当金(新)
                    Select Case intItemNo
                        Case 7, 50, 334
                            Return 2
                        Case 20, 32, 33, 34, 37, 38, 42, 43, 207, 217, 218, 219, 220, 223, 224, 226, 227, 330, 331, 337
                            Return 3
                        Case 59, 93, 127
                            Return 5
                        Case 175, 176, 185, 186, 195, 196
                            Return 7
                        Case Else
                            Return 0
                    End Select

                Case "611169", "611268", "611367", "611190", "611299", "611183", "611282"
                    ' 出産手当金(新)
                    Select Case intItemNo
                        Case 7
                            Return 2
                        Case 20, 30, 31, 32, 33, 36, 37, 40, 41, 46, 268
                            Return 3
                        Case 52, 86, 120, 154, 188
                            Return 5
                        Case 236, 237, 246, 247, 256, 257
                            Return 7
                        Case Else
                            Return 0
                    End Select

                Case "621168", "621267", "621175", "621274", "621168", "621267", "621175", "621274"
                    ' '出産育児一時金(新)
                    Select Case intItemNo
                        Case 7, 31
                            Return 2
                        Case 20, 32, 46, 51, 60, 61
                            Return 3
                        Case Else
                            Return 0
                    End Select

                Case "621519"
                    ' 出産育児一時金(新)保険者間調整
                    Select Case intItemNo
                        Case 7, 20, 31, 32, 46, 51, 60, 61
                            Return 1
                        Case Else
                            Return 0
                    End Select

                Case "631167", "631266", "631174", "631273"
                    ' 埋葬料(新)
                    Select Case intItemNo
                        Case 7, 33
                            Return 2
                        Case 20, 29, 41, 52, 53
                            Return 3
                        Case Else
                            Return 0
                    End Select



                Case "641111", "641210", "641128", "641227"
                    ' 高額療養費
                    Select Case intItemNo
                        Case 7, 20, 32, 35, 38, 45, 48, 51
                            Return 1
                        Case 29
                            Return 4
                        Case 69
                            Return 6
                        Case Else
                            Return 0
                    End Select

                Case "661119", "661218", "661126", "661225"
                    ' 療養費
                    Select Case intItemNo
                        Case 7, 20, 31, 33, 42, 43, 45, 46, 48
                            Return 1
                        Case Else
                            Return 0
                    End Select

                Case "641166", "641265", "641173", "641272"
                    ' 高額療養費(新)
                    Select Case intItemNo
                        Case 7, 32, 35, 38
                            Return 2
                        Case 20, 45, 48, 51
                            Return 3
                        Case 29
                            Return 5
                        Case 69
                            Return 6
                        Case Else
                            Return 0
                    End Select

                Case "641517"
                    ' 高額療養費(新)保険者間調整
                    Select Case intItemNo
                        Case 7, 20, 32, 35, 38, 45, 48, 51
                            Return 1
                        Case 29
                            Return 4
                        Case 69
                            Return 6
                        Case Else
                            Return 0
                    End Select

                Case "661164", "661263", "661171", "661270", "661669", "661768", "661676", "661775"
                    ' 療養費(新)
                    Select Case intItemNo
                        Case 7, 31
                            Return 2
                        Case 20, 33, 42, 43, 45, 46, 48
                            Return 3
                        Case Else
                            Return 0
                    End Select

                Case "661515"
                    ' 療養費(新)保険者間調整
                    Select Case intItemNo
                        Case 7, 20, 31, 33, 42, 43, 45, 46, 48
                            Return 1
                        Case Else
                            Return 0
                    End Select

            End Select


            Return 0
        Catch ex As Exception
            CommonLog.WriteLog(MethodBase.GetCurrentMethod.Name & "でエラーを検地しました", EventLogEntryType.Error)
            Throw ex
        End Try
    End Function
#End Region

#Region "日付変換1(明大昭平令) YYMMDD"
    Private Function ConvDate1(strValue As String) As String()
        Try
            Dim strResult() As String = {String.Empty, String.Empty, String.Empty, String.Empty}
            Dim strDate() As String = SplitDate(strValue)
            Dim strWareki() As String = GetWareki(strDate)

            strResult(0) = strWareki(0)
            strResult(1) = strWareki(1)
            strResult(2) = strDate(2)
            strResult(3) = strDate(3)

            Return strResult
        Catch ex As Exception
            CommonLog.WriteLog(MethodBase.GetCurrentMethod.Name & "でエラーを検地しました", EventLogEntryType.Error)
            Throw ex
        End Try
    End Function
#End Region

#Region "日付変換2(昭平令) YYMMDD"
    Private Function ConvDate2(strValue As String) As String()
        Try
            Dim strResult() As String = {String.Empty, String.Empty, String.Empty, String.Empty}

            Dim strDate() As String = SplitDate(strValue)
            Dim strWareki() As String = GetWareki(strDate)

            Select Case strWareki(0)
                Case "1", "2", "9"
                    strResult(0) = "9"
                    strResult(1) = strDate(1)
                Case "3"
                    strResult(0) = "1"
                    strResult(1) = strWareki(1)
                Case "4"
                    strResult(0) = "2"
                    strResult(1) = strWareki(1)
                Case "5"
                    strResult(0) = "3"
                    strResult(1) = strWareki(1)
                Case String.Empty
                    strResult(0) = String.Empty
                    strResult(1) = strDate(1)

            End Select

            strResult(2) = strDate(2)
            strResult(3) = strDate(3)

            Return strResult
        Catch ex As Exception
            CommonLog.WriteLog(MethodBase.GetCurrentMethod.Name & "でエラーを検地しました", EventLogEntryType.Error)
            Throw ex
        End Try
    End Function
#End Region

#Region "日付変換3(平令) YYMMDD"
    Private Function ConvDate3(strValue As String) As String()
        Try
            Dim strResult() As String = {String.Empty, String.Empty, String.Empty, String.Empty}

            Dim strDate() As String = SplitDate(strValue)
            Dim strWareki() As String = GetWareki(strDate)

            Select Case strWareki(0)
                Case "1", "2", "3", "9"
                    strResult(0) = "9"
                    strResult(1) = strDate(1)
                Case "4"
                    strResult(0) = "1"
                    strResult(1) = strWareki(1)
                Case "5"
                    strResult(0) = "2"
                    strResult(1) = strWareki(1)
                Case String.Empty
                    strResult(0) = String.Empty
                    strResult(1) = strDate(1)
            End Select

            strResult(2) = strDate(2)
            strResult(3) = strDate(3)

            Return strResult

        Catch ex As Exception
            CommonLog.WriteLog(MethodBase.GetCurrentMethod.Name & "でエラーを検地しました", EventLogEntryType.Error)
            Throw ex
        End Try
    End Function
#End Region

#Region "日付変換4(明大昭平令) YYMM"
    Private Function ConvDate4(strValue As String) As String()
        Try
            Dim strResult() As String = {String.Empty, String.Empty, String.Empty}

            Dim strDate() As String = SplitDate(strValue)
            Dim strWareki() As String = GetWareki(strDate)

            strResult(0) = strWareki(0)
            strResult(1) = strWareki(1)
            strResult(2) = strDate(2)

            Return strResult
        Catch ex As Exception
            CommonLog.WriteLog(MethodBase.GetCurrentMethod.Name & "でエラーを検地しました", EventLogEntryType.Error)
            Throw ex
        End Try
    End Function
#End Region

#Region "日付変換5(平令) YYMM"
    Private Function ConvDate5(strValue As String) As String()
        Try
            Dim strResult() As String = {String.Empty, String.Empty, String.Empty}

            Dim strDate() As String = SplitDate(strValue)
            Dim strWareki() As String = GetWareki(strDate)

            Select Case strWareki(0)
                Case "1", "2", "3", "9"
                    strResult(0) = "9"
                    strResult(1) = strDate(1)
                Case "4"
                    strResult(0) = "1"
                    strResult(1) = strWareki(1)
                Case "5"
                    strResult(0) = "2"
                    strResult(1) = strWareki(1)
                Case String.Empty
                    strResult(0) = String.Empty
                    strResult(1) = strDate(1)
            End Select

            strResult(2) = strDate(2)

            Return strResult

        Catch ex As Exception
            CommonLog.WriteLog(MethodBase.GetCurrentMethod.Name & "でエラーを検地しました", EventLogEntryType.Error)
            Throw ex
        End Try
    End Function
#End Region

#Region "日付変換6(平令) YY"
    Private Function ConvDate6(strValue As String) As String()
        Try
            Dim strResult() As String = {String.Empty, String.Empty}

            Dim strDate() As String = SplitDate(strValue)
            Dim strWareki() As String = GetWareki(strDate)

            Select Case strWareki(0)
                Case "1", "2", "3", "9"
                    strResult(0) = "9"
                    strResult(1) = strDate(1)
                Case "4"
                    strResult(0) = "1"
                    strResult(1) = strWareki(1)
                Case "5"
                    strResult(0) = "2"
                    strResult(1) = strWareki(1)
                Case String.Empty
                    strResult(0) = String.Empty
                    strResult(1) = strDate(1)
            End Select

            Return strResult

        Catch ex As Exception
            CommonLog.WriteLog(MethodBase.GetCurrentMethod.Name & "でエラーを検地しました", EventLogEntryType.Error)
            Throw ex
        End Try
    End Function
#End Region

#Region "日付変換7 MMDD"
    Private Function ConvDate7(strValue As String) As String()
        Try
            Dim strResult() As String = {String.Empty, String.Empty, String.Empty, String.Empty}

            Dim strDate() As String = SplitDate(strValue)

            strResult(2) = strDate(2)
            strResult(3) = strDate(3)

            Return strResult
        Catch ex As Exception
            CommonLog.WriteLog(MethodBase.GetCurrentMethod.Name & "でエラーを検地しました", EventLogEntryType.Error)
            Throw ex
        End Try
    End Function
#End Region


#Region "OCRデータ項目数判定"
    Private Function CheckCountOCR(strSlipID As String, intItemNo As Integer) As Boolean
        Try
            Dim intCount As Integer = 0
            Select Case strSlipID
                Case "601115", "601214", "601313", "601412", "601146", "601245", "601139", "601238"
                    ' 傷病手当金
                    intCount = 342

                Case "611114", "611213", "611312", "611145", "611244", "611138", "611237"
                    ' 出産手当金
                    intCount = 273

                Case "621113", "621212", "621120", "621229", "621113", "621212", "621120", "621229"
                    ' '出産育児一時金
                    intCount = 64

                Case "631112", "631211", "631129", "631228"
                    ' 埋葬料
                    intCount = 58

                Case "601160", "601269", "601368", "601467", "601191", "601290", "601184", "601283"
                    ' 傷病手当金(新)
                    intCount = 342

                Case "611169", "611268", "611367", "611190", "611299", "611183", "611282"
                    ' 出産手当金(新)
                    intCount = 273

                Case "621168", "621267", "621175", "621274", "621168", "621267", "621175", "621274"
                    ' '出産育児一時金(新)
                    intCount = 64

                Case "621519"
                    ' 出産育児一時金(新)保険者間調整
                    intCount = 64

                Case "631167", "631266", "631174", "631273"
                    ' 埋葬料(新)
                    intCount = 58

                Case "641111", "641210", "641128", "641227"
                    ' 高額療養費
                    intCount = 70

                Case "661119", "661218", "661126", "661225"
                    ' 療養費
                    intCount = 51

                Case "641166", "641265", "641173", "641272"
                    ' 高額療養費(新)
                    intCount = 70

                Case "641517"
                    ' 高額療養費(新)保険者間調整
                    intCount = 70

                Case "661164", "661263", "661171", "661270", "661669", "661768", "661676", "661775"
                    ' 療養費(新)
                    intCount = 51

                Case "661515"
                    ' 療養費(新)保険者間調整
                    intCount = 51

            End Select

            If intCount <> intItemNo Then
                Return False
            End If

            Return True

        Catch ex As Exception
            CommonLog.WriteLog(MethodBase.GetCurrentMethod.Name & "でエラーを検地しました", EventLogEntryType.Error)
            Throw ex
        End Try
    End Function
#End Region

#Region "日付分割"
    Private Function SplitDate(strValue As String) As String()
        Try
            Dim strResult() As String = {String.Empty, String.Empty, String.Empty, String.Empty}

            ' 日部分が存在する場合
            If strValue.Length > 6 Then
                strResult(3) = strValue.Substring(6).Replace("#", "?").PadLeft(2, "0")
                strValue = strValue.Substring(0, 6)
            End If

            ' 月部分が存在する場合
            If strValue.Length > 4 Then
                strResult(2) = strValue.Substring(4).Replace("#", "?").PadLeft(2, "0")
                strValue = strValue.Substring(0, 4)
            End If

            ' 年部分が存在する場合
            If strValue.Length > 0 Then
                strResult(1) = strValue.PadLeft(4, "0")
                strResult(0) = "9"
            End If

            ' YYYYの一部に"#"を含むとき
            If strResult(1).Contains("#") Then
                strResult(0) = String.Empty
                strResult(1) = strResult(1).Replace("#", "?")
            End If

            Return strResult

        Catch ex As Exception
            CommonLog.WriteLog(MethodBase.GetCurrentMethod.Name & "でエラーを検地しました", EventLogEntryType.Error)
            Throw ex
        End Try
    End Function
#End Region

#Region "和暦の元号と年を取得"
    Private Function GetWareki(strValue() As String) As String()
        Try
            Dim strResult() As String = {String.Empty, String.Empty}

            ' 年の判定を行います
            Dim intY As Integer = 0
            If IsNumeric(strValue(1)) Then
                intY = Convert.ToInt32(strValue(1))
            Else
                strResult(0) = String.Empty
                strResult(1) = strValue(1)
                Return strResult
            End If

            ' 月の判定を行います
            Dim intM As Integer = 0
            If IsNumeric(strValue(2)) Then
                intM = Convert.ToInt32(strValue(2))
            Else
                intM = 12
            End If

            ' 日の判定を行います
            Dim intD As Integer = 0
            If IsNumeric(strValue(3)) Then
                intD = Convert.ToInt32(strValue(3))
            Else
                intM = 31
            End If

            ' 年月日の判定結果から和暦の元号を導出します
            Dim intDate As Integer = (intY * 10000) + (intM * 100) + intD
            Dim intBaseYear As Integer = 0
            If intDate < Gengo_StartDate.MEIJI Then
                ' 明治より過去の場合は西暦のままとします
                strResult(0) = 9
                strResult(1) = strValue(1)
                Return strResult

            ElseIf intDate < Gengo_StartDate.TAISYOU Then
                ' 明治以上、大正未満
                strResult(0) = "1"
                intBaseYear = Gengo_StartDate.MEIJI / 10000

            ElseIf intDate < Gengo_StartDate.SYOUWA Then
                ' 大正以上、昭和未満
                strResult(0) = "2"
                intBaseYear = Gengo_StartDate.TAISYOU / 10000

            ElseIf intDate < Gengo_StartDate.HEISEI Then
                ' 昭和以上、平成未満
                strResult(0) = "3"
                intBaseYear = Gengo_StartDate.SYOUWA / 10000

            ElseIf intDate < Gengo_StartDate.REIWA Then
                ' 生成以上、令和未満
                strResult(0) = "4"
                intBaseYear = Gengo_StartDate.HEISEI / 10000

            Else
                ' 令和以上
                strResult(0) = "5"
                intBaseYear = Gengo_StartDate.REIWA / 10000
            End If

            ' 西暦年を和暦に変換します
            strResult(1) = (intY - intBaseYear + 1).ToString("0000")

            Return strResult

        Catch ex As Exception
            CommonLog.WriteLog(MethodBase.GetCurrentMethod.Name & "でエラーを検地しました", EventLogEntryType.Error)
            Throw ex
        End Try
    End Function
#End Region

#Region "日付変換のテストロジック"
    Private Sub DateConvertTest()

        Dim strTestData() As String = { _
            "00000000", _
            "18680124", _
            "18680125", _
            "19120729", _
            "19120730", _
            "19261224", _
            "19261225", _
            "19890107", _
            "19890108", _
            "20190428", _
            "20190501", _
            "99991231", _
            "2#191120", _
            "20191#20", _
            "2019112#", _
            "20191#2#", _
            "20191120", _
            "2019112", _
            "201911", _
            "20191", _
            "2019", _
            "20", _
            "2" _
        }
        Dim stbResult As New StringBuilder(String.Empty)

        stbResult.AppendLine("日付変換1(明大昭平令) YYMMDD")
        For Each s As String In strTestData
            Dim strResult() As String = ConvDate1(s)
            stbResult.Append("    ")
            stbResult.Append(s)
            stbResult.Append(" → ")
            stbResult.AppendLine(Join(strResult, "/"))
        Next

        stbResult.AppendLine("日付変換2(昭平令) YYMMDD")
        For Each s As String In strTestData
            Dim strResult() As String = ConvDate2(s)
            stbResult.Append("    ")
            stbResult.Append(s)
            stbResult.Append(" → ")
            stbResult.AppendLine(Join(strResult, "/"))
        Next

        stbResult.AppendLine("日付変換3(平令) YYMMDD")
        For Each s As String In strTestData
            Dim strResult() As String = ConvDate3(s)
            stbResult.Append("    ")
            stbResult.Append(s)
            stbResult.Append(" → ")
            stbResult.AppendLine(Join(strResult, "/"))
        Next

        stbResult.AppendLine("日付変換4(明大昭平令) YYMM")
        For Each s As String In strTestData
            Dim strResult() As String = ConvDate4(s)
            stbResult.Append("    ")
            stbResult.Append(s)
            stbResult.Append(" → ")
            stbResult.AppendLine(Join(strResult, "/"))
        Next

        stbResult.AppendLine("日付変換5(平令) YYMM")
        For Each s As String In strTestData
            Dim strResult() As String = ConvDate5(s)
            stbResult.Append("    ")
            stbResult.Append(s)
            stbResult.Append(" → ")
            stbResult.AppendLine(Join(strResult, "/"))
        Next

        stbResult.AppendLine("日付変換6(平令) YY")
        For Each s As String In strTestData
            Dim strResult() As String = ConvDate6(s)
            stbResult.Append("    ")
            stbResult.Append(s)
            stbResult.Append(" → ")
            stbResult.AppendLine(Join(strResult, "/"))
        Next

        stbResult.AppendLine("日付変換7 MMDD")
        For Each s As String In strTestData
            Dim strResult() As String = ConvDate7(s)
            stbResult.Append("    ")
            stbResult.Append(s)
            stbResult.Append(" → ")
            stbResult.AppendLine(Join(strResult, "/"))
        Next

        Using sw As New StreamWriter("C:\BPS_TEST\523_TEST\DateConvertResult.txt", False, Encoding.GetEncoding("shift-jis"))
            sw.Write(stbResult.ToString)
        End Using

    End Sub
#End Region

End Class
