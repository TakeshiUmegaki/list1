﻿Imports CommonSystem
Imports System
Imports System.IO
Imports System.Text
Imports System.Text.RegularExpressions

''' <summary>
''' 帳票編集処理クラス
''' </summary>
''' <remarks>各帳票ごとの編集処理を実施する</remarks>
Public Class clsEditOutput

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="dicValue">Appコンフィギュレーションオブジェクト</param>
    ''' <remarks></remarks>
    Sub New(ByVal dicValue As Dictionary(Of String, String))
        MdicConfig = dicValue
        OutputListEast = New List(Of SortedList(Of Integer, String))
        OutputListWest = New List(Of SortedList(Of Integer, String))

        SubjectListEast = New List(Of String)
        SubjectListWest = New List(Of String)
    End Sub

#Region "定数"
    ' 空を明示的に示す定数
    Public Const EMPTY_VALUE As String = "EMPTY"
#End Region

#Region "インスタンス変数"
    ' シーケンス用インスタンス変数（東）
    Public seqNoEast As Integer = 0
    ' シーケンス用インスタンス変数（西）
    Public seqNoWest As Integer = 0

#End Region

#Region "クラス変数"
    '*** [2015/04/16 修正 Kuwahara] ***
    Public _strConvObj As clsComStringConw

#End Region

#Region "列挙体"
    ''' <summary>
    ''' 元号を識別するための列挙体
    ''' </summary>
    ''' <remarks></remarks>
    Enum Gengo
        MEIJI = 1             ' 明治
        TAISYOU = 2           ' 大正
        SYOUWA = 3            ' 昭和
        HEISEI = 4            ' 平成
        REIWA = 5             ' 令和
        SEIREKI = 9           ' 西暦
    End Enum

    ''' <summary>
    ''' 元号を算出するための値の列挙体
    ''' </summary>
    ''' <remarks>和暦の値から西暦の値を算出時に使用する</remarks>
    Enum CalcGengo
        MEIJI = 1867          ' 明治
        TAISYOU = 1911        ' 大正
        SYOUWA = 1925         ' 昭和
        HEISEI = 1988         ' 平成
        REIWA = 2018         ' 令和
    End Enum

    ''' <summary>
    ''' 元号の開始年月日
    ''' </summary>
    ''' <remarks>元号ごとの開始年月日(YYYYMMDD)</remarks>
    Enum Gengo_StartDate
        MEIJI = 18680125      ' 明治
        TAISYOU = 19120730    ' 大正
        SYOUWA = 19261225     ' 昭和
        HEISEI = 19890108     ' 平成
        REIWA = 20190501      ' 令和
    End Enum

    ''' <summary>
    ''' 元号の終了年月日
    ''' </summary>
    ''' <remarks>元号ごとの終了年月日(YYYYMMDD)</remarks>
    Enum Gengo_EndDate
        MEIJI = 19120730      ' 明治
        TAISYOU = 19261225    ' 大正
        SYOUWA = 19890107     ' 昭和
        HEISEI = 99991231     ' 平成      クライアント要望により平成31年以降も許諾する
        REIWA = 99991231      ' 令和
    End Enum

    ''' <summary>
    ''' 西暦の列挙対
    ''' </summary>
    ''' <remarks></remarks>
    Enum Seireki
        Gengo           ' 元号
        Year            ' 年
        Month           ' 月
        Day             ' 日
    End Enum

    ''' <summary>
    ''' チェック区分
    ''' </summary>
    ''' <remarks></remarks>
    Enum CheckType
        Match          ' 一致
        Include        ' 含む
    End Enum

    ''' <summary>
    ''' チェック対象
    ''' </summary>
    ''' <remarks></remarks>
    Enum CheckTarget
        EntryData        ' エントリーデータ
        DefectFlg        ' 不備フラグ
    End Enum

#End Region

#Region "プロパティ"
    ''' <summary>
    ''' コンフィギュレーションファイルのコレクション
    ''' </summary>
    ''' <remarks></remarks>
    Private _mdicConfig As Dictionary(Of String, String)
    Property MdicConfig() As Dictionary(Of String, String)
        Set(ByVal value As Dictionary(Of String, String))
            _mdicConfig = value
        End Set
        Get
            Return _mdicConfig
        End Get
    End Property

    ''' <summary>
    ''' メソッド定義のコレクション
    ''' </summary>
    ''' <remarks></remarks>
    Private _editMethodList As List(Of clsMethodDef)
    Property EditMethodList() As List(Of clsMethodDef)
        Get
            Return _editMethodList
        End Get
        Set(ByVal value As List(Of clsMethodDef))
            _editMethodList = value
        End Set
    End Property

    ''' <summary>
    ''' 出力レコード（東）のリスト
    ''' </summary>
    ''' <remarks></remarks>
    Private _outputListEast As List(Of SortedList(Of Integer, String))
    Property OutputListEast() As List(Of SortedList(Of Integer, String))
        Get
            Return _outputListEast
        End Get
        Set(ByVal value As List(Of SortedList(Of Integer, String)))
            _outputListEast = value
        End Set
    End Property

    ''' <summary>
    ''' 案件番号（東）のリスト
    ''' </summary>
    ''' <remarks></remarks>
    Private _subjectListEast As List(Of String)
    Property SubjectListEast() As List(Of String)
        Get
            Return _subjectListEast
        End Get
        Set(ByVal value As List(Of String))
            _subjectListEast = value
        End Set
    End Property

    ''' <summary>
    ''' 出力レコード（西）のリスト
    ''' </summary>
    ''' <remarks></remarks>
    Private _outputListWest As List(Of SortedList(Of Integer, String))
    Property OutputListWest() As List(Of SortedList(Of Integer, String))
        Get
            Return _outputListWest
        End Get
        Set(ByVal value As List(Of SortedList(Of Integer, String)))
            _outputListWest = value
        End Set
    End Property

    ''' <summary>
    ''' 案件番号（西）のリスト
    ''' </summary>
    ''' <remarks></remarks>
    Private _subjectListWest As List(Of String)
    Property SubjectListWest() As List(Of String)
        Get
            Return _subjectListWest
        End Get
        Set(ByVal value As List(Of String))
            _subjectListWest = value
        End Set
    End Property

    ''' <summary>
    ''' 処理対象の抽出データ（DataRow）のコレクション
    ''' </summary>
    ''' <remarks></remarks>
    Private _targetDatas As List(Of DataRow)
    WriteOnly Property TargetDatas() As List(Of DataRow)
        Set(ByVal value As List(Of DataRow))
            _targetDatas = value
        End Set
    End Property

#End Region

#Region "編集メソッド実行"
    ''' <summary>
    ''' 帳票編集処理
    ''' </summary>
    ''' <remarks>メソッド定義のコレクションに存在するメンバーすべてのメソッドを実行する</remarks>
    Public Sub executeEdit(Optional strExcSubjectNo As String = "")

        ' メソッド定義リストの反復子の取得
        Dim iterator As List(Of clsMethodDef).Enumerator = Nothing
        ' メソッド定義クラス
        Dim methodDef As clsMethodDef = Nothing
        ' 編集後文字列
        Dim retString As String = String.Empty
        ' 帳票ID
        Dim slipId As String
        ' 東西区分
        Dim ewKbn As String = String.Empty
        ' レコードリスト（東）
        Dim recListEast As New SortedList(Of Integer, String)
        ' レコードリスト（西）
        Dim recListWest As New SortedList(Of Integer, String)
        ' シーケンスNo編集メソッド実行有無フラグ（ループの初回のみ実行する）
        Dim seqNoExFlg As Boolean = True     ' 未実行（True）で初期化

        '変換文字ファイルを取得する *** [2015/04/16 修正 Kuwahara] ***
        Dim _OutSideMappingFile As String = MdicConfig("OUTSIDE_MAPPING_FILE")
        '文字列変換用オブジェクト生成
        _strConvObj = New clsComStringConw
        With _strConvObj
            .OutputKanjiSet = KanjiSet.UNICODE20
            .OutputKanjiEncoding = KanjiEncoding.UTF_8
            '.OutputKanjiSet = KanjiSet.JISX0208
            '.OutputKanjiEncoding = KanjiEncoding.Shift_JIS
            .MappingTableFileName = _OutSideMappingFile
            '.OutBoundChar = CChar(_OutSideConvStr)
        End With

        Try
            ' 1案件分の全データを出力バッファに設定し、コレクションに追加する
            For Each targetData As DataRow In _targetDatas
                '処理中のイメージIDのログ出力
                CommonLog.WriteLog("**** IMAGE_ID **** -> " & GetValue(targetData, "IMAGE_ID"), EventLogEntryType.Information)
                ' 帳票IDの取得
                slipId = targetData.Item("SLIP_DEFINE_ID").ToString
                ' 東西情報の取得
                ewKbn = targetData.Item("EXC_IMAGE_KEY01").ToString
                ' メソッド定義リストの反復子の取得
                iterator = _editMethodList.GetEnumerator
                ' 全メソッド定義の実行
                While iterator.MoveNext()
                    'メソッド編集定義オブジェクトの取得
                    methodDef = iterator.Current()
                    'メソッド定義情報のログ出力  *** [2015/1/14 Add] ***
                    writeErrorDataInfo(methodDef, targetData, False)
                    'メソッド呼び出しチェック（条件に一致しないとスキップする）
                    If isExec(methodDef, slipId, seqNoExFlg) Then
                        ' 編集メソッドの呼び出し
                        retString = Convert.ToString(CallByName(Me, methodDef.MethodName, CallType.Method, methodDef, targetData))
                        ' 実行した編集メソッドがD901なら実行済みにする
                        If methodDef.MethodName = MdicConfig("SEQ_METHOD") Then
                            seqNoExFlg = False    ' 実行済み（False）
                        End If
                        ' 東西判定
                        If ewKbn = "PE" Then
                            ' レコードリスト（東）へ追加
                            If Not recListEast.ContainsKey(methodDef.SeqNo) Then
                                recListEast.Add(methodDef.SeqNo, retString)
                            End If
                        ElseIf ewKbn = "PW" Then
                            ' レコードリスト（西）へ追加
                            If Not recListWest.ContainsKey(methodDef.SeqNo) Then
                                recListWest.Add(methodDef.SeqNo, retString)
                            End If
                        End If
                    End If
                End While
            Next
            ' 反復子解放
            iterator.Dispose()

            ' 2014/11/28 Add
            ' 全メソッド定義を再度列挙し、欠番があれば登録する（歯抜け対応）
            ' （東西区分[変数：ewKbn]は、同一案件内であれば全て同じであることが前提であるため、最後に取得したものを利用）
            Dim defValue As String = String.Empty
            For Each mthDef As clsMethodDef In _editMethodList
                ' デフォルト値の取得
                If mthDef.DefaultValue.ToUpper() = "NULL" Then
                    defValue = String.Empty
                Else
                    defValue = mthDef.DefaultValue
                End If
                If ewKbn = "PE" Then
                    ' レコードリスト（東）の欠落番号を探索し、デフォルト値をセット
                    If Not recListEast.ContainsKey(mthDef.SeqNo) Then
                        recListEast.Add(mthDef.SeqNo, defValue)
                    End If
                ElseIf ewKbn = "PW" Then
                    ' レコードリスト（西）の欠落番号を探索し、デフォルト値をセット
                    If Not recListWest.ContainsKey(mthDef.SeqNo) Then
                        recListWest.Add(mthDef.SeqNo, defValue)
                    End If
                End If
            Next

            ' 編集結果を納品ファイル出力用バッファに記憶
            If ewKbn = "PE" Then
                ' 出力レコード（東）のリストへ追加
                _outputListEast.Add(recListEast)
                _subjectListEast.Add(strExcSubjectNo)
            ElseIf ewKbn = "PW" Then
                ' 出力レコード（西）のリストへ追加
                _outputListWest.Add(recListWest)
                _subjectListWest.Add(strExcSubjectNo)
            End If

        Catch ex As Exception
            CommonLog.WriteLog("executeEditメソッドでエラーを検出しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            Throw ex
        End Try

    End Sub
#End Region

#Region "ステータス更新用ディクショナリの編集メソッド"
    ''' <summary>
    ''' editStatusDictionary
    ''' </summary>
    ''' <param name="statusDict">ステータス更新用ディクショナリ</param>
    ''' <returns>要素追加されたステータス更新用ディクショナリ</returns>
    ''' <remarks>ステータス更新用ディクショナリ
    ''' 　　　　　キー：イメージID
    '''           値：出力レコード件数
    ''' </remarks>
    Public Function editStatusDictionary(ByVal statusDict As Dictionary(Of String, Integer)) As Dictionary(Of String, Integer)
        Dim imageId As String = String.Empty
        Dim ewKbn As String = String.Empty

        Try
            For Each rowData As DataRow In _targetDatas
                'イメージID & 東西情報の取得
                imageId = GetValue(rowData, "IMAGE_ID")
                ewKbn = GetValue(rowData, "EXC_IMAGE_KEY01")
                '東西の出力バッファリストより現在のレコードカウント（出力件数）をセット
                If ewKbn = "PE" Then
                    ' レコードリスト（東）の出力件数を値としてセット
                    statusDict.Add(imageId, OutputListEast.Count)
                ElseIf ewKbn = "PW" Then
                    ' レコードリスト（西）の出力件数を値としてセット
                    statusDict.Add(imageId, OutputListWest.Count)
                End If
            Next
            Return statusDict

        Catch ex As Exception
            CommonLog.WriteLog("editStatusDictionaryメソッドでエラーを検出しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            Throw ex
        End Try

    End Function

#End Region

#Region "ユーティリティメソッド"
    ''' <summary>
    ''' IsNumeric
    ''' </summary>
    ''' <param name="checkStr">チェック対象の文字列</param>
    ''' <returns>指定した文字列が数値であればtrue、それ以外はFalse</returns>
    ''' <remarks></remarks>
    Public Overloads Shared Function IsNumeric(ByVal checkStr As String) As Boolean
        Return Double.TryParse(checkStr, System.Globalization.NumberStyles.Any, Nothing, 0.0#)
    End Function

    ''' <summary>
    ''' LengthB
    ''' </summary>
    ''' <param name="targetStr">対象の文字列</param>
    ''' <returns>文字列のバイト数</returns>
    ''' <remarks>半角1バイト、全角2バイトでカウントしたバイト数を返却します</remarks>
    Public Shared Function LengthB(ByVal targetStr As String) As Integer
        Return System.Text.Encoding.GetEncoding("Shift_JIS").GetByteCount(targetStr)
    End Function

    ''' <summary>
    ''' LastReplaceString
    ''' </summary>
    ''' <param name="targetStr">対象の文字列</param>
    ''' <param name="replaceStr">置き換え文字列</param>
    ''' <returns>置き換え文字で置き換えられた文字列</returns>
    ''' <remarks>文字列の最後の桁の文字を置き換え文字列で指定された文字列に置き換える</remarks>
    Public Shared Function LastReplaceString(ByVal targetStr As String, ByVal replaceStr As String) As String

        ' *** [2015/06/24] Mod Start ***
        '        Return Regex.Replace(targetStr, Right(targetStr, 1) & "$", replaceStr)
        ' 変換対象元が空だった場合
        If String.IsNullOrEmpty(targetStr) Then
            Return targetStr
        End If
        ' 最後尾の文字列を削除して置き換え文字列を連結
        Return targetStr.Remove(targetStr.Length - 1, 1) & replaceStr
        ' *** [2015/06/24] Mod End ***

    End Function

    ''' <summary>
    ''' RemoveNoNumChar
    ''' </summary>
    ''' <param name="targetStr">対象の文字列</param>
    ''' <returns>数値と"?"以外が削除された文字列</returns>
    ''' <remarks>引数として渡された値の数値と"?"以外の文字列を削除する</remarks>
    Public Shared Function RemoveNoNumChar(ByVal targetStr As String) As String
        If String.IsNullOrEmpty(targetStr) Then
            Return targetStr
        End If
        Return Regex.Replace(targetStr, "[^\d\?]*", "")
    End Function

    ''' <summary>
    ''' RemoveHalfByteChr
    ''' </summary>
    ''' <param name="targetStr">対象の文字列</param>
    ''' <returns>半角文字列が削除された文字列</returns>
    ''' <remarks>引数として渡された文字列より、半角の文字列を削除する</remarks>
    Public Shared Function RemoveHalfByteChr(ByVal targetStr As String) As String
        Return Regex.Replace(targetStr, "[a-zA-Z0-9!-/:-@¥[-`{-~｡-･ｦｧ-ｯｰｱ-ﾝﾞﾟ ]*", "")
    End Function

    ''' <summary>
    ''' isExec
    ''' </summary>
    ''' <param name="objMethodDef">メソッド編集定義オブジェクト</param>
    ''' <param name="slipId">帳票ID</param>
    ''' <param name="seqNoExFlg">シーケンスNo編集フラグ</param>
    ''' <returns>True:実行する False:実行しない</returns>
    ''' <remarks>メソッド定義オブジェクトから取得したメソッドを実行するかどうかをチェックする</remarks>
    Public Function isExec(ByVal objMethodDef As clsMethodDef, ByVal slipId As String, ByVal seqNoExFlg As Boolean) As Boolean
        'リターン値
        Dim retResult As Boolean = False
        '帳票IDに関係なく実行するメソッド名の取得
        Dim noSlipidMethod() As String = Split(MdicConfig("NO_SLIP_ID_METHOD"), ",")

        Try
            For Each execMethodName As String In noSlipidMethod
                ' 実行対象のメソッドとメソッド名が一致するか
                If objMethodDef.MethodName = execMethodName Then
                    'シーケンスNo取得メソッドの場合、初回実行なら実行可とする
                    If objMethodDef.MethodName = MdicConfig("SEQ_METHOD") Then
                        If seqNoExFlg = True Then
                            Return True
                        Else
                            Return False
                        End If
                    Else
                        ' シーケンスNo取得メソッドでなければ、毎回実行
                        Return True
                    End If
                End If
            Next

            ' メソッド定義ファイルの帳票IDが一致すれば実行
            For Each tmpSlipId As String In objMethodDef.SlipId
                If tmpSlipId = slipId Then
                    retResult = True
                    Exit For
                End If
            Next

            Return retResult

        Catch ex As Exception
            CommonLog.WriteLog("isExecでエラーを検出しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            Throw ex
        End Try

    End Function

    '''' <summary>
    '''' CheckDefectDate
    '''' </summary>
    '''' <param name="DateKind">日付区分</param>
    '''' <param name="EntryData">対象データ</param>
    '''' <param name="Target">チェック対象</param>
    '''' <param name="CheckType">チェック種別</param>
    '''' <param name="CheckValue">チェック値</param>
    '''' <param name="SetValue">該当時の設定値</param>
    '''' <param name="ReturnValue">返値</param>
    '''' <remarks>日付項目不備チェック</remarks>
    'Public Shared Sub CheckDefectData(ByVal DateKind As Seireki, ByVal EntryData() As String, _
    '                                  ByVal Target As CheckTarget, ByVal CheckType As CheckType, ByVal CheckValue As String, _
    '                                  ByVal SetValue As String, ByRef ReturnValue As String)

    '    Try
    '        '既に値が設定されている場合は処理しない
    '        'If Not String.IsNullOrEmpty(ReturnValue) Then
    '        '    Exit Sub
    '        'End If

    '        '既に｢#｣が設定されている場合は処理しない
    '        If ReturnValue.IndexOf("#") >= 0 Then
    '            Exit Sub
    '        End If

    '        '値がない場合は処理しない
    '        If String.IsNullOrEmpty(EntryData(0).Trim) AndAlso EntryData(1).Trim = "00" Then
    '            Exit Sub
    '        End If

    '        Dim value As String = String.Empty
    '        'チェック対象項目
    '        If Target = CheckTarget.DefectFlg Then
    '            '不備フラグ
    '            value = EntryData(1)
    '        ElseIf Target = CheckTarget.EntryData Then
    '            '入力値
    '            value = EntryData(0)
    '        End If

    '        Dim blnCheckResult As Boolean = True
    '        'チェックの仕方によって評価の方法を変える
    '        If CheckType = CheckType.Include Then
    '            'チェック対象文字を含む
    '            If value.IndexOf(CheckValue) >= 0 Then
    '                blnCheckResult = False
    '            End If
    '        ElseIf CheckType = CheckType.Match Then
    '            'チェック対象文字と一致する
    '            If value.Trim = CheckValue Then
    '                blnCheckResult = False
    '            End If
    '        End If

    '        If Not blnCheckResult Then
    '            Select Case DateKind
    '                Case Seireki.Gengo, Seireki.Year
    '                    ReturnValue = String.Empty.PadLeft(4, SetValue)
    '                Case Seireki.Month, Seireki.Day
    '                    ReturnValue = String.Empty.PadLeft(2, SetValue)
    '            End Select
    '        Else
    '            ReturnValue = EntryData(0)
    '        End If

    '    Catch ex As Exception
    '        CommonLog.WriteLog("CheckDefectDataでエラーを検出しました。", EventLogEntryType.Error)
    '        Throw ex
    '    End Try
    'End Sub

    ''' <summary>
    ''' ReplaceIncompleteDateForAll[不完全な日付データのチェック]
    ''' </summary>
    ''' <param name="strDateArr">日付情報の配列</param>
    ''' <param name="strDateDefArr">日付不備情報の配列</param>
    ''' <returns>返却値へ変換後の文字列</returns>
    ''' <remarks>日付フィールドの各項目が不完全かどうかをチェックし、返却値に変換する（元号、年、月、日）。</remarks>
    Public Overloads Shared Function ReplaceIncompleteDateForAll(ByVal strDateArr() As String, ByVal strDateDefArr() As String, Optional ByVal procType As String = "All") As String

        ' 編集後の文字列
        Dim retStr As String = String.Empty
        ' 日付項目定義
        Dim strEra As String = String.Empty
        Dim strYea As String = String.Empty
        Dim strMon As String = String.Empty
        Dim strDay As String = String.Empty
        ' 日付不備定義
        Dim strEraDef As String = String.Empty
        Dim strYeaDef As String = String.Empty
        Dim strMonDef As String = String.Empty
        Dim strDayDef As String = String.Empty
        ' 日付編集用
        Dim retStrYear As String = String.Empty
        Dim retStrMonth As String = String.Empty
        Dim retStrDay As String = String.Empty
        ' 日付書式用
        Const fmtChrYear As String = "0000"
        Dim fmtChrMonth As String = String.Empty
        Dim fmtChrDay As String = String.Empty

        Try
            ' 日付項目取得
            strEra = strDateArr(0)
            strYea = strDateArr(1)
            strMon = strDateArr(2)
            strDay = strDateArr(3)
            ' 日付不備項目取得
            strEraDef = strDateDefArr(0)
            strYeaDef = strDateDefArr(1)
            strMonDef = strDateDefArr(2)
            strDayDef = strDateDefArr(3)

            ' 元号、年、月、日の全てが未入力の場合、空文字を返却
            If String.IsNullOrEmpty(strEra) AndAlso _
               String.IsNullOrEmpty(strYea) AndAlso _
               String.IsNullOrEmpty(strMon) AndAlso _
               String.IsNullOrEmpty(strDay) Then
                Return EMPTY_VALUE
            End If

            '*======= procTypeが"part"（不正な値である桁の部分のみを変換する）の場合の月、日の編集 ========*
            ' [年は"0000"固定となる]
            ' 月の値が数値の場合は"00"形式に編集し、数値でない場合は"##"で、Nullの場合は"00"で格納
            If Not String.IsNullOrEmpty(strMon) AndAlso IsNumeric(strMon) Then
                fmtChrMonth = String.Format("{0:00}", Integer.Parse(strMon))
            ElseIf String.IsNullOrEmpty(strMon) Then
                fmtChrMonth = String.Empty.PadLeft(2, "0")
            ElseIf Not IsNumeric(strMon) Then
                fmtChrMonth = String.Empty.PadLeft(2, "#")
            End If
            ' 日の値が数値の場合は"00"形式に編集し、数値でない場合は"##"で、Nullの場合は"00"で格納
            If Not String.IsNullOrEmpty(strDay) AndAlso IsNumeric(strDay) Then
                fmtChrDay = String.Format("{0:00}", Integer.Parse(strDay))
            ElseIf String.IsNullOrEmpty(strDay) Then
                fmtChrDay = String.Empty.PadLeft(2, "0")
            ElseIf Not IsNumeric(strDay) Then
                fmtChrDay = String.Empty.PadLeft(2, "#")
            End If

            '*========= 元号、年、月、日のいずれかに"?"が入力されている場合 ========*
            If strEra.IndexOf("?") >= 0 OrElse _
               strYea.IndexOf("?") >= 0 OrElse _
               strMon.IndexOf("?") >= 0 OrElse _
               strDay.IndexOf("?") >= 0 Then

                ' ?の含まれている部分によって、"#"への置換えパターンが異なる場合（支払開始・終了日編集の場合）
                If procType = "part" Then
                    retStrYear = String.Empty
                    retStrMonth = String.Empty
                    retStrDay = String.Empty
                    '------- 元号、年の置換え処理 [2015/03/15] -----------------------------
                    'If strEra.IndexOf("?") >= 0 OrElse strYea.IndexOf("?") >= 0 Then
                    '［削除］--> ' ####MMDD形式
                    '［削除］--> retStr = String.Empty.PadLeft(4, "#") & fmtChrMonth & fmtChrDay
                    '［削除］2015/3/15 -->  元号、年に'?'が入力されている場合は、"####"に置換え
                    '［削除］2015/3/15 --> retStrYear = String.Empty.PadLeft(4, "#")
                    '［削除］2015/3/15 --> Else
                    '［削除］2015/3/15 --> 元号、年に'?'が入力にない場合は、"0000"に置換え
                    '［削除］2015/3/15 -->    retStrYear = fmtChrYear
                    'End If

                    ' 元号、年は、"0000"に置換え   [2015/03/15] 修正 
                    retStrYear = fmtChrYear

                    '------- 月の置換え処理 [2015/03/15] -----------------------------------
                    If strMon.IndexOf("?") >= 0 Then
                        '［削除］-->  0000##DD形式
                        '［削除］--> retStr = fmtChrYear & String.Empty.PadLeft(2, "#") & fmtChrDay
                        ' 月に'?'が入力されている場合は、"##"に置換え
                        retStrMonth = String.Empty.PadLeft(2, "#")
                    Else
                        ' 月に'?'が入力されていない場合は、月の値を"00"形式で格納
                        ' 月の値が数値でない場合は、"##"に置換え
                        retStrMonth = fmtChrMonth
                    End If
                    '------- 日の置換え処理 [2015/03/15] -----------------------------------
                    If strDay.IndexOf("?") >= 0 Then
                        '［削除］-->   0000MM##形式
                        '［削除］-->  retStr = fmtChrYear & fmtChrMonth & String.Empty.PadLeft(2, "#")
                        ' 日に'?'が入力されている場合は、"##"に置換え
                        retStrDay = String.Empty.PadLeft(2, "#")
                    Else
                        ' 日に'?'が入力されていない場合は、日の値を"00"形式で格納
                        ' 日の値が数値でない場合は、"##"に置換え
                        retStrDay = fmtChrDay
                    End If
                    '------- 年、月、日連結 [2015/03/15] -----------------------------------
                    retStr = retStrYear & retStrMonth & retStrDay

                ElseIf procType = "All" Then
                    '全て"#"で返却
                    retStr = String.Empty.PadLeft(8, "#")
                End If

                Return retStr
            End If

            ' 元号、年、月、日のうち、いずれかに数値でないものが含まれている場合、全て"#"で返却
            If (Not String.IsNullOrEmpty(strEra) AndAlso Not IsNumeric(strEra)) OrElse _
               (Not String.IsNullOrEmpty(strYea) AndAlso Not IsNumeric(strYea)) OrElse _
               (Not String.IsNullOrEmpty(strMon) AndAlso Not IsNumeric(strMon)) OrElse _
               (Not String.IsNullOrEmpty(strDay) AndAlso Not IsNumeric(strDay)) Then

                ' 数値でない部分によって、"#"への置換えが異なる場合（支払開始・終了日編集の場合）
                If procType = "part" Then
                    '------- 元号、年の置換え処理 [2015/03/15] -----------------------------
                    '［削除］2015/3/15 --> If (Not String.IsNullOrEmpty(strEra) AndAlso Not IsNumeric(strEra)) OrElse _
                    '［削除］2015/3/15 -->    (Not String.IsNullOrEmpty(strYea) AndAlso Not IsNumeric(strYea)) Then
                    '［削除］2015/3/15 -->     ' 元号、年が数値でない場合は、"####"に置換え
                    '［削除］2015/3/15 -->    retStrYear = String.Empty.PadLeft(4, "#")
                    '［削除］2015/3/15 --> Else
                    '［削除］2015/3/15 -->     ' 元号、年が数値の場合、"0000"に置換え
                    '［削除］2015/3/15 -->     retStrYear = fmtChrYear
                    'End If
                    '------- 元号、年はすべて"0000"へ置換え処理 [2015/03/15] -----------------------------
                    retStr = fmtChrYear & fmtChrMonth & fmtChrDay

                ElseIf procType = "All" Then
                    '全て"#"で返却
                    retStr = String.Empty.PadLeft(8, "#")
                End If

                Return retStr

            End If

            ' 元号、年、月、日のうち、いずれかの不備フラグに"02"が入力されている場合、全て"#"で返却
            If strEraDef.Trim = "02" OrElse _
               strYeaDef.Trim = "02" OrElse _
               strMonDef.Trim = "02" OrElse _
               strDayDef.Trim = "02" Then

                ' 不備フラグに"02"の含まれている部分によって、"#"への置換えが異なる場合（支払開始・終了日編集の場合）
                If procType = "part" Then
                    retStrYear = String.Empty
                    retStrMonth = String.Empty
                    retStrDay = String.Empty

                    '［削除］--> If strEraDef.Trim = "02" OrElse strYeaDef.Trim = "02" Then
                    '［削除］--> ####MMDD形式
                    '［削除］-->retStr = String.Empty.PadLeft(4, "#") & fmtChrMonth & fmtChrDay
                    '［削除］-->retStrYear = String.Empty.PadLeft(4, "#")
                    '------- 元号、年はすべて"0000"へ置換え処理 [2015/03/15] -----------------------------

                    '［削除］--> Else
                    ' 元号、年が数値の場合、"0000"に置換え
                    retStrYear = fmtChrYear

                    '［削除］--> End If
                    If strMonDef.Trim = "02" Then
                        '［削除］--> 0000##DD形式
                        '［削除］-->retStr = fmtChrYear & String.Empty.PadLeft(2, "#") & fmtChrDay
                        retStrMonth = String.Empty.PadLeft(2, "#")
                    Else
                        retStrMonth = fmtChrMonth
                    End If
                    If strDayDef.Trim = "02" Then
                        '［削除］--> 0000MM##形式
                        '［削除］-->retStr = fmtChrYear & fmtChrMonth & String.Empty.PadLeft(2, "#")
                        retStrDay = String.Empty.PadLeft(2, "#")
                    Else
                        retStrDay = fmtChrDay
                    End If
                    ' 編集後の年月日を連結
                    retStr = retStrYear & retStrMonth & retStrDay

                ElseIf procType = "All" Then
                    '全て"#"で返却
                    retStr = String.Empty.PadLeft(8, "#")
                End If

                Return retStr
            End If

            ' 元号に不正な値が入力されている場合、全て"#"で返却
            Dim eraVal As Integer = 0
            If Not String.IsNullOrEmpty(strEra) AndAlso IsNumeric(strEra) Then
                eraVal = Integer.Parse(strEra)
                If eraVal <> Gengo.MEIJI AndAlso _
                    eraVal <> Gengo.TAISYOU AndAlso _
                    eraVal <> Gengo.SYOUWA AndAlso _
                    eraVal <> Gengo.HEISEI AndAlso _
                    eraVal <> Gengo.REIWA AndAlso _
                    eraVal <> Gengo.SEIREKI Then
                    ' 支払開始・終了日編集の場合は、年は0000
                    If procType = "part" Then
                        '［削除］2015/3/15 --> retStr = fmtChrYear & String.Empty.PadLeft(4, "#")
                        '------- 元号、年はすべて"0000"へ置換え処理 [2015/03/15] -----------------------------
                        retStr = fmtChrYear & fmtChrMonth & fmtChrDay
                    ElseIf procType = "All" Then
                        retStr = String.Empty.PadLeft(8, "#")
                    End If
                End If
            End If

            Return retStr

        Catch ex As Exception
            CommonLog.WriteLog("IsIncompleteDateDataでエラーを検出しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog("procType -> " & procType, EventLogEntryType.Error)
            CommonLog.WriteLog("元号 -> " & strEra, EventLogEntryType.Error)
            CommonLog.WriteLog("年 -> " & strYea, EventLogEntryType.Error)
            CommonLog.WriteLog("月 -> " & strMon, EventLogEntryType.Error)
            CommonLog.WriteLog("日 -> " & strDay, EventLogEntryType.Error)
            CommonLog.WriteLog("元号(不備項目) -> " & strEraDef, EventLogEntryType.Error)
            CommonLog.WriteLog("年(不備項目) -> " & strYeaDef, EventLogEntryType.Error)
            CommonLog.WriteLog("月(不備項目) -> " & strMonDef, EventLogEntryType.Error)
            CommonLog.WriteLog("日(不備項目) -> " & strDayDef, EventLogEntryType.Error)
            Throw ex
        End Try
    End Function

    ''' <summary>
    ''' ReplaceIncompleteDateUntilMonth[不完全な日付データのチェック]
    ''' </summary>
    ''' <param name="strDateArr">日付情報の配列</param>
    ''' <param name="strDateDefArr">日付不備情報の配列</param>
    ''' <returns>返却値へ変換後の文字列</returns>
    ''' <remarks>日付フィールドの各項目が不完全かどうかをチェックし、返却値に変換する（元号、年、月）。</remarks>
    Public Overloads Shared Function ReplaceIncompleteDateUntilMonth(ByVal strDateArr() As String, ByVal strDateDefArr() As String) As String

        ' 編集後の文字列
        Dim retStr As String = String.Empty
        ' 日付項目定義
        Dim strEra As String = String.Empty
        Dim strYea As String = String.Empty
        Dim strMon As String = String.Empty
        ' 日付不備定義
        Dim strEraDef As String = String.Empty
        Dim strYeaDef As String = String.Empty
        Dim strMonDef As String = String.Empty

        Try
            ' 日付項目取得
            strEra = strDateArr(0)
            strYea = strDateArr(1)
            strMon = strDateArr(2)
            ' 日付不備項目取得
            strEraDef = strDateDefArr(0)
            strYeaDef = strDateDefArr(1)
            strMonDef = strDateDefArr(2)

            ' 元号、年、月の全てが未入力の場合、空文字を返却
            If String.IsNullOrEmpty(strEra) AndAlso _
               String.IsNullOrEmpty(strYea) AndAlso _
               String.IsNullOrEmpty(strMon) Then
                Return EMPTY_VALUE
            End If

            ' 元号、年、月のいずれかに"?"が入力されている場合、全て"#"で返却
            If strEra.IndexOf("?") >= 0 OrElse _
               strYea.IndexOf("?") >= 0 OrElse _
               strMon.IndexOf("?") >= 0 Then
                Return String.Empty.PadLeft(6, "#")
            End If

            ' 元号、年、月のいずれかに数値でない値が入力されている場合、全て"#"で返却  [2015/3/15　追加] 
            '▼----  *** [2015/04/16 修正 Kuwahara] ***
            If (Not String.IsNullOrEmpty(strEra) AndAlso Not IsNumeric(strEra)) OrElse _
               (Not String.IsNullOrEmpty(strYea) AndAlso Not IsNumeric(strYea)) OrElse _
               (Not String.IsNullOrEmpty(strMon) AndAlso Not IsNumeric(strMon)) Then
                Return String.Empty.PadLeft(6, "#")
            End If
            'If Not IsNumeric(strEra) OrElse _
            '   Not IsNumeric(strYea) OrElse _
            '   Not IsNumeric(strMon) Then
            'Return String.Empty.PadLeft(6, "#")
            'End If
            '▲----
            ' 元号、年、月のうち、いずれかの不備フラグに"02"が入力されている場合、全て"#"で返却
            If strEraDef.Trim = "02" OrElse _
               strYeaDef.Trim = "02" OrElse _
               strMonDef.Trim = "02" Then
                Return String.Empty.PadLeft(6, "#")
            End If

            ' 元号に不正な値が入力されている場合、全て"#"で返却
            Dim eraVal As Integer = 0
            If Not String.IsNullOrEmpty(strEra) AndAlso IsNumeric(strEra) Then
                eraVal = Integer.Parse(strEra)
                If eraVal <> Gengo.MEIJI AndAlso _
                    eraVal <> Gengo.TAISYOU AndAlso _
                    eraVal <> Gengo.SYOUWA AndAlso _
                    eraVal <> Gengo.HEISEI AndAlso _
                    eraVal <> Gengo.REIWA AndAlso _
                    eraVal <> Gengo.SEIREKI Then
                    retStr = String.Empty.PadLeft(6, "#")
                End If
            Else
                '▼----  *** [2015/04/16 修正 Kuwahara] ***
                'ｺﾒﾝﾄOUT
                'retStr = String.Empty.PadLeft(6, "#")
                '▲----
            End If

            Return retStr

        Catch ex As Exception
            CommonLog.WriteLog("ReplaceIncompleteDateUntilMonthでエラーを検出しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog("元号 -> " & strEra, EventLogEntryType.Error)
            CommonLog.WriteLog("年 -> " & strYea, EventLogEntryType.Error)
            CommonLog.WriteLog("月 -> " & strMon, EventLogEntryType.Error)
            CommonLog.WriteLog("元号(不備項目) -> " & strEraDef, EventLogEntryType.Error)
            CommonLog.WriteLog("年(不備項目) -> " & strYeaDef, EventLogEntryType.Error)
            CommonLog.WriteLog("月(不備項目) -> " & strMonDef, EventLogEntryType.Error)
            Throw ex
        End Try
    End Function

    ''' <summary>
    ''' padDateString[日付の各パートがNullの場合の0埋め]
    ''' </summary>
    ''' <param name="strEra">元号の文字列</param>
    ''' <param name="strYea">年の文字列</param>
    ''' <param name="strMon">月の文字列</param>
    ''' <param name="strDay">日の文字列</param>
    ''' <returns>年を0埋めした文字列</returns>
    ''' <remarks>日付の各パートが欠落している場合に、0埋めした文字列を返却する</remarks>
    Public Shared Function padDateString( _
                                    ByVal strEra As String, _
                                    ByVal strYea As String, _
                                    ByVal strMon As String, _
                                    ByVal strDay As String) As String
        ' 編集後の文字列
        Dim retStr As String = String.Empty
        Dim retStrYear As String = String.Empty
        Dim retStrMonth As String = String.Empty
        Dim retStrDay As String = String.Empty

        Try
            ' 元号か年が未入力の場合、"0000MMDD"形式で返却
            If String.IsNullOrEmpty(strEra) OrElse String.IsNullOrEmpty(strYea) Then
                retStrYear = "0000"
            End If
            ' 月が未入力の場合、"YYYY00DD"形式で返却
            If String.IsNullOrEmpty(strMon) Then
                'Return editDateForYYYYMMDD(strEra, strYea, "00", strDay)
                retStrMonth = "00"
            End If
            ' 日が未入力の場合、"YYYYMM00"形式で返却
            If String.IsNullOrEmpty(strDay) Then
                'Return editDateForYYYYMMDD(strEra, strYea, strMon, "00")
                retStrDay = "00"
            End If

            ' 0パディングの文字列編集　
            If Not String.IsNullOrEmpty(retStrYear) Then
                If String.IsNullOrEmpty(retStrMonth) Then
                    retStrMonth = String.Format("{0:00}", Integer.Parse(strMon))
                End If
                If String.IsNullOrEmpty(retStrDay) Then
                    retStrDay = String.Format("{0:00}", Integer.Parse(strDay))
                End If
                retStr = retStrYear & retStrMonth & retStrDay

                ' 月日がともにNullの場合　*** [2015/04/16 修正 Kuwahara] ***
            ElseIf Not String.IsNullOrEmpty(retStrMonth) And Not String.IsNullOrEmpty(retStrDay) Then
                retStr = editDateForYYYYMMDD(strEra, strYea, retStrMonth, retStrDay)

            ElseIf Not String.IsNullOrEmpty(retStrMonth) Then
                retStr = editDateForYYYYMMDD(strEra, strYea, retStrMonth, strDay)
            ElseIf Not String.IsNullOrEmpty(retStrDay) Then
                retStr = editDateForYYYYMMDD(strEra, strYea, strMon, retStrDay)
            End If

            Return retStr

        Catch ex As Exception
            CommonLog.WriteLog("padDateString[日付の各パートがNullの場合の0埋め]でエラーを検出しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog("元号 -> " & strEra, EventLogEntryType.Error)
            CommonLog.WriteLog("年 -> " & strYea, EventLogEntryType.Error)
            CommonLog.WriteLog("月 -> " & strMon, EventLogEntryType.Error)
            CommonLog.WriteLog("日 -> " & strDay, EventLogEntryType.Error)
            Throw ex
        End Try

    End Function


    ''' <summary>
    ''' padDateString[日付の各パートがNullの場合の0埋め]
    ''' </summary>
    ''' <param name="strEra">元号の文字列</param>
    ''' <param name="strYea">年の文字列</param>
    ''' <param name="strMon">月の文字列</param>
    ''' <returns>年を0埋めした文字列</returns>
    ''' <remarks>日付の各パートが欠落している場合に、0埋めした文字列を返却する</remarks>
    Public Shared Function padDateString( _
                                    ByVal strEra As String, _
                                    ByVal strYea As String, _
                                    ByVal strMon As String) As String
        ' 編集後の文字列
        Dim retStr As String = String.Empty
        Dim retStrYear As String = String.Empty
        Dim retStrMonth As String = String.Empty

        Try
            ' 元号か年が未入力の場合、"0000MMDD"形式で返却
            If String.IsNullOrEmpty(strEra) OrElse String.IsNullOrEmpty(strYea) Then
                retStrYear = "0000"
            End If
            ' 月が未入力の場合、"YYYY00DD"形式で返却
            If String.IsNullOrEmpty(strMon) Then
                retStrMonth = "00"
            End If

            ' 0パディングの文字列編集
            If Not String.IsNullOrEmpty(retStrYear) Then
                If String.IsNullOrEmpty(retStrMonth) Then
                    retStrMonth = String.Format("{0:00}", Integer.Parse(strMon))
                End If
                retStr = retStrYear & retStrMonth
            ElseIf Not String.IsNullOrEmpty(retStrMonth) Then
                retStr = editDateForYYYYMM(strEra, strYea, retStrMonth)
            End If

            Return retStr

        Catch ex As Exception
            CommonLog.WriteLog("padDateString[日付の各パートがNullの場合の0埋め]でエラーを検出しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog("元号 -> " & strEra, EventLogEntryType.Error)
            CommonLog.WriteLog("年 -> " & strYea, EventLogEntryType.Error)
            CommonLog.WriteLog("月 -> " & strMon, EventLogEntryType.Error)
            Throw ex
        End Try

    End Function

    ''' <summary>
    ''' IsDateForGengo
    ''' </summary>
    ''' <param name="eraVal">元号の数値</param>
    ''' <param name="yearVal">年の数値</param>
    ''' <param name="monVal">月の数値</param>
    ''' <param name="dayVal">日の数値</param>
    ''' <returns>True:日付の妥当性OK False:日付の妥当性NG</returns>
    ''' <remarks>元号が和暦の場合の日付の妥当性をチェック（年月日）</remarks>
    Public Overloads Shared Function IsDateForGengo( _
                                    ByVal eraVal As String, _
                                    ByVal yearVal As String, _
                                    ByVal monVal As String, _
                                    ByVal dayVal As String) As Boolean

        Dim strEditVal As String = String.Empty
        Dim cmpValStart As Integer = 0
        Dim cmpValEnd As Integer = 0
        Dim retValue As Boolean = False

        Try
            Select Case eraVal
                Case Gengo.MEIJI
                    strEditVal = String.Format("{0:0000}{1:00}{2:00}", yearVal + CalcGengo.MEIJI, Integer.Parse(monVal), Integer.Parse(dayVal))
                    cmpValStart = Gengo_StartDate.MEIJI : cmpValEnd = Gengo_EndDate.MEIJI
                Case Gengo.TAISYOU
                    strEditVal = String.Format("{0:0000}{1:00}{2:00}", yearVal + CalcGengo.TAISYOU, Integer.Parse(monVal), Integer.Parse(dayVal))
                    cmpValStart = Gengo_StartDate.TAISYOU : cmpValEnd = Gengo_EndDate.TAISYOU
                Case Gengo.SYOUWA
                    strEditVal = String.Format("{0:0000}{1:00}{2:00}", yearVal + CalcGengo.SYOUWA, Integer.Parse(monVal), Integer.Parse(dayVal))
                    cmpValStart = Gengo_StartDate.SYOUWA : cmpValEnd = Gengo_EndDate.SYOUWA
                Case Gengo.HEISEI
                    strEditVal = String.Format("{0:0000}{1:00}{2:00}", yearVal + CalcGengo.HEISEI, Integer.Parse(monVal), Integer.Parse(dayVal))
                    cmpValStart = Gengo_StartDate.HEISEI : cmpValEnd = Gengo_EndDate.HEISEI
                Case Gengo.REIWA
                    strEditVal = String.Format("{0:0000}{1:00}{2:00}", yearVal + CalcGengo.REIWA, Integer.Parse(monVal), Integer.Parse(dayVal))
                    cmpValStart = Gengo_StartDate.REIWA : cmpValEnd = Gengo_EndDate.REIWA
                Case Gengo.SEIREKI
                    ' 西暦の場合は、無条件にTrueをセットして終了
                    Return True
                    'Case Else
                    '    Throw New Exception("元号が不正な値です -> " & eraVal)
            End Select

            ' 対象の日付（和暦）が妥当かどうか
            If cmpValStart <= Integer.Parse(strEditVal) AndAlso cmpValEnd >= Integer.Parse(strEditVal) Then
                retValue = True
            Else
                retValue = False
            End If

            Return retValue

        Catch ex As Exception
            CommonLog.WriteLog("IsDateForGengoでエラーを検出しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog("元号 -> " & eraVal, EventLogEntryType.Error)
            CommonLog.WriteLog("年 -> " & yearVal, EventLogEntryType.Error)
            CommonLog.WriteLog("月 -> " & monVal, EventLogEntryType.Error)
            CommonLog.WriteLog("日 -> " & dayVal, EventLogEntryType.Error)
            Throw ex
        End Try
    End Function

    ''' <summary>
    ''' IsDateForGengo
    ''' </summary>
    ''' <param name="eraVal">元号の数値</param>
    ''' <param name="yearVal">年の数値</param>
    ''' <param name="monVal">月の数値</param>
    ''' <returns>True:日付の妥当性OK False:日付の妥当性NG</returns>
    ''' <remarks>元号が和暦の場合の日付の妥当性をチェック（年月）</remarks>
    Public Overloads Shared Function IsDateForGengo( _
                                    ByVal eraVal As String, _
                                    ByVal yearVal As String, _
                                    ByVal monVal As String) As Boolean

        Dim strEditVal As String = String.Empty
        Dim cmpValStart As Integer = 0
        Dim cmpValEnd As Integer = 0
        Dim retValue As Boolean = False

        Try
            Select Case eraVal
                Case Gengo.MEIJI
                    strEditVal = String.Format("{0:0000}{1:00}", yearVal + CalcGengo.MEIJI, Integer.Parse(monVal))
                    cmpValStart = Left(Gengo_StartDate.MEIJI, 6) : cmpValEnd = Left(Gengo_EndDate.MEIJI, 6)
                Case Gengo.TAISYOU
                    strEditVal = String.Format("{0:0000}{1:00}", yearVal + CalcGengo.TAISYOU, Integer.Parse(monVal))
                    cmpValStart = Left(Gengo_StartDate.TAISYOU, 6) : cmpValEnd = Left(Gengo_EndDate.TAISYOU, 6)
                Case Gengo.SYOUWA
                    strEditVal = String.Format("{0:0000}{1:00}", yearVal + CalcGengo.SYOUWA, Integer.Parse(monVal))
                    cmpValStart = Left(Gengo_StartDate.SYOUWA, 6) : cmpValEnd = Left(Gengo_EndDate.SYOUWA, 6)
                Case Gengo.HEISEI
                    strEditVal = String.Format("{0:0000}{1:00}", yearVal + CalcGengo.HEISEI, Integer.Parse(monVal))
                    cmpValStart = Left(Gengo_StartDate.HEISEI, 6) : cmpValEnd = Left(Gengo_EndDate.HEISEI, 6)
                Case Gengo.REIWA
                    strEditVal = String.Format("{0:0000}{1:00}", yearVal + CalcGengo.REIWA, Integer.Parse(monVal))
                    cmpValStart = Left(Gengo_StartDate.REIWA, 6) : cmpValEnd = Left(Gengo_EndDate.REIWA, 6)
                Case Gengo.SEIREKI
                    ' 西暦の場合は、無条件にTrueをセットして終了
                    Return True
                    'Case Else
                    '    Throw New Exception("元号が不正な値です -> " & eraVal)
            End Select

            ' 対象の日付（和暦）が妥当かどうか
            If cmpValStart <= Integer.Parse(strEditVal) AndAlso cmpValEnd >= Integer.Parse(strEditVal) Then
                retValue = True
            Else
                retValue = False
            End If

            Return retValue

        Catch ex As Exception
            CommonLog.WriteLog("IsDateForGengoでエラーを検出しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog("元号 -> " & eraVal, EventLogEntryType.Error)
            CommonLog.WriteLog("年 -> " & yearVal, EventLogEntryType.Error)
            CommonLog.WriteLog("月 -> " & monVal, EventLogEntryType.Error)
            Throw ex
        End Try
    End Function

    ''' <summary>
    ''' IsDateValid
    ''' </summary>
    ''' <param name="yearVal">チェックする年</param>
    ''' <param name="monVal">チェックする月</param>
    ''' <param name="dayVal">チェックする日</param>
    ''' <returns>指定した年・月・日が正しい日付であれば True、それ以外は False</returns>
    Public Overloads Shared Function IsDateValid(ByVal yearVal As Integer, ByVal monVal As Integer, ByVal dayVal As Integer) As Boolean
        If (DateTime.MinValue.Year > yearVal) OrElse (yearVal > DateTime.MaxValue.Year) Then
            Return False
        End If

        If (DateTime.MinValue.Month > monVal) OrElse (monVal > DateTime.MaxValue.Month) Then
            Return False
        End If

        Dim lastDay As Integer = DateTime.DaysInMonth(yearVal, monVal)

        If (DateTime.MinValue.Day > dayVal) OrElse (dayVal > lastDay) Then
            Return False
        End If

        Return True
    End Function

    ''' <summary>
    ''' IsDateValid
    ''' </summary>
    ''' <param name="monVal">チェックする月</param>
    ''' <param name="dayVal">チェックする日</param>
    ''' <returns>指定した月・日が正しい日付であれば True、それ以外は False</returns>
    Public Overloads Shared Function IsDateValid(ByVal monVal As Integer, ByVal dayVal As Integer) As Boolean
        If (DateTime.MinValue.Month > monVal) OrElse (monVal > DateTime.MaxValue.Month) Then
            Return False
        End If

        Select Case monVal
            Case 1, 3, 5, 7, 8, 10, 12
                If dayVal < 1 OrElse dayVal > 31 Then
                    Return False
                End If
            Case 4, 6, 9, 11
                If dayVal < 1 OrElse dayVal > 30 Then
                    Return False
                End If
            Case 2
                If dayVal < 1 OrElse dayVal > 29 Then
                    Return False
                End If
        End Select

        Return True
    End Function


    ''' <summary>
    ''' IsDateValid
    ''' </summary>
    ''' <param name="monVal">チェックする月</param>
    ''' <returns>指定した月が正しい日付であれば True、それ以外は False</returns>
    Public Overloads Shared Function IsDateValid(ByVal monVal As Integer) As Boolean
        If (DateTime.MinValue.Month > monVal) OrElse (monVal > DateTime.MaxValue.Month) Then
            Return False
        End If

        Return True
    End Function

    ''' <summary>
    ''' editDateForYYYYMMDD
    ''' </summary>
    ''' <param name="strEra">元号の文字列</param>
    ''' <param name="strYea">年の文字列</param>
    ''' <param name="strMon">月の文字列</param>
    ''' <param name="strDay">日の文字列</param>
    ''' <returns>編集後の文字列</returns>
    ''' <remarks>元号、年、月、日の入力内容よりYYYYMMDD形式の文字列を作成する</remarks>
    Public Shared Function editDateForYYYYMMDD( _
                                    ByVal strEra As String, _
                                    ByVal strYea As String, _
                                    ByVal strMon As String, _
                                    ByVal strDay As String) As String
        ' 編集後の文字列
        Dim retStr As String = String.Empty

        Try
            ' 月入力値編集
            Dim monVal As Integer = Integer.Parse(strMon)
            ' 日入力値編集
            Dim dayVal As Integer = Integer.Parse(strDay)
            ' 元号入力値取得
            Dim eraVal As Integer = Integer.Parse(strEra)
            ' 年編集
            Dim yearVal As Integer = Integer.Parse(strYea)
            Select Case eraVal
                Case Gengo.MEIJI
                    retStr = String.Format("{0:0000}{1:00}{2:00}", yearVal + CalcGengo.MEIJI, monVal, dayVal)
                Case Gengo.TAISYOU
                    retStr = String.Format("{0:0000}{1:00}{2:00}", yearVal + CalcGengo.TAISYOU, monVal, dayVal)
                Case Gengo.SYOUWA
                    retStr = String.Format("{0:0000}{1:00}{2:00}", yearVal + CalcGengo.SYOUWA, monVal, dayVal)
                Case Gengo.HEISEI
                    retStr = String.Format("{0:0000}{1:00}{2:00}", yearVal + CalcGengo.HEISEI, monVal, dayVal)
                Case Gengo.REIWA
                    retStr = String.Format("{0:0000}{1:00}{2:00}", yearVal + CalcGengo.REIWA, monVal, dayVal)
                Case Gengo.SEIREKI
                    retStr = String.Format("{0:0000}{1:00}{2:00}", yearVal, monVal, dayVal)
            End Select

            Return retStr

        Catch ex As Exception
            CommonLog.WriteLog("editDateYYYYMMDD[YYYYMMDD形式の編集メソッド]でエラーを検出しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog("元号 -> " & strEra, EventLogEntryType.Error)
            CommonLog.WriteLog("年 -> " & strYea, EventLogEntryType.Error)
            CommonLog.WriteLog("月 -> " & strMon, EventLogEntryType.Error)
            CommonLog.WriteLog("日 -> " & strDay, EventLogEntryType.Error)
            Throw ex
        End Try

    End Function

    ''' <summary>
    ''' editDateForYYYYMM
    ''' </summary>
    ''' <param name="strEra">元号の文字列</param>
    ''' <param name="strYea">年の文字列</param>
    ''' <param name="strMon">月の文字列</param>
    ''' <returns>編集後の文字列</returns>
    ''' <remarks>元号、年、月の入力内容よりYYYYMM形式の文字列を作成する</remarks>
    Public Shared Function editDateForYYYYMM( _
                                    ByVal strEra As String, _
                                    ByVal strYea As String, _
                                    ByVal strMon As String) As String
        ' 編集後の文字列
        Dim retStr As String = String.Empty

        Try
            ' 月入力値編集
            Dim monVal As Integer = Integer.Parse(strMon)
            ' 元号入力値取得
            Dim eraVal As Integer = Integer.Parse(strEra)
            ' 年編集
            Dim yearVal As Integer = Integer.Parse(strYea)
            Select Case eraVal
                Case Gengo.MEIJI
                    retStr = String.Format("{0:0000}{1:00}", yearVal + CalcGengo.MEIJI, monVal)
                Case Gengo.TAISYOU
                    retStr = String.Format("{0:0000}{1:00}", yearVal + CalcGengo.TAISYOU, monVal)
                Case Gengo.SYOUWA
                    retStr = String.Format("{0:0000}{1:00}", yearVal + CalcGengo.SYOUWA, monVal)
                Case Gengo.HEISEI
                    retStr = String.Format("{0:0000}{1:00}", yearVal + CalcGengo.HEISEI, monVal)
                Case Gengo.REIWA
                    retStr = String.Format("{0:0000}{1:00}", yearVal + CalcGengo.REIWA, monVal)
                Case Gengo.SEIREKI
                    retStr = String.Format("{0:0000}{1:00}", yearVal, monVal)
            End Select

            Return retStr

        Catch ex As Exception
            CommonLog.WriteLog("editDateYYYYMM[YYYYMM形式の編集メソッド]でエラーを検出しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog("元号 -> " & strEra, EventLogEntryType.Error)
            CommonLog.WriteLog("年 -> " & strYea, EventLogEntryType.Error)
            CommonLog.WriteLog("月 -> " & strMon, EventLogEntryType.Error)
            Throw ex
        End Try

    End Function

    '''' <summary>
    '''' editDateYYYYMMDD
    '''' </summary>
    '''' <param name="strDateArr">日付情報の配列</param>
    '''' <param name="strDateDefArr">日付不備情報の配列</param>
    '''' <returns>編集後の文字列</returns>
    '''' <remarks>元号、年、月、日の入力内容よりYYYYMMDD形式の文字列を作成する</remarks>
    'Public Shared Function editDateYYYYMMDD(ByVal strDateArr() As String, ByVal strDateDefArr() As String) As String
    '    ' 編集後の文字列
    '    Dim retStr As String = String.Empty
    '    ' 日付項目定義
    '    Dim strEra As String = String.Empty
    '    Dim strYea As String = String.Empty
    '    Dim strMon As String = String.Empty
    '    Dim strDay As String = String.Empty
    '    ' 日付不備定義
    '    Dim strEraDef As String = String.Empty
    '    Dim strYeaDef As String = String.Empty
    '    Dim strMonDef As String = String.Empty
    '    Dim strDayDef As String = String.Empty

    '    Try
    '        ' 日付項目取得
    '        strEra = strDateArr(0)
    '        strYea = strDateArr(1)
    '        strMon = strDateArr(2)
    '        strDay = strDateArr(3)
    '        ' 日付不備項目取得
    '        strEraDef = strDateDefArr(0)
    '        strYeaDef = strDateDefArr(1)
    '        strMonDef = strDateDefArr(2)
    '        strDayDef = strDateDefArr(3)

    '        ' 元号のみ未入力の場合、"0000MMDD"形式で返却
    '        If String.IsNullOrEmpty(strEra) AndAlso _
    '           Not String.IsNullOrEmpty(strYea) AndAlso _
    '           Not String.IsNullOrEmpty(strMon) AndAlso _
    '           Not String.IsNullOrEmpty(strDay) Then
    '            Return String.Format("{0:0000}{1:00}{2:00}", 0, Integer.Parse(strMon), Integer.Parse(strDay))
    '        End If

    '        ' 年のみ未入力の場合、"0000MMDD"形式で返却
    '        If String.IsNullOrEmpty(strYea) AndAlso _
    '           Not String.IsNullOrEmpty(strEra) AndAlso _
    '           Not String.IsNullOrEmpty(strMon) AndAlso _
    '           Not String.IsNullOrEmpty(strDay) Then
    '            Return String.Format("{0:0000}{1:00}{2:00}", 0, Integer.Parse(strMon), Integer.Parse(strDay))
    '        End If

    '        ' 月入力値編集
    '        Dim monVal As Integer = 0
    '        If Not String.IsNullOrEmpty(strMon) AndAlso IsNumeric(strMon) Then
    '            monVal = Integer.Parse(strMon)
    '        End If
    '        ' 日入力値編集
    '        Dim dayVal As Integer = 0
    '        If Not String.IsNullOrEmpty(strDay) AndAlso IsNumeric(strDay) Then
    '            dayVal = Integer.Parse(strDay)
    '        End If

    '        ' 元号入力値取得
    '        Dim eraVal As Integer = 0
    '        If Not String.IsNullOrEmpty(strEra) AndAlso IsNumeric(strEra) Then
    '            eraVal = Integer.Parse(strEra)
    '        End If

    '        ' 年編集
    '        Dim yearVal As Integer = 0
    '        If Not String.IsNullOrEmpty(strYea) AndAlso IsNumeric(strYea) Then
    '            yearVal = Integer.Parse(strYea)
    '            Select Case eraVal
    '                Case Gengo.MEIJI
    '                    retStr = String.Format("{0:0000}{1:00}{2:00}", yearVal + CalcGengo.MEIJI, monVal, dayVal)
    '                Case Gengo.TAISYOU
    '                    retStr = String.Format("{0:0000}{1:00}{2:00}", yearVal + CalcGengo.TAISYOU, monVal, dayVal)
    '                Case Gengo.SYOUWA
    '                    retStr = String.Format("{0:0000}{1:00}{2:00}", yearVal + CalcGengo.SYOUWA, monVal, dayVal)
    '                Case Gengo.HEISEI
    '                    retStr = String.Format("{0:0000}{1:00}{2:00}", yearVal + CalcGengo.HEISEI, monVal, dayVal)
    '                Case Gengo.SEIREKI
    '                    retStr = String.Format("{0:0000}{1:00}{2:00}", yearVal, monVal, dayVal)
    '                Case Else
    '                    ' 元号がNullか不正な値の場合だった場合どうするか？
    '                    retStr = String.Format("{0:0000}{1:00}{2:00}", yearVal, monVal, dayVal)
    '            End Select
    '        Else
    '            ' 年がNullか不正な値の場合だった場合どうするか？
    '            retStr = String.Format("{0:0000}{1:00}{2:00}", yearVal, monVal, dayVal)
    '        End If

    '        Return retStr

    '    Catch ex As Exception
    '        CommonLog.WriteLog("editDateYYYYMMDD[YYYYMMDD形式の編集メソッド]でエラーを検出しました。", EventLogEntryType.Error)
    '        CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
    '        CommonLog.WriteLog("元号 -> " & strEra, EventLogEntryType.Error)
    '        CommonLog.WriteLog("年 -> " & strYea, EventLogEntryType.Error)
    '        CommonLog.WriteLog("月 -> " & strMon, EventLogEntryType.Error)
    '        CommonLog.WriteLog("日 -> " & strDay, EventLogEntryType.Error)
    '        Throw ex
    '    End Try

    'End Function

    '''' <summary>
    '''' editDateMMDD
    '''' </summary>
    '''' <param name="strDateArr">日付情報の配列</param>
    '''' <param name="strDateDefArr">日付不備情報の配列</param>
    '''' <returns>編集後の文字列</returns>
    '''' <remarks>元号、年、月、日の入力内容よりYYYYMMDD形式の文字列を作成する(YYYYは固定値)</remarks>
    'Public Shared Function editDateMMDD(ByVal strDateArr() As String, _
    '                                    ByVal strDateDefArr() As String) As String

    '    ' 編集後の文字列
    '    Dim EditStr As String = String.Empty
    '    Dim retStr(3) As String

    '    '日付チェックする際の配列(エントリー値, 不備フラグ)
    '    Dim CheckValue(1) As String
    '    For i As Integer = 0 To retStr.Length - 1
    '        retStr(i) = ""
    '    Next

    '    ' 日付項目定義
    '    Dim strEra As String = String.Empty
    '    Dim strYea As String = String.Empty
    '    Dim strMon As String = String.Empty
    '    Dim strDay As String = String.Empty

    '    ' 日付不備定義
    '    Dim strEraDef As String = String.Empty
    '    Dim strYeaDef As String = String.Empty
    '    Dim strMonDef As String = String.Empty
    '    Dim strDayDef As String = String.Empty

    '    Try
    '        ' 日付項目取得
    '        strEra = strDateArr(0)
    '        strYea = strDateArr(1)
    '        strMon = strDateArr(2)
    '        strDay = strDateArr(3)

    '        ' 日付不備項目取得
    '        strEraDef = strDateDefArr(0)
    '        strYeaDef = strDateDefArr(1)
    '        strMonDef = strDateDefArr(2)
    '        strDayDef = strDateDefArr(3)

    '        ' 元号、年、月、日の全てが未入力の場合、空文字を返却
    '        If String.IsNullOrEmpty(strEra) AndAlso _
    '           String.IsNullOrEmpty(strYea) AndAlso _
    '           String.IsNullOrEmpty(strMon) AndAlso _
    '           String.IsNullOrEmpty(strDay) Then
    '            Return String.Empty
    '        End If

    '        ' ↓元号・年・月・日のいずれかに｢?｣を含むもしくは不備フラグが｢02｣なら当該文字を｢#｣で返却
    '        ' ↓元号
    '        CheckValue(0) = strEra
    '        CheckValue(1) = strEraDef
    '        Call CheckDefectData(Seireki.Gengo, CheckValue, CheckTarget.EntryData, CheckType.Include, "?", "#", retStr(0))
    '        Call CheckDefectData(Seireki.Gengo, CheckValue, CheckTarget.DefectFlg, CheckType.Match, "02", "#", retStr(0))

    '        ' ↓年
    '        CheckValue(0) = strYea
    '        CheckValue(1) = strYeaDef
    '        Call CheckDefectData(Seireki.Year, CheckValue, CheckTarget.EntryData, CheckType.Include, "?", "#", retStr(1))
    '        Call CheckDefectData(Seireki.Year, CheckValue, CheckTarget.DefectFlg, CheckType.Match, "02", "#", retStr(1))

    '        ' ↓月
    '        CheckValue(0) = strMon
    '        CheckValue(1) = strMonDef
    '        Call CheckDefectData(Seireki.Month, CheckValue, CheckTarget.EntryData, CheckType.Include, "?", "#", retStr(2))
    '        Call CheckDefectData(Seireki.Month, CheckValue, CheckTarget.DefectFlg, CheckType.Match, "02", "#", retStr(2))

    '        ' ↓日
    '        CheckValue(0) = strDay
    '        CheckValue(1) = strDayDef
    '        Call CheckDefectData(Seireki.Day, CheckValue, CheckTarget.EntryData, CheckType.Include, "?", "#", retStr(3))
    '        Call CheckDefectData(Seireki.Day, CheckValue, CheckTarget.DefectFlg, CheckType.Match, "02", "#", retStr(3))
    '        ' ↑元号・年・月・日のいずれかに｢?｣を含むもしくは不備フラグが｢02｣なら当該文字を｢#｣で返却


    '        ' 元号入力値格納
    '        If String.IsNullOrEmpty(retStr(0)) Then
    '            If Not String.IsNullOrEmpty(strEra) AndAlso IsNumeric(strEra) Then
    '                retStr(0) = strEra
    '            Else
    '                retStr(0) = "0"
    '            End If
    '        End If
    '        ' 年入力値格納
    '        If String.IsNullOrEmpty(retStr(1)) Then
    '            If Not String.IsNullOrEmpty(strYea) AndAlso IsNumeric(strYea) Then
    '                retStr(1) = String.Format("{0:0000}", CInt(strYea))
    '            Else
    '                retStr(1) = "0000"
    '            End If
    '        End If

    '        ' 月入力値格納
    '        If String.IsNullOrEmpty(retStr(2)) Then
    '            If Not String.IsNullOrEmpty(strMon) AndAlso IsNumeric(strMon) Then
    '                retStr(2) = String.Format("{0:00}", CInt(strMon))
    '            Else
    '                retStr(2) = "00"
    '            End If
    '        End If

    '        ' 日入力値格納
    '        If String.IsNullOrEmpty(retStr(3)) Then
    '            If Not String.IsNullOrEmpty(strDay) AndAlso IsNumeric(strDay) Then
    '                retStr(3) = String.Format("{0:00}", CInt(strDay))
    '            Else
    '                retStr(3) = "00"
    '            End If
    '        End If

    '        '↓戻値編集
    '        ' 元号・年未入力の場合、"0000MMDD"形式で返却
    '        If String.IsNullOrEmpty(strEra) AndAlso _
    '           String.IsNullOrEmpty(strYea) AndAlso _
    '       Not String.IsNullOrEmpty(strMon) AndAlso _
    '       Not String.IsNullOrEmpty(strDay) Then
    '            Return retStr(1) & retStr(2) & retStr(3)
    '        End If

    '        '日付編集
    '        '年・月・日は｢0｣埋め
    '        If Not String.IsNullOrEmpty(retStr(1)) AndAlso IsNumeric(retStr(1)) Then
    '            Select Case Integer.Parse(retStr(0))
    '                Case Gengo.MEIJI
    '                    EditStr = (CInt(retStr(1)) + CalcGengo.MEIJI).ToString & retStr(2) & retStr(3)
    '                Case Gengo.TAISYOU
    '                    EditStr = (CInt(retStr(1)) + CalcGengo.TAISYOU).ToString & retStr(2) & retStr(3)
    '                Case Gengo.SYOUWA
    '                    EditStr = (CInt(retStr(1)) + CalcGengo.SYOUWA).ToString & retStr(2) & retStr(3)
    '                Case Gengo.HEISEI
    '                    EditStr = (CInt(retStr(1)) + CalcGengo.HEISEI).ToString & retStr(2) & retStr(3)
    '                Case Gengo.SEIREKI
    '                    EditStr = retStr(1) & retStr(2) & retStr(3)
    '                Case Else
    '                    If String.IsNullOrEmpty(strEra) Then
    '                        EditStr = retStr(1) & retStr(2) & retStr(3)
    '                    Else
    '                        ' 元号が不正な値の場合だった場合どうするか？
    '                        EditStr = retStr(1) & retStr(2) & retStr(3)
    '                    End If
    '            End Select
    '        Else
    '            '年がNullか不正な値の場合だった場合
    '            EditStr = retStr(1) & retStr(2) & retStr(3)
    '        End If

    '        Return EditStr

    '    Catch ex As Exception
    '        CommonLog.WriteLog("editDateMMDD[MMDD形式の編集メソッド]でエラーを検出しました。", EventLogEntryType.Error)
    '        CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
    '        CommonLog.WriteLog("元号 -> " & strEra, EventLogEntryType.Error)
    '        CommonLog.WriteLog("年 -> " & strYea, EventLogEntryType.Error)
    '        CommonLog.WriteLog("月 -> " & strMon, EventLogEntryType.Error)
    '        CommonLog.WriteLog("日 -> " & strDay, EventLogEntryType.Error)
    '        Throw ex
    '    End Try

    'End Function

    ''' <summary>
    ''' writeErrorDataInfo
    ''' </summary>
    ''' <param name="methodDef">メソッド定義オブジェクト</param>
    ''' <param name="targetData">対象データのDataRowオブジェクト</param>
    ''' <param name="detailFlg">詳細表示を行うかどうか</param>
    ''' <remarks>エラー時のメソッド定義オブジェクトと対象レコード情報のログ出力を行う</remarks>
    Public Sub writeErrorDataInfo(ByVal methodDef As clsMethodDef, ByVal targetData As DataRow, Optional ByVal detailFlg As Boolean = True)
        'Errorタイプの設定
        Dim errType As String = String.Empty
        If detailFlg Then
            errType = EventLogEntryType.Error
        Else
            errType = EventLogEntryType.Information
        End If

        'メソッド定義オブジェクト情報出力
        CommonLog.WriteLog("SEQNo. -> " & methodDef.SeqNo & _
                           "  納品項目名 -> " & methodDef.Name & _
                           "  メソッド名 -> " & methodDef.MethodName, errType)
        If detailFlg Then
            Dim i As Integer = 0    '配列インデックスワーク
            For Each itemColumn As String In methodDef.InputItems
                i += 1
                CommonLog.WriteLog("入力項目" & i & " -> " & itemColumn, errType)
            Next
            i = 0
            For Each paramValue As String In methodDef.MethodParam
                i += 1
                CommonLog.WriteLog("引数" & i & " -> " & paramValue, errType)
            Next
            i = 0
            For Each slipIdValue As String In methodDef.SlipId
                i += 1
                CommonLog.WriteLog("帳票ID" & i & " -> " & slipIdValue, errType)
            Next
            CommonLog.WriteLog("デフォルト値 -> " & methodDef.DefaultValue, errType)

            '対象テーブル情報出力
            CommonLog.WriteLog("IMAGE_ID -> " & GetValue(targetData, "IMAGE_ID"), errType)
            For Each itemColumn As String In methodDef.InputItems
                CommonLog.WriteLog(itemColumn & " -> " & GetValue(targetData, itemColumn), errType)
            Next
        End If
    End Sub

#End Region

#Region "D101[半角項目の編集メソッド]"
    ''' <summary>
    ''' D101
    ''' </summary>
    ''' <param name="methodDef">納品編集定義情報</param>
    ''' <param name="targetData">エントリ結果</param>
    ''' <returns>編集後の文字列</returns>
    ''' <remarks>引数で指定された値によって、指定された項目のパディング処理や置き換え処理などを行う</remarks>
    Public Function D101(ByVal methodDef As clsMethodDef, ByVal targetData As DataRow) As String
        ' 編集後の文字列
        Dim retStr As String = String.Empty
        Try
            ' 編集項目内容取得
            Dim itemValue As String = GetValue(targetData, methodDef.InputItems(0))
            ' 編集不備項目内容取得
            Dim itemDefcValue As String = GetValue(targetData, methodDef.InputItems(0) & "_DEF")

            ' 引数内容取得
            Dim argValues As String() = methodDef.MethodParam
            ' 納品桁数のチェック
            If String.IsNullOrEmpty(argValues(3)) OrElse Not IsNumeric(argValues(3)) Then
                Throw New Exception("半角項目の編集処理で引数に不正な値が設定されています(第4引数) -> " & argValues(3))
            End If
            ' 納品桁数の取得
            Dim limitLen As Integer = Integer.Parse(argValues(3))

            ' 編集項目がNullの場合、第2引数(未入力時の編集方法)により編集処理を分岐
            If String.IsNullOrEmpty(itemValue) Then
                ' 第2引数がNullの場合
                If String.IsNullOrEmpty(argValues(1)) Then
                    Return itemValue
                End If
                If argValues(1) = "0" Then
                    ' 第2引数が"0"の場合
                    retStr = itemValue.PadLeft(limitLen, "0")
                ElseIf argValues(1) = "S" Then
                    ' 第2引数が"S"の場合
                    retStr = itemValue.PadLeft(limitLen)
                Else
                    Throw New Exception("半角項目の編集処理で引数に不正な値が設定されています(第2引数) -> " & argValues(1))
                End If

                Return retStr
            End If

            ' 不備項目の内容が"02"(桁オーバー)の場合
            If Not String.IsNullOrEmpty(itemDefcValue) AndAlso Trim(itemDefcValue) = "02" Then
                ' 第3引数がNullの場合、第4引数の値（桁数）でカット
                If String.IsNullOrEmpty(argValues(2)) Then
                    retStr = itemValue.Substring(0, limitLen)
                ElseIf argValues(2) = "#" Then
                    '第3引数が"#"の場合、最終文字を"#"で置き換え
                    retStr = LastReplaceString(itemValue, "#")
                ElseIf argValues(2) = "A#" Then
                    '第3引数が"A#"の場合、納品桁数分"#"で埋める   *** [2015/1/13 修正] ***
                    retStr = String.Empty.PadLeft(limitLen, "#")
                ElseIf argValues(2) = "9" Then
                    '第3引数が"9"の場合、納品桁数分"9"を埋める
                    retStr = String.Empty.PadLeft(limitLen, "9")
                Else
                    Throw New Exception("半角項目の編集処理で引数に不正な値が設定されています(第3引数) -> " & argValues(2))
                End If
            Else
                ' 第1引数(編集方法)がNull以外の場合
                If Not String.IsNullOrEmpty(argValues(0)) Then
                    ' 編集項目の値の中より数値と「?」以外の文字を削除する[2015/3/4 仕変]
                    Dim itemValueAfterReomove As String = RemoveNoNumChar(itemValue)
                    ' 納品桁数（バイト数）－ 編集項目のバイト数
                    'Dim itemLenDiff As Integer = limitLen - LengthB(itemValue)
                    Dim itemLenDiff As Integer = limitLen - LengthB(itemValueAfterReomove)

                    ' 編集項目の長さが納品桁数に満たない場合、指定に応じてパディング
                    If itemLenDiff > 0 Then
                        Select Case argValues(0)
                            Case "L0"
                                ' 前0パディング
                                retStr = itemValueAfterReomove.PadLeft(limitLen, "0")
                            Case "R0"
                                ' 後0パディング
                                retStr = itemValueAfterReomove.PadRight(limitLen, "0")
                            Case "LS"
                                ' 前スペースパディング
                                retStr = itemValueAfterReomove.PadLeft(limitLen)
                            Case "RS"
                                ' 後スペースパディング
                                retStr = itemValueAfterReomove.PadRight(limitLen)
                            Case "A#"
                                ' 納品桁数分"#"を埋める *** [2015/1/13 追加] ***
                                retStr = String.Empty.PadLeft(limitLen, "#")
                            Case "K"
                                ' 編集項目の値をそのままセット　*** [2015/3/4 追加] ***
                                retStr = itemValue
                        End Select
                    Else
                        If itemLenDiff < 0 Then
                            ' 不備項目の内容が"02"(桁オーバー)ではないが桁数がオーバーしている場合
                            ' 第3引数がNullの場合
                            If String.IsNullOrEmpty(argValues(2)) Then
                                retStr = itemValueAfterReomove.Substring(0, limitLen)
                            ElseIf argValues(2) = "#" Then
                                '第3引数が"#"の場合、最終文字を"#"で置き換え
                                retStr = LastReplaceString(itemValueAfterReomove.Substring(0, limitLen), "#")
                            ElseIf argValues(2) = "A#" Then
                                '第3引数が"A#"の場合、納品桁数分"#"で埋める   *** [2015/1/13 修正] ***
                                retStr = String.Empty.PadLeft(limitLen, "#")
                            ElseIf argValues(2) = "9" Then
                                '第3引数が"9"の場合、納品桁数分"9"を埋める
                                retStr = String.Empty.PadLeft(limitLen, "9")
                            Else
                                retStr = itemValueAfterReomove.Substring(0, limitLen)
                            End If
                        Else
                            ' 指定レングスと同じ場合、項目値（数値or?以外カット後）を単純セット *** [2015/3/4 修正] ***
                            retStr = itemValueAfterReomove
                        End If
                    End If
                Else
                    '----> 第1引数(編集方法)がNullの場合、項目値を単純セット
                    '----> retStr = itemValue
                    '第1引数(編集方法)がNullの場合、項目値（数値or?以外カット後）を単純セット *** [2015/3/4 修正] ***
                    retStr = RemoveNoNumChar(itemValue)
                End If
            End If

            ' 第3引数("?"を含む時の編集方法)がNull以外の場合
            If Not String.IsNullOrEmpty(argValues(2)) AndAlso retStr.IndexOf("?") >= 0 Then
                If argValues(2) = "#" Then
                    '第3引数が"#"の場合、"?"を"#"で置き換え
                    retStr = retStr.Replace("?", "#")
                ElseIf argValues(2) = "A#" Then
                    '第3引数が"A#"の場合、納品桁数分"#"を埋める
                    retStr = String.Empty.PadLeft(limitLen, "#")
                ElseIf argValues(2) = "9" Then
                    '第3引数が"9"の場合、"納品桁数分"9"を埋める
                    retStr = String.Empty.PadLeft(limitLen, "9")
                Else
                    Throw New Exception("半角項目の編集処理で引数に不正な値が設定されています(第3引数) -> " & argValues(2))
                End If
            End If

            Return retStr

        Catch ex As Exception
            CommonLog.WriteLog("D101[半角項目の編集メソッド]でエラーを検出しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            writeErrorDataInfo(methodDef, targetData)
            Throw ex
        End Try
    End Function
#End Region

#Region "D102[全角項目の編集メソッド]"
    ''' <summary>
    ''' D102
    ''' </summary>
    ''' <param name="methodDef">納品編集定義情報</param>
    ''' <param name="targetData">エントリ結果</param>
    ''' <returns>編集後の文字列</returns>
    ''' <remarks>引数で指定された値より、置き換え処理を行う</remarks>
    Public Function D102(ByVal methodDef As clsMethodDef, ByVal targetData As DataRow) As String
        ' 編集後の文字列
        Dim retStr As String = String.Empty
        Try
            ' 編集項目内容取得
            Dim itemValue As String = GetValue(targetData, methodDef.InputItems(0))
            ' 編集不備項目内容取得
            Dim itemDefcValue As String = GetValue(targetData, methodDef.InputItems(0) & "_DEF")

            ' 非SS対応 
            If methodDef.SlipId(0).StartsWith("641") OrElse methodDef.SlipId(0).StartsWith("661") Then
                retStr = itemValue
            Else
                '外字変換処理  *** [2015/04/16 修正 Kuwahara] ***
                Dim filterBytes As Byte() = _strConvObj.Filter(itemValue)
                retStr = System.Text.Encoding.GetEncoding("UTF-8").GetString(filterBytes)
            End If

            ' 不正文字の置き換え（"〓" ⇒ "★"）
            retStr = retStr.Replace("〓", "★")

            ' 不備項目に"02"がセットされている場合
            If Not String.IsNullOrEmpty(itemDefcValue) AndAlso itemDefcValue = "02" Then
                '最終文字を"★"で置き換え
                retStr = LastReplaceString(retStr, "★")
            End If

            If Not methodDef.SlipId(0).StartsWith("641") AndAlso Not methodDef.SlipId(0).StartsWith("661") Then
                ' 文字列から半角文字列を削除する *** [2015/3/4 修正] ***
                retStr = RemoveHalfByteChr(retStr)
            End If

            Return retStr

        Catch ex As Exception
            CommonLog.WriteLog("D102[全角項目の編集メソッド]でエラーを検出しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            writeErrorDataInfo(methodDef, targetData)
            Throw ex
        End Try
    End Function
#End Region

#Region "D103[YYYYMMDD形式編集メソッド]"
    ''' <summary>
    ''' D103
    ''' </summary>
    ''' <param name="methodDef">納品編集定義情報</param>
    ''' <param name="targetData">エントリ結果</param>
    ''' <returns>編集後の文字列</returns>
    ''' <remarks>元号、年、月、日の入力内容よりYYYYMMDD形式の文字列を作成する</remarks>
    Public Function D103(ByVal methodDef As clsMethodDef, ByVal targetData As DataRow) As String
        ' 編集後の文字列
        Dim retStr As String = String.Empty
        Try
            ' 日付項目取得
            Dim strDateArr() As String = {String.Empty, String.Empty, String.Empty, String.Empty}
            strDateArr(0) = GetValue(targetData, methodDef.InputItems(0))      ' 元号1桁
            strDateArr(1) = GetValue(targetData, methodDef.InputItems(1))      ' 年4桁前ゼロ
            strDateArr(2) = GetValue(targetData, methodDef.InputItems(2))      ' 月2桁前ゼロ
            strDateArr(3) = GetValue(targetData, methodDef.InputItems(3))      ' 日2桁前ゼロ
            ' 日付不備項目取得
            Dim strDateDefArr() As String = {String.Empty, String.Empty, String.Empty, String.Empty}
            strDateDefArr(0) = GetValue(targetData, methodDef.InputItems(0) & "_DEF")
            strDateDefArr(1) = GetValue(targetData, methodDef.InputItems(1) & "_DEF")
            strDateDefArr(2) = GetValue(targetData, methodDef.InputItems(2) & "_DEF")
            strDateDefArr(3) = GetValue(targetData, methodDef.InputItems(3) & "_DEF")

            ' 日付項目が不完全かどうかのチェックと返却文字列の生成 [2015/3/14 追加] ***
            retStr = ReplaceIncompleteDateForAll(strDateArr, strDateDefArr)
            If retStr = EMPTY_VALUE OrElse retStr = "########" Then
                If retStr = EMPTY_VALUE Then
                    retStr = String.Empty
                End If
                Return retStr
            End If

            ' 編集後の年、月、日の数値格納用変数の宣言
            Dim retYear As Integer = 0
            Dim retMon As Integer = 0
            Dim retDay As Integer = 0

            ' 日付項目の中でNullがある項目に0埋めをした文字列を生成 [2015/3/14 追加] ***
            retStr = padDateString(strDateArr(0), strDateArr(1), strDateArr(2), strDateArr(3))
            If Not String.IsNullOrEmpty(retStr) Then
                retYear = Integer.Parse(retStr.Substring(0, 4))
                retMon = Integer.Parse(retStr.Substring(4, 2))
                retDay = Integer.Parse(retStr.Substring(6, 2))
                If retYear = 0 Then
                    If retMon <> 0 AndAlso retDay <> 0 Then
                        '年が0000の時は月と日の妥当性チェックを実施
                        If Not IsDateValid(retMon, retDay) Then
                            retStr = String.Empty.PadLeft(8, "#")
                        End If
                    End If
                ElseIf retDay = 0 Then
                    '日が00の時は月の妥当性チェックを実施
                    If retMon <> 0 Then
                        If Not IsDateValid(retMon) Then
                            retStr = String.Empty.PadLeft(8, "#")
                        End If
                    End If
                ElseIf retMon = 0 Then
                    '月が00の時は妥当性チェックは実施しない（できない）
                End If

                Return retStr
            End If

            ' YYYYMMDD編集実行 [2015/3/14 修正] ***
            retStr = editDateForYYYYMMDD(strDateArr(0), strDateArr(1), strDateArr(2), strDateArr(3))

            ' *** 日付妥当性チェック[2015/3/5 追加] ***
            ' 編集後の年、月、日を数値に変換
            retYear = Integer.Parse(retStr.Substring(0, 4))
            retMon = Integer.Parse(retStr.Substring(4, 2))
            retDay = Integer.Parse(retStr.Substring(6, 2))
            ' 日付の妥当性チェック（妥当な日付でない場合は、"########"に変換） *** 追加[2015/3/5] ***
            ' [妥当性チェックの対象は、年月日が全て入力されている時のみ]
            ' 元号を含めた年の妥当性チェック
            If Not IsDateForGengo(strDateArr(0), strDateArr(1), strDateArr(2), strDateArr(3)) Then
                retStr = String.Empty.PadLeft(8, "#")
            ElseIf Not IsDateValid(retYear, retMon, retDay) Then
                ' 月や日などの妥当性チェック
                retStr = String.Empty.PadLeft(8, "#")
            End If

            Return retStr

        Catch ex As Exception
            CommonLog.WriteLog("D103[YYYYMMDD形式の編集メソッド]でエラーを検出しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            writeErrorDataInfo(methodDef, targetData)
            Throw ex
        End Try

    End Function
#End Region

#Region "D104[YYYYMM形式編集メソッド]"
    ''' <summary>
    ''' D104
    ''' </summary>
    ''' <param name="methodDef">納品編集定義情報</param>
    ''' <param name="targetData">エントリ結果</param>
    ''' <returns>編集後の文字列</returns>
    ''' <remarks>元号、年、月の入力内容よりYYYYMM形式の文字列を作成する</remarks>
    Public Function D104(ByVal methodDef As clsMethodDef, ByVal targetData As DataRow) As String
        ' 編集後の文字列
        Dim retStr As String = String.Empty
        Try
            ' 日付項目取得
            Dim strDateArr() As String = {String.Empty, String.Empty, String.Empty}
            strDateArr(0) = GetValue(targetData, methodDef.InputItems(0))      ' 元号1桁
            strDateArr(1) = GetValue(targetData, methodDef.InputItems(1))      ' 年4桁前ゼロ
            strDateArr(2) = GetValue(targetData, methodDef.InputItems(2))      ' 月2桁前ゼロ
            ' 日付不備項目取得
            Dim strDateDefArr() As String = {String.Empty, String.Empty, String.Empty}
            strDateDefArr(0) = GetValue(targetData, methodDef.InputItems(0) & "_DEF")
            strDateDefArr(1) = GetValue(targetData, methodDef.InputItems(1) & "_DEF")
            strDateDefArr(2) = GetValue(targetData, methodDef.InputItems(2) & "_DEF")

            ' 日付項目が不完全かどうかのチェックと返却文字列の生成 [2015/3/14 追加] ***
            retStr = ReplaceIncompleteDateUntilMonth(strDateArr, strDateDefArr)
            If retStr = EMPTY_VALUE OrElse retStr = "######" Then
                If retStr = EMPTY_VALUE Then
                    retStr = String.Empty
                End If
                Return retStr
            End If

            ' 編集後の年、月、日の数値格納用変数の宣言
            Dim retYear As Integer = 0
            Dim retMon As Integer = 0

            ' 日付項目の中でNullがある項目に0埋めをした文字列を生成 [2015/3/14 追加] ***
            retStr = padDateString(strDateArr(0), strDateArr(1), strDateArr(2))
            If Not String.IsNullOrEmpty(retStr) Then
                retYear = Integer.Parse(retStr.Substring(0, 4))
                retMon = Integer.Parse(retStr.Substring(4, 2))
                If retYear = 0 Then
                    '年が0000の時は月と日の妥当性チェックを実施
                    If Not IsDateValid(retMon) Then
                        retStr = String.Empty.PadLeft(6, "#")
                    End If
                ElseIf retMon = 0 Then
                    '月が00の時は妥当性チェックは実施しない（できない）
                End If

                Return retStr
            End If

            ' YYYYMMDD編集実行 [2015/3/14 修正] ***
            retStr = editDateForYYYYMM(strDateArr(0), strDateArr(1), strDateArr(2))


            ' 編集後の年、月、日を数値に変換   *** 日付妥当性チェックのため追加[2015/3/5] ***
            retYear = Integer.Parse(retStr.Substring(0, 4))
            retMon = Integer.Parse(retStr.Substring(4, 2))

            ' 日付の妥当性チェック（妥当な日付でない場合は、"########"に変換） *** 追加[2015/3/5] ***
            ' [妥当性チェックの対象は、年月が全て入力されている時のみ]
            ' 元号を含めた年の妥当性チェック
            If Not IsDateForGengo(strDateArr(0), strDateArr(1), strDateArr(2)) Then
                retStr = String.Empty.PadLeft(6, "#")
                ' 月の妥当性チェック
            ElseIf Not IsDateValid(retMon) Then
                retStr = String.Empty.PadLeft(6, "#")
            End If

            Return retStr

        Catch ex As Exception
            CommonLog.WriteLog("D104[YYYYMM形式の編集メソッド]でエラーを検出しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            writeErrorDataInfo(methodDef, targetData)
            Throw ex
        End Try

    End Function
#End Region

#Region "D105[MM形式編集メソッド]"
    ''' <summary>
    ''' D105
    ''' </summary>
    ''' <param name="methodDef">納品編集定義情報</param>
    ''' <param name="targetData">エントリ結果</param>
    ''' <returns>編集後の文字列</returns>
    ''' <remarks>月の入力内容よりMM形式の文字列を作成する</remarks>
    Public Function D105(ByVal methodDef As clsMethodDef, ByVal targetData As DataRow) As String
        Try
            ' 日付(月)項目取得
            Dim strMon As String = GetValue(targetData, methodDef.InputItems(0))
            ' 日付(月)不備項目取得
            Dim strMonDef As String = GetValue(targetData, methodDef.InputItems(0) & "_DEF")

            ' 月が未入力の場合、空文字を返却
            If String.IsNullOrEmpty(strMon) Then
                Return String.Empty
            End If
            ' 月に"?"が入力されている場合、"##"を返却
            If strMon.IndexOf("?") >= 0 Then
                Return "##"
            End If
            ' 月の不備フラグに"02"が入力されている場合、"##"を返却
            If strMonDef.Trim = "02" Then
                Return "##"
            End If

            ' 月入力値編集(MM形式で返却)
            Dim monVal As Integer = 0
            If Not String.IsNullOrEmpty(strMon) AndAlso IsNumeric(strMon) Then
                monVal = Integer.Parse(strMon)
            End If

            ' 月の妥当性をチェック  *** 追加[2015/3/5] ***
            If Not IsDateValid(monVal) Then
                '妥当でない場合は"##"を返却
                Return "##"
            End If

            ' "MM"形式で返却
            Return String.Format("{0:00}", monVal)

        Catch ex As Exception
            CommonLog.WriteLog("D105[MM形式の編集メソッド]でエラーを検出しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            writeErrorDataInfo(methodDef, targetData)
            Throw ex
        End Try

    End Function
#End Region

#Region "D106[固定値編集メソッド]"
    ''' <summary>
    ''' D106
    ''' </summary>
    ''' <param name="methodDef">納品編集定義情報</param>
    ''' <param name="targetData">エントリ結果</param>
    ''' <returns>編集後の文字列</returns>
    ''' <remarks>引数（固定値）に指定された値を文字列として返却する</remarks>
    Public Function D106(ByVal methodDef As clsMethodDef, ByVal targetData As DataRow) As String
        Try
            ' 引数項目（固定値）取得
            Dim constValue As String = methodDef.MethodParam(0)

            ' 固定値（Null）の場合は、空文字を返却する
            If Not String.IsNullOrEmpty(constValue) AndAlso constValue.ToUpper() = "NULL" Then
                Return String.Empty
            End If
            ' 引数項目（固定値）を返却
            Return constValue

        Catch ex As Exception
            CommonLog.WriteLog("D106[固定値編集メソッド]でエラーを検出しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            writeErrorDataInfo(methodDef, targetData)
            Throw ex
        End Try

    End Function
#End Region

#Region "D107[住所項目編集メソッド]"
    ''' <summary>
    ''' D107
    ''' </summary>
    ''' <param name="methodDef">納品編集定義情報</param>
    ''' <param name="targetData">エントリ結果</param>
    ''' <returns>編集後の文字列</returns>
    ''' <remarks>引数に指定された値より住所の文字列を編集し、返却する</remarks>
    Public Function D107(ByVal methodDef As clsMethodDef, ByVal targetData As DataRow) As String
        ' 編集後の文字列
        Dim retStr As String = String.Empty
        Try
            ' 住所項目取得
            Dim addrA As String = GetValue(targetData, methodDef.InputItems(0))     ' 都道府県
            Dim addrB As String = GetValue(targetData, methodDef.InputItems(1))     ' 市区郡町村
            Dim addrC As String = GetValue(targetData, methodDef.InputItems(2))     ' 大字通称
            Dim addrD As String = GetValue(targetData, methodDef.InputItems(3))     ' 字町名
            Dim addrE As String = GetValue(targetData, methodDef.InputItems(4))     ' マスタ以降
            Dim addrF As String = GetValue(targetData, methodDef.InputItems(5))     ' 建物名

            ' 住所編集
            Dim strAddrWK As String
            '1. 住所項目A～住所項目Eをスペースを詰めて結合
            strAddrWK = addrA.Trim & _
                        addrB.Trim & _
                        addrC.Trim & _
                        addrD.Trim & _
                        addrE.Trim
            strAddrWK = strAddrWK.Replace("　", String.Empty)       ' 全角空白を除去
            strAddrWK = strAddrWK.Replace(" ", String.Empty)        ' 半角空白を除去
            '2. 1の編集に1つスペースをはさみ、住所項目Fを結合
            If Not String.IsNullOrEmpty(Trim(addrF)) Then
                strAddrWK = strAddrWK & "　" & addrF
            End If
            Dim strAddrLen As Integer = strAddrWK.Length            ' 住所項目文字列の長さを取得

            '3. 2で編集した文字列から13文字分を「住所1」に設定()
            Dim address1 As String = Left(strAddrWK, 13).TrimEnd()  ' 住所1の設定

            '4. 3で設定した以降の文字列を13文字分「住所2」に設定
            Dim address2 As String = String.Empty                   ' 住所2の設定
            If strAddrLen > 13 Then
                address2 = Mid(strAddrWK, 14, 13).TrimEnd()
            End If

            '5. 4で設定した以降の文字列を13文字分「住所3」に設定
            Dim address3 As String = String.Empty                   ' 住所3の設定
            If strAddrLen > 26 Then
                address3 = Mid(strAddrWK, 27, 13).TrimEnd()
            End If

            '6. 住所3の先頭がスペースなら消去する
            If Left(address3, 1) = "　" Then
                address3 = Mid(address3, 2)
            End If

            '6. 住所2の先頭がスペースなら消去する
            If Left(address2, 1) = "　" Then
                address2 = Mid(address2, 2)
            End If

            '7. 不正文字の置き換え（"〓" ⇒ "★"） **** [2015/01/30 追加] ***
            address1 = address1.Replace("〓", "★")
            address2 = address2.Replace("〓", "★")
            address3 = address3.Replace("〓", "★")

            '8. 半角文字の削除 **** [2015/03/05 追加] ***
            address1 = RemoveHalfByteChr(address1)
            address2 = RemoveHalfByteChr(address2)
            address3 = RemoveHalfByteChr(address3)

            '9. 住所項目が39文字を超える場合、住所3の最終文字を"★"（不備）に置き換える
            '  （住所3の先頭が全角空白の場合は40文字を超える場合）
            If Mid(strAddrWK, 37, 1) = "　" AndAlso strAddrLen > 40 Then
                address3 = LastReplaceString(address3, "★")
            ElseIf strAddrLen > 39 Then
                address3 = LastReplaceString(address3, "★")
            End If

            ' 引数取得
            Dim argValue As String = methodDef.MethodParam(0)
            ' 引数によって、設定を分岐
            Select Case argValue
                Case "1"
                    retStr = address1       ' パラメータ=1の時、住所1を設定
                Case "2"
                    retStr = address2       ' パラメータ=2の時、住所2を設定
                Case "3"
                    retStr = address3       ' パラメータ=3の時、住所3を設定
            End Select

            ' 編集内容を返却
            Return retStr

        Catch ex As Exception
            CommonLog.WriteLog("D107[住所項目編集メソッド]でエラーを検出しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            writeErrorDataInfo(methodDef, targetData)
            Throw ex
        End Try

    End Function
#End Region

#Region "D108[入力値変換編集メソッド]"
    ''' <summary>
    ''' D108
    ''' </summary>
    ''' <param name="methodDef">納品編集定義情報</param>
    ''' <param name="targetData">エントリ結果</param>
    ''' <returns>編集後の文字列</returns>
    ''' <remarks>引数に指定された値より住所の文字列を編集し、返却する</remarks>
    Public Function D108(ByVal methodDef As clsMethodDef, ByVal targetData As DataRow) As String
        ' 編集後の文字列
        Dim retStr As String = String.Empty
        Try
            ' 項目取得
            Dim itemValue As String = GetValue(targetData, methodDef.InputItems(0))
            ' 引数内容取得
            Dim argValues As String() = methodDef.MethodParam
            '引数の値を分割、格納するための変数定義
            Dim splitStr() As String

            '引数取り出し（引数に一致しない場合はNullを返却）
            For Each argValue As String In argValues
                ' 引数の格納形式"キー文字列:値文字列"という形式をキーと値に分割
                splitStr = Split(argValue, ":")
                ' 取得項目がNullの場合                
                If String.IsNullOrEmpty(itemValue) Then
                    ' 引数が"Null"というキー文字列に一致したものを返却対象とする
                    If splitStr(0).ToUpper = "NULL" Then
                        If splitStr(1).ToUpper = "NULL" Then
                            '値文字列が"Null"という文字列なら空文字を返却
                            retStr = String.Empty
                        Else
                            '値文字列が"Null"という文字列でなければ、値文字列で置き換えて返却
                            retStr = splitStr(1)
                        End If
                        ' 引数の探索を終了
                        Exit For
                    End If
                Else
                    ' 取得項目と引数のキー文字列が一致した場合
                    If splitStr(0) = itemValue Then
                        '値文字列を返却
                        retStr = splitStr(1)
                        ' 引数の探索を終了
                        Exit For
                    End If
                End If
            Next

            Return retStr

        Catch ex As Exception
            CommonLog.WriteLog("D108[入力値変換編集メソッド]でエラーを検出しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            writeErrorDataInfo(methodDef, targetData)
            Throw ex
        End Try

    End Function
#End Region

#Region "D109[YYYYMMDD形式編集メソッド 昭和・平成・令和]"
    ''' <summary>
    ''' D109
    ''' </summary>
    ''' <param name="methodDef">納品編集定義情報</param>
    ''' <param name="targetData">エントリ結果</param>
    ''' <returns>編集後の文字列</returns>
    ''' <remarks>元号、年、月、日の入力内容よりYYYYMMDD形式の文字列を作成する</remarks>
    Public Function D109(ByVal methodDef As clsMethodDef, ByVal targetData As DataRow) As String
        ' 編集後の文字列
        Dim retStr As String = String.Empty
        Try
            ' 日付項目取得
            Dim strDateArr() As String = {String.Empty, String.Empty, String.Empty, String.Empty}
            Select Case GetValue(targetData, methodDef.InputItems(0))      ' 元号1桁
                Case "1"
                    strDateArr(0) = "3"
                Case "2"
                    strDateArr(0) = "4"
                Case "3"
                    strDateArr(0) = "5"
                Case "9"
                    strDateArr(0) = "9"
                Case String.Empty
                    strDateArr(0) = String.Empty
                Case Else
                    strDateArr(0) = "?"
            End Select
            strDateArr(1) = GetValue(targetData, methodDef.InputItems(1))      ' 年4桁前ゼロ
            strDateArr(2) = GetValue(targetData, methodDef.InputItems(2))      ' 月2桁前ゼロ
            strDateArr(3) = GetValue(targetData, methodDef.InputItems(3))      ' 日2桁前ゼロ
            ' 日付不備項目取得
            Dim strDateDefArr() As String = {String.Empty, String.Empty, String.Empty, String.Empty}
            strDateDefArr(0) = GetValue(targetData, methodDef.InputItems(0) & "_DEF")
            strDateDefArr(1) = GetValue(targetData, methodDef.InputItems(1) & "_DEF")
            strDateDefArr(2) = GetValue(targetData, methodDef.InputItems(2) & "_DEF")
            strDateDefArr(3) = GetValue(targetData, methodDef.InputItems(3) & "_DEF")

            ' 日付項目が不完全かどうかのチェックと返却文字列の生成 [2015/3/14 追加] ***
            retStr = ReplaceIncompleteDateForAll(strDateArr, strDateDefArr)
            If retStr = EMPTY_VALUE OrElse retStr = "########" Then
                If retStr = EMPTY_VALUE Then
                    retStr = String.Empty
                End If
                Return retStr
            End If

            ' 編集後の年、月、日の数値格納用変数の宣言
            Dim retYear As Integer = 0
            Dim retMon As Integer = 0
            Dim retDay As Integer = 0

            ' 日付項目の中でNullがある項目に0埋めをした文字列を生成 [2015/3/14 追加] ***
            retStr = padDateString(strDateArr(0), strDateArr(1), strDateArr(2), strDateArr(3))
            If Not String.IsNullOrEmpty(retStr) Then
                retYear = Integer.Parse(retStr.Substring(0, 4))
                retMon = Integer.Parse(retStr.Substring(4, 2))
                retDay = Integer.Parse(retStr.Substring(6, 2))
                If retYear = 0 Then
                    If retMon <> 0 AndAlso retDay <> 0 Then
                        '年が0000の時は月と日の妥当性チェックを実施
                        If Not IsDateValid(retMon, retDay) Then
                            retStr = String.Empty.PadLeft(8, "#")
                        End If
                    End If
                ElseIf retDay = 0 Then
                    '日が00の時は月の妥当性チェックを実施
                    If retMon <> 0 Then
                        If Not IsDateValid(retMon) Then
                            retStr = String.Empty.PadLeft(8, "#")
                        End If
                    End If
                ElseIf retMon = 0 Then
                    '月が00の時は妥当性チェックは実施しない（できない）
                End If

                Return retStr
            End If

            ' YYYYMMDD編集実行 [2015/3/14 修正] ***
            retStr = editDateForYYYYMMDD(strDateArr(0), strDateArr(1), strDateArr(2), strDateArr(3))

            ' *** 日付妥当性チェック[2015/3/5 追加] ***
            ' 編集後の年、月、日を数値に変換
            retYear = Integer.Parse(retStr.Substring(0, 4))
            retMon = Integer.Parse(retStr.Substring(4, 2))
            retDay = Integer.Parse(retStr.Substring(6, 2))
            ' 日付の妥当性チェック（妥当な日付でない場合は、"########"に変換） *** 追加[2015/3/5] ***
            ' [妥当性チェックの対象は、年月日が全て入力されている時のみ]
            ' 元号を含めた年の妥当性チェック
            If Not IsDateForGengo(strDateArr(0), strDateArr(1), strDateArr(2), strDateArr(3)) Then
                retStr = String.Empty.PadLeft(8, "#")
            ElseIf Not IsDateValid(retYear, retMon, retDay) Then
                ' 月や日などの妥当性チェック
                retStr = String.Empty.PadLeft(8, "#")
            End If

            Return retStr

        Catch ex As Exception
            CommonLog.WriteLog("D103[YYYYMMDD形式の編集メソッド]でエラーを検出しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            writeErrorDataInfo(methodDef, targetData)
            Throw ex
        End Try

    End Function
#End Region

#Region "D110[YYYYMMDD形式編集メソッド 平成・令和]"
    ''' <summary>
    ''' D110
    ''' </summary>
    ''' <param name="methodDef">納品編集定義情報</param>
    ''' <param name="targetData">エントリ結果</param>
    ''' <returns>編集後の文字列</returns>
    ''' <remarks>元号、年、月、日の入力内容よりYYYYMMDD形式の文字列を作成する</remarks>
    Public Function D110(ByVal methodDef As clsMethodDef, ByVal targetData As DataRow) As String
        ' 編集後の文字列
        Dim retStr As String = String.Empty
        Try
            ' 日付項目取得
            Dim strDateArr() As String = {String.Empty, String.Empty, String.Empty, String.Empty}
            Select Case GetValue(targetData, methodDef.InputItems(0))      ' 元号1桁
                Case "1"
                    strDateArr(0) = "4"
                Case "2"
                    strDateArr(0) = "5"
                Case "9"
                    strDateArr(0) = "9"
                Case String.Empty
                    strDateArr(0) = String.Empty
                Case Else
                    strDateArr(0) = "?"
            End Select
            strDateArr(1) = GetValue(targetData, methodDef.InputItems(1))      ' 年4桁前ゼロ
            strDateArr(2) = GetValue(targetData, methodDef.InputItems(2))      ' 月2桁前ゼロ
            strDateArr(3) = GetValue(targetData, methodDef.InputItems(3))      ' 日2桁前ゼロ
            ' 日付不備項目取得
            Dim strDateDefArr() As String = {String.Empty, String.Empty, String.Empty, String.Empty}
            strDateDefArr(0) = GetValue(targetData, methodDef.InputItems(0) & "_DEF")
            strDateDefArr(1) = GetValue(targetData, methodDef.InputItems(1) & "_DEF")
            strDateDefArr(2) = GetValue(targetData, methodDef.InputItems(2) & "_DEF")
            strDateDefArr(3) = GetValue(targetData, methodDef.InputItems(3) & "_DEF")

            ' 日付項目が不完全かどうかのチェックと返却文字列の生成 [2015/3/14 追加] ***
            retStr = ReplaceIncompleteDateForAll(strDateArr, strDateDefArr)
            If retStr = EMPTY_VALUE OrElse retStr = "########" Then
                If retStr = EMPTY_VALUE Then
                    retStr = String.Empty
                End If
                Return retStr
            End If

            ' 編集後の年、月、日の数値格納用変数の宣言
            Dim retYear As Integer = 0
            Dim retMon As Integer = 0
            Dim retDay As Integer = 0

            ' 日付項目の中でNullがある項目に0埋めをした文字列を生成 [2015/3/14 追加] ***
            retStr = padDateString(strDateArr(0), strDateArr(1), strDateArr(2), strDateArr(3))
            If Not String.IsNullOrEmpty(retStr) Then
                retYear = Integer.Parse(retStr.Substring(0, 4))
                retMon = Integer.Parse(retStr.Substring(4, 2))
                retDay = Integer.Parse(retStr.Substring(6, 2))
                If retYear = 0 Then
                    If retMon <> 0 AndAlso retDay <> 0 Then
                        '年が0000の時は月と日の妥当性チェックを実施
                        If Not IsDateValid(retMon, retDay) Then
                            retStr = String.Empty.PadLeft(8, "#")
                        End If
                    End If
                ElseIf retDay = 0 Then
                    '日が00の時は月の妥当性チェックを実施
                    If retMon <> 0 Then
                        If Not IsDateValid(retMon) Then
                            retStr = String.Empty.PadLeft(8, "#")
                        End If
                    End If
                ElseIf retMon = 0 Then
                    '月が00の時は妥当性チェックは実施しない（できない）
                End If

                Return retStr
            End If

            ' YYYYMMDD編集実行 [2015/3/14 修正] ***
            retStr = editDateForYYYYMMDD(strDateArr(0), strDateArr(1), strDateArr(2), strDateArr(3))

            ' *** 日付妥当性チェック[2015/3/5 追加] ***
            ' 編集後の年、月、日を数値に変換
            retYear = Integer.Parse(retStr.Substring(0, 4))
            retMon = Integer.Parse(retStr.Substring(4, 2))
            retDay = Integer.Parse(retStr.Substring(6, 2))
            ' 日付の妥当性チェック（妥当な日付でない場合は、"########"に変換） *** 追加[2015/3/5] ***
            ' [妥当性チェックの対象は、年月日が全て入力されている時のみ]
            ' 元号を含めた年の妥当性チェック
            If Not IsDateForGengo(strDateArr(0), strDateArr(1), strDateArr(2), strDateArr(3)) Then
                retStr = String.Empty.PadLeft(8, "#")
            ElseIf Not IsDateValid(retYear, retMon, retDay) Then
                ' 月や日などの妥当性チェック
                retStr = String.Empty.PadLeft(8, "#")
            End If

            Return retStr

        Catch ex As Exception
            CommonLog.WriteLog("D103[YYYYMMDD形式の編集メソッド]でエラーを検出しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            writeErrorDataInfo(methodDef, targetData)
            Throw ex
        End Try

    End Function
#End Region

#Region "D111[YYYYMM形式編集メソッド]"
    ''' <summary>
    ''' D111
    ''' </summary>
    ''' <param name="methodDef">納品編集定義情報</param>
    ''' <param name="targetData">エントリ結果</param>
    ''' <returns>編集後の文字列</returns>
    ''' <remarks>元号、年、月の入力内容よりYYYYMM形式の文字列を作成する</remarks>
    Public Function D111(ByVal methodDef As clsMethodDef, ByVal targetData As DataRow) As String
        ' 編集後の文字列
        Dim retStr As String = String.Empty
        Try
            ' 日付項目取得
            Dim strDateArr() As String = {String.Empty, String.Empty, String.Empty}
            strDateArr(0) = GetValue(targetData, methodDef.InputItems(0))      ' 元号1桁
            strDateArr(1) = GetValue(targetData, methodDef.InputItems(1))      ' 年4桁前ゼロ
            strDateArr(2) = GetValue(targetData, methodDef.InputItems(2))      ' 月2桁前ゼロ
            ' 日付不備項目取得
            Dim strDateDefArr() As String = {String.Empty, String.Empty, String.Empty}
            strDateDefArr(0) = GetValue(targetData, methodDef.InputItems(0) & "_DEF")
            strDateDefArr(1) = GetValue(targetData, methodDef.InputItems(1) & "_DEF")
            strDateDefArr(2) = GetValue(targetData, methodDef.InputItems(2) & "_DEF")

            Select Case GetValue(targetData, methodDef.InputItems(0))      ' 元号1桁
                Case "1"
                    strDateArr(0) = "4"
                Case "2"
                    strDateArr(0) = "5"
                Case "9"
                    strDateArr(0) = "9"
                Case String.Empty
                    strDateArr(0) = String.Empty
                Case Else
                    strDateArr(0) = "?"
            End Select

            ' 日付項目が不完全かどうかのチェックと返却文字列の生成 [2015/3/14 追加] ***
            retStr = ReplaceIncompleteDateUntilMonth(strDateArr, strDateDefArr)
            If retStr = EMPTY_VALUE OrElse retStr = "######" Then
                If retStr = EMPTY_VALUE Then
                    retStr = String.Empty
                End If
                Return retStr
            End If

            ' 編集後の年、月、日の数値格納用変数の宣言
            Dim retYear As Integer = 0
            Dim retMon As Integer = 0

            ' 日付項目の中でNullがある項目に0埋めをした文字列を生成 [2015/3/14 追加] ***
            retStr = padDateString(strDateArr(0), strDateArr(1), strDateArr(2))
            If Not String.IsNullOrEmpty(retStr) Then
                retYear = Integer.Parse(retStr.Substring(0, 4))
                retMon = Integer.Parse(retStr.Substring(4, 2))
                If retYear = 0 Then
                    '年が0000の時は月と日の妥当性チェックを実施
                    If Not IsDateValid(retMon) Then
                        retStr = String.Empty.PadLeft(6, "#")
                    End If
                ElseIf retMon = 0 Then
                    '月が00の時は妥当性チェックは実施しない（できない）
                End If

                Return retStr
            End If

            ' YYYYMMDD編集実行 [2015/3/14 修正] ***
            retStr = editDateForYYYYMM(strDateArr(0), strDateArr(1), strDateArr(2))


            ' 編集後の年、月、日を数値に変換   *** 日付妥当性チェックのため追加[2015/3/5] ***
            retYear = Integer.Parse(retStr.Substring(0, 4))
            retMon = Integer.Parse(retStr.Substring(4, 2))

            ' 日付の妥当性チェック（妥当な日付でない場合は、"########"に変換） *** 追加[2015/3/5] ***
            ' [妥当性チェックの対象は、年月が全て入力されている時のみ]
            ' 元号を含めた年の妥当性チェック
            If Not IsDateForGengo(strDateArr(0), strDateArr(1), strDateArr(2)) Then
                retStr = String.Empty.PadLeft(6, "#")
                ' 月の妥当性チェック
            ElseIf Not IsDateValid(retMon) Then
                retStr = String.Empty.PadLeft(6, "#")
            End If

            Return retStr

        Catch ex As Exception
            CommonLog.WriteLog("D104[YYYYMM形式の編集メソッド]でエラーを検出しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            writeErrorDataInfo(methodDef, targetData)
            Throw ex
        End Try

    End Function
#End Region

#Region "D112[YYYY形式編集メソッド]"
    ''' <summary>
    ''' D112
    ''' </summary>
    ''' <param name="methodDef">納品編集定義情報</param>
    ''' <param name="targetData">エントリ結果</param>
    ''' <returns>編集後の文字列</returns>
    ''' <remarks>元号、年、月の入力内容よりYYYYMM形式の文字列を作成する</remarks>
    Public Function D112(ByVal methodDef As clsMethodDef, ByVal targetData As DataRow) As String
        ' 編集後の文字列
        Dim retStr As String = String.Empty
        Try
            ' 日付項目取得
            Dim strDateArr() As String = {String.Empty, String.Empty, String.Empty}
            strDateArr(0) = GetValue(targetData, methodDef.InputItems(0))      ' 元号1桁
            strDateArr(1) = GetValue(targetData, methodDef.InputItems(1))      ' 年4桁前ゼロ
            If strDateArr(0).Length = 0 AndAlso strDateArr(1).Length = 0 Then
                Return retStr
            End If
            strDateArr(2) = "12"

            ' 日付不備項目取得
            Dim strDateDefArr() As String = {String.Empty, String.Empty, String.Empty}
            strDateDefArr(0) = GetValue(targetData, methodDef.InputItems(0) & "_DEF")
            strDateDefArr(1) = GetValue(targetData, methodDef.InputItems(1) & "_DEF")
            strDateDefArr(2) = "00"

            ' 日付項目が不完全かどうかのチェックと返却文字列の生成 [2015/3/14 追加] ***
            retStr = ReplaceIncompleteDateUntilMonth(strDateArr, strDateDefArr)
            If retStr = EMPTY_VALUE OrElse retStr = "######" Then
                If retStr = EMPTY_VALUE Then
                    retStr = String.Empty
                End If
                Return retStr
            End If

            ' 編集後の年、月、日の数値格納用変数の宣言
            Dim retYear As Integer = 0
            Dim retMon As Integer = 0

            ' 日付項目の中でNullがある項目に0埋めをした文字列を生成 [2015/3/14 追加] ***
            retStr = padDateString(strDateArr(0), strDateArr(1), strDateArr(2))
            If Not String.IsNullOrEmpty(retStr) Then
                retYear = Integer.Parse(retStr.Substring(0, 4))
                If strDateArr(0) = "4" AndAlso retYear = 2019 Then
                    retYear -= 1
                End If
                retMon = Integer.Parse(retStr.Substring(4, 2))
                If retYear = 0 Then
                    '年が0000の時は月と日の妥当性チェックを実施
                    If Not IsDateValid(retMon) Then
                        retStr = String.Empty.PadLeft(6, "#")
                    End If
                ElseIf retMon = 0 Then
                    '月が00の時は妥当性チェックは実施しない（できない）
                End If

                Return retYear.ToString("0000")
            End If

            ' YYYYMMDD編集実行 [2015/3/14 修正] ***
            retStr = editDateForYYYYMM(strDateArr(0), strDateArr(1), strDateArr(2))


            ' 編集後の年、月、日を数値に変換   *** 日付妥当性チェックのため追加[2015/3/5] ***
            retYear = Integer.Parse(retStr.Substring(0, 4))
            If strDateArr(0) = "4" AndAlso retYear = 2019 Then
                retYear -= 1
            End If

            Return retYear.ToString("0000")

        Catch ex As Exception
            CommonLog.WriteLog("D104[YYYYMM形式の編集メソッド]でエラーを検出しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            writeErrorDataInfo(methodDef, targetData)
            Throw ex
        End Try
    End Function
#End Region

#Region "D113[YYYY形式編集メソッド] 平成・令和"
    ''' <summary>
    ''' D113
    ''' </summary>
    ''' <param name="methodDef">納品編集定義情報</param>
    ''' <param name="targetData">エントリ結果</param>
    ''' <returns>編集後の文字列</returns>
    ''' <remarks>元号、年、月の入力内容よりYYYYMM形式の文字列を作成する</remarks>
    Public Function D113(ByVal methodDef As clsMethodDef, ByVal targetData As DataRow) As String
        ' 編集後の文字列
        Dim retStr As String = String.Empty
        Try
            ' 日付項目取得
            Dim strDateArr() As String = {String.Empty, String.Empty, String.Empty}
            strDateArr(0) = GetValue(targetData, methodDef.InputItems(0))      ' 元号1桁
            strDateArr(1) = GetValue(targetData, methodDef.InputItems(1))      ' 年4桁前ゼロ
            If strDateArr(0).Length = 0 AndAlso strDateArr(1).Length = 0 Then
                Return retStr
            End If
            strDateArr(2) = "12"

            Select Case GetValue(targetData, methodDef.InputItems(0))      ' 元号1桁
                Case "1"
                    strDateArr(0) = "4"
                Case "2"
                    strDateArr(0) = "5"
                Case "9"
                    strDateArr(0) = "9"
                Case String.Empty
                    strDateArr(0) = String.Empty
                Case Else
                    strDateArr(0) = "?"
            End Select

            ' 日付不備項目取得
            Dim strDateDefArr() As String = {String.Empty, String.Empty, String.Empty}
            strDateDefArr(0) = GetValue(targetData, methodDef.InputItems(0) & "_DEF")
            strDateDefArr(1) = GetValue(targetData, methodDef.InputItems(1) & "_DEF")
            strDateDefArr(2) = "00"

            ' 日付項目が不完全かどうかのチェックと返却文字列の生成 [2015/3/14 追加] ***
            retStr = ReplaceIncompleteDateUntilMonth(strDateArr, strDateDefArr)
            If retStr = EMPTY_VALUE OrElse retStr = "######" Then
                If retStr = EMPTY_VALUE Then
                    retStr = String.Empty
                End If
                Return retStr
            End If

            ' 編集後の年、月、日の数値格納用変数の宣言
            Dim retYear As Integer = 0
            Dim retMon As Integer = 0

            ' 日付項目の中でNullがある項目に0埋めをした文字列を生成 [2015/3/14 追加] ***
            retStr = padDateString(strDateArr(0), strDateArr(1), strDateArr(2))
            If Not String.IsNullOrEmpty(retStr) Then
                retYear = Integer.Parse(retStr.Substring(0, 4))
                If strDateArr(0) = "4" AndAlso retYear = 2019 Then
                    retYear -= 1
                End If
                retMon = Integer.Parse(retStr.Substring(4, 2))
                If retYear = 0 Then
                    '年が0000の時は月と日の妥当性チェックを実施
                    If Not IsDateValid(retMon) Then
                        retStr = String.Empty.PadLeft(6, "#")
                    End If
                ElseIf retMon = 0 Then
                    '月が00の時は妥当性チェックは実施しない（できない）
                End If

                Return retYear.ToString("0000")
            End If

            ' YYYYMMDD編集実行 [2015/3/14 修正] ***
            retStr = editDateForYYYYMM(strDateArr(0), strDateArr(1), strDateArr(2))


            ' 編集後の年、月、日を数値に変換   *** 日付妥当性チェックのため追加[2015/3/5] ***
            retYear = Integer.Parse(retStr.Substring(0, 4))
            If strDateArr(0) = "4" AndAlso retYear = 2019 Then
                retYear -= 1
            End If

            Return retYear.ToString("0000")

        Catch ex As Exception
            CommonLog.WriteLog("D104[YYYYMM形式の編集メソッド]でエラーを検出しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            writeErrorDataInfo(methodDef, targetData)
            Throw ex
        End Try
    End Function
#End Region

#Region "D114[項目結合メソッド]"
    ''' <summary>
    ''' D114
    ''' </summary>
    ''' <param name="methodDef">納品編集定義情報</param>
    ''' <param name="targetData">エントリ結果</param>
    ''' <returns>編集後の文字列</returns>
    ''' <remarks></remarks>
    Public Function D114(ByVal methodDef As clsMethodDef, ByVal targetData As DataRow) As String
        ' 編集後の文字列
        Dim retStr As String = String.Empty
        Try
            ' 項目取得
            Dim stbResult As New StringBuilder(String.Empty)
            For i As Integer = 0 To methodDef.InputItems.Count - 1 Step 1
                stbResult.Append(GetValue(targetData, methodDef.InputItems(i)))
            Next
            retStr = stbResult.ToString.Replace("?", "#")

            Return retStr

        Catch ex As Exception
            CommonLog.WriteLog("D104[YYYYMM形式の編集メソッド]でエラーを検出しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            writeErrorDataInfo(methodDef, targetData)
            Throw ex
        End Try
    End Function
#End Region

#Region "D201[被保険者証記号編集メソッド]"
    ''' <summary>
    ''' D201
    ''' </summary>
    ''' <param name="methodDef">納品編集定義情報</param>
    ''' <param name="targetData">エントリ結果</param>
    ''' <returns>編集後の文字列</returns>
    ''' <remarks>項目の桁数や内容より被保険者証記号の文字列を編集し、返却する</remarks>
    Public Function D201(ByVal methodDef As clsMethodDef, ByVal targetData As DataRow) As String
        ' 編集後の文字列
        Dim retStr As String = String.Empty
        Try
            ' 項目取得
            Dim itemValue As String = GetValue(targetData, methodDef.InputItems(0))
            ' 不備項目内容取得
            Dim itemDefcValue As String = GetValue(targetData, methodDef.InputItems(0) & "_DEF")

            ' 項目がNullの場合、空文字を返却する
            If String.IsNullOrEmpty(itemValue) Then
                Return String.Empty
            End If

            ' 数値と"?"以外の文字は削除する    *** [2015/03/05 追加] ***
            itemValue = RemoveNoNumChar(itemValue)

            ' "?"の置き換え
            retStr = itemValue.Replace("?", "#")
            ' 不備項目に"02"（桁オーバー）がセットされている場合
            If itemDefcValue = "02" Then
                retStr = LastReplaceString(retStr, "#")
            End If
            ' 7桁(バイト)未満なら0パディング
            If LengthB(retStr) < 7 Then
                ' 前0パディング
                retStr = retStr.PadLeft(7, "0")
            End If

            Return retStr

        Catch ex As Exception
            CommonLog.WriteLog("D201[被保険者証記号編集メソッド]でエラーを検出しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            writeErrorDataInfo(methodDef, targetData)
            Throw ex
        End Try

    End Function
#End Region

#Region "D202[基礎年金番号（申）・年金コード編集メソッド]"
    ''' <summary>
    ''' D202
    ''' </summary>
    ''' <param name="methodDef">納品編集定義情報</param>
    ''' <param name="targetData">エントリ結果</param>
    ''' <returns>編集後の文字列</returns>
    ''' <remarks>条件項目の内容より基礎年金番号or年金コードの文字列を編集し、返却する</remarks>
    Public Function D202(ByVal methodDef As clsMethodDef, ByVal targetData As DataRow) As String
        ' 編集後の文字列
        Dim retStr As String = String.Empty
        Try
            ' 項目取得
            Dim item1Value As String = GetValue(targetData, methodDef.InputItems(0)) '条件項目1
            Dim item2Value As String = GetValue(targetData, methodDef.InputItems(1)) '条件項目2
            Dim item3Value As String = GetValue(targetData, methodDef.InputItems(2)) '基礎年金番号or年金コード1
            Dim item4Value As String = GetValue(targetData, methodDef.InputItems(3)) '基礎年金番号or年金コード2
            ' 不備項目内容取得
            Dim item3DefcValue As String = GetValue(targetData, methodDef.InputItems(2) & "_DEF")
            Dim item4DefcValue As String = GetValue(targetData, methodDef.InputItems(3) & "_DEF")
            '納品桁数取得    *** [ 2015/1/16 Add ] ***
            Dim strValueLen As String = methodDef.MethodParam(0)
            Dim valueLen As Integer
            If Not String.IsNullOrEmpty(strValueLen) Then
                valueLen = Integer.Parse(strValueLen)
            Else
                CommonLog.WriteLog("メソッド定義に納品桁数の指定がされていません", EventLogEntryType.Error)
                Throw New Exception("メソッド定義に納品桁数の指定がされていません")
            End If

            ' 条件判断
            Dim item1condition, item2condition As Boolean
            ' 条件項目1が"1"or"2"ならTrueを設定
            If item1Value.Trim = "1" OrElse item1Value.Trim = "2" Then
                item1condition = True
            End If
            ' 条件項目2が"1"or"2"ならTrueを設定
            If item2Value.Trim = "1" OrElse item2Value.Trim = "2" Then
                item2condition = True
            End If

            ' 条件項目1と条件項目2の両方がTrueの場合は"#"を返却
            ' 条件項目1と条件項目2の両方がTrueの場合は、基礎年金番号 or 年金コード1を編集  *** [2015/04/16 修正 Kuwahara] ***
            If item1condition AndAlso item2condition Then
                'retStr = String.Empty.PadLeft(valueLen, "#")
                '▼----  *** [2015/04/16 修正 Kuwahara] ***
                If item3DefcValue = "02" Then
                    '桁オーバーなら最終桁を"#"に置き換え
                    retStr = LastReplaceString(item3Value, "#")
                Else
                    ' 数値と"?"以外の文字は削除し、納品桁数に足りない桁数は0埋めする
                    retStr = RemoveNoNumChar(item3Value)
                    If Not String.IsNullOrEmpty(retStr) Then
                        retStr = retStr.PadLeft(valueLen, "0")
                    End If
                End If
                '▲----

            ElseIf item1condition Then
                ' 条件項目1が"1"or"2"なら基礎年金番号 or 年金コード1
                If item3DefcValue = "02" Then
                    '桁オーバーなら最終桁を"#"に置き換え
                    retStr = LastReplaceString(item3Value, "#")
                Else
                    ' 数値と"?"以外の文字は削除し、納品桁数に足りない桁数は0埋めする  *** [2015/03/05 追加] ***
                    ' ---> 【変更前】retStr = item3Value
                    retStr = RemoveNoNumChar(item3Value)
                    If Not String.IsNullOrEmpty(retStr) Then
                        retStr = retStr.PadLeft(valueLen, "0")
                    End If
                End If
            ElseIf item2condition Then
                ' 条件項目2が"1"or"2"なら基礎年金番号 or 年金コード2
                If item4DefcValue = "02" Then
                    '桁オーバーなら最終桁を"#"に置き換え
                    retStr = LastReplaceString(item4Value, "#")
                Else
                    ' 数値と"?"以外の文字は削除し、納品桁数に足りない桁数は0埋めする  *** [2015/03/05 追加] ***
                    ' ---> 【変更前】retStr = item4Value
                    retStr = RemoveNoNumChar(item4Value)
                    If Not String.IsNullOrEmpty(retStr) Then
                        retStr = retStr.PadLeft(valueLen, "0")
                    End If
                End If
            Else
                ' 条件項目1,2ともに"1"or"2"以外の場合、指定桁数分"#"に置き換え  *** [2015/1/17] 修正***
                ' 条件項目1,2ともに"1"or"2"以外の場合、NULLを返却  *** [2015/1/20] 修正***
                ' 条件項目1,2ともに"1"or"2"以外の場合、基礎年金番号 or 年金コード1を編集  *** [2015/04/16 修正 Kuwahara] ***
                'retStr = String.Empty.PadLeft(valueLen, "#")
                'retStr = String.Empty
                '▼----  *** [2015/04/16 修正 Kuwahara] ***
                If item3DefcValue = "02" Then
                    '桁オーバーなら最終桁を"#"に置き換え
                    retStr = LastReplaceString(item3Value, "#")
                Else
                    ' 数値と"?"以外の文字は削除し、納品桁数に足りない桁数は0埋めする
                    retStr = RemoveNoNumChar(item3Value)
                    If Not String.IsNullOrEmpty(retStr) Then
                        retStr = retStr.PadLeft(valueLen, "0")
                    End If
                End If
                '▲----

            End If

            ' "?"の置き換え
            If retStr.IndexOf("?") >= 0 Then
                retStr = String.Empty.PadLeft(valueLen, "#")
            End If

            Return retStr

        Catch ex As Exception
            CommonLog.WriteLog("D202[基礎年金番号（申）・年金コード編集メソッド]でエラーを検出しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            writeErrorDataInfo(methodDef, targetData)
            Throw ex
        End Try

    End Function
#End Region

#Region "D203[支給開始年月日編集メソッド]"
    ''' <summary>
    ''' D203
    ''' </summary>
    ''' <param name="methodDef">納品編集定義情報</param>
    ''' <param name="targetData">エントリ結果</param>
    ''' <returns>編集後の文字列</returns>
    ''' <remarks>条件項目の内容より支給開始年月日の文字列を編集し、返却する</remarks>
    Public Function D203(ByVal methodDef As clsMethodDef, ByVal targetData As DataRow) As String
        ' 編集後の文字列
        Dim retStr As String = String.Empty
        Try
            ' 項目取得
            Dim item1Value As String = GetValue(targetData, methodDef.InputItems(0)) '条件項目1
            Dim item2Value As String = GetValue(targetData, methodDef.InputItems(1)) '条件項目2

            ' 日付項目取得
            Dim strDateArr() As String = {String.Empty, String.Empty, String.Empty, String.Empty}
            ' 日付不備項目取得
            Dim strDateDefArr() As String = {String.Empty, String.Empty, String.Empty, String.Empty}

            ' 条件判断
            Dim item1condition, item2condition As Boolean
            ' 条件項目1が"1"or"2"ならTrueを設定
            If item1Value.Trim = "1" OrElse item1Value.Trim = "2" Then
                item1condition = True
            End If
            ' 条件項目2が"1"or"2"ならTrueを設定
            If item2Value.Trim = "1" OrElse item2Value.Trim = "2" Then
                item2condition = True
            End If

            ' 条件項目1と条件項目2の両方がTrueの場合は"########"を返却
            ' 条件項目1と条件項目2の両方がTrueの場合は、A(Item3-6)を編集　*** [2015/04/16 修正 Kuwahara] ***
            If item1condition AndAlso item2condition Then
                'Return "########"
                '▼----  *** [2015/04/16 修正 Kuwahara] ***
                strDateArr(0) = GetValue(targetData, methodDef.InputItems(2))       'A元号1桁
                strDateArr(1) = GetValue(targetData, methodDef.InputItems(3))       'A年4桁前ゼロ
                strDateArr(2) = GetValue(targetData, methodDef.InputItems(4))       'A月2桁前ゼロ
                strDateArr(3) = GetValue(targetData, methodDef.InputItems(5))       'A日2桁前ゼロ
                ' 日付不備項目取得
                strDateDefArr(0) = GetValue(targetData, methodDef.InputItems(2) & "_DEF")
                strDateDefArr(1) = GetValue(targetData, methodDef.InputItems(3) & "_DEF")
                strDateDefArr(2) = GetValue(targetData, methodDef.InputItems(4) & "_DEF")
                strDateDefArr(3) = GetValue(targetData, methodDef.InputItems(5) & "_DEF")
                '▲----

            ElseIf item1condition Then
                ' 日付項目取得
                strDateArr(0) = GetValue(targetData, methodDef.InputItems(2))       'A元号1桁
                strDateArr(1) = GetValue(targetData, methodDef.InputItems(3))       'A年4桁前ゼロ
                strDateArr(2) = GetValue(targetData, methodDef.InputItems(4))       'A月2桁前ゼロ
                strDateArr(3) = GetValue(targetData, methodDef.InputItems(5))       'A日2桁前ゼロ
                ' 日付不備項目取得
                strDateDefArr(0) = GetValue(targetData, methodDef.InputItems(2) & "_DEF")
                strDateDefArr(1) = GetValue(targetData, methodDef.InputItems(3) & "_DEF")
                strDateDefArr(2) = GetValue(targetData, methodDef.InputItems(4) & "_DEF")
                strDateDefArr(3) = GetValue(targetData, methodDef.InputItems(5) & "_DEF")
            ElseIf item2condition Then
                ' 日付項目取得
                strDateArr(0) = GetValue(targetData, methodDef.InputItems(6))       'B元号1桁
                strDateArr(1) = GetValue(targetData, methodDef.InputItems(7))       'B年4桁前ゼロ
                strDateArr(2) = GetValue(targetData, methodDef.InputItems(8))       'B月2桁前ゼロ
                strDateArr(3) = GetValue(targetData, methodDef.InputItems(9))       'B日2桁前ゼロ
                ' 日付不備項目取得
                strDateDefArr(0) = GetValue(targetData, methodDef.InputItems(6) & "_DEF")
                strDateDefArr(1) = GetValue(targetData, methodDef.InputItems(7) & "_DEF")
                strDateDefArr(2) = GetValue(targetData, methodDef.InputItems(8) & "_DEF")
                strDateDefArr(3) = GetValue(targetData, methodDef.InputItems(9) & "_DEF")
            Else
                ' 条件項目1,2ともに"1"or"2"以外の場合、NULLを返却  *** [2015/1/20] 修正***
                ' 条件項目1,2ともに"1"or"2"以外の場合、A(Item3-6)を編集　*** [2015/04/16 修正 Kuwahara] ***
                'Return String.Empty
                'Return "########"
                '▼----  *** [2015/04/16 修正 Kuwahara] ***
                strDateArr(0) = GetValue(targetData, methodDef.InputItems(2))       'A元号1桁
                strDateArr(1) = GetValue(targetData, methodDef.InputItems(3))       'A年4桁前ゼロ
                strDateArr(2) = GetValue(targetData, methodDef.InputItems(4))       'A月2桁前ゼロ
                strDateArr(3) = GetValue(targetData, methodDef.InputItems(5))       'A日2桁前ゼロ
                ' 日付不備項目取得
                strDateDefArr(0) = GetValue(targetData, methodDef.InputItems(2) & "_DEF")
                strDateDefArr(1) = GetValue(targetData, methodDef.InputItems(3) & "_DEF")
                strDateDefArr(2) = GetValue(targetData, methodDef.InputItems(4) & "_DEF")
                strDateDefArr(3) = GetValue(targetData, methodDef.InputItems(5) & "_DEF")
                '▲----

            End If

            ' 日付項目が不完全かどうかのチェックと返却文字列の生成 [2015/3/14 追加] ***
            retStr = ReplaceIncompleteDateForAll(strDateArr, strDateDefArr)
            If retStr = EMPTY_VALUE OrElse retStr = "########" Then
                If retStr = EMPTY_VALUE Then
                    retStr = String.Empty
                End If
                Return retStr
            End If

            ' 編集後の年、月、日の数値格納用変数の宣言
            Dim retYear As Integer = 0
            Dim retMon As Integer = 0
            Dim retDay As Integer = 0

            ' 日付項目の中でNullがある項目に0埋めをした文字列を生成 [2015/3/14 追加] ***
            retStr = padDateString(strDateArr(0), strDateArr(1), strDateArr(2), strDateArr(3))
            If Not String.IsNullOrEmpty(retStr) Then
                retYear = Integer.Parse(retStr.Substring(0, 4))
                retMon = Integer.Parse(retStr.Substring(4, 2))
                retDay = Integer.Parse(retStr.Substring(6, 2))
                If retYear = 0 Then
                    '年が0000の時は月と日の妥当性チェックを実施
                    If Not IsDateValid(retMon, retDay) Then
                        retStr = String.Empty.PadLeft(8, "#")
                    End If
                ElseIf retDay = 0 Then
                    '日が00の時は月の妥当性チェックを実施
                    '▼----  *** [2015/04/16 修正 Kuwahara] ***
                    If retMon <> 0 Then
                        If Not IsDateValid(retMon) Then
                            retStr = String.Empty.PadLeft(8, "#")
                        End If
                    End If
                    'If Not IsDateValid(retMon) Then
                    'retStr = String.Empty.PadLeft(8, "#")
                    'End If
                    '▲----
                ElseIf retMon = 0 Then
                    '月が00の時は妥当性チェックは実施しない（できない）
                End If

                Return retStr
            End If

            ' YYYYMMDD編集実行 [2015/3/14 修正] ***
            retStr = editDateForYYYYMMDD(strDateArr(0), strDateArr(1), strDateArr(2), strDateArr(3))

            ' *** 日付妥当性チェック[2015/3/5 追加] ***
            ' 編集後の年、月、日を数値に変換
            retYear = Integer.Parse(retStr.Substring(0, 4))
            retMon = Integer.Parse(retStr.Substring(4, 2))
            retDay = Integer.Parse(retStr.Substring(6, 2))
            ' 日付の妥当性チェック（妥当な日付でない場合は、"########"に変換） *** 追加[2015/3/5] ***
            ' [妥当性チェックの対象は、年月日が全て入力されている時のみ]
            ' 元号を含めた年の妥当性チェック
            If Not IsDateForGengo(strDateArr(0), strDateArr(1), strDateArr(2), strDateArr(3)) Then
                retStr = String.Empty.PadLeft(8, "#")
            ElseIf Not IsDateValid(retYear, retMon, retDay) Then
                ' 月や日などの妥当性チェック
                retStr = String.Empty.PadLeft(8, "#")
            End If

            Return retStr

        Catch ex As Exception
            CommonLog.WriteLog("D203[支給開始年月日編集メソッド]でエラーを検出しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            writeErrorDataInfo(methodDef, targetData)
            Throw ex
        End Try

    End Function
#End Region

#Region "D204[年金支給額編集メソッド]"
    ''' <summary>
    ''' D204
    ''' </summary>
    ''' <param name="methodDef">納品編集定義情報</param>
    ''' <param name="targetData">エントリ結果</param>
    ''' <returns>編集後の文字列</returns>
    ''' <remarks>条件項目の内容より年金支給額の文字列を編集し、返却する</remarks>
    Public Function D204(ByVal methodDef As clsMethodDef, ByVal targetData As DataRow) As String

        ' 編集後の文字列
        Dim retStr As String = String.Empty

        Try
            ' 項目取得
            Dim item1Value As String = GetValue(targetData, methodDef.InputItems(0))            '条件項目1
            Dim item2Value As String = GetValue(targetData, methodDef.InputItems(1))            '条件項目2
            Dim item3Value As String = GetValue(targetData, methodDef.InputItems(2))            '年金支給額1
            Dim item4Value As String = GetValue(targetData, methodDef.InputItems(3))            '年金支給額2
            Dim item3DefValue As String = GetValue(targetData, methodDef.InputItems(2) & "_DEF") '不備項目1
            Dim item4DefValue As String = GetValue(targetData, methodDef.InputItems(3) & "_DEF") '不備項目2

            ' 条件判断
            Dim item1condition, item2condition As Boolean
            ' 条件項目1が"1"or"2"ならTrueを設定
            If item1Value.Trim = "1" OrElse item1Value.Trim = "2" Then
                item1condition = True
            End If
            ' 条件項目2が"1"or"2"ならTrueを設定
            If item2Value.Trim = "1" OrElse item2Value.Trim = "2" Then
                item2condition = True
            End If

            ' 条件項目1と条件項目2の両方がTrueの場合は"9999999999"を返却
            ' 条件項目1と条件項目2の両方がTrueの場合は、年金支給額1を編集　*** [2015/04/16 修正 Kuwahara] ***
            If item1condition AndAlso item2condition Then
                'Return "9999999999"
                '▼----  *** [2015/04/16 修正 Kuwahara] ***
                If item3DefValue = "02" Then
                    '9(10桁)を設定
                    Return "9999999999"
                Else
                    ' 数値と"?"以外の文字は削除する
                    retStr = RemoveNoNumChar(item3Value)
                    ' "?"が存在する場合、"9999999999"に置き換え
                    If retStr.IndexOf("?") >= 0 Then
                        Return "9999999999"
                    End If
                End If
                '▲----

            ElseIf item1condition Then
                ' 条件項目1が"1"or"2"なら年金支給額1を編集
                If item3DefValue = "02" Then
                    ''桁オーバーなら最終桁を"#"に置き換え
                    'retStr = LastReplaceString(item3Value, "#")
                    '9(10桁)を設定
                    Return "9999999999"
                Else
                    ' 数値と"?"以外の文字は削除する    *** [2015/03/05 追加] ***
                    retStr = RemoveNoNumChar(item3Value)
                    ' "?"が存在する場合、"9999999999"に置き換え
                    If retStr.IndexOf("?") >= 0 Then
                        Return "9999999999"
                    End If
                End If
            ElseIf item2condition Then
                ' 条件項目2が"1"or"2"なら年金支給額2を編集
                If item4DefValue = "02" Then
                    ''桁オーバーなら最終桁を"#"に置き換え
                    ''retStr = LastReplaceString(item4Value, "#")
                    '9(10桁)を設定
                    Return "9999999999"
                Else
                    ' 数値と"?"以外の文字は削除する    *** [2015/03/05 追加] ***
                    retStr = RemoveNoNumChar(item4Value)
                    ' "?"が存在する場合、"9999999999"に置き換え
                    If retStr.IndexOf("?") >= 0 Then
                        Return "9999999999"
                    End If
                End If
            Else
                ' 条件項目1,2ともに"1"or"2"以外の場合、年金支給額1を編集　*** [2015/04/16 修正 Kuwahara] ***
                'Return String.Empty
                '▼----  *** [2015/04/16 修正 Kuwahara] ***
                If item3DefValue = "02" Then
                    '9(10桁)を設定
                    Return "9999999999"
                Else
                    ' 数値と"?"以外の文字は削除する
                    retStr = RemoveNoNumChar(item3Value)
                    ' "?"が存在する場合、"9999999999"に置き換え
                    If retStr.IndexOf("?") >= 0 Then
                        Return "9999999999"
                    End If
                End If
                '▲----

            End If

            Return retStr

        Catch ex As Exception
            CommonLog.WriteLog("D204[年金支給額編集メソッド]でエラーを検出しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            writeErrorDataInfo(methodDef, targetData)
            Throw ex
        End Try

    End Function
#End Region

#Region "D205[介護保険サービス有無編集メソッド]"
    ''' <summary>
    ''' D205
    ''' </summary>
    ''' <param name="methodDef">納品編集定義情報</param>
    ''' <param name="targetData">エントリ結果</param>
    ''' <returns>編集後の文字列</returns>
    ''' <remarks>項目の内容より介護保険サービス有無の文字列を編集し、返却する</remarks>
    Public Function D205(ByVal methodDef As clsMethodDef, ByVal targetData As DataRow) As String
        ' 編集後の文字列
        Dim retStr As String = String.Empty
        Try
            ' 項目取得
            Dim item1Value As String = GetValue(targetData, methodDef.InputItems(0))            '条件項目1
            Dim item2Value As String = GetValue(targetData, methodDef.InputItems(1))            '条件項目2
            Dim item3Value As String = GetValue(targetData, methodDef.InputItems(2))            '条件項目3

            ' 条件判断
            If String.IsNullOrEmpty(item1Value) AndAlso _
               String.IsNullOrEmpty(item2Value) AndAlso _
               String.IsNullOrEmpty(item3Value) Then
                ' いずれも入力がない場合は"0"を設定
                retStr = "0"
            Else
                ' いずれかに何か入力があれば"1"を設定
                retStr = "1"
            End If

            Return retStr

        Catch ex As Exception
            CommonLog.WriteLog("D205[介護保険サービス有無編集メソッド]でエラーを検出しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            writeErrorDataInfo(methodDef, targetData)
            Throw ex
        End Try

    End Function
#End Region

#Region "D206[死亡者区分編集メソッド]"
    ''' <summary>
    ''' D206
    ''' </summary>
    ''' <param name="methodDef">納品編集定義情報</param>
    ''' <param name="targetData">エントリ結果</param>
    ''' <returns>編集後の文字列</returns>
    ''' <remarks>項目の内容より死亡者区分の文字列を編集し、返却する</remarks>
    Public Function D206(ByVal methodDef As clsMethodDef, ByVal targetData As DataRow) As String
        ' 編集後の文字列
        Dim retStr As String = String.Empty
        Try
            ' 項目取得
            Dim item1Value As String = GetValue(targetData, methodDef.InputItems(0))            '条件項目1
            Dim item2Value As String = GetValue(targetData, methodDef.InputItems(1))            '条件項目2

            ' 条件判断
            If Not String.IsNullOrEmpty(item1Value) AndAlso _
               Not String.IsNullOrEmpty(item2Value) Then
                ' いずれにも入力がある場合は"#"を設定
                retStr = "#"
            ElseIf Not String.IsNullOrEmpty(item1Value) Then
                ' 項目1に入力がある場合は"1"を設定
                retStr = "1"
            ElseIf Not String.IsNullOrEmpty(item2Value) Then
                ' 項目2に入力がある場合は"2"を設定
                retStr = "2"
            Else
                '↓2015/01/30 EDT
                ' いずれも入力がない場合は"0"を設定
                'retStr = "0"
                ' いずれも入力がない場合はNULLを設定
                retStr = ""
                '↑2015/01/30 EDT
            End If

            Return retStr

        Catch ex As Exception
            CommonLog.WriteLog("D206[死亡者区分編集メソッド]でエラーを検出しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            writeErrorDataInfo(methodDef, targetData)
            Throw ex
        End Try

    End Function
#End Region

#Region "D207[診療日の編集メソッド]"
    ''' <summary>
    ''' D207
    ''' </summary>
    ''' <param name="methodDef">納品編集定義情報</param>
    ''' <param name="targetData">エントリ結果</param>
    ''' <returns>編集後の文字列</returns>
    ''' <remarks>
    ''' 条件項目に基づいて、診療日の編集を行う
    ''' 　methodDef.MethodParam(0)　エントリ値（データベースの項目値）に含まれているか探索する値
    ''' 　methodDef.MethodParam(1)　InputItems(0)に値が含まれる場合に設定する値
    ''' 　methodDef.MethodParam(2)　InputItems(0)に値が含まれない場合に設定する値
    ''' 　methodDef.MethodParam(3)　エントリ値（データベースの項目値）に?が含まれる場合に設定する値
    ''' </remarks>
    Public Function D207(ByVal methodDef As clsMethodDef, ByVal targetData As DataRow) As String
        ' 編集後の文字列
        Dim retStr As String = String.Empty
        Try
            'エントリ値（データベースの項目値）
            Dim itemValues() As String = Split(GetValue(targetData, methodDef.InputItems(0)), ".")
            '引数値（探索値、設定値）
            Dim param1Value As String = methodDef.MethodParam(0)
            Dim param2Value As String = methodDef.MethodParam(1)
            Dim param3Value As String = methodDef.MethodParam(2)
            Dim param4Value As String = methodDef.MethodParam(3)

            'エントリ値探索
            For Each itemval As String In itemValues
                If itemval.IndexOf(param1Value & "?") >= 0 Then
                    'エントリ値に"引数1+?"が含まれている場合、引数4を戻り値に設定
                    retStr = param4Value
                    Exit For
                ElseIf itemval = param1Value Then
                    'エントリ値と引数1が一致する場合、引数2を戻り値に設定
                    retStr = param2Value
                    Exit For
                End If
            Next

            If String.IsNullOrEmpty(retStr) Then
                'エントリ値に"?"が含まれておらず、引数1に一致する値がない場合、引数3を戻り値に設定
                retStr = param3Value
            End If

            Return retStr

        Catch ex As Exception
            CommonLog.WriteLog("D207[診療日の編集メソッド]でエラーを検出しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            writeErrorDataInfo(methodDef, targetData)
            Throw ex
        End Try

    End Function
#End Region

#Region "D208[支払開始・終了日編集メソッド]"
    ''' <summary>
    ''' D208
    ''' </summary>
    ''' <param name="methodDef">納品編集定義情報</param>
    ''' <param name="targetData">エントリ結果</param>
    ''' <returns>編集後の文字列</returns>
    ''' <remarks>月、日の入力内容よりYYYYMMDD形式の文字列を作成する(YYYYは｢0000｣固定値 ※値があれば入力値)</remarks>
    Public Function D208(ByVal methodDef As clsMethodDef, ByVal targetData As DataRow) As String


        ' 編集後の文字列
        Dim retStr As String = String.Empty

        Try
            ' 日付項目取得
            Dim strDateArr() As String = {String.Empty, String.Empty, String.Empty, String.Empty}
            strDateArr(0) = GetValue(targetData, methodDef.InputItems(0))      ' 元号1桁
            strDateArr(1) = GetValue(targetData, methodDef.InputItems(1))      ' 年4桁前ゼロ
            strDateArr(2) = GetValue(targetData, methodDef.InputItems(2))      ' 月2桁前ゼロ
            strDateArr(3) = GetValue(targetData, methodDef.InputItems(3))      ' 日2桁前ゼロ
            ' 日付不備項目取得
            Dim strDateDefArr() As String = {String.Empty, String.Empty, String.Empty, String.Empty}
            strDateDefArr(0) = GetValue(targetData, methodDef.InputItems(0) & "_DEF")
            strDateDefArr(1) = GetValue(targetData, methodDef.InputItems(1) & "_DEF")
            strDateDefArr(2) = GetValue(targetData, methodDef.InputItems(2) & "_DEF")
            strDateDefArr(3) = GetValue(targetData, methodDef.InputItems(3) & "_DEF")

            ' 日付項目が不完全かどうかのチェックと返却文字列の生成 [2015/3/14 追加] ***
            retStr = ReplaceIncompleteDateForAll(strDateArr, strDateDefArr, "part")
            If retStr = EMPTY_VALUE OrElse retStr.IndexOf("#") >= 0 Then
                If retStr = EMPTY_VALUE Then
                    retStr = String.Empty
                End If
                Return retStr
            End If

            ' 編集後の年、月、日の数値格納用変数の宣言
            Dim retYear As Integer = 0
            Dim retMon As Integer = 0
            Dim retDay As Integer = 0

            ' 日付項目の中でNullがある項目に0埋めをした文字列を生成 [2015/3/14 追加] ***
            retStr = padDateString(strDateArr(0), strDateArr(1), strDateArr(2), strDateArr(3))
            If Not String.IsNullOrEmpty(retStr) Then
                retYear = Integer.Parse(retStr.Substring(0, 4))
                retMon = Integer.Parse(retStr.Substring(4, 2))
                retDay = Integer.Parse(retStr.Substring(6, 2))
                If retYear = 0 Then
                    '年が0000の時は月と日の妥当性チェックを実施
                    If Not IsDateValid(retMon, retDay) Then
                        retStr = "0000" & String.Empty.PadLeft(4, "#")
                    End If
                ElseIf retDay = 0 Then
                    '日が00の時は月の妥当性チェックを実施
                    '▼----  *** [2015/04/16 修正 Kuwahara] ***
                    If retMon <> 0 Then
                        If Not IsDateValid(retMon) Then
                            retStr = "0000" & String.Empty.PadLeft(4, "#")
                        End If
                    End If
                    'If Not IsDateValid(retMon) Then
                    'retStr = "0000" & String.Empty.PadLeft(4, "#")
                    'End If
                    '▲----
                ElseIf retMon = 0 Then
                    '月が00の時は妥当性チェックは実施しない（できない）
                End If

                Return retStr
            End If

            ' YYYYMMDD編集実行 [2015/3/14 修正] ***
            retStr = editDateForYYYYMMDD(strDateArr(0), strDateArr(1), strDateArr(2), strDateArr(3))
            '-->' MMDD編集実行(「YYYY」は発生しない想定だが保険)
            '-->retStr = editDateMMDD(strDateArr, strDateDefArr)

            ' *** 日付妥当性チェック[2015/3/5 追加] ***
            ' 編集後の月、日を数値に変換
            retYear = Integer.Parse(retStr.Substring(0, 4))
            retMon = Integer.Parse(retStr.Substring(4, 2))
            retDay = Integer.Parse(retStr.Substring(6, 2))
            ' 日付の妥当性チェック（妥当な日付でない場合は、"0000####"に変換） *** 追加[2015/3/5] ***

            If Not IsDateForGengo(strDateArr(0), strDateArr(1), strDateArr(2), strDateArr(3)) Then
                retStr = "0000####"
            ElseIf Not IsDateValid(retYear, retMon, retDay) Then
                ' 月や日などの妥当性チェック
                retStr = "0000####"
            End If

            Return retStr

        Catch ex As Exception
            CommonLog.WriteLog("D208[支払開始・終了日編集メソッド]でエラーを検出しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            writeErrorDataInfo(methodDef, targetData)
            Throw ex
        End Try

    End Function

#End Region


#Region "D901[シーケンスNo編集メソッド]"
    ''' <summary>
    ''' D901
    ''' </summary>
    ''' <param name="methodDef">メソッド定義オブジェクト（当該メソッドでは使用しません）</param>
    ''' <param name="targetData">対象データのDataRowオブジェクト（当該メソッドでは使用しません）</param>
    ''' <returns>採番された6桁の番号の文字列</returns>
    ''' <remarks>6桁の番号を採番し、文字列として返却する</remarks>
    Public Function D901(ByVal methodDef As clsMethodDef, ByVal targetData As DataRow) As String
        Try
            ' 東西情報の取得
            Dim ewKbn = GetValue(targetData, "EXC_IMAGE_KEY01")
            Dim seqNo As Integer

            If ewKbn = "PE" Then
                seqNoEast += 1
                seqNo = seqNoEast
            ElseIf ewKbn = "PW" Then
                seqNoWest += 1
                seqNo = seqNoWest
            End If

            Return String.Format("{0:000000}", seqNo)

        Catch ex As Exception
            CommonLog.WriteLog("D901[シーケンスNo編集メソッド]でエラーを検出しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            Throw ex
        End Try

    End Function

#End Region

#Region "D902[受付番号編集メソッド]"
    ''' <summary>
    ''' D902
    ''' </summary>
    ''' <param name="methodDef">メソッド定義オブジェクト</param>
    ''' <param name="targetData">対象データのDataRowオブジェクト</param>
    ''' <returns>編集された受付番号の文字列</returns>
    ''' <remarks>イメージファイル名の指定された範囲から受付番号を編集する</remarks>
    Public Function D902(ByVal methodDef As clsMethodDef, ByVal targetData As DataRow) As String
        ' 編集後の文字列
        Dim retStr As String = String.Empty
        Try
            ' 項目取得
            Dim item1Value As String = GetValue(targetData, methodDef.InputItems(0))    'イメージファイル名
            ' 引数内容取得
            Dim argValues As String() = methodDef.MethodParam
            ' 文字列部分抜き出し開始位置
            Dim startIndx As String = argValues(0)
            ' 文字列部分抜き出し終了位置
            Dim endIndx As String = argValues(1)
            ' トリムする文字列
            Dim rmveStr As String = argValues(2)

            ' 引数の値チェック
            If String.IsNullOrEmpty(startIndx) OrElse Not IsNumeric(startIndx) OrElse _
               String.IsNullOrEmpty(endIndx) OrElse Not IsNumeric(endIndx) OrElse _
               String.IsNullOrEmpty(rmveStr) Then
                Throw New Exception("受付番号の編集処理で引数がNullか不正な値が設定されています")
            End If

            ' 指定された文字列の部分抜き出しの実施
            retStr = Mid(item1Value, Integer.Parse(startIndx), Integer.Parse(endIndx))
            ' 指定された文字列でのトリム処理の実施
            retStr = Replace(retStr, rmveStr, String.Empty)

            Return retStr

        Catch ex As Exception
            CommonLog.WriteLog("D902[受付番号編集メソッド]でエラーを検出しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            writeErrorDataInfo(methodDef, targetData)
            Throw ex
        End Try

    End Function

#End Region

#Region "D209[傷病名の編集メソッド]"
    ''' <summary>
    ''' D209
    ''' </summary>
    ''' <param name="methodDef">納品編集定義情報</param>
    ''' <param name="targetData">エントリ結果</param>
    ''' <returns>編集後の文字列</returns>
    ''' <remarks>条件項目の内容より傷病名の文字列を編集し、返却する *** [2015/04/16 追加 Kuwahara] ***</remarks>
    Public Function D209(ByVal methodDef As clsMethodDef, ByVal targetData As DataRow) As String
        ' 編集後の文字列
        Dim retStr As String = String.Empty
        Try
            ' 項目取得
            Dim item1Value As String = GetValue(targetData, methodDef.InputItems(0)) '条件項目1
            Dim item2Value As String = GetValue(targetData, methodDef.InputItems(1)) '条件項目2
            Dim item3Value As String = GetValue(targetData, methodDef.InputItems(2)) '傷病名
            ' 不備項目内容取得
            Dim item3DefcValue As String = GetValue(targetData, methodDef.InputItems(2) & "_DEF")

            ' 条件判断
            Dim item1condition, item2condition As Boolean
            ' 条件項目1が"1"or"2"ならTrueを設定
            If item1Value.Trim = "1" OrElse item1Value.Trim = "2" Then
                item1condition = True
            End If
            ' 条件項目2が"1"or"2"ならTrueを設定
            If item2Value.Trim = "1" OrElse item2Value.Trim = "2" Then
                item2condition = True
            End If

            ' 非SS対応 
            If methodDef.SlipId(0).StartsWith("641") OrElse methodDef.SlipId(0).StartsWith("661") Then
                retStr = item3Value
            Else
                '外字変換処理
                Dim filterBytes As Byte() = _strConvObj.Filter(item3Value)
                retStr = System.Text.Encoding.GetEncoding("UTF-8").GetString(filterBytes)
            End If

            ' 条件項目1と条件項目2の両方がTrueの場合は、傷病名を編集
            If item1condition AndAlso item2condition Then
                ' 不正文字の置き換え（"〓" ⇒ "★"）
                retStr = retStr.Replace("〓", "★")

                ' 不備項目に"02"がセットされている場合
                If Not String.IsNullOrEmpty(item3DefcValue) AndAlso item3DefcValue = "02" Then
                    '最終文字を"★"で置き換え
                    retStr = LastReplaceString(retStr, "★")
                End If

                If Not methodDef.SlipId(0).StartsWith("641") AndAlso Not methodDef.SlipId(0).StartsWith("661") Then
                    ' 文字列から半角文字列を削除する
                    retStr = RemoveHalfByteChr(retStr)
                End If


            ElseIf item1condition Then
                ' 条件項目1が"1"or"2"なら傷病名を編集
                ' 不正文字の置き換え（"〓" ⇒ "★"）
                retStr = retStr.Replace("〓", "★")

                ' 不備項目に"02"がセットされている場合
                If Not String.IsNullOrEmpty(item3DefcValue) AndAlso item3DefcValue = "02" Then
                    '最終文字を"★"で置き換え
                    retStr = LastReplaceString(retStr, "★")
                End If

                If Not methodDef.SlipId(0).StartsWith("641") AndAlso Not methodDef.SlipId(0).StartsWith("661") Then
                    ' 文字列から半角文字列を削除する
                    retStr = RemoveHalfByteChr(retStr)
                End If

            ElseIf item2condition Then
                ' 条件項目2が"1"or"2"ならNullをセット
                retStr = String.Empty

            Else
                ' 条件項目1,2ともに"1"or"2"以外の場合、傷病名を編集
                ' 不正文字の置き換え（"〓" ⇒ "★"）
                retStr = retStr.Replace("〓", "★")

                ' 不備項目に"02"がセットされている場合
                If Not String.IsNullOrEmpty(item3DefcValue) AndAlso item3DefcValue = "02" Then
                    '最終文字を"★"で置き換え
                    retStr = LastReplaceString(retStr, "★")
                End If

                If Not methodDef.SlipId(0).StartsWith("641") AndAlso Not methodDef.SlipId(0).StartsWith("661") Then
                    ' 文字列から半角文字列を削除する
                    retStr = RemoveHalfByteChr(retStr)
                End If

            End If

            Return retStr

        Catch ex As Exception
            CommonLog.WriteLog("D209[傷病名の編集メソッド]でエラーを検出しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            writeErrorDataInfo(methodDef, targetData)
            Throw ex
        End Try

    End Function
#End Region

#Region "D210[住所の編集メソッド]"
    ''' <summary>
    ''' D210
    ''' </summary>
    ''' <param name="methodDef">納品編集定義情報</param>
    ''' <param name="targetData">エントリ結果</param>
    ''' <returns>編集後の文字列</returns>
    ''' <remarks>条件項目の内容より住所の文字列を編集し、返却する *** [2015/04/16 追加 Kuwahara] ***</remarks>
    Public Function D210(ByVal methodDef As clsMethodDef, ByVal targetData As DataRow) As String
        ' 編集後の文字列
        Dim retStr As String = String.Empty
        '住所文字列一時保管用
        Dim tmpStr As String = String.Empty
        Try
            ' 項目取得
            Dim itemValue As String = GetValue(targetData, methodDef.InputItems(0)) '住所
            ' 不備項目内容取得
            'Dim itemDefcValue As String = GetValue(targetData, methodDef.InputItems(2) & "_DEF")
            Dim itemDefcValue As String = GetValue(targetData, methodDef.InputItems(0) & "_DEF")

            Dim strAddrLen As Integer = itemValue.Length            ' 住所項目文字列の長さを取得
            Dim strTmp As String                                    '住所文字列編集用

            ' 非SS対応 
            Dim strAddress As String
            If methodDef.SlipId(0).StartsWith("641") OrElse methodDef.SlipId(0).StartsWith("661") Then
                strAddress = itemValue
            Else
                '外字変換処理
                Dim filterBytes As Byte() = _strConvObj.Filter(itemValue)
                strAddress = System.Text.Encoding.GetEncoding("UTF-8").GetString(filterBytes)
            End If

            '1. 文字列から13文字分を「住所1」に設定()
            Dim address1 As String = Left(strAddress, 13).TrimEnd()  ' 住所1の設定

            '2. 1で設定した以降の文字列を13文字分「住所2」に設定
            Dim address2 As String = String.Empty                ' 住所2の設定
            strTmp = Mid(strAddress, 14)
            If strTmp.Length > 0 Then
                '先頭がスペースなら削除する
                If Left(strTmp, 1) = "　" Then
                    strTmp = Mid(strTmp, 2)
                End If
                address2 = Left(strTmp, 13).TrimEnd()
            End If

            '3. 2で設定した以降の文字列を13文字分「住所3」に設定
            Dim address3 As String = String.Empty                ' 住所3の設定
            strTmp = Mid(strTmp, 14)
            If strTmp.Length > 0 Then
                '先頭がスペースなら削除する
                If Left(strTmp, 1) = "　" Then
                    strTmp = Mid(strTmp, 2)
                End If
                address3 = Left(strTmp, 13).TrimEnd()
            End If

            '4. 不正文字の置き換え（"〓" ⇒ "★"）
            address1 = address1.Replace("〓", "★")
            address2 = address2.Replace("〓", "★")
            address3 = address3.Replace("〓", "★")

            If Not methodDef.SlipId(0).StartsWith("641") AndAlso Not methodDef.SlipId(0).StartsWith("661") Then
                '5. 半角文字の削除
                address1 = RemoveHalfByteChr(address1)
                address2 = RemoveHalfByteChr(address2)
                address3 = RemoveHalfByteChr(address3)
            End If

            '6. 住所項目が39文字を超える場合、住所3の最終文字を"★"（不備）に置き換える
            '  （住所3の先頭が全角空白の場合は40文字を超える場合）
            If Mid(itemValue, 37, 1) = "　" AndAlso strAddrLen > 40 Then
                address3 = LastReplaceString(address3, "★")
            ElseIf strAddrLen > 39 Then
                address3 = LastReplaceString(address3, "★")
            End If

            ' 引数取得
            Dim argValue As String = methodDef.MethodParam(0)
            ' 引数によって、設定を分岐
            Select Case argValue
                Case "1"
                    retStr = address1       ' パラメータ=1の時、住所1を設定
                Case "2"
                    retStr = address2       ' パラメータ=2の時、住所2を設定
                Case "3"
                    retStr = address3       ' パラメータ=3の時、住所3を設定
            End Select

            Return retStr

        Catch ex As Exception
            CommonLog.WriteLog("D210[住所の編集メソッド]でエラーを検出しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            writeErrorDataInfo(methodDef, targetData)
            Throw ex
        End Try

    End Function
#End Region

#Region "D211[支給開始年月日編集メソッド]"
    ''' <summary>
    ''' D211
    ''' </summary>
    ''' <param name="methodDef">納品編集定義情報</param>
    ''' <param name="targetData">エントリ結果</param>
    ''' <returns>編集後の文字列</returns>
    ''' <remarks>条件項目の内容より支給開始年月日の文字列を編集し、返却する</remarks>
    Public Function D211(ByVal methodDef As clsMethodDef, ByVal targetData As DataRow) As String
        ' 編集後の文字列
        Dim retStr As String = String.Empty
        Try
            ' 項目取得
            Dim item1Value As String = GetValue(targetData, methodDef.InputItems(0)) '条件項目1
            Dim item2Value As String = GetValue(targetData, methodDef.InputItems(1)) '条件項目2

            ' 日付項目取得
            Dim strDateArr() As String = {String.Empty, String.Empty, String.Empty, String.Empty}
            ' 日付不備項目取得
            Dim strDateDefArr() As String = {String.Empty, String.Empty, String.Empty, String.Empty}

            ' 条件判断
            Dim item1condition, item2condition As Boolean
            ' 条件項目1が"1"or"2"ならTrueを設定
            If item1Value.Trim = "1" OrElse item1Value.Trim = "2" Then
                item1condition = True
            End If
            ' 条件項目2が"1"or"2"ならTrueを設定
            If item2Value.Trim = "1" OrElse item2Value.Trim = "2" Then
                item2condition = True
            End If

            ' 条件項目1と条件項目2の両方がTrueの場合は"########"を返却
            ' 条件項目1と条件項目2の両方がTrueの場合は、A(Item3-6)を編集　*** [2015/04/16 修正 Kuwahara] ***
            If item1condition AndAlso item2condition Then
                'Return "########"
                '▼----  *** [2015/04/16 修正 Kuwahara] ***
                strDateArr(0) = GetValue(targetData, methodDef.InputItems(2))       'A元号1桁
                strDateArr(1) = GetValue(targetData, methodDef.InputItems(3))       'A年4桁前ゼロ
                strDateArr(2) = GetValue(targetData, methodDef.InputItems(4))       'A月2桁前ゼロ
                strDateArr(3) = GetValue(targetData, methodDef.InputItems(5))       'A日2桁前ゼロ
                ' 日付不備項目取得
                strDateDefArr(0) = GetValue(targetData, methodDef.InputItems(2) & "_DEF")
                strDateDefArr(1) = GetValue(targetData, methodDef.InputItems(3) & "_DEF")
                strDateDefArr(2) = GetValue(targetData, methodDef.InputItems(4) & "_DEF")
                strDateDefArr(3) = GetValue(targetData, methodDef.InputItems(5) & "_DEF")
                '▲----

            ElseIf item1condition Then
                ' 日付項目取得
                strDateArr(0) = GetValue(targetData, methodDef.InputItems(2))       'A元号1桁
                strDateArr(1) = GetValue(targetData, methodDef.InputItems(3))       'A年4桁前ゼロ
                strDateArr(2) = GetValue(targetData, methodDef.InputItems(4))       'A月2桁前ゼロ
                strDateArr(3) = GetValue(targetData, methodDef.InputItems(5))       'A日2桁前ゼロ
                ' 日付不備項目取得
                strDateDefArr(0) = GetValue(targetData, methodDef.InputItems(2) & "_DEF")
                strDateDefArr(1) = GetValue(targetData, methodDef.InputItems(3) & "_DEF")
                strDateDefArr(2) = GetValue(targetData, methodDef.InputItems(4) & "_DEF")
                strDateDefArr(3) = GetValue(targetData, methodDef.InputItems(5) & "_DEF")
            ElseIf item2condition Then
                ' 日付項目取得
                strDateArr(0) = GetValue(targetData, methodDef.InputItems(6))       'B元号1桁
                strDateArr(1) = GetValue(targetData, methodDef.InputItems(7))       'B年4桁前ゼロ
                strDateArr(2) = GetValue(targetData, methodDef.InputItems(8))       'B月2桁前ゼロ
                strDateArr(3) = GetValue(targetData, methodDef.InputItems(9))       'B日2桁前ゼロ
                ' 日付不備項目取得
                strDateDefArr(0) = GetValue(targetData, methodDef.InputItems(6) & "_DEF")
                strDateDefArr(1) = GetValue(targetData, methodDef.InputItems(7) & "_DEF")
                strDateDefArr(2) = GetValue(targetData, methodDef.InputItems(8) & "_DEF")
                strDateDefArr(3) = GetValue(targetData, methodDef.InputItems(9) & "_DEF")
            Else
                ' 条件項目1,2ともに"1"or"2"以外の場合、NULLを返却  *** [2015/1/20] 修正***
                ' 条件項目1,2ともに"1"or"2"以外の場合、A(Item3-6)を編集　*** [2015/04/16 修正 Kuwahara] ***
                'Return String.Empty
                'Return "########"
                '▼----  *** [2015/04/16 修正 Kuwahara] ***
                strDateArr(0) = GetValue(targetData, methodDef.InputItems(2))       'A元号1桁
                strDateArr(1) = GetValue(targetData, methodDef.InputItems(3))       'A年4桁前ゼロ
                strDateArr(2) = GetValue(targetData, methodDef.InputItems(4))       'A月2桁前ゼロ
                strDateArr(3) = GetValue(targetData, methodDef.InputItems(5))       'A日2桁前ゼロ
                ' 日付不備項目取得
                strDateDefArr(0) = GetValue(targetData, methodDef.InputItems(2) & "_DEF")
                strDateDefArr(1) = GetValue(targetData, methodDef.InputItems(3) & "_DEF")
                strDateDefArr(2) = GetValue(targetData, methodDef.InputItems(4) & "_DEF")
                strDateDefArr(3) = GetValue(targetData, methodDef.InputItems(5) & "_DEF")
                '▲----

            End If

            Select Case strDateArr(0)
                Case "1"
                    strDateArr(0) = "3"
                Case "2"
                    strDateArr(0) = "4"
                Case "3"
                    strDateArr(0) = "5"
                Case "9"
                    strDateArr(0) = "9"
                Case String.Empty
                    strDateArr(0) = String.Empty
                Case Else
                    strDateArr(0) = "?"
            End Select

            ' 日付項目が不完全かどうかのチェックと返却文字列の生成 [2015/3/14 追加] ***
            retStr = ReplaceIncompleteDateForAll(strDateArr, strDateDefArr)
            If retStr = EMPTY_VALUE OrElse retStr = "########" Then
                If retStr = EMPTY_VALUE Then
                    retStr = String.Empty
                End If
                Return retStr
            End If

            ' 編集後の年、月、日の数値格納用変数の宣言
            Dim retYear As Integer = 0
            Dim retMon As Integer = 0
            Dim retDay As Integer = 0

            ' 日付項目の中でNullがある項目に0埋めをした文字列を生成 [2015/3/14 追加] ***
            retStr = padDateString(strDateArr(0), strDateArr(1), strDateArr(2), strDateArr(3))
            If Not String.IsNullOrEmpty(retStr) Then
                retYear = Integer.Parse(retStr.Substring(0, 4))
                retMon = Integer.Parse(retStr.Substring(4, 2))
                retDay = Integer.Parse(retStr.Substring(6, 2))
                If retYear = 0 Then
                    '年が0000の時は月と日の妥当性チェックを実施
                    If Not IsDateValid(retMon, retDay) Then
                        retStr = String.Empty.PadLeft(8, "#")
                    End If
                ElseIf retDay = 0 Then
                    '日が00の時は月の妥当性チェックを実施
                    '▼----  *** [2015/04/16 修正 Kuwahara] ***
                    If retMon <> 0 Then
                        If Not IsDateValid(retMon) Then
                            retStr = String.Empty.PadLeft(8, "#")
                        End If
                    End If
                    'If Not IsDateValid(retMon) Then
                    'retStr = String.Empty.PadLeft(8, "#")
                    'End If
                    '▲----
                ElseIf retMon = 0 Then
                    '月が00の時は妥当性チェックは実施しない（できない）
                End If

                Return retStr
            End If

            ' YYYYMMDD編集実行 [2015/3/14 修正] ***
            retStr = editDateForYYYYMMDD(strDateArr(0), strDateArr(1), strDateArr(2), strDateArr(3))

            ' *** 日付妥当性チェック[2015/3/5 追加] ***
            ' 編集後の年、月、日を数値に変換
            retYear = Integer.Parse(retStr.Substring(0, 4))
            retMon = Integer.Parse(retStr.Substring(4, 2))
            retDay = Integer.Parse(retStr.Substring(6, 2))
            ' 日付の妥当性チェック（妥当な日付でない場合は、"########"に変換） *** 追加[2015/3/5] ***
            ' [妥当性チェックの対象は、年月日が全て入力されている時のみ]
            ' 元号を含めた年の妥当性チェック
            If Not IsDateForGengo(strDateArr(0), strDateArr(1), strDateArr(2), strDateArr(3)) Then
                retStr = String.Empty.PadLeft(8, "#")
            ElseIf Not IsDateValid(retYear, retMon, retDay) Then
                ' 月や日などの妥当性チェック
                retStr = String.Empty.PadLeft(8, "#")
            End If

            Return retStr

        Catch ex As Exception
            CommonLog.WriteLog("D203[支給開始年月日編集メソッド]でエラーを検出しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            writeErrorDataInfo(methodDef, targetData)
            Throw ex
        End Try

    End Function
#End Region

#Region "D212[支払開始・終了日編集メソッド]"
    ''' <summary>
    ''' D212
    ''' </summary>
    ''' <param name="methodDef">納品編集定義情報</param>
    ''' <param name="targetData">エントリ結果</param>
    ''' <returns>編集後の文字列</returns>
    ''' <remarks>月、日の入力内容よりYYYYMMDD形式の文字列を作成する(YYYYは｢0000｣固定値 ※値があれば入力値)</remarks>
    Public Function D212(ByVal methodDef As clsMethodDef, ByVal targetData As DataRow) As String


        ' 編集後の文字列
        Dim retStr As String = String.Empty

        Try
            ' 日付項目取得
            Dim strDateArr() As String = {String.Empty, String.Empty, String.Empty, String.Empty}
            strDateArr(0) = GetValue(targetData, methodDef.InputItems(0))      ' 元号1桁
            Select Case strDateArr(0)
                Case "1"
                    strDateArr(0) = "4"
                Case "2"
                    strDateArr(0) = "5"
                Case "9"
                    strDateArr(0) = "9"
                Case String.Empty
                    strDateArr(0) = String.Empty
                Case Else
                    strDateArr(0) = "?"
            End Select
            strDateArr(1) = GetValue(targetData, methodDef.InputItems(1))      ' 年4桁前ゼロ
            strDateArr(2) = GetValue(targetData, methodDef.InputItems(2))      ' 月2桁前ゼロ
            strDateArr(3) = GetValue(targetData, methodDef.InputItems(3))      ' 日2桁前ゼロ
            ' 日付不備項目取得
            Dim strDateDefArr() As String = {String.Empty, String.Empty, String.Empty, String.Empty}
            strDateDefArr(0) = GetValue(targetData, methodDef.InputItems(0) & "_DEF")
            strDateDefArr(1) = GetValue(targetData, methodDef.InputItems(1) & "_DEF")
            strDateDefArr(2) = GetValue(targetData, methodDef.InputItems(2) & "_DEF")
            strDateDefArr(3) = GetValue(targetData, methodDef.InputItems(3) & "_DEF")

            ' 日付項目が不完全かどうかのチェックと返却文字列の生成 [2015/3/14 追加] ***
            retStr = ReplaceIncompleteDateForAll(strDateArr, strDateDefArr, "part")
            If retStr = EMPTY_VALUE OrElse retStr.IndexOf("#") >= 0 Then
                If retStr = EMPTY_VALUE Then
                    retStr = String.Empty
                End If
                Return retStr
            End If

            ' 編集後の年、月、日の数値格納用変数の宣言
            Dim retYear As Integer = 0
            Dim retMon As Integer = 0
            Dim retDay As Integer = 0

            ' 日付項目の中でNullがある項目に0埋めをした文字列を生成 [2015/3/14 追加] ***
            retStr = padDateString(strDateArr(0), strDateArr(1), strDateArr(2), strDateArr(3))
            If Not String.IsNullOrEmpty(retStr) Then
                retYear = Integer.Parse(retStr.Substring(0, 4))
                retMon = Integer.Parse(retStr.Substring(4, 2))
                retDay = Integer.Parse(retStr.Substring(6, 2))
                If retYear = 0 Then
                    '年が0000の時は月と日の妥当性チェックを実施
                    If Not IsDateValid(retMon, retDay) Then
                        retStr = "0000" & String.Empty.PadLeft(4, "#")
                    End If
                ElseIf retDay = 0 Then
                    '日が00の時は月の妥当性チェックを実施
                    '▼----  *** [2015/04/16 修正 Kuwahara] ***
                    If retMon <> 0 Then
                        If Not IsDateValid(retMon) Then
                            retStr = "0000" & String.Empty.PadLeft(4, "#")
                        End If
                    End If
                    'If Not IsDateValid(retMon) Then
                    'retStr = "0000" & String.Empty.PadLeft(4, "#")
                    'End If
                    '▲----
                ElseIf retMon = 0 Then
                    '月が00の時は妥当性チェックは実施しない（できない）
                End If

                Return retStr
            End If

            ' YYYYMMDD編集実行 [2015/3/14 修正] ***
            retStr = editDateForYYYYMMDD(strDateArr(0), strDateArr(1), strDateArr(2), strDateArr(3))
            '-->' MMDD編集実行(「YYYY」は発生しない想定だが保険)
            '-->retStr = editDateMMDD(strDateArr, strDateDefArr)

            ' *** 日付妥当性チェック[2015/3/5 追加] ***
            ' 編集後の月、日を数値に変換
            retYear = Integer.Parse(retStr.Substring(0, 4))
            retMon = Integer.Parse(retStr.Substring(4, 2))
            retDay = Integer.Parse(retStr.Substring(6, 2))
            ' 日付の妥当性チェック（妥当な日付でない場合は、"0000####"に変換） *** 追加[2015/3/5] ***

            If Not IsDateForGengo(strDateArr(0), strDateArr(1), strDateArr(2), strDateArr(3)) Then
                retStr = "0000####"
            ElseIf Not IsDateValid(retYear, retMon, retDay) Then
                ' 月や日などの妥当性チェック
                retStr = "0000####"
            End If

            Return retStr

        Catch ex As Exception
            CommonLog.WriteLog("D208[支払開始・終了日編集メソッド]でエラーを検出しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            writeErrorDataInfo(methodDef, targetData)
            Throw ex
        End Try

    End Function

#End Region

#Region "D213[住所の編集メソッド(アイテム結合方式)]"
    ''' <summary>
    ''' D213
    ''' </summary>
    ''' <param name="methodDef">納品編集定義情報</param>
    ''' <param name="targetData">エントリ結果</param>
    ''' <returns>編集後の文字列</returns>
    ''' <remarks>条件項目の内容より住所の文字列を編集し、返却する *** [2015/04/16 追加 Kuwahara] ***</remarks>
    Public Function D213(ByVal methodDef As clsMethodDef, ByVal targetData As DataRow) As String
        ' 編集後の文字列
        Dim retStr As String = String.Empty
        '住所文字列一時保管用
        Dim tmpStr As String = String.Empty
        Try
            Dim stbItem As New StringBuilder(String.Empty)
            For i As Integer = 0 To methodDef.InputItems.Length - 1 Step 1
                stbItem.Append(GetValue(targetData, methodDef.InputItems(i)))
            Next
            ' 項目取得
            Dim itemValue As String = stbItem.ToString.Trim

            ' 不備項目内容取得
            'Dim itemDefcValue As String = GetValue(targetData, methodDef.InputItems(2) & "_DEF")
            Dim itemDefcValue As String = GetValue(targetData, methodDef.InputItems(0) & "_DEF")

            Dim strAddrLen As Integer = itemValue.Length            ' 住所項目文字列の長さを取得
            Dim strTmp As String                                    '住所文字列編集用

            ' 非SS対応 
            Dim strAddress As String
            If methodDef.SlipId(0).StartsWith("641") OrElse methodDef.SlipId(0).StartsWith("661") Then
                strAddress = itemValue
            Else
                '外字変換処理
                Dim filterBytes As Byte() = _strConvObj.Filter(itemValue)
                strAddress = System.Text.Encoding.GetEncoding("UTF-8").GetString(filterBytes)
            End If

            '1. 文字列から13文字分を「住所1」に設定()
            Dim address1 As String = Left(strAddress, 13).TrimEnd()  ' 住所1の設定

            '2. 1で設定した以降の文字列を13文字分「住所2」に設定
            Dim address2 As String = String.Empty                ' 住所2の設定
            strTmp = Mid(strAddress, 14)
            If strTmp.Length > 0 Then
                '先頭がスペースなら削除する
                If Left(strTmp, 1) = "　" Then
                    strTmp = Mid(strTmp, 2)
                End If
                address2 = Left(strTmp, 13).TrimEnd()
            End If

            '3. 2で設定した以降の文字列を13文字分「住所3」に設定
            Dim address3 As String = String.Empty                ' 住所3の設定
            strTmp = Mid(strTmp, 14)
            If strTmp.Length > 0 Then
                '先頭がスペースなら削除する
                If Left(strTmp, 1) = "　" Then
                    strTmp = Mid(strTmp, 2)
                End If
                address3 = Left(strTmp, 13).TrimEnd()
            End If

            '4. 不正文字の置き換え（"〓" ⇒ "★"）
            address1 = address1.Replace("〓", "★")
            address2 = address2.Replace("〓", "★")
            address3 = address3.Replace("〓", "★")

            If Not methodDef.SlipId(0).StartsWith("641") AndAlso Not methodDef.SlipId(0).StartsWith("661") Then
                '5. 半角文字の削除
                address1 = RemoveHalfByteChr(address1)
                address2 = RemoveHalfByteChr(address2)
                address3 = RemoveHalfByteChr(address3)
            End If

            '6. 住所項目が39文字を超える場合、住所3の最終文字を"★"（不備）に置き換える
            '  （住所3の先頭が全角空白の場合は40文字を超える場合）
            If Mid(itemValue, 37, 1) = "　" AndAlso strAddrLen > 40 Then
                address3 = LastReplaceString(address3, "★")
            ElseIf strAddrLen > 39 Then
                address3 = LastReplaceString(address3, "★")
            End If

            ' 引数取得
            Dim argValue As String = methodDef.MethodParam(0)
            ' 引数によって、設定を分岐
            Select Case argValue
                Case "1"
                    retStr = address1       ' パラメータ=1の時、住所1を設定
                Case "2"
                    retStr = address2       ' パラメータ=2の時、住所2を設定
                Case "3"
                    retStr = address3       ' パラメータ=3の時、住所3を設定
            End Select

            Return retStr

        Catch ex As Exception
            CommonLog.WriteLog("D210[住所の編集メソッド]でエラーを検出しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            writeErrorDataInfo(methodDef, targetData)
            Throw ex
        End Try

    End Function
#End Region

#Region "D214[4件目移行データ有無編集メソッド]"
    ''' <summary>
    ''' D214
    ''' </summary>
    ''' <param name="methodDef">納品編集定義情報</param>
    ''' <param name="targetData">エントリ結果</param>
    ''' <returns>編集後の文字列</returns>
    ''' <remarks></remarks>
    Public Function D214(ByVal methodDef As clsMethodDef, ByVal targetData As DataRow) As String
        ' 編集後の文字列
        Dim retStr As String = String.Empty
        Try
            ' 編集項目内容取得
            Dim itemValue1 As String = GetValue(targetData, methodDef.InputItems(0))
            Dim itemValue2 As String = GetValue(targetData, methodDef.InputItems(1))

            If itemValue1.Equals("1") OrElse itemValue2.Equals("1") Then
                retStr = "1"
            Else
                retStr = "0"
            End If

            Return retStr

        Catch ex As Exception
            CommonLog.WriteLog("D101[半角項目の編集メソッド]でエラーを検出しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            writeErrorDataInfo(methodDef, targetData)
            Throw ex
        End Try
    End Function
#End Region

#Region "D215[住所の編集メソッド(アイテム結合方式)]"
    ''' <summary>
    ''' D215
    ''' </summary>
    ''' <param name="methodDef">納品編集定義情報</param>
    ''' <param name="targetData">エントリ結果</param>
    ''' <returns>編集後の文字列</returns>
    ''' <remarks>条件項目の内容より住所の文字列を編集し、返却する *** [2015/04/16 追加 Kuwahara] ***</remarks>
    Public Function D215(ByVal methodDef As clsMethodDef, ByVal targetData As DataRow) As String
        ' 編集後の文字列
        Dim retStr As String = String.Empty
        Try
            Dim stbItem As New StringBuilder(String.Empty)
            For i As Integer = 0 To methodDef.InputItems.Length - 1 Step 1
                stbItem.Append(GetValue(targetData, methodDef.InputItems(i)))
            Next
            ' 項目取得
            retStr = stbItem.ToString.Trim

            Return retStr

        Catch ex As Exception
            CommonLog.WriteLog("D210[住所の編集メソッド]でエラーを検出しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            writeErrorDataInfo(methodDef, targetData)
            Throw ex
        End Try

    End Function
#End Region

#Region "エントリ内容の取得"
    ''' <summary>
    ''' GetValue
    ''' </summary>
    ''' <param name="dr">対象となるDataRowオブジェクト</param>
    ''' <param name="cd">取得対象の項目（列）名</param>
    ''' <returns>項目（列）の値</returns>
    ''' <remarks></remarks>
    Private Function GetValue(ByVal dr As DataRow, ByVal cd As String) As String

        Try
            Return Convert.ToString(dr.Item(cd))
        Catch ex As Exception
            CommonLog.WriteLog("項目取得エラー：" & cd, EventLogEntryType.Error)
            Throw
        End Try

    End Function
#End Region



    Protected Overrides Sub Finalize()
        MyBase.Finalize()
    End Sub
End Class
