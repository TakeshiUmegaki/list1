''' <summary>
''' �[�i�f�[�^���\�b�h��`�N���X
''' </summary>
''' <remarks></remarks>
Public Class clsMethodDef

    ''' <summary>
    ''' SEQNo.
    ''' </summary>
    ''' <remarks></remarks>
    Private _seqNo As String
    Public Property SeqNo() As String
        Get
            Return _seqNo
        End Get
        Set(ByVal value As String)
            _seqNo = value
        End Set
    End Property

    ''' <summary>
    ''' �[�i���ږ�
    ''' </summary>
    ''' <remarks></remarks>
    Private _name As String
    Public Property Name() As String
        Get
            Return _name
        End Get
        Set(ByVal value As String)
            _name = value
        End Set
    End Property

    ''' <summary>
    ''' ���͍���
    ''' </summary>
    ''' <remarks></remarks>
    Private _inputItems() As String
    Public Property InputItems() As String()
        Get
            Return _inputItems
        End Get
        Set(ByVal value As String())
            _inputItems = value
        End Set
    End Property

    ''' <summary>
    ''' �ҏW���\�b�h��
    ''' </summary>
    ''' <remarks></remarks>
    Private _methodName As String
    Public Property MethodName() As String
        Get
            Return _methodName
        End Get
        Set(ByVal value As String)
            _methodName = value
        End Set
    End Property

    ''' <summary>
    ''' �ҏW���\�b�h����
    ''' </summary>
    ''' <remarks></remarks>
    Private _methodParam() As String
    Public Property MethodParam() As String()
        Get
            Return _methodParam
        End Get
        Set(ByVal value As String())
            _methodParam = value
        End Set
    End Property

    ''' <summary>
    ''' ���[ID
    ''' </summary>
    ''' <remarks></remarks>
    Private _slipId() As String
    Public Property SlipId() As String()
        Get
            Return _slipId
        End Get
        Set(ByVal value As String())
            _slipId = value
        End Set
    End Property

    ''' <summary>
    ''' �f�t�H���g�l
    ''' </summary>
    ''' <remarks></remarks>
    Private _defaultValue As String
    Public Property DefaultValue() As String
        Get
            Return _defaultValue
        End Get
        Set(ByVal value As String)
            _defaultValue = value
        End Set
    End Property

End Class
