﻿'**************************************************
'【Class】KanjiFilter
' 機　能：文字エンコーディング変換処理クラス
' 作成者：BPS張水清

' 作成日：2008/01/07
' -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-
' 修正履歴
'**************************************************

Imports System
Imports System.Text
Imports System.Text.RegularExpressions
Imports System.IO

' 文字セット定義
Public Enum KanjiSet
    JISX0208 = 0    ' JISX0201(半角文字セット) + 新JIS
    CP932 = 1       ' JISX0201(半角文字セット) + 新JIS + Microsoftによる拡張文字

    UNICODE20 = 2   ' MicrosoftによるUnicode2.0
End Enum

' エンコーディング定義
Public Enum KanjiEncoding
    Shift_JIS = 0   ' シフトJIS
    JIS = 1         ' JIS（IN/OUT有）

    EUC_JP = 2      ' UNIX等で利用
    UTF_8 = 3       ' XML等で利用
    UTF_16 = 4      ' Windowsネイティブコード、リトルエンディアンのバイト順

End Enum

'**************************************************
' KanjiFilter
' 機能：文字エンコーディング変換処理クラス
'**************************************************
Public Class clsComStringConw
    'Private _logs As Common.LogForNet               'ログ用のクラス
    'Private _DbCon As Common.DBcomUtility           'DB接続クラス


#Region "プライベート変数"

    ' 出力文字列の文字セット
    Private m_OutputKanjiSet As KanjiSet

    ' 出力文字列のエンコーディング
    Private m_OutputKanjiEncoding As KanjiEncoding

    ' 内部処理用のエンコーディングオブジェクト(UnicodeEncoding)
    Private m_UniEncoding As System.Text.Encoding

    ' 出力文字列のエンコーディングオブジェクト

    Private m_OutputEncoding As System.Text.Encoding

    ' 「外字」の置換え文字

    Private m_OutBoundChar As Char

    ' 外字と置換え文字の文字コード（Unicode）のマッピングを記述したファイル名

    Private m_MappingTableFileName As String

    ' 入力文字の置換マッピングファイルを展開したHashTable
    Private m_MappingTable As Hashtable

    ' 変換された文字と置換え文字の文字コードのマッピングを記述したファイル名

    Private m_DupMappingTableFileName As String

    ' 変換された文字の置換マッピングファイルを展開したHashTable
    Private m_DupMappingTable As Hashtable

    ' 最後の入力文字列
    Private m_LastInput As String

    ' 最後の出力文字列
    Private m_LastOutput As String

    ' 最後の出力文字列のバイト配列

    Private m_LastOutputBytes As Byte()

    ' エンコーディング名定義
    Private EncName As Array

#End Region

#Region "プロパティ"

    '**************************************************
    ' 変換処理出力する文字の文字セットを設定、取得

    '**************************************************
    Public Property OutputKanjiSet() As KanjiSet
        Get
            Return m_OutputKanjiSet
        End Get
        Set(ByVal value As KanjiSet)
            m_OutputKanjiSet = value
        End Set
    End Property

    '**************************************************
    ' 変換処理出力する文字のエンコーディングを設定、取得

    '**************************************************
    Public Property OutputKanjiEncoding() As KanjiEncoding
        Get
            Return m_OutputKanjiEncoding
        End Get
        Set(ByVal Value As KanjiEncoding)
            m_OutputKanjiEncoding = Value

            ' 上記のValueにより対応するエンコーディング名前を取得

            Dim encName As String = CType(GetEncodingName(Value), String)
            ' 出力エンコーディングを作成
            m_OutputEncoding = Encoding.GetEncoding(encName)
        End Set
    End Property

    '**************************************************
    ' 「外字」の置換え文字を設定、取得

    '**************************************************
    Public Property OutBoundChar() As Char
        Get
            Return m_OutBoundChar
        End Get
        Set(ByVal Value As Char)
            m_OutBoundChar = Value
        End Set
    End Property

    '**************************************************
    ' 置換文字コードのマッピングを記述したファイル名を設定、取得

    '**************************************************
    Public Property MappingTableFileName() As String
        Get
            Return m_MappingTableFileName
        End Get
        Set(ByVal Value As String)
            m_MappingTableFileName = Value
            m_MappingTable.Clear()

            Dim count As Integer

            ' HashTableにマッピングファイルを展開
            If Not File.Exists(m_MappingTableFileName) Then
                Throw New Exception(m_MappingTableFileName + "が存在しません。")
                Exit Property
            End If
            count = ReadMappingFile(m_MappingTableFileName, _
                                    Encoding.GetEncoding(GetEncodingName(KanjiEncoding.Shift_JIS)), _
                                    m_MappingTable)
        End Set
    End Property

    '**************************************************
    ' 変換後文字の置換文字コードマッピングを記述したファイル名を設定、取得

    '**************************************************
    Public Property DupMappingTableFileName() As String
        Get
            Return m_DupMappingTableFileName
        End Get
        Set(ByVal Value As String)
            m_DupMappingTableFileName = Value
            m_DupMappingTable.Clear()

            ' HashTableにマッピングファイルを展開
            Dim count As Integer
            If Not File.Exists(m_DupMappingTableFileName) Then
                ' Throw New Exception(m_DupMappingTableFileName + "が存在しません。")
                Exit Property
            End If
            count = ReadMappingFile(m_DupMappingTableFileName, _
                                    Encoding.GetEncoding(GetEncodingName(KanjiEncoding.Shift_JIS)), _
                                    m_DupMappingTable)
        End Set
    End Property

    '**************************************************
    ' 最後の入力文字列を取得

    '**************************************************
    Public ReadOnly Property LastInput() As String
        Get
            Return m_LastInput
        End Get
    End Property

    '**************************************************
    ' 最後の出力文字列を取得

    '**************************************************
    Public ReadOnly Property LastOutput() As String
        Get
            Return m_LastOutput
        End Get
    End Property

    '**************************************************
    ' 最後の出力文字列のバイト配列を取得

    '**************************************************
    Public ReadOnly Property LastOutputBytes() As Byte()
        Get
            Return m_LastOutputBytes
        End Get
    End Property

#End Region

#Region "コンストラクタ"

    Public Sub New()
        ' 変数初期化

        'm_OutputKanjiSet = KanjiSet.JISX0208
        'm_OutputKanjiEncoding = KanjiEncoding.Shift_JIS
        'm_OutBoundChar = "●"
        ''m_OutputKanjiSet = ""
        ''m_OutputKanjiEncoding = ""
        ''m_OutBoundChar = ""
        m_MappingTableFileName = ""
        m_DupMappingTableFileName = ""
        m_LastInput = ""
        m_LastOutput = ""

        ' 内部処理用エンコーディング（utf-16）を作成
        m_UniEncoding = Encoding.Unicode

        '' 出力エンコーディング名前を取得

        'Dim encName As String = GetEncodingName(m_OutputKanjiEncoding)

        '' 出力エンコーディングを作成
        'm_OutputEncoding = Encoding.GetEncoding(encName)

        ' HashTableを初期化
        m_MappingTable = New Hashtable
        m_DupMappingTable = New Hashtable

        ' 出力バイト配列を初期化

        m_LastOutputBytes = New Byte() {}
    End Sub

#End Region

#Region "パブリックメソッド - Filter"

    '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    '【Function】Filter
    '────────────────────────────────────
    ' [機　能]　文字列の文字変換・エンコーディング処理

    ' [引　数]     input    String  入力文字列
    ' [戻り値]     m_LastOutputBytes    Byte()  変換後の文字列
    '   バージョン 	  更新日	     作成者         内容 
    '　　 V3.0.0.0           2008/02/18 作成
    '────────────────────────────────────
    Public Function Filter(ByVal input As String) As Byte()
        Dim i As Integer                            ' ループ用変数
        Dim strCode As String = String.Empty        ' 文字コード

        Dim strReplaceCode As String = String.Empty ' 置換文字コード

        Dim strChar As String = String.Empty        ' 一文字

        Dim strOutput As String = String.Empty      ' UNICODE置換処理の出力文字列
        Dim OutputBytes As Byte() = New Byte() {}   ' 出力文字列のバイト配列

        Dim bytes As Byte()                         ' 一文字のバイト配列

        Dim intByte As Integer

        '_logs.Debug("Function Filterが開始しました!-------------------------")
        '_logs.Debug("入力1：input=" & input)

        ' 最後の入力文字列
        m_LastInput = input

        ' 最後の出力文字列クリア
        m_LastOutput = ""

        '// UNICODE文字置換処理

        If m_MappingTable.Count > 0 Then
            '// 入力文字列の各文字の置換え処理（内部処理はUnicodeEncodingを利用する）

            For i = 0 To input.Length() - 1

                ' 単一文字の取得
                strChar = input.Substring(i, 1)

                intByte = clsEditOutput.LengthB(strChar)

                Select Case intByte

                    Case 2
                        strOutput += strChar

                    Case 1
                        If i = input.Length() - 1 Then
                            strOutput += strChar
                            Exit Select
                        End If

                        strChar = input.Substring(i, 1) + input.Substring(i + 1, 1)

                        ' Unicodeエンコーディングで、各文字を文字コード（16進数）の文字列に変換する
                        strCode = StringToCode(strChar, m_UniEncoding)

                        ' マッピングテーブルに置換文字が存在するかどうかを検査する
                        If m_MappingTable.ContainsKey(strCode) = True Then

                            ' 置換文字コードの取得
                            strReplaceCode = CType(m_MappingTable(strCode), String)
                            ' 置換文字コードから置換え文字に変換する
                            strChar = CodeToString(strReplaceCode, m_UniEncoding)
                            strOutput += strChar
                            i += 1
                        Else
                            ' 置換しない
                            strOutput += input.Substring(i, 1)

                        End If

                End Select

            Next i
        Else
            strOutput = input
        End If

        '// 出力エンコーディングでエンコーディング処理（コード変換）

        For i = 0 To strOutput.Length() - 1
            strChar = strOutput.Substring(i, 1)

            ' 各文字を出力エンコーディングでバイト配列に変換する
            Try
                bytes = m_OutputEncoding.GetBytes(strChar)
            Catch ex As Exception
                bytes = m_OutputEncoding.GetBytes("?")
            End Try

            '// 上記の変換処理結果を検査する
            ' 変換失敗条件：bytesに対応する文字が「?」になる、且つ元の文字は「?」ではない

            If m_OutputEncoding.GetString(bytes) = "?" And strChar <> "?" Then
                ' 「外字」の置換え文字で置換する

                strChar = m_OutBoundChar
                bytes = m_OutputEncoding.GetBytes(strChar)
            End If

            ' 指定した出力エンコーディングで、各文字を文字コード（16進数）の文字列に変換する
            strCode = StringToCode(strChar, m_OutputEncoding)

            '// 出力文字コードの置換処理

            If m_DupMappingTable.Count > 0 Then

                ' 出力文字置換マッピングテーブルに置換え文字が存在するかどうかを検査する
                'If Not strReplaceCode Is Nothing Then
                If m_DupMappingTable.ContainsKey(strCode) = True Then
                    strReplaceCode = CType(m_DupMappingTable(strCode), String)

                    ' 置換え文字コードから置換え文字に変換する
                    strChar = CodeToString(strReplaceCode, m_OutputEncoding)
                    strCode = strReplaceCode
                    bytes = CodeToBytes(strReplaceCode)
                Else
                    ' 置換えしない

                End If
            End If

            '// 各文字が指定した文字セット範囲内に存在するかどうかを検査する
            If KanjiSetRangeCheck(strCode, m_OutputKanjiSet, m_OutputKanjiEncoding) = False Then
                ' 指定した文字セット範囲外の場合

                ' 「外字」の置換え文字で置換する

                strChar = m_OutBoundChar
                bytes = m_OutputEncoding.GetBytes(strChar)
            End If

            ' 最後の出力文字列を作成
            m_LastOutput += strChar

            ' 出力するバイト配列の後にに変換した文字バイト配列を追加する
            OutputBytes = BytesAppend(OutputBytes, bytes)
        Next i

        m_LastOutputBytes = OutputBytes

        '_logs.Debug("Function Filterが完了しました!-------------------------")
        ' 出力エンコーディングで変換した文字列のバイト配列を戻る

        Return m_LastOutputBytes

    End Function

#End Region

#Region "プライベートメソッド"

    '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    '【Function】GetEncodingName
    '────────────────────────────────────
    ' [機　能]　エンコーディング名前取得

    ' [引　数]     kenc    KanjiEncoding  指定されたエンコーディング
    ' [戻り値]     encName    String  エンコーディング名前
    '   バージョン 	  更新日	     作成者         内容 
    '　　 V3.0.0.0           2008/02/18                                            作成
    '────────────────────────────────────
    Private Function GetEncodingName(ByVal kenc As KanjiEncoding) As String
        '_logs.Debug("Function GetEncodingNameが開始しました!-------------------------")
        Dim encName As String = String.Empty

        Select Case kenc
            Case KanjiEncoding.Shift_JIS
                encName = "shift_jis"
            Case KanjiEncoding.JIS
                encName = "iso-2022-jp"
            Case KanjiEncoding.EUC_JP
                encName = "euc-jp"
            Case KanjiEncoding.UTF_8
                encName = "utf-8"
            Case KanjiEncoding.UTF_16
                encName = "utf-16"
            Case Else
                encName = ""
                Throw New System.Exception("指定したエンコーディング（" + [Enum].GetName(GetType(KanjiEncoding), kenc) + "）のエンコーディング名前を定義されていません。")
        End Select
        '_logs.Debug("Function GetEncodingNameが完了しました!-------------------------")
        Return encName
    End Function

    '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    '【Function】CheckFormat
    '────────────────────────────────────
    ' [機　能]　正規表現で文字列フォーマットを検査する
    ' [引　数]     (1)input    String  文字列
    '                      (2)pattern    String  正規表現の式

    ' [戻り値]     Boolean - True（OK）;False（NG）

    '   バージョン 	  更新日	     作成者         内容 
    '　　 V3.0.0.0           2008/02/18                                            作成
    '────────────────────────────────────
    Private Function CheckFormat(ByVal input As String, ByVal pattern As String) As Boolean
        Dim rx As Regex = New Regex(pattern)
        Return rx.IsMatch(input)
    End Function

    '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    '【Function】StringToCode
    '────────────────────────────────────
    ' [機　能]　指定する文字列を、あるエンコードの文字コードに変換、文字列型の文字コード値（16進数）を返す
    ' [引　数]     (1)str    String  文字列
    '                      (2)enc    Encoding  エンコーディング
    ' [戻り値]     strCode   String  文字列型の文字コード値（16進数）

    '   バージョン 	  更新日	     作成者         内容 
    '　　 V3.0.0.0           2008/02/18                                            作成
    '────────────────────────────────────
    Private Function StringToCode( _
        ByVal str As String, _
        ByVal enc As Encoding _
    ) As String
        '_logs.Debug("Function StringToCodeが開始しました!-------------------------")
        '_logs.Debug("入力1：str=" & str)
        Dim strCode As String = String.Empty
        Dim low As String = String.Empty
        Dim high As String = String.Empty

        For i As Integer = 0 To str.Length() - 1
            ' 指定したエンコーディングで各文字のバイト配列を取得

            Dim bytes As Byte() = enc.GetBytes(str.Substring(i, 1))

            ' リトルエンディアンのバイト順(UTF-16LE)の場合、バイトデータ順番変更
            If enc Is Encoding.Unicode Then
                Dim tmpByte As Byte = bytes(0)
                bytes(0) = bytes(1)
                bytes(1) = tmpByte
            End If

            strCode += BitConverter.ToString(bytes).Replace("-", "")
        Next i
        ''_logs.Debug("Function StringToCodeが完了しました!-------------------------")
        Return strCode
    End Function

    '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    '【Function】CodeToString
    '────────────────────────────────────
    ' [機　能]　指定する文字列型の文字コード（16進数）を、あるエンコーディングで、文字列に変換する
    ' [引　数]     (1)strCode    String  文字列
    '                      (2)enc    Encoding  エンコーディング
    ' [戻り値]     str   String  変換された文字列
    '   バージョン 	  更新日	     作成者         内容 
    '　　 V3.0.0.0           2008/02/18                                            作成
    '────────────────────────────────────
    Private Function CodeToString( _
             ByVal strCode As String, _
             ByVal enc As Encoding _
         ) As String
        '_logs.Debug("Function CodeToStringが開始しました!-------------------------")
        '_logs.Debug("入力1：strCode=" & strCode)
        ' Code文字列をバイト配列に変換
        Dim bytes As Byte() = CodeToBytes(strCode)

        ' リトルエンディアンのバイト順(UTF-16LE)の場合、バイトデータ順番変更
        If enc Is Encoding.Unicode Then
            Dim tmpByte As Byte = bytes(0)
            bytes(0) = bytes(1)
            bytes(1) = tmpByte
        End If

        ' 指定したエンコーディングでバイト配列を文字列にデコードする

        Dim str = enc.GetString(bytes)
        ''_logs.Debug("Function CodeToStringが完了しました!-------------------------")
        Return str
    End Function

    '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    '【Function】CodeToBytes
    '────────────────────────────────────
    ' [機　能]　指定する文字列型の文字コード（16進数）をバイト配列に変換する
    ' [引　数]    strCode    String  文字列
    ' [戻り値]     bytes   Byte()  文字列のバイト配列

    '   バージョン 	  更新日	     作成者         内容 
    '　　 V3.0.0.0           2008/02/18                                            作成
    '────────────────────────────────────
    Private Function CodeToBytes(ByVal strCode As String) As Byte()

        '_logs.Debug("Function CodeToBytesが開始しました!-------------------------")
        '_logs.Debug("入力1：strCode=" & strCode)
        Dim bytes As Byte() = New Byte(strCode.Length() / 2 - 1) {}
        Dim j As Integer = 0
        For i As Integer = 0 To strCode.Length() - 1 Step 2
            Dim code As String = strCode.Substring(i, 2)
            bytes(j) = System.Convert.ToByte(code, 16)
            j += 1
        Next i
        '_logs.Debug("Function CodeToBytesが完了しました!-------------------------")
        Return bytes
    End Function

    '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    '【Function】BytesAppend
    '────────────────────────────────────
    ' [機　能]　あるハイド配列の後に、別のバイト配列を追加、新しいバイト配列を取得する

    ' [引　数]    (1)srcbytes   Byte()  元のバイト配列

    '                      (2)appendbytes    Byte()  追加のバイト配列

    ' [戻り値]     bytes   Byte()  新作成のバイト配列

    '   バージョン 	  更新日	     作成者         内容 
    '　　 V3.0.0.0           2008/02/18                                            作成
    '────────────────────────────────────
    Private Function BytesAppend(ByVal srcbytes As Byte(), ByVal appendbytes As Byte()) As Byte()
        '_logs.Debug("Function BytesAppendが開始しました!-------------------------")
        Dim size As Integer = srcbytes.Length() + appendbytes.Length() - 1

        ' 新サイズのバイト配列定義
        Dim NewBytes As Byte() = New Byte(size) {}

        ' srcbytesの内容をNewBytesにコピー
        Array.Copy(srcbytes, NewBytes, srcbytes.Length())

        ' NewBytesにappendbytesの内容を設定する

        Array.Copy(appendbytes, 0, NewBytes, srcbytes.Length(), appendbytes.Length())
        '_logs.Debug("Function BytesAppendが完了しました!-------------------------")
        Return NewBytes
    End Function

    '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    '【Function】KanjiSetRangeCheck
    '────────────────────────────────────
    ' [機　能]　指定する文字コード（16進数）を、出力文字セットの文字範囲内にあるかどうか検査する
    '       Unicode(utf-16)とJISX0208・CP932(Shift-JIS)の文字コードチェックをサポートする

    ' [引　数]    (1)strCode    String  文字コード

    '                      (2)kset KanjiSet  文字セット
    '                      (3)kenc KanjiEncoding  エンコーディング
    ' [戻り値]     Boolean - True（範囲内）;False（範囲外）

    '   バージョン 	  更新日	     作成者         内容 
    '　　 V3.0.0.0           2008/02/18                                            作成
    '────────────────────────────────────
    Private Function KanjiSetRangeCheck(ByVal strCode As String, ByVal kset As KanjiSet, ByVal kenc As KanjiEncoding) As Boolean
        Dim flag As Integer
        '_logs.Debug("Function KanjiSetRangeCheckが開始しました!-------------------------")
        '_logs.Debug("入力1：strCode=" & strCode)
        ' 文字セット範囲内チェック
        If kset = KanjiSet.UNICODE20 Then
            ' Unicode
            flag = UnicodeCheck(strCode, kenc)

        ElseIf kset = KanjiSet.CP932 Or kset = KanjiSet.JISX0208 Then
            ' CP932、JISX0208
            If kenc = KanjiEncoding.Shift_JIS Then
                ' Shift-JISエンコードの場合

                flag = ShiftJISCheck(strCode)
                If Not (flag = 1 And (kset = KanjiSet.JISX0208 Or kset = KanjiSet.CP932)) And _
                   Not (flag = 2 And kset = KanjiSet.CP932) Then
                    flag = 0
                End If
            Else
                ' その他エンコードの場合

                flag = 1
            End If
        Else
            ' その他文字セット
            flag = 0
        End If

        ' 範囲外

        If (flag = 0) Then
            Return False
        End If
        ''_logs.Debug("Function KanjiSetRangeCheckが完了しました!-------------------------")
        ' 範囲内

        Return True
    End Function

    '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    '【Function】UnicodeCheck
    '────────────────────────────────────
    ' [機　能]　指定する文字コード（16進数）を、UNICODE文字範囲内にあるかどうか検査する
    ' [引　数]    (1)strCode    String - 文字コード

    '                      (2)kenc KanjiEncoding - エンコーディング
    ' [戻り値]     Integer - 0（範囲外）  1（UTF-16範囲内）

    '   バージョン 	  更新日	     作成者         内容 
    '　　 V3.0.0.0           2008/02/18                                            作成
    '────────────────────────────────────
    Private Function UnicodeCheck(ByVal strCode As String, ByVal kenc As KanjiEncoding) As Integer
        Dim flag As Integer = 0
        '_logs.Debug("Function UnicodeCheckが開始しました!-------------------------")
        '_logs.Debug("入力1：strCode=" & strCode)
        If kenc = KanjiEncoding.UTF_16 Then
            ' uft-16エンコードの場合

            If CheckFormat(strCode, "[0-9A-Fa-f]{4}") = True Then
                ' 16進数、4桁のコードはWindowsOSの処理範囲なので、範囲内

                flag = 1
            Else
                flag = 0
            End If
        Else
            ' その他エンコードの場合

            flag = 1
        End If

        '// 範囲内を判断する
        If (flag = 1) Then
            Return 1
        End If
        ''_logs.Debug("Function UnicodeCheckが完了しました!-------------------------")
        ' 範囲外

        Return 0
    End Function

    '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    '【Function】ShiftJISCheck
    '────────────────────────────────────
    ' [機　能]　指定する文字コード（16進数）を、ShiftJISコードの範囲内にあるかどうか検査する
    ' [引　数]    (1)strCode    String  文字コード

    ' [戻り値]    Integer - 0（範囲外）

    '                       1（JISX0201・JISX0208範囲内）

    '                       2（CP932拡張範囲内）

    '   バージョン 	  更新日	     作成者         内容 
    '　　 V3.0.0.0           2008/02/18                                            作成
    '────────────────────────────────────
    Private Function ShiftJISCheck(ByVal strCode As String) As Integer
        Dim flag As Integer = 0
        '_logs.Debug("Function ShiftJISCheckが開始しました!-------------------------")
        '_logs.Debug("入力1：strCode=" & strCode)
        ' 2桁・4桁16進数チェック
        If CheckFormat(strCode, "[0-9A-Fa-f]{2}") = False And _
           CheckFormat(strCode, "[0-9A-Fa-f]{4}") = False Then
            '_logs.Debug("Function ShiftJISCheckが完了しました!-------------------------")
            Return 0
        End If

        '// Shift-JIS文字コード範囲をチェック
        If (strCode.Length() = 2) Then
            ' JIS X 0201(半角文字セット)
            If (strCode >= "00" And strCode <= "1F") Or (strCode = "7F") Then
                ' ASCII
                flag = 1
            ElseIf (strCode >= "20" And strCode <= "7E") Then
                '記号・半角英数字

                flag = 1
            ElseIf strCode >= "A1" And strCode <= "DF" Then
                ' 半角文字

                flag = 1
            Else
                flag = -1
            End If
        ElseIf (strCode <= "86FC") Then
            ' JIS X 0208（非漢字）

            If (strCode >= "8140" And strCode <= "81FC") Then
                ' 記号
                flag = 1
            ElseIf (strCode >= "824F" And strCode <= "8258") Then
                ' 数字

                flag = 1
            ElseIf (strCode >= "8260" And strCode <= "8279") Then
                ' 英字(大文字アルファベット)
                flag = 1
            ElseIf (strCode >= "8281" And strCode <= "829A") Then
                ' 英字(小文字アルファベット)
                flag = 1
            ElseIf (strCode >= "829F" And strCode <= "82F1") Then
                ' ひらがな
                flag = 1
            ElseIf (strCode >= "8340" And strCode <= "837E") Then
                ' カタカナ

                flag = 1
            ElseIf (strCode >= "8380" And strCode <= "8396") Then
                ' カタカナ

                flag = 1
            ElseIf (strCode >= "839F" And strCode <= "83B6") Then
                ' 大文字ギリシャ文字

                flag = 1
            ElseIf (strCode >= "83BF" And strCode <= "83D6") Then
                ' 小文字ギリシャ文字

                flag = 1
            ElseIf (strCode >= "8440" And strCode <= "8460") Then
                ' 大文字ロシア文字

                flag = 1
            ElseIf (strCode >= "8470" And strCode <= "847E") Or _
                (strCode >= "8480" And strCode <= "8491") Then
                ' 小文字ロシア文字

                flag = 1
            ElseIf (strCode >= "849F" And strCode <= "84BE") Then
                ' 罫線

                flag = 1
            Else
                flag = 0
            End If

        ElseIf (strCode >= "889F" And strCode <= "9872") Then
            ' JIS X 0208（第一水準漢字）

            ' 第一水準漢字

            flag = 1
        ElseIf (strCode >= "989F" And strCode <= "9FFC") Then
            ' JIS X 0208（第二水準漢字）

            ' 第二水準漢字

            flag = 1
        ElseIf (strCode >= "E040" And strCode <= "EAA4") Then
            ' JIS X 0208（第二水準漢字）

            flag = 1
        ElseIf (strCode >= "8740" And strCode <= "875D") Then
            ' CP932（拡張文字）

            ' NEC特殊文字(丸付アラビア数字、大文字ローマ数字)
            flag = 2
        ElseIf (strCode >= "875F" And strCode <= "8775") Then
            ' CP932（拡張文字）

            ' NEC特殊文字（単位記号）

            flag = 2
        ElseIf (strCode = "877E") Or (strCode >= "8780" And strCode <= "879C") Then
            ' CP932（拡張文字）

            ' NEC特殊文字(和暦元号、株式会社・有限会社記号含む)
            flag = 2
        ElseIf (strCode >= "ED40" And strCode <= "EEFC") Then
            ' CP932（拡張文字）

            ' NEC選定IBM拡張文字

            flag = 2
        ElseIf (strCode >= "FA40" And strCode <= "FC4B") Then
            ' CP932（拡張文字）

            ' IBM選定IBM拡張文字

            flag = 2
        Else
            flag = 0
        End If

        ' 下2桁が「7F」「FD」「FE」「FF」のものは除く

        Dim low As String = Right(strCode, 2)
        If low = "7F" Or low = "FD" Or low = "FE" Or low = "FF" Then
            flag = 0
        End If

        '// JISX0208の範囲内を判断する
        If (flag = 1) Then
            Return 1
        End If

        '// CP932の範囲内（マイクロソフトによる拡張文字）を判断する
        If (flag = 2) Then
            Return 2
        End If
        '_logs.Debug("Function ShiftJISCheckが完了しました!-------------------------")

        ' JISX0208・CP932の範囲外

        Return 0
    End Function

    '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    '【Function】ReadMappingFile
    '────────────────────────────────────
    ' [機　能]　マッピングファイルをHashTableに展開する
    ' [引　数]    (1)mappingFileName String - マッピングファイル名

    '                      (2)enc   Encoding - マッピングファイルのエンコーディング
    '                      (3)mappingTable   Hashtable - マッピングを展開するHashTable
    ' [戻り値]    Integer - 処理した行数
    '   バージョン 	  更新日	     作成者         内容 
    '　　 V3.0.0.0           2008/02/18                                            作成
    '────────────────────────────────────
    Private Function ReadMappingFile(ByVal mappingFileName As String, ByVal enc As Encoding, ByRef mappingTable As Hashtable) As Integer

        Dim reader As StreamReader = New StreamReader(mappingFileName, enc)
        Dim line As String = String.Empty
        Dim val() As String
        Dim count As Integer = 0

        Try
            '_logs.Debug("Function ReadMappingFileが開始しました!-------------------------")
            '_logs.Debug("入力1：mappingFileName=" & mappingFileName)
            Do  ' マッピングファイル.一行ずつ読取()
                line = reader.ReadLine()
                If line Is Nothing Then Exit Do

                line.Trim()
                If line.Substring(0, 1) <> "#" And line <> "" Then
                    ' TAB区切で各項目を取得

                    ' 置換前コード<TAB>置換後コード<TAB>置換前文字<TAB>置換後文字

                    val = line.Split(Chr(9))

                    ' 置換前コードチェック（4桁、16進数）

                    If CheckFormat(val(0), "[0-9A-Fa-f]{4}") = False Then
                        mappingTable.Clear()
                        ' Throw New Exception(mappingFileName + "のフォーマットが正しくありません")
                        Exit Function
                    End If
                    ' 置換後コードチェック（4桁、16進数）

                    If CheckFormat(val(1), "[0-9A-Fa-f]{4}") = False Then
                        mappingTable.Clear()
                        ' Throw New Exception(mappingFileName + "のフォーマットが正しくありません")
                        Exit Function
                    End If

                    '置換前コード/置換後コードをHashTableに展開
                    mappingTable.Add(val(0), val(1))

                    ' 計数
                    count += 1
                End If

                ' 次の行へ
            Loop

        Catch ex As Exception
            Throw New Exception("マッピングファイル（" + mappingFileName + "）を展開する時、エラーが発生しました。", ex)
        Finally
            reader.Close()
            '_logs.Debug("Function ReadMappingFileが完了しました!-------------------------")
        End Try

        Return count
    End Function

#End Region

#Region "ログオブジェクトプロパティ"

    '----------------------------------------------------------------------------------------
    ' 概要

    '   ログオブジェクトプロパティ
    '
    ' 更新履歴
    '   2008/07/25 M.Ogawa 新規作成
    '----------------------------------------------------------------------------------------
    'Public WriteOnly Property logs() As Common.LogForNet
    '    Set(ByVal value As Common.LogForNet)
    '        _logs = value
    '    End Set
    'End Property

#End Region

#Region "ＤＢオブジェクトプロパティ"

    '----------------------------------------------------------------------------------------
    ' 概要

    '   ＤＢオブジェクトプロパティ
    '
    ' 更新履歴
    '   2008/07/25 M.Ogawa 新規作成
    '----------------------------------------------------------------------------------------
    'Public WriteOnly Property DbCon() As Common.DBcomUtility
    '    Set(ByVal value As Common.DBcomUtility)
    '        _DbCon = value
    '    End Set
    'End Property

#End Region

End Class
