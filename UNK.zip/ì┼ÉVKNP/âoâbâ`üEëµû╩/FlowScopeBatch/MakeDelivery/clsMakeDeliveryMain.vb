﻿Imports CommonSystem
Imports CommonBase
Imports System
Imports System.Configuration
Imports System.IO
Imports System.Text
Imports Oracle.DataAccess.Client

Public Class clsMakeDeliveryMain
    Inherits clsBatchBase

#Region "共通変数"

    ''' <summary>
    ''' 自端末処理
    ''' 帳票出力上限数を東西４種(計８種)追加  *** [2015/06/24] 追加 ***
    ''' </summary>
    ''' <remarks></remarks>
    Private Shared mainProc As clsMakeDeliveryMain

#End Region

#Region "内部変数定義"

    Private mstrDeliveryDate As String = String.Empty

    ''' <summary>
    ''' 帳票ID統一用辞書
    ''' </summary>
    ''' <remarks></remarks>
    Private mstrSlipConv()() As String = { _
        New String() {"601115", "601160"}, _
        New String() {"601214", "601269"}, _
        New String() {"601313", "601368"}, _
        New String() {"601412", "601467"}, _
        New String() {"601146", "601191"}, _
        New String() {"601245", "601290"}, _
        New String() {"601139", "601184"}, _
        New String() {"601238", "601283"}, _
        New String() {"611114", "611169"}, _
        New String() {"611213", "611268"}, _
        New String() {"611312", "611367"}, _
        New String() {"611145", "611190"}, _
        New String() {"611244", "611299"}, _
        New String() {"611138", "611183"}, _
        New String() {"611237", "611282"}, _
        New String() {"621113", "621168"}, _
        New String() {"621212", "621267"}, _
        New String() {"621120", "621175"}, _
        New String() {"621229", "621274"}, _
        New String() {"631112", "631167"}, _
        New String() {"631211", "631266"}, _
        New String() {"631129", "631174"}, _
        New String() {"631228", "631273"}, _
        New String() {"641111", "641166"}, _
        New String() {"641210", "641265"}, _
        New String() {"641128", "641173"}, _
        New String() {"641227", "641272"}, _
        New String() {"661119", "661164"}, _
        New String() {"661218", "661263"}, _
        New String() {"661126", "661171"}, _
        New String() {"661225", "661270"} _
    }

    ' 元号変換テーブル
    Private mstrEraConv()() As String = { _
        New String() {"601160", "ITEM_003", "3"}, _
        New String() {"601160", "ITEM_023", "4"}, _
        New String() {"601184", "ITEM_003", "3"}, _
        New String() {"601184", "ITEM_023", "4"}, _
        New String() {"601184", "ITEM_104", "4"}, _
        New String() {"601184", "ITEM_108", "4"}, _
        New String() {"601184", "ITEM_112", "4"}, _
        New String() {"601184", "ITEM_118", "4"}, _
        New String() {"601184", "ITEM_122", "4"}, _
        New String() {"601184", "ITEM_129", "4"}, _
        New String() {"601184", "ITEM_133", "4"}, _
        New String() {"601184", "ITEM_143", "3"}, _
        New String() {"601184", "ITEM_151", "3"}, _
        New String() {"601191", "ITEM_003", "3"}, _
        New String() {"601191", "ITEM_023", "4"}, _
        New String() {"601191", "ITEM_104", "4"}, _
        New String() {"601191", "ITEM_108", "4"}, _
        New String() {"601191", "ITEM_112", "4"}, _
        New String() {"601191", "ITEM_118", "4"}, _
        New String() {"601191", "ITEM_122", "4"}, _
        New String() {"601191", "ITEM_129", "4"}, _
        New String() {"601191", "ITEM_133", "4"}, _
        New String() {"601191", "ITEM_143", "3"}, _
        New String() {"601191", "ITEM_151", "3"}, _
        New String() {"601269", "ITEM_104", "4"}, _
        New String() {"601269", "ITEM_108", "4"}, _
        New String() {"601269", "ITEM_112", "4"}, _
        New String() {"601269", "ITEM_118", "4"}, _
        New String() {"601269", "ITEM_122", "4"}, _
        New String() {"601269", "ITEM_129", "4"}, _
        New String() {"601269", "ITEM_133", "4"}, _
        New String() {"601269", "ITEM_143", "3"}, _
        New String() {"601269", "ITEM_151", "3"}, _
        New String() {"601283", "ITEM_001", "4"}, _
        New String() {"601283", "ITEM_037", "4"}, _
        New String() {"601283", "ITEM_073", "4"}, _
        New String() {"601283", "ITEM_123", "4"}, _
        New String() {"601283", "ITEM_127", "4"}, _
        New String() {"601283", "ITEM_139", "4"}, _
        New String() {"601283", "ITEM_143", "4"}, _
        New String() {"601283", "ITEM_155", "4"}, _
        New String() {"601283", "ITEM_159", "4"}, _
        New String() {"601283", "ITEM_173", "4"}, _
        New String() {"601283", "ITEM_205", "4"}, _
        New String() {"601283", "ITEM_209", "4"}, _
        New String() {"601283", "ITEM_213", "4"}, _
        New String() {"601283", "ITEM_217", "4"}, _
        New String() {"601283", "ITEM_223", "4"}, _
        New String() {"601283", "ITEM_227", "4"}, _
        New String() {"601283", "ITEM_232", "4"}, _
        New String() {"601283", "ITEM_236", "4"}, _
        New String() {"601283", "ITEM_342", "4"}, _
        New String() {"601283", "ITEM_346", "4"}, _
        New String() {"601283", "ITEM_352", "3"}, _
        New String() {"601283", "ITEM_358", "4"}, _
        New String() {"601290", "ITEM_001", "4"}, _
        New String() {"601290", "ITEM_037", "4"}, _
        New String() {"601290", "ITEM_073", "4"}, _
        New String() {"601290", "ITEM_123", "4"}, _
        New String() {"601290", "ITEM_127", "4"}, _
        New String() {"601290", "ITEM_139", "4"}, _
        New String() {"601290", "ITEM_143", "4"}, _
        New String() {"601290", "ITEM_155", "4"}, _
        New String() {"601290", "ITEM_159", "4"}, _
        New String() {"601290", "ITEM_173", "4"}, _
        New String() {"601290", "ITEM_205", "4"}, _
        New String() {"601290", "ITEM_209", "4"}, _
        New String() {"601290", "ITEM_213", "4"}, _
        New String() {"601290", "ITEM_217", "4"}, _
        New String() {"601290", "ITEM_223", "4"}, _
        New String() {"601290", "ITEM_227", "4"}, _
        New String() {"601290", "ITEM_232", "4"}, _
        New String() {"601290", "ITEM_236", "4"}, _
        New String() {"601290", "ITEM_342", "4"}, _
        New String() {"601290", "ITEM_346", "4"}, _
        New String() {"601290", "ITEM_352", "3"}, _
        New String() {"601290", "ITEM_358", "4"}, _
        New String() {"601368", "ITEM_001", "4"}, _
        New String() {"601368", "ITEM_037", "4"}, _
        New String() {"601368", "ITEM_073", "4"}, _
        New String() {"601368", "ITEM_123", "4"}, _
        New String() {"601368", "ITEM_127", "4"}, _
        New String() {"601368", "ITEM_139", "4"}, _
        New String() {"601368", "ITEM_143", "4"}, _
        New String() {"601368", "ITEM_155", "4"}, _
        New String() {"601368", "ITEM_159", "4"}, _
        New String() {"601368", "ITEM_173", "4"}, _
        New String() {"601467", "ITEM_205", "4"}, _
        New String() {"601467", "ITEM_209", "4"}, _
        New String() {"601467", "ITEM_213", "4"}, _
        New String() {"601467", "ITEM_217", "4"}, _
        New String() {"601467", "ITEM_223", "4"}, _
        New String() {"601467", "ITEM_227", "4"}, _
        New String() {"601467", "ITEM_232", "4"}, _
        New String() {"601467", "ITEM_236", "4"}, _
        New String() {"601467", "ITEM_342", "4"}, _
        New String() {"601467", "ITEM_346", "4"}, _
        New String() {"601467", "ITEM_352", "3"}, _
        New String() {"601467", "ITEM_358", "4"}, _
        New String() {"611169", "ITEM_003", "3"}, _
        New String() {"611169", "ITEM_023", "4"}, _
        New String() {"611183", "ITEM_003", "3"}, _
        New String() {"611183", "ITEM_023", "4"}, _
        New String() {"611183", "ITEM_102", "4"}, _
        New String() {"611183", "ITEM_106", "4"}, _
        New String() {"611183", "ITEM_110", "4"}, _
        New String() {"611183", "ITEM_114", "4"}, _
        New String() {"611183", "ITEM_120", "4"}, _
        New String() {"611183", "ITEM_124", "4"}, _
        New String() {"611183", "ITEM_130", "4"}, _
        New String() {"611183", "ITEM_134", "4"}, _
        New String() {"611183", "ITEM_142", "4"}, _
        New String() {"611190", "ITEM_003", "3"}, _
        New String() {"611190", "ITEM_023", "4"}, _
        New String() {"611190", "ITEM_102", "4"}, _
        New String() {"611190", "ITEM_106", "4"}, _
        New String() {"611190", "ITEM_110", "4"}, _
        New String() {"611190", "ITEM_114", "4"}, _
        New String() {"611190", "ITEM_120", "4"}, _
        New String() {"611190", "ITEM_124", "4"}, _
        New String() {"611190", "ITEM_130", "4"}, _
        New String() {"611190", "ITEM_134", "4"}, _
        New String() {"611190", "ITEM_142", "4"}, _
        New String() {"611268", "ITEM_102", "4"}, _
        New String() {"611268", "ITEM_106", "4"}, _
        New String() {"611268", "ITEM_110", "4"}, _
        New String() {"611268", "ITEM_114", "4"}, _
        New String() {"611268", "ITEM_120", "4"}, _
        New String() {"611268", "ITEM_124", "4"}, _
        New String() {"611268", "ITEM_130", "4"}, _
        New String() {"611268", "ITEM_134", "4"}, _
        New String() {"611268", "ITEM_142", "4"}, _
        New String() {"611282", "ITEM_001", "4"}, _
        New String() {"611282", "ITEM_037", "4"}, _
        New String() {"611282", "ITEM_073", "4"}, _
        New String() {"611282", "ITEM_109", "4"}, _
        New String() {"611282", "ITEM_145", "4"}, _
        New String() {"611282", "ITEM_195", "4"}, _
        New String() {"611282", "ITEM_199", "4"}, _
        New String() {"611282", "ITEM_211", "4"}, _
        New String() {"611282", "ITEM_215", "4"}, _
        New String() {"611282", "ITEM_227", "4"}, _
        New String() {"611282", "ITEM_231", "4"}, _
        New String() {"611282", "ITEM_245", "4"}, _
        New String() {"611299", "ITEM_001", "4"}, _
        New String() {"611299", "ITEM_037", "4"}, _
        New String() {"611299", "ITEM_073", "4"}, _
        New String() {"611299", "ITEM_109", "4"}, _
        New String() {"611299", "ITEM_145", "4"}, _
        New String() {"611299", "ITEM_195", "4"}, _
        New String() {"611299", "ITEM_199", "4"}, _
        New String() {"611299", "ITEM_211", "4"}, _
        New String() {"611299", "ITEM_215", "4"}, _
        New String() {"611299", "ITEM_227", "4"}, _
        New String() {"611299", "ITEM_231", "4"}, _
        New String() {"611299", "ITEM_245", "4"}, _
        New String() {"611367", "ITEM_001", "4"}, _
        New String() {"611367", "ITEM_037", "4"}, _
        New String() {"611367", "ITEM_073", "4"}, _
        New String() {"611367", "ITEM_109", "4"}, _
        New String() {"611367", "ITEM_145", "4"}, _
        New String() {"611367", "ITEM_195", "4"}, _
        New String() {"611367", "ITEM_199", "4"}, _
        New String() {"611367", "ITEM_211", "4"}, _
        New String() {"611367", "ITEM_215", "4"}, _
        New String() {"611367", "ITEM_227", "4"}, _
        New String() {"611367", "ITEM_231", "4"}, _
        New String() {"611367", "ITEM_245", "4"}, _
        New String() {"621168", "ITEM_004", "3"}, _
        New String() {"621168", "ITEM_024", "4"}, _
        New String() {"621175", "ITEM_004", "3"}, _
        New String() {"621175", "ITEM_024", "4"}, _
        New String() {"621267", "ITEM_103", "3"}, _
        New String() {"621267", "ITEM_107", "4"}, _
        New String() {"621267", "ITEM_124", "4"}, _
        New String() {"621267", "ITEM_132", "4"}, _
        New String() {"621267", "ITEM_144", "4"}, _
        New String() {"621267", "ITEM_148", "4"}, _
        New String() {"621274", "ITEM_103", "3"}, _
        New String() {"621274", "ITEM_107", "4"}, _
        New String() {"621274", "ITEM_124", "4"}, _
        New String() {"621274", "ITEM_132", "4"}, _
        New String() {"621274", "ITEM_144", "4"}, _
        New String() {"621274", "ITEM_148", "4"}, _
        New String() {"631167", "ITEM_003", "3"}, _
        New String() {"631167", "ITEM_023", "4"}, _
        New String() {"631174", "ITEM_003", "3"}, _
        New String() {"631174", "ITEM_023", "4"}, _
        New String() {"631266", "ITEM_101", "4"}, _
        New String() {"631266", "ITEM_108", "3"}, _
        New String() {"631266", "ITEM_119", "4"}, _
        New String() {"631266", "ITEM_133", "4"}, _
        New String() {"631266", "ITEM_137", "4"}, _
        New String() {"631273", "ITEM_101", "4"}, _
        New String() {"631273", "ITEM_108", "3"}, _
        New String() {"631273", "ITEM_119", "4"}, _
        New String() {"631273", "ITEM_133", "4"}, _
        New String() {"631273", "ITEM_137", "4"}, _
        New String() {"641166", "ITEM_003", "3"}, _
        New String() {"641166", "ITEM_022", "4"}, _
        New String() {"641173", "ITEM_003", "3"}, _
        New String() {"641173", "ITEM_022", "4"}, _
        New String() {"641265", "ITEM_022", "3"}, _
        New String() {"641265", "ITEM_027", "3"}, _
        New String() {"641265", "ITEM_032", "3"}, _
        New String() {"641265", "ITEM_036", "4"}, _
        New String() {"641265", "ITEM_044", "4"}, _
        New String() {"641265", "ITEM_052", "4"}, _
        New String() {"641265", "ITEM_074", "4"}, _
        New String() {"641265", "ITEM_075", "4"}, _
        New String() {"641272", "ITEM_022", "3"}, _
        New String() {"641272", "ITEM_027", "3"}, _
        New String() {"641272", "ITEM_032", "3"}, _
        New String() {"641272", "ITEM_036", "4"}, _
        New String() {"641272", "ITEM_044", "4"}, _
        New String() {"641272", "ITEM_052", "4"}, _
        New String() {"641272", "ITEM_074", "4"}, _
        New String() {"641272", "ITEM_075", "4"}, _
        New String() {"641T72", "ITEM_036", "4"}, _
        New String() {"641T72", "ITEM_044", "4"}, _
        New String() {"641T72", "ITEM_052", "4"}, _
        New String() {"641T73", "ITEM_022", "4"}, _
        New String() {"661164", "ITEM_003", "3"}, _
        New String() {"661164", "ITEM_022", "4"}, _
        New String() {"661171", "ITEM_003", "3"}, _
        New String() {"661171", "ITEM_022", "4"}, _
        New String() {"661263", "ITEM_002", "4"}, _
        New String() {"661263", "ITEM_006", "4"}, _
        New String() {"661263", "ITEM_012", "4"}, _
        New String() {"661263", "ITEM_016", "4"}, _
        New String() {"661263", "ITEM_025", "3"}, _
        New String() {"661263", "ITEM_035", "4"}, _
        New String() {"661263", "ITEM_039", "4"}, _
        New String() {"661270", "ITEM_002", "4"}, _
        New String() {"661270", "ITEM_006", "4"}, _
        New String() {"661270", "ITEM_012", "4"}, _
        New String() {"661270", "ITEM_016", "4"}, _
        New String() {"661270", "ITEM_025", "3"}, _
        New String() {"661270", "ITEM_035", "4"}, _
        New String() {"661270", "ITEM_039", "4"}, _
        New String() {"661669", "ITEM_003", "3"}, _
        New String() {"661669", "ITEM_022", "4"}, _
        New String() {"661676", "ITEM_003", "3"}, _
        New String() {"661676", "ITEM_022", "4"}, _
        New String() {"661768", "ITEM_002", "4"}, _
        New String() {"661768", "ITEM_006", "4"}, _
        New String() {"661768", "ITEM_012", "4"}, _
        New String() {"661768", "ITEM_016", "4"}, _
        New String() {"661768", "ITEM_025", "3"}, _
        New String() {"661768", "ITEM_035", "4"}, _
        New String() {"661768", "ITEM_039", "4"}, _
        New String() {"661775", "ITEM_002", "4"}, _
        New String() {"661775", "ITEM_006", "4"}, _
        New String() {"661775", "ITEM_012", "4"}, _
        New String() {"661775", "ITEM_016", "4"}, _
        New String() {"661775", "ITEM_025", "3"}, _
        New String() {"661775", "ITEM_035", "4"}, _
        New String() {"661775", "ITEM_039", "4"} _
    }

    ' 帳票ID統一用辞書
    Private mdicSlipConv As New Dictionary(Of String, String)
    ' 元号変換対象項目辞書
    Private mdicEraConv As New Dictionary(Of String, Dictionary(Of String, String))
#End Region

#Region "メイン処理[Main]"
    ''' ======================================================================
    ''' メソッド名：Main
    ''' <summary>
    ''' メイン処理
    ''' </summary>
    ''' <remarks></remarks>
    ''' ======================================================================
    Shared Function Main(ByVal CmdArgs() As String) As Integer

        mainProc = New clsMakeDeliveryMain

        ' 処理の戻り値を返却
        Return mainProc.Run()

    End Function

#End Region

#Region "バッチ処理本体"
    ''' <summary>
    ''' バッチ処理本体
    ''' </summary>
    ''' <remarks></remarks>
    Protected Overrides Sub Execute()

        ' 納品ファイル出力先（東西）ルートパス
        Dim strRootPathEast As String = String.Empty
        Dim strRootPathWest As String = String.Empty

        Try

            ' 帳票IDを統一するための変換辞書を作成します
            For Each strSlip() As String In mstrSlipConv
                If Not mdicSlipConv.ContainsKey(strSlip(0)) Then
                    mdicSlipConv.Add(strSlip(0), strSlip(1))
                End If
            Next
            ' 元号変換用辞書を作成します
            For Each strEra() As String In mstrEraConv
                If Not mdicEraConv.ContainsKey(strEra(0)) Then
                    Dim dic As New Dictionary(Of String, String)
                    mdicEraConv.Add(strEra(0), dic)
                End If
                mdicEraConv(strEra(0)).Add(strEra(1), strEra(2))
            Next

            ' 納品日時を取得します
            mstrDeliveryDate = GetDeliveryDate()

            Dim strDIstSlip() As String = mdicConfig("DIST_SLIP_ID").Split(",")
            Dim dicDistSlip As New Dictionary(Of String, String)
            For Each S As String In strDIstSlip
                dicDistSlip.Add(S, String.Empty)
            Next

            ' 納品編集メソッド定義ファイルを読込み、編集メソッド定義リストマップに格納する
            Dim editMethodMap As Dictionary(Of String, List(Of clsMethodDef)) = LoadEditDefine()

            ' イメージテーブルステータスを更新する為の関連帳票番号リスト(OUT) *** [2015/06/24] 追加 ***</param>
            Dim strExcSubjectNumArrayList As New ArrayList


            ' 処理対象となるイメージデータを取得します。
            Dim isDataNothing As Boolean = False
            Dim dtbAllImage As DataTable = GetImageData()
            If dtbAllImage Is Nothing OrElse dtbAllImage.Rows.Count = 0 Then
                CommonLog.WriteLog("作成する納品データ対象データが存在しません", EventLogEntryType.Warning)
                isDataNothing = True
            End If

            ' 帳票IDの読み替えを行います
            Call MakeSlipConvertTable(dtbAllImage)

            ' 編集・出力クラスのインスタンス生成（帳票ごと）を生成し、ディクショナリに格納
            Dim editOutputMap As New Dictionary(Of String, clsEditOutput)
            editOutputMap.Add(mdicConfig("prefix_syoubyou"), New clsEditOutput(mdicConfig))    ' 傷病手当金支給申請書
            editOutputMap.Add(mdicConfig("prefix_syussan"), New clsEditOutput(mdicConfig))     ' 出産手当金支給申請書
            editOutputMap.Add(mdicConfig("prefix_ikuji"), New clsEditOutput(mdicConfig))       ' 出産育児一時金申請書
            editOutputMap.Add(mdicConfig("prefix_maisou"), New clsEditOutput(mdicConfig))      ' 埋葬量支給申請書

            '対象データなしの場合は0件データファイルを作成する  *** 2015/01/13 追加 ***
            If isDataNothing Then
                ' 納品フォルダの作成
                strRootPathEast = CreateDeliveryDir(mdicConfig("DELIVERY_PATH_EAST"))
                strRootPathWest = CreateDeliveryDir(mdicConfig("DELIVERY_PATH_WEST"))
                Directory.CreateDirectory(strRootPathEast)
                Directory.CreateDirectory(strRootPathWest)
                ' 納品データファイル出力
                '                execOutput(strRootPathEast, strRootPathWest, editOutputMap) ' *** [2015/06/24] 削除 ***
                execOutput(strRootPathEast, strRootPathWest, strExcSubjectNumArrayList, editOutputMap) ' *** [2015/06/24] 追加 ***

                ' トリガーファイルの作成
                OutputTrigger(strRootPathEast, mdicConfig("TRIGGER_FILE_EAST"))
                OutputTrigger(strRootPathWest, mdicConfig("TRIGGER_FILE_WEST"))

                Return
            End If

            ' ブレイク処理用ファイル名
            Dim breakFileName As String = Left(GetValue(dtbAllImage.Rows(0), "IMAGE_FILE_NAME"), 23)

            ' 繰り返し処理用  編集・出力クラス変数
            Dim slipKindObj As clsEditOutput
            ' レコードオブジェクト(DataRow)のコレクション
            Dim records As New List(Of DataRow)
            '            ' イメージIDのコレクション（ステータスUPDATE用）    ' *** [2015/06/24] 削除 ***
            '            Dim targetImages As New Dictionary(Of String, Integer)    ' *** [2015/06/24] 削除 ***
            ' イメージID
            Dim strImageID As String = String.Empty
            ' イメージファイル名
            Dim strFileName As String = String.Empty

            '帳票IDの取得
            '案件単位で編集定義を決めるため、aryListに変更
            Dim arySlipDefineId As New ArrayList
            Dim strSlipID As String = GetValue(dtbAllImage.Rows(0), "SLIP_DEFINE_ID")

            ' エントリデータがない帳票IDの識別情報の取得
            ' getEditMethodListにて使用している為、ここでは除外
            ' Dim distSlipId() As String = Split(mdicConfig("DIST_SLIP_ID"), ",")

            ' 納品対象データを１件ずつ処理します。
            For Each dr As DataRow In dtbAllImage.Rows
                ' イメージIDの取得
                strImageID = GetValue(dr, "IMAGE_ID")
                ' イメージファイル名の取得
                strFileName = GetValue(dr, "IMAGE_FILE_NAME").Trim
                ' 取得したファイル名が異なった場合
                If breakFileName <> Left(strFileName, 23) Then

                    ' 頭紙１枚で来た場合には帳票IDをイメージファイル名から生成します
                    If dicDistSlip.ContainsKey(strSlipID.Substring(3, 3)) AndAlso records.Count = 1 Then
                        Dim strTargetFileName As String = GetValue(records(0), "IMAGE_FILE_NAME").Trim
                        Dim strNameParts() As String = strTargetFileName.Split("-")
                        strSlipID = strNameParts(3) & strSlipID.Substring(3)
                    End If

                    ' 帳票IDより処理する帳票のインスタンスを決定
                    slipKindObj = getEditOutput(strSlipID, editOutputMap)
                    ' 編集メソッドリストセット
                    slipKindObj.EditMethodList = getEditMethodList(arySlipDefineId, strSlipID, editMethodMap)
                    ' 1案件分のDataRowオブジェクトのコレクションをセット
                    slipKindObj.TargetDatas = records
                    ' 編集メソッドを実行し、出力用レコードを作成
                    slipKindObj.executeEdit()
                    '                    ' ステータスUpdate用イメージIDと出力データ件数のディクショナリへ要素を追加  *** [2015/1/13] 追加 ***    ' *** [2015/06/24] 削除 ***
                    '                    targetImages = slipKindObj.editStatusDictionary(targetImages)    ' *** [2015/06/24] 削除 ***
                    ' ブレイク用ファイル名の更新
                    breakFileName = Left(strFileName, 23)
                    ' DataRowオブジェクトのクリア
                    records.Clear()
                    ' 帳票IDリストクリア
                    arySlipDefineId.Clear()
                End If
                ' 帳票IDの取得
                strSlipID = GetValue(dr, "SLIP_DEFINE_ID")
                arySlipDefineId.Add(strSlipID)
                ' 現在のDataRowオブジェクトをリストに設定
                records.Add(dr)
            Next

            ' 最後の1件分の処理を実施
            If records.Count > 0 Then

                ' 頭紙１枚で来た場合には帳票IDをイメージファイル名から生成します
                If dicDistSlip.ContainsKey(strSlipID.Substring(3, 3)) AndAlso records.Count = 1 Then
                    Dim strTargetFileName As String = GetValue(records(0), "IMAGE_FILE_NAME").Trim
                    Dim strNameParts() As String = strTargetFileName.Split("-")
                    strSlipID = strNameParts(3) & strSlipID.Substring(3)
                End If

                ' 帳票IDより処理する帳票のインスタンスを決定
                slipKindObj = getEditOutput(strSlipID, editOutputMap)
                ' 編集メソッドリストセット
                slipKindObj.EditMethodList = getEditMethodList(arySlipDefineId, strSlipID, editMethodMap)
                ' 1案件分のDataRowオブジェクトのコレクションをセット
                slipKindObj.TargetDatas = records
                ' 編集メソッドを実行し、出力用レコードを作成
                slipKindObj.executeEdit()
                '                ' ステータスUpdate用イメージIDと出力データ件数のディクショナリへ要素を追加  *** [2015/1/13] 追加 ***    ' *** [2015/06/24] 削除 ***
                '                targetImages = slipKindObj.editStatusDictionary(targetImages)    ' *** [2015/06/24] 削除 ***
            End If

            ' 納品フォルダの作成
            strRootPathEast = CreateDeliveryDir(mdicConfig("DELIVERY_PATH_EAST"))
            strRootPathWest = CreateDeliveryDir(mdicConfig("DELIVERY_PATH_WEST"))
            Directory.CreateDirectory(strRootPathEast)
            Directory.CreateDirectory(strRootPathWest)

            ' 納品データファイル出力
            '            execOutput(strRootPathEast, strRootPathWest, editOutputMap)
            execOutput(strRootPathEast, strRootPathWest, strExcSubjectNumArrayList, editOutputMap) ' *** [2015/06/24] 追加 ***

            Try
                ' DBトランザクションの開始
                mobjCommonDB.DB_Transaction()

                'イメージステータス関連DB更新処理  *** [2015/06/24] 追加 ***
                updateImageStatus(strExcSubjectNumArrayList)

                ' *** [2015/06/24] 削除ここから ***
                '                ' 帳票出力上限数
                '                Dim outLimitCount As Integer = mdicConfig("OUT_LIMIT_COUNT")
                '                ' イメージIDのコレクションより反復子を取得
                '                Dim imageIds As Dictionary(Of String, Integer).KeyCollection = targetImages.Keys
                '                Dim imageEnumer As Dictionary(Of String, Integer).KeyCollection.Enumerator = imageIds.GetEnumerator
                '                Dim updImageId As String = String.Empty
                '                Dim outDataCount As Integer = 0
                '                While imageEnumer.MoveNext
                '                    ' イメージIDの取得
                '                    updImageId = imageEnumer.Current
                '                    ' イメージIDに紐づくデータ件数（レコード位置）の取得
                '                    outDataCount = targetImages(updImageId)
                '
                '                    If outDataCount <= outLimitCount Then
                '                        ' イメージステータスの更新
                '                        UpdateImageData(updImageId, mdicConfig("OUTPUT_STATUS"))
                '                        ' イメージステータス履歴の登録
                '                        InsertHistory(updImageId, mdicConfig("OUTPUT_STATUS"))
                '                    End If
                '                End While
                ' *** [2015/06/24] 削除ここまで ***

                ' トリガーファイルの作成
                OutputTrigger(strRootPathEast, mdicConfig("TRIGGER_FILE_EAST"))
                OutputTrigger(strRootPathWest, mdicConfig("TRIGGER_FILE_WEST"))

                ' トランザクションを確定
                mobjCommonDB.DB_Commit()

            Catch ex As Exception
                Try
                    ' トランザクションロールバック
                    mobjCommonDB.DB_Rollback()
                Catch nfex As NullReferenceException
                    CommonLog.WriteLog("ロールバック実施時のNull Reference Exceptionが発生", EventLogEntryType.Error)
                    CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
                End Try
                Throw ex
            End Try

        Catch ex As Exception

            ' イベントログを出力します。
            MyBase.WriteLog("納品ファイル作成中にエラーを検出しました。", EventLogEntryType.Error)
            ' ログファイルにエラー内容を出力します。
            CommonLog.WriteLog(ex.ToString, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)

            ' 納品フォルダが出力されていれば削除します。
            If Not strRootPathEast.Equals(String.Empty) AndAlso Directory.Exists(strRootPathEast) Then
                Directory.Delete(strRootPathEast, True)
            End If
            If Not strRootPathWest.Equals(String.Empty) AndAlso Directory.Exists(strRootPathWest) Then
                Directory.Delete(strRootPathWest, True)
            End If
        Finally
            If Not IsNothing(mobjCommonDB) AndAlso Not IsDBNull(mobjCommonDB) Then
                ' データベース接続クローズ
                mobjCommonDB.DB_Close()
            End If
        End Try
    End Sub

#End Region

#Region "納品データ出力"
    ''' <summary>
    ''' execOutput
    ''' </summary>
    ''' <param name="outPathEast">東の出力先パス</param>
    ''' <param name="outPathWest">西の出力先パス</param>
    ''' <param name="strExcSubjectNumArrayList">イメージテーブルステータスを更新する為の関連帳票番号リスト(OUT) *** [2015/06/24] 追加 ***</param>
    ''' <param name="editOutputMap">出力レコードバッファのコレクション</param>
    ''' <remarks>編集後の出力バッファよりcsvファイルへ出力を行う</remarks>
    Public Sub execOutput(ByVal outPathEast As String, _
                          ByVal outPathWest As String, _
                          ByRef strExcSubjectNumArrayList As ArrayList, _
                          ByVal editOutputMap As Dictionary(Of String, clsEditOutput) _
                         )
        ' 帳票編集オブジェクト
        Dim editOutputObj As clsEditOutput
        ' 帳票出力用バッファ（東）取得
        Dim outPutListEast As List(Of SortedList(Of Integer, String))
        ' 帳票出力用バッファ（西）取得
        Dim outPutListWest As List(Of SortedList(Of Integer, String))
        ' 出力ファイル名
        Dim fileNameDeliverEast As String           ' 送達ファイル（東）
        Dim fileNameDeliverWest As String           ' 送達ファイル（西）
        Dim fileNamePunchEast As String             ' エントリーファイル（東）
        Dim fileNamePunchWest As String             ' エントリーファイル（西）
        Dim outLimitCount As Integer                ' 帳票出力上限数 *** [2015/06/24] 追加 ***

        Try
            '《傷病手当金支給申請書の出力》
            editOutputObj = editOutputMap.Item(mdicConfig("prefix_syoubyou"))
            outPutListEast = editOutputObj.OutputListEast
            outPutListWest = editOutputObj.OutputListWest
            '【東】
            fileNameDeliverEast = getOutputFileName(outPathEast, mdicConfig("PNAME_PREFIX_SYOUBYOU"), mdicConfig("DELIVERY_EAST"))
            fileNamePunchEast = getOutputFileName(outPathEast, mdicConfig("PNAME_PREFIX_SYOUBYOU"), mdicConfig("PUNCH_EAST"))
            '            writeRecords(fileNameDeliverEast, fileNamePunchEast, outPutListEast)                   ' *** [2015/06/24] 削除 ***
            outLimitCount = mdicConfig("OUT_LIMIT_COUNT_EAST_SYOUBYOU")                             ' *** [2015/06/24] 追加 ***
            writeRecords(fileNameDeliverEast, fileNamePunchEast, outLimitCount, outPutListEast, strExcSubjectNumArrayList)     ' *** [2015/06/24] 追加 ***
            '【西】
            fileNameDeliverWest = getOutputFileName(outPathWest, mdicConfig("PNAME_PREFIX_SYOUBYOU"), mdicConfig("DELIVERY_WEST"))
            fileNamePunchWest = getOutputFileName(outPathWest, mdicConfig("PNAME_PREFIX_SYOUBYOU"), mdicConfig("PUNCH_WEST"))
            '            writeRecords(fileNameDeliverWest, fileNamePunchWest, outPutListWest)                   ' *** [2015/06/24] 削除 ***
            outLimitCount = mdicConfig("OUT_LIMIT_COUNT_WEST_SYOUBYOU")                             ' *** [2015/06/24] 追加 ***
            writeRecords(fileNameDeliverWest, fileNamePunchWest, outLimitCount, outPutListWest, strExcSubjectNumArrayList)     ' *** [2015/06/24] 追加 ***

            '《出産手当金支給申請書の出力》
            editOutputObj = editOutputMap.Item(mdicConfig("prefix_syussan"))
            outPutListEast = editOutputObj.OutputListEast
            outPutListWest = editOutputObj.OutputListWest
            '【東】
            fileNameDeliverEast = getOutputFileName(outPathEast, mdicConfig("PNAME_PREFIX_SYUSSAN"), mdicConfig("DELIVERY_EAST"))
            fileNamePunchEast = getOutputFileName(outPathEast, mdicConfig("PNAME_PREFIX_SYUSSAN"), mdicConfig("PUNCH_EAST"))
            '            writeRecords(fileNameDeliverEast, fileNamePunchEast, outPutListEast)               '     *** [2015/06/24] 削除 ***
            outLimitCount = mdicConfig("OUT_LIMIT_COUNT_EAST_SYUSSAN")                              ' *** [2015/06/24] 追加 ***
            writeRecords(fileNameDeliverEast, fileNamePunchEast, outLimitCount, outPutListEast, strExcSubjectNumArrayList)     ' *** [2015/06/24] 追加 ***
            '【西】
            fileNameDeliverWest = getOutputFileName(outPathWest, mdicConfig("PNAME_PREFIX_SYUSSAN"), mdicConfig("DELIVERY_WEST"))
            fileNamePunchWest = getOutputFileName(outPathWest, mdicConfig("PNAME_PREFIX_SYUSSAN"), mdicConfig("PUNCH_WEST"))
            '            writeRecords(fileNameDeliverWest, fileNamePunchWest, outPutListWest)                   ' *** [2015/06/24] 削除 ***
            outLimitCount = mdicConfig("OUT_LIMIT_COUNT_WEST_SYUSSAN")                              ' *** [2015/06/24] 追加 ***
            writeRecords(fileNameDeliverWest, fileNamePunchWest, outLimitCount, outPutListWest, strExcSubjectNumArrayList)     ' *** [2015/06/24] 追加 ***

            '《出産育児一時金支給申請書の出力》
            editOutputObj = editOutputMap.Item(mdicConfig("prefix_ikuji"))
            outPutListEast = editOutputObj.OutputListEast
            outPutListWest = editOutputObj.OutputListWest
            '【東】
            fileNameDeliverEast = getOutputFileName(outPathEast, mdicConfig("PNAME_PREFIX_IKUJI"), mdicConfig("DELIVERY_EAST"))
            fileNamePunchEast = getOutputFileName(outPathEast, mdicConfig("PNAME_PREFIX_IKUJI"), mdicConfig("PUNCH_EAST"))
            '            writeRecords(fileNameDeliverEast, fileNamePunchEast, outPutListEast)                   ' *** [2015/06/24] 削除 ***
            outLimitCount = mdicConfig("OUT_LIMIT_COUNT_EAST_IKUJI")                                ' *** [2015/06/24] 追加 ***
            writeRecords(fileNameDeliverEast, fileNamePunchEast, outLimitCount, outPutListEast, strExcSubjectNumArrayList)     ' *** [2015/06/24] 追加 ***
            '【西】
            fileNameDeliverWest = getOutputFileName(outPathWest, mdicConfig("PNAME_PREFIX_IKUJI"), mdicConfig("DELIVERY_WEST"))
            fileNamePunchWest = getOutputFileName(outPathWest, mdicConfig("PNAME_PREFIX_IKUJI"), mdicConfig("PUNCH_WEST"))
            '            writeRecords(fileNameDeliverWest, fileNamePunchWest, outPutListWest)                   ' *** [2015/06/24] 削除 ***
            outLimitCount = mdicConfig("OUT_LIMIT_COUNT_WEST_IKUJI")                                ' *** [2015/06/24] 追加 ***
            writeRecords(fileNameDeliverWest, fileNamePunchWest, outLimitCount, outPutListWest, strExcSubjectNumArrayList)     ' *** [2015/06/24] 追加 ***

            '《埋葬量支給申請書の出力》
            editOutputObj = editOutputMap.Item(mdicConfig("prefix_maisou"))
            outPutListEast = editOutputObj.OutputListEast
            outPutListWest = editOutputObj.OutputListWest
            '【東】
            fileNameDeliverEast = getOutputFileName(outPathEast, mdicConfig("PNAME_PREFIX_MAISOU"), mdicConfig("DELIVERY_EAST"))
            fileNamePunchEast = getOutputFileName(outPathEast, mdicConfig("PNAME_PREFIX_MAISOU"), mdicConfig("PUNCH_EAST"))
            '            writeRecords(fileNameDeliverEast, fileNamePunchEast, outPutListEast)                   ' *** [2015/06/24] 削除 ***
            outLimitCount = mdicConfig("OUT_LIMIT_COUNT_EAST_MAISOU")                               ' *** [2015/06/24] 追加 ***
            writeRecords(fileNameDeliverEast, fileNamePunchEast, outLimitCount, outPutListEast, strExcSubjectNumArrayList)     ' *** [2015/06/24] 追加 ***
            '【西】
            fileNameDeliverWest = getOutputFileName(outPathWest, mdicConfig("PNAME_PREFIX_MAISOU"), mdicConfig("DELIVERY_WEST"))
            fileNamePunchWest = getOutputFileName(outPathWest, mdicConfig("PNAME_PREFIX_MAISOU"), mdicConfig("PUNCH_WEST"))
            '            writeRecords(fileNameDeliverWest, fileNamePunchWest, outPutListWest)                   ' *** [2015/06/24] 削除 ***
            outLimitCount = mdicConfig("OUT_LIMIT_COUNT_WEST_MAISOU")                               ' *** [2015/06/24] 追加 ***
            writeRecords(fileNameDeliverWest, fileNamePunchWest, outLimitCount, outPutListWest, strExcSubjectNumArrayList)     ' *** [2015/06/24] 追加 ***

        Catch ex As Exception
            CommonLog.WriteLog("execOutput（納品データ出力）でエラーが発生しました", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            Throw ex
        End Try

    End Sub
#End Region

#Region "ファイル出力処理"
    ''' <summary>
    ''' writeRecords
    ''' <para name="dlvFileName">送達ファイル名</para>
    ''' <para name="pchFileName">エントリーファイル名</para>
    ''' <para name="outLimitCount">帳票出力上限数</para>
    ''' <para name="outputList">各帳票別の出力レコードのコレクション</para>
    ''' <para name="strExcSubjectNumArrayList">イメージテーブルステータスを更新する為の関連帳票番号リスト(OUT) *** [2015/06/24] 追加 ***</para>
    ''' </summary>
    ''' <remarks>コレクションにある出力レコードからcsvファイルへ出力を行う</remarks>
    Public Sub writeRecords(ByVal dlvFileName As String, _
                            ByVal pchFileName As String, _
                            ByVal outLimitCount As Integer, _
                            ByVal outputList As List(Of SortedList(Of Integer, String)), _
                            ByRef strExcSubjectNumArrayList As ArrayList)
        '                            ByVal outputList As List(Of SortedList(Of Integer, String)))   ' *** [2015/06/24] 削除 ***

        ' 出力レコードカウント
        Dim outRecCount As Integer = 0

        Try

            ' 出力ストリームの取得
            Dim writerDlv As StreamWriter = File.CreateText(dlvFileName)    '送達ファイル
            Dim writerPch As StreamWriter = File.CreateText(pchFileName)    'エントリーファイル

            '            ' 帳票出力上限数                                             ' *** [2015/06/24] 削除 ***
            '            Dim outLimitCount As Integer = mdicConfig("OUT_LIMIT_COUNT") ' *** [2015/06/24] 削除 ***
            ' 出力リストの反復子の取得
            Dim outListEnum As List(Of SortedList(Of Integer, String)).Enumerator = outputList.GetEnumerator()
            ' 出力情報コレクション（マップ）
            Dim outInfoList As SortedList(Of Integer, String)
            ' 出力レコードキーパートの反復子の取得
            Dim recKeys As IList(Of Integer)
            Dim seqNoEnum As IEnumerator(Of Integer)
            ' 出力レコードキー（シーケンスNo）
            Dim seqNo As Integer
            ' 出力レコードバッファ（送達）
            Dim outRecDerivery(2) As String
            ' 出力レコードバッファ（エントリー）
            Dim outRecPunch() As String = Nothing

            ' ************************************
            ' *** エントリーデータ出力編集処理 ***
            ' ************************************
            ' 出力レコード数分繰り返し処理を実施
            While outListEnum.MoveNext()
                '件数カウント
                outRecCount += 1
                If outRecCount > outLimitCount Then
                    outRecCount = outLimitCount
                    '上限数に達したレコードは出力しない
                    Exit While
                End If
                '1件分のデータ取得
                outInfoList = outListEnum.Current
                'エントリーデータ出力レコードバッファの要素数決定
                ReDim outRecPunch(outInfoList.Count - 1)
                'キー（シーケンスNo）のコレクション取得
                recKeys = outInfoList.Keys
                'キー（シーケンスNo）の反復子取得
                seqNoEnum = recKeys.GetEnumerator
                '配列用カウンタ初期化
                Dim i As Integer = 0
                '項目数分繰り返し処理を実行
                While seqNoEnum.MoveNext()
                    seqNo = seqNoEnum.Current
                    '項目取得を取得し、エントリーレコードに追加()
                    outRecPunch(i) = """" & outInfoList.Item(seqNo) & """"
                    i += 1
                End While

                ' *** [2015/06/24] 追加 ***
                ' イメージテーブルステータスを更新する為の関連帳票番号
                excSubjectNumCsvAdd(outInfoList.Item(2), strExcSubjectNumArrayList)

                ' エントリーのレコードを出力
                writerPch.WriteLine(Join(outRecPunch, ","))
                writerPch.Flush()
            End While
            ' ******************************
            ' *** 送達データ出力編集処理 ***
            ' ******************************
            Dim fileInfo As New System.IO.FileInfo(pchFileName)
            Dim fileLen = fileInfo.Length
            outRecDerivery(0) = Path.GetFileName(pchFileName)
            outRecDerivery(1) = fileLen
            'outRecDerivery(2) = outputList.Count    [2015/1/17] 出力件数をオブジェクトの要素数から出力したレコード件数へ変更
            outRecDerivery(2) = outRecCount
            ' 送達レコードの出力
            writerDlv.WriteLine(Join(outRecDerivery, ","))

            ' ストリームのクローズ
            writerDlv.Close() : writerPch.Close()
        Catch ex As Exception
            CommonLog.WriteLog("writeRecords（ファイル出力処理）でエラーが発生しました", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog("送達ファイル名 -> " & dlvFileName, EventLogEntryType.Error)
            CommonLog.WriteLog("エントリーファイル名 -> " & pchFileName, EventLogEntryType.Error)
            CommonLog.WriteLog("出力レコード件数 -> " & outputList.Count, EventLogEntryType.Error)
            CommonLog.WriteLog("処理行 -> " & outRecCount, EventLogEntryType.Error)
            Throw ex
        End Try

    End Sub
#End Region

    ' *** [2015/06/24] 追加ここから ***
#Region "イメージステータス関連DB更新処理"
    ''' <summary>
    ''' updateImageStatus
    ''' <param name="strExcSubjectNumArrayList">イメージテーブルステータスを更新する為の関連帳票番号リスト(IN)</param>
    ''' </summary>
    ''' <remarks>イメージステータスの更新とイメージステータス履歴の登録を行う。</remarks>
    Public Sub updateImageStatus(ByVal strExcSubjectNumArrayList As ArrayList)

        Try
            For Each strExcSubjectNum As String In strExcSubjectNumArrayList

#If DEBUG Then
                CommonLog.WriteLog("EXC_SUBJECT_NO -> " & strExcSubjectNum, EventLogEntryType.Warning)
#End If

                ' イメージステータスを更新するイメージIDリストを取得する
                Dim stbSQL As New StringBuilder("SELECT IMAGE_ID FROM T_JJ_IMAGE WHERE IMAGE_STATUS = __IMGSTS__ AND EXC_SUBJECT_NO IN(__EXC_SUBJECT_NO_LIST__)")
                stbSQL.Replace("__IMGSTS__", mdicConfig("INPUT_STATUS"))
                stbSQL.Replace("__EXC_SUBJECT_NO_LIST__", strExcSubjectNum)
                ' SQL実行
                Dim dt As System.Data.DataTable = mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)
                ' 更新対象のイメージIDリスト
                Dim aryImageId As New ArrayList
                ' 取得したイメージIDをリストに格納
                For Each dr As DataRow In dt.Rows
                    aryImageId.Add(Convert.ToString(dr.Item("IMAGE_ID")))
                Next
                dt.Dispose()
                ' 取得したイメージIDからイメージステータスを更新する
                For Each updImageId As String In aryImageId

#If DEBUG Then
                    CommonLog.WriteLog("IMAGE_ID -> " & updImageId, EventLogEntryType.Warning)
#End If

                    ' イメージステータスの更新
                    UpdateImageData(updImageId, mdicConfig("OUTPUT_STATUS"))
                    ' イメージステータス履歴の登録
                    InsertHistory(updImageId, mdicConfig("OUTPUT_STATUS"))
                Next
            Next
        Catch ex As Exception
            CommonLog.WriteLog("updateImageStatus（イメージステータス関連DB更新処理）でエラーが発生しました", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            Throw ex
        End Try



    End Sub
#End Region
    ' *** [2015/06/24] 追加ここまで ***

#Region "出力ファイル名取得"
    ''' <summary>
    ''' getOutputFileName
    ''' </summary>
    ''' <param name="ouDir">出力先パス</param>
    ''' <param name="fileKind1">帳票名のプリフィックス</param>
    ''' <param name="fileKind2">ファイルの種類情報</param>
    ''' <returns>編集後の出力ファイル名</returns>
    ''' <remarks></remarks>
    Public Shared Function getOutputFileName(ByVal ouDir As String, ByVal fileKind1 As String, ByVal fileKind2 As String) As String
        Return Path.Combine(ouDir, fileKind1 & fileKind2 & "DTR_99_" & Now.ToString("yyyyMMddHHmmssf") & ".csv")
    End Function
#End Region

#Region "編集メソッドリストマップ作成"
    ''' <summary>
    ''' createEditMethodList
    ''' </summary>
    ''' <returns>帳票別様式毎のメソッド定義オブジェクトのコレクション</returns>
    ''' <remarks></remarks>
    Public Function createEditMethodList() As Dictionary(Of String, List(Of clsMethodDef))
        ' 編集メソッドリストマップ
        Dim retMap As New Dictionary(Of String, List(Of clsMethodDef))
        retMap.Add(mdicConfig("syoubyou_A4_OS"), New List(Of clsMethodDef))
        retMap.Add(mdicConfig("syoubyou_A3_OS"), New List(Of clsMethodDef))
        retMap.Add(mdicConfig("syoubyou_A3_BS"), New List(Of clsMethodDef))
        retMap.Add(mdicConfig("syussan_A4_OS"), New List(Of clsMethodDef))
        retMap.Add(mdicConfig("syussan_A3_OS"), New List(Of clsMethodDef))
        retMap.Add(mdicConfig("syussan_A3_BS"), New List(Of clsMethodDef))
        retMap.Add(mdicConfig("ikuji_A4_OS"), New List(Of clsMethodDef))
        retMap.Add(mdicConfig("ikuji_A4_BS"), New List(Of clsMethodDef))
        retMap.Add(mdicConfig("maisou_A4_OS"), New List(Of clsMethodDef))
        retMap.Add(mdicConfig("maisou_A4_BS"), New List(Of clsMethodDef))
        retMap.Add(mdicConfig("syoubyou_default"), New List(Of clsMethodDef))
        retMap.Add(mdicConfig("syussan_default"), New List(Of clsMethodDef))
        retMap.Add(mdicConfig("ikuji_default"), New List(Of clsMethodDef))
        retMap.Add(mdicConfig("maisou_default"), New List(Of clsMethodDef))


        retMap.Add(mdicConfig("syoubyou_A4_OS_ocr"), New List(Of clsMethodDef))
        retMap.Add(mdicConfig("syoubyou_A3_OS_ocr"), New List(Of clsMethodDef))
        retMap.Add(mdicConfig("syoubyou_A3_BS_ocr"), New List(Of clsMethodDef))
        retMap.Add(mdicConfig("syussan_A4_OS_ocr"), New List(Of clsMethodDef))
        retMap.Add(mdicConfig("syussan_A3_OS_ocr"), New List(Of clsMethodDef))
        retMap.Add(mdicConfig("syussan_A3_BS_ocr"), New List(Of clsMethodDef))
        retMap.Add(mdicConfig("ikuji_A4_OS_ocr"), New List(Of clsMethodDef))
        retMap.Add(mdicConfig("ikuji_A4_BS_ocr"), New List(Of clsMethodDef))
        retMap.Add(mdicConfig("ikuji_A4_BSH_ocr"), New List(Of clsMethodDef))
        retMap.Add(mdicConfig("maisou_A4_OS_ocr"), New List(Of clsMethodDef))
        retMap.Add(mdicConfig("maisou_A4_BS_ocr"), New List(Of clsMethodDef))


        Return retMap

    End Function
#End Region

#Region "メソッド編集オブジェクト取得"
    ''' <summary>
    ''' getEditOutput
    ''' </summary>
    ''' <returns>メソッド編集オブジェクトのインスタンス</returns>
    ''' <remarks>帳票IDから該当する帳票のメソッド編集オブジェクトのインスタンスを戻す</remarks>
    Public Function getEditOutput(ByVal slipId As String, ByVal edtOuputDic As Dictionary(Of String, clsEditOutput)) As clsEditOutput
        Dim retDic As clsEditOutput = Nothing
        ' 帳票IDより処理する帳票のインスタンスを決定
        Select Case Left(slipId, 3)
            Case mdicConfig("pid_syoubyou")  '"601"
                retDic = edtOuputDic(mdicConfig("prefix_syoubyou"))
            Case mdicConfig("pid_syussan")   '"611"
                retDic = edtOuputDic(mdicConfig("prefix_syussan"))
            Case mdicConfig("pid_ikuji")     '"621"
                retDic = edtOuputDic(mdicConfig("prefix_ikuji"))
            Case mdicConfig("pid_maisou")    '"631"
                retDic = edtOuputDic(mdicConfig("prefix_maisou"))
        End Select

        Return retDic

    End Function
#End Region

#Region "メソッド定義オブジェクトリストの取得"
    ''' <summary>
    ''' getEditMethodList
    ''' </summary>
    ''' <returns>該当するメソッド定義オブジェクトのリスト</returns>
    ''' <remarks>帳票IDから該当する帳票のメソッド定義オブジェクトリストのインスタンスを戻す</remarks>
    Public Function getEditMethodList(ByVal arySlipID As ArrayList, ByVal SlipID As String, _
                                      ByVal editMethodMap As Dictionary(Of String, List(Of clsMethodDef))) As List(Of clsMethodDef)
        'リターン値
        Dim methodDefList As List(Of clsMethodDef) = Nothing
        '' エントリデータがない帳票IDの識別情報の取得
        'Dim distSlipId() As String = Split(mdicConfig("DIST_SLIP_ID"), ",")

        'If Right(SlipID, 3) = distSlipId(0) _
        'OrElse Right(SlipID, 3) = distSlipId(1) _
        'OrElse Right(SlipID, 3) = distSlipId(2) _
        'OrElse Right(SlipID, 3) = distSlipId(3) _
        'OrElse Right(SlipID, 3) = distSlipId(4) Then

        '    ' 編集メソッドリスト取得(デフォルト用)
        '    methodDefList = editMethodMap(Left(SlipID, 3) & mdicConfig("DIST_SLIP_SUFFIX"))
        'Else
        '    ' 編集メソッドリスト取得
        '    methodDefList = editMethodMap(mdicConfig("S" & SlipID))
        'End If

        'エントリーデータ用帳票ID識別情報
        Dim EditSlipId() As String = Split(mdicConfig("EDIT_ID"), ",")

        For i As Integer = 0 To arySlipID.Count - 1
            For j As Integer = 0 To EditSlipId.Length - 1
                If arySlipID(i).ToString = EditSlipId(j) Then
                    methodDefList = editMethodMap(mdicConfig("S" & arySlipID(i)))
                End If
            Next
        Next

        If methodDefList Is Nothing Then
            methodDefList = editMethodMap(Left(SlipID, 3) & mdicConfig("DIST_SLIP_SUFFIX"))
        End If


        Return methodDefList

    End Function
#End Region

#Region "編集定義クラスのコレクション作成"

    ''' <summary>
    ''' 編集定義クラスのコレクション作成
    ''' </summary>
    ''' <returns>各申請書の各様式ごとに定義されたメソッド定義コレクション</returns>
    ''' <remarks>各申請書の各様式ごとに定義されたメソッド定義クラスのコレクションを作成して戻す</remarks>
    Private Function LoadEditDefine() As Dictionary(Of String, List(Of clsMethodDef))
        ' イメージデータの入力様式
        Dim imgStyle As String = String.Empty
        ' ファイル行カウンタ
        Dim lineCnt As Integer = 0
        Try
            ' メソッド定義クラス
            Dim methodDef As clsMethodDef
            ' 編集メソッド定義リストマップ作成
            Dim editMethodMap As Dictionary(Of String, List(Of clsMethodDef)) = createEditMethodList()
            ' 編集メソッド定義リスト（イメージデータの入力様式ごと）
            Dim editMethodList As List(Of clsMethodDef)
            ' コンフィギュレーションファイルからメソッド定義ファイルの配置フォルダを取得。
            Dim strPath As String = mdicConfig("EDIT_DEFINE_PATH")
            ' 配置フォルダにあるCSVファイルの一覧を取得します。
            Dim strFiles() As String = Directory.GetFiles(strPath, "*.csv")
            ' CSVファイルを１つずつ処理します。
            For Each f As String In strFiles
                ' ファイル名からイメージデータの入力様式を取得します。
                imgStyle = Path.GetFileNameWithoutExtension(f)
                ' イメージデータの入力様式ごとのメソッド定義リストを取得。
                editMethodList = editMethodMap(imgStyle)
                ' ファイル行カウンタを0にリセット
                lineCnt = 0
                ' CSVファイルを開きます。
                Using sr As New StreamReader(f, Encoding.GetEncoding("shift_jis"))
                    ' CSVファイルの末尾に達するまで読込を繰り返します。
                    Do Until sr.EndOfStream
                        ' １行読み込みます。
                        lineCnt += 1
                        Dim strLine As String = sr.ReadLine
                        ' 先頭が // で始まる行はコメント行として無視します。
                        If strLine.StartsWith("//") Then
                            Continue Do
                        End If
                        ' 読み込んだ１行をカンマで分割
                        Dim strItem() As String = Split(strLine, ",")
                        ' 編集メソッド定義オブジェクトに設定
                        ' メソッド定義クラスのインスタンス生成
                        methodDef = New clsMethodDef
                        methodDef.SeqNo = strItem(0)                        ' SEQNo.
                        methodDef.Name = strItem(1)                         ' 納品項目名
                        methodDef.InputItems = Split(strItem(2), "|")       ' 入力項目
                        methodDef.MethodName = strItem(3)                   ' 編集メソッド
                        methodDef.MethodParam = Split(strItem(4), "|")      ' 引数
                        methodDef.SlipId = Split(strItem(5), "|")           ' 帳票ID
                        methodDef.DefaultValue = strItem(6)                 ' デフォルト値
                        ' 編集メソッド定義リストに追加します。
                        editMethodList.Add(methodDef)
                    Loop
                End Using
                ' 作成した編集メソッド定義リストを編集メソッド定義リストマップに追加
                editMethodMap.Item(imgStyle) = editMethodList
            Next

            ' 編集メソッド定義リストマップを返却
            Return editMethodMap

        Catch ex As Exception
            ' ログファイルにエラー内容を出力します。
            CommonLog.WriteLog("LoadEditDefineで例外を検知しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog("行番号 -> " & lineCnt, EventLogEntryType.Error)
            CommonLog.WriteLog("帳票様式 -> " & imgStyle, EventLogEntryType.Error)
            Throw ex
        End Try
    End Function
#End Region

#Region "帳票マスタの取得"
    '''' <summary>
    '''' 帳票マスタの取得
    '''' </summary>
    '''' <remarks></remarks>
    'Private Sub GetSlipName()
    '    Try
    '        ' 帳票マスタから有効データを全件取得します。
    '        Dim stbSQL As New StringBuilder("SELECT * FROM M_SLIP_DEFINE WHERE DELETE_FLG = '0'")
    '        Dim dt As System.Data.DataTable = mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)
    '        ' 取得したデータから帳票IDをKeyに、帳票名をvalueとして辞書に登録します。
    '        For Each dr As DataRow In dt.Rows
    '            Dim strID As String = Convert.ToString(dr.Item("SLIP_DEFINE_ID"))
    '            Dim strName As String = Convert.ToString(dr.Item("SLIP_DEFINE_NAME"))
    '            mdicSlip.Add(strID, strName)
    '        Next
    '    Catch ex As Exception
    '        ' ログファイルにエラー内容を出力します。
    '        CommonLog.WriteLog("GetSlipNameで例外を検知しました。", EventLogEntryType.Error)
    '        Throw ex
    '    End Try
    'End Sub
#End Region

#Region "納品対象データの取得[GetImageData]"
    ''' ======================================================================
    ''' メソッド名：GetImageData
    ''' <summary>
    ''' 納品対象データの取得
    ''' </summary>
    ''' <remarks>イメージテーブル、イメージ補正テーブルより納品対象データを取得する</remarks>
    ''' ======================================================================
    Private Function GetImageData() As DataTable

        Try
            ' 納品対象データを抽出するためのSQLを作成します。
            Dim stbSQL As New StringBuilder(String.Empty)
            'stbSQL.AppendLine("SELECT")
            'stbSQL.AppendLine("      IMG1.IMAGE_ID")
            'stbSQL.AppendLine("     ,IMG1.SLIP_DEFINE_ID")
            'stbSQL.AppendLine("     ,IMG1.IMAGE_FILE_NAME")
            'stbSQL.AppendLine("     ,IMG1.EXC_IMAGE_KEY01")
            'stbSQL.AppendLine("     ,CRCT.* ")
            'stbSQL.AppendLine(" FROM  T_JJ_IMAGE IMG1 ")
            'stbSQL.AppendLine(" LEFT OUTER JOIN T_JJ_ENTRY_CORRECTION CRCT ")
            'stbSQL.AppendLine("       ON IMG1.IMAGE_ID = CRCT.IMAGE_ID")
            'stbSQL.AppendLine(" WHERE (SUBSTR(IMG1.IMAGE_FILE_NAME,1,23), IMG1.SLIP_DEFINE_ID) IN ")
            'stbSQL.AppendLine("   ( ")
            'stbSQL.AppendLine("     SELECT SUBSTR(IMG2.IMAGE_FILE_NAME,1,23), IMG2.SLIP_DEFINE_ID ")
            'stbSQL.AppendLine("     FROM T_JJ_IMAGE IMG2")
            'stbSQL.AppendLine("     WHERE  IMG2.IMAGE_STATUS <= %IMGSTS%")
            'stbSQL.AppendLine("     AND    IMG2.SLIP_DEFINE_ID IN (%SLIPID%)")
            'stbSQL.AppendLine("     GROUP BY SUBSTR(IMG2.IMAGE_FILE_NAME,1,23), IMG2.SLIP_DEFINE_ID ")
            'stbSQL.AppendLine("     HAVING  MIN(IMG2.IMAGE_STATUS) = %IMGSTS% ")
            'stbSQL.AppendLine("   )")
            'stbSQL.AppendLine(" AND IMG1.DELETE_FLG = '0' ")
            'stbSQL.AppendLine(" ORDER BY ")
            'stbSQL.AppendLine("      IMG1.IMAGE_FILE_NAME")
            'stbSQL.AppendLine("     ,IMG1.EXC_IMAGE_KEY01")
            'stbSQL.AppendLine("     ,IMG1.SLIP_DEFINE_ID")
            With stbSQL
                ''MOD 2015.11.17 速度改善 ↓
                ''.AppendLine(" SELECT ")
                ''.AppendLine("       IMG1.IMAGE_ID        ")
                ''.AppendLine("      ,IMG1.IMAGE_STATUS    ")
                ''.AppendLine("      ,IMG1.SLIP_DEFINE_ID  ")
                ''.AppendLine("      ,IMG1.IMAGE_FILE_NAME ")
                ''.AppendLine("      ,IMG1.EXC_IMAGE_KEY01 ")
                ''.AppendLine("      ,CRCT.*               ")
                ''.AppendLine(" FROM ")
                ''.AppendLine("     T_JJ_IMAGE IMG1 LEFT OUTER JOIN T_JJ_ENTRY_CORRECTION CRCT  ON IMG1.IMAGE_ID = CRCT.IMAGE_ID, ")
                ''.AppendLine(" 	    (SELECT ")
                ''.AppendLine(" 	            EXC_SUBJECT_NO, ")
                ''.AppendLine(" 	            MIN(IMAGE_STATUS) AS IMAGE_STATUS ")
                ''.AppendLine(" 	        FROM ")
                ''.AppendLine(" 	            T_JJ_IMAGE ")
                ''.AppendLine(" 	        WHERE ")
                ''.AppendLine(" 	            EXC_SUBJECT_NO IN ")
                ''.AppendLine(" 	        				(SELECT ")
                ''.AppendLine(" 	        					EXC_SUBJECT_NO ")
                ''.AppendLine(" 	        				FROM ")
                ''.AppendLine(" 	        					T_JJ_IMAGE I ")
                ''.AppendLine(" 	        				WHERE ")
                ''.AppendLine(" 	        					I.SLIP_DEFINE_ID IN (%SLIPID%) AND ")
                ''.AppendLine(" 	        					I.IMAGE_STATUS = %IMGSTS% AND ")
                ''.AppendLine(" 	        					I.DELETE_FLG   = '0' ")
                ''.AppendLine(" 	        				) ")
                ''.AppendLine(" 	        AND DELETE_FLG = '0' ")
                ''.AppendLine(" 	        GROUP BY ")
                ''.AppendLine(" 	           EXC_SUBJECT_NO ")
                ''.AppendLine(" 		) IMG2 ")
                ''.AppendLine(" WHERE ")
                ''.AppendLine("     IMG2.IMAGE_STATUS   = %IMGSTS% ")
                ''.AppendLine(" AND IMG1.EXC_SUBJECT_NO = IMG2.EXC_SUBJECT_NO ")
                ''.AppendLine(" AND IMG1.DELETE_FLG     = '0' ")
                ''.AppendLine("  ORDER BY  ")
                ''.AppendLine("       IMG1.IMAGE_FILE_NAME ")
                ''.AppendLine("      ,IMG1.EXC_IMAGE_KEY01 ")
                ''.AppendLine("      ,IMG1.SLIP_DEFINE_ID  ")
                .AppendLine("SELECT")
                .AppendLine("    I.IMAGE_ID,")
                .AppendLine("    I.IMAGE_STATUS,")
                .AppendLine("    I.SLIP_DEFINE_ID,")
                .AppendLine("    I.IMAGE_FILE_NAME,")
                .AppendLine("    I.EXC_IMAGE_KEY01,")
                .AppendLine("    E.*")
                .AppendLine("FROM")
                .AppendLine("    T_JJ_IMAGE I")
                .AppendLine("LEFT OUTER JOIN")
                .AppendLine("    T_JJ_ENTRY_CORRECTION E")
                .AppendLine("ON  I.IMAGE_ID = E.IMAGE_ID")
                .AppendLine("INNER JOIN")
                .AppendLine("    (")
                .AppendLine("        SELECT")
                .AppendLine("            A.EXC_SUBJECT_NO")
                .AppendLine("        FROM")
                .AppendLine("        (")
                .AppendLine("           SELECT EXC_SUBJECT_NO")
                .AppendLine("           FROM T_JJ_IMAGE")
                .AppendLine("           WHERE DELETE_FLG = '0'")
                .AppendLine("           GROUP BY EXC_SUBJECT_NO")
                .AppendLine("           HAVING MIN(IMAGE_STATUS) = %IMGSTS% ")
                .AppendLine("        ) A,")
                .AppendLine("        (")
                .AppendLine("           SELECT EXC_SUBJECT_NO")
                .AppendLine("           FROM T_JJ_IMAGE")
                .AppendLine("           WHERE DELETE_FLG = '0'")
                .AppendLine("           AND SLIP_DEFINE_ID IN (%SLIPID%) ")
                .AppendLine("           AND IMAGE_STATUS = %IMGSTS%")
                .AppendLine("           GROUP BY EXC_SUBJECT_NO")
                .AppendLine("        ) B")
                .AppendLine("        WHERE A.EXC_SUBJECT_NO = B.EXC_SUBJECT_NO")
                .AppendLine("    ) C")
                .AppendLine("ON  I.EXC_SUBJECT_NO = C.EXC_SUBJECT_NO")
                .AppendLine("WHERE I.DELETE_FLG = '0'")
                .AppendLine("ORDER BY")
                .AppendLine("    I.IMAGE_FILE_NAME,")
                .AppendLine("    I.EXC_IMAGE_KEY01,")
                .AppendLine("    I.SLIP_DEFINE_ID")
                ''MOD 2015.11.17 速度改善 ↑

            End With

            ' 抽出条件部分をコンフィギュレーションファイルから取得した値に置換します。
            stbSQL.Replace("%IMGSTS%", mdicConfig("INPUT_STATUS"))
            stbSQL.Replace("%SLIPID%", mdicConfig("SLIP_ID"))

#If DEBUG Then
            CommonLog.WriteLog("納品対象データの取得SQL：" & stbSQL.ToString, EventLogEntryType.Information)
#End If
            ' SQLステートメントを実行し、結果を返却する。
            Return MyBase.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)

        Catch ex As Exception
            ' ログファイルにエラー内容を出力します。
            CommonLog.WriteLog("納品データの対象データ抽出処理でエラーが発生しました", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            Throw ex
        End Try
    End Function
#End Region

#Region "納品用ディレクトリ作成[CreateDeliveryDir]"
    ''' ======================================================================
    ''' メソッド名：CreateDeliveryDir
    ''' <summary>
    ''' 納品用ディレクトリ作成
    ''' </summary>
    ''' <param name="deliveryPath">納品ファイルの出力フォルダ</param>''' 
    ''' <returns>生成したフォルダへのフルパス</returns>
    ''' <remarks></remarks>
    ''' ======================================================================
    Private Function CreateDeliveryDir(ByVal deliveryPath As String) As String

        Dim strRequestDir As String
        For i As Integer = 0 To 1000

            Dim strDate As String = Now.ToString("yyMMddHHmmssfff")
            ' 現在日付のフォルダを作成
            strRequestDir = Path.Combine(deliveryPath, strDate)

            If Directory.Exists(strRequestDir) Then
                System.Threading.Thread.Sleep(1000)
                Continue For
            End If

            Try
                Directory.CreateDirectory(strRequestDir)
            Catch ex As IOException
                System.Threading.Thread.Sleep(1000)
                Continue For
            End Try

            ' 作成したディレクトリを返却
            Return strRequestDir

        Next

        ' ここまで来た場合、exception発行
        Throw New Exception("納品用ディレクトリの作成に失敗しました。")

    End Function
#End Region

#Region "トリガファイルの出力"
    ''' <summary>
    ''' トリガファイルの出力
    ''' </summary>
    ''' <param name="strRootPath">トリガファイル出力先フォルダパス</param>
    ''' <param name="triggerFile">トリガファイル名</param>
    ''' <remarks></remarks>
    Private Sub OutputTrigger(ByVal strRootPath As String, ByVal triggerFile As String)
        Try
            ' 外部定義にトリガファイルの名前が定義されていない場合は出力しません。
            If triggerFile.Trim.Length = 0 Then
                Return
            End If

            ' トリガファイルの作成
            Dim strPath As String = Path.Combine(strRootPath, triggerFile)
            Using sw As New StreamWriter(strPath, False, Encoding.GetEncoding("shift_jis"))
            End Using

        Catch ex As Exception
            ' ログファイルにエラー内容を出力します。
            CommonLog.WriteLog("トリガファイル出力失敗", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            Throw ex

        End Try
    End Sub
#End Region

#Region "エントリ内容を項目IDから取得"
    ''' <summary>
    ''' エントリ内容を項目IDから取得
    ''' </summary>
    ''' <param name="dr">エントリ結果レコード</param>
    ''' <param name="id">取得対象の項目ID</param>
    ''' <returns>エントリ結果</returns>
    ''' <remarks></remarks>
    Public Shared Function GetValue(ByVal dr As DataRow, ByVal id As String) As String
        Try

            Return Convert.ToString(dr.Item(id))

        Catch ex As Exception
            ' ログファイルにエラー内容を出力します。
            CommonLog.WriteLog("エントリ内容の取得に失敗", EventLogEntryType.Error)
            CommonLog.WriteLog("項目ID:「" & id & "」", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            Throw ex
        End Try
    End Function
#End Region

#Region "T_JJ_IMAGEの更新"
    ''' <summary>
    ''' T_JJ_IMAGEの更新
    ''' </summary>
    ''' <param name="strImageID">イメージID</param>
    ''' <param name="strStatus">イメージステータス</param>
    ''' <remarks>2015.11.17 速度改善のため、パラメータ使用</remarks>
    Private Sub UpdateImageData(ByVal strImageID As String, _
                                ByVal strStatus As String)
        Try

            ' T_JJ_IMAGE更新用SQLを作成します。
            Dim stbUpdateSQL As New StringBuilder(String.Empty)
            stbUpdateSQL.AppendLine("UPDATE")
            stbUpdateSQL.AppendLine("    T_JJ_IMAGE")
            stbUpdateSQL.AppendLine("SET")
            ''MOD 2015.11.17 速度改善 ↓
            'stbUpdateSQL.AppendLine("     IMAGE_STATUS   = '__IMAGE_STATUS__'")
            stbUpdateSQL.AppendLine("     IMAGE_STATUS   = :OutStatus")
            ''MOD 2015.11.17 速度改善 ↑
            stbUpdateSQL.AppendLine("    ,DELIVERY_DATE       = TO_DATE('" & mstrDeliveryDate & "','YYYYMMDDHH24MISS') ")
            stbUpdateSQL.AppendLine("    ,DELIVERY_DATE_REAL  = SYSDATE ")
            stbUpdateSQL.AppendLine("    ,UPDATE_USER    = 'MakeDelivery'")
            stbUpdateSQL.AppendLine("    ,UPDATE_DATE    = SYSDATE")
            stbUpdateSQL.AppendLine("WHERE")
            ''MOD 2015.11.17 速度改善 ↓
            'stbUpdateSQL.AppendLine("    IMAGE_ID = __IMAGE_ID__")
            stbUpdateSQL.AppendLine("    IMAGE_ID = :DocumentID")
            ''MOD 2015.11.17 速度改善 ↑


            ''MOD 2015.11.17 速度改善 ↓
            ' 作成したSQLの設定値の部分を実際の値に置換します。
            'stbUpdateSQL.Replace("__IMAGE_STATUS__", strStatus)
            'stbUpdateSQL.Replace("__IMAGE_ID__", strImageID)

            ' イメージ状態更新用パラメータ宣言
            Dim oraUpdateParam(1) As OracleParameter
            oraUpdateParam(0) = New OracleParameter(":DocumentID", OracleDbType.Decimal)
            oraUpdateParam(0).Value = Convert.ToInt64(strImageID)
            oraUpdateParam(1) = New OracleParameter(":OutStatus", OracleDbType.Char)
            oraUpdateParam(1).Value = strStatus

            '' 作成したSQLを実行してT_JJ_IMAGEを更新します。
            'Dim intInsertRet As Integer = MyBase.mobjCommonDB.DB_ExecuteNonQuery(stbUpdateSQL.ToString)
            Dim intInsertRet As Integer = MyBase.mobjCommonDB.DB_ExecuteNonQuery(stbUpdateSQL.ToString, oraUpdateParam)
            ''MOD 2015.11.17 速度改善 ↑

            If Not intInsertRet = 1 Then
                Throw New Exception("イメージデータの更新に失敗しました。")
            End If

        Catch ex As Exception
            ' ログファイルにエラー内容を出力します。
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(MyBase.mobjCommonDB.GetInfoMessage, EventLogEntryType.Error)
            Throw ex
        End Try
    End Sub
#End Region

#Region "T_JJ_IMAGE_HISTORYの登録"
    ''' ======================================================================
    ''' メソッド名：InsertHistory
    ''' <summary>
    ''' T_JJ_IMAGE_HISTORYの登録
    ''' </summary>
    ''' <param name="strDocumentId">書類ID</param>
    ''' <remarks></remarks>
    ''' ======================================================================
    Private Sub InsertHistory(ByVal strDocumentId As String, ByVal strStatus As String)

        Try
            Dim strUpdateStatus As String = strStatus

            ' イメージ状態履歴登録用SQLを作成します。
            Dim stbInsertSQL As New System.Text.StringBuilder(String.Empty)
            stbInsertSQL.AppendLine("INSERT INTO T_JJ_IMAGE_HISTORY (")
            stbInsertSQL.AppendLine("     IMAGE_ID")
            stbInsertSQL.AppendLine("    ,IMAGE_STATUS")
            stbInsertSQL.AppendLine("    ,CREATE_DATE")
            stbInsertSQL.AppendLine("    ,CREATE_USER")
            stbInsertSQL.AppendLine(") VALUES (")
            stbInsertSQL.AppendLine("     :DocumentID")
            stbInsertSQL.AppendLine("    ,:OutStatus")
            stbInsertSQL.AppendLine("    ,SYSDATE")
            stbInsertSQL.AppendLine("    ,'MakeDelivery'")
            stbInsertSQL.AppendLine(")")

            ' イメージ状態履歴登録用パラメータ宣言
            Dim oraInsertParam(1) As OracleParameter
            oraInsertParam(0) = New OracleParameter(":DocumentID", OracleDbType.Decimal)
            oraInsertParam(0).Value = Convert.ToInt64(strDocumentId)
            oraInsertParam(1) = New OracleParameter(":OutStatus", OracleDbType.Char)
            oraInsertParam(1).Value = strUpdateStatus
            ' イメージ状態履歴を登録します。
            Dim intInsertRet As Integer = MyBase.mobjCommonDB.DB_ExecuteNonQuery(stbInsertSQL.ToString, oraInsertParam)
            If Not intInsertRet = 1 Then
                Throw New Exception("イメージ履歴の登録に失敗しました。")
            End If

        Catch ex As Exception
            ' ログファイルにエラー内容を出力します。
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(MyBase.mobjCommonDB.GetInfoMessage, EventLogEntryType.Error)
            Throw ex
        End Try

    End Sub
#End Region

#Region "イメージテーブルステータス更新連帳票番号追加"
    ''' <summary>
    ''' excSubjectNumCsvAdd
    ''' <para name="excSubjectNum">帳票番号(IN)</para>
    ''' <para name="strExcSubjectNumArrayList">イメージテーブルステータスを更新する為の関連帳票番号リスト</para>
    ''' </summary>
    ''' <remarks>イメージテーブルステータスを更新する為の関連帳票番号を19桁から23桁にしてCSV形式で追加</remarks>
    Private Sub excSubjectNumCsvAdd(ByVal excSubjectNum As String, _
                                    ByRef strExcSubjectNumArrayList As ArrayList)
        Dim SEPARATOR As String = "-"
        '対象が19桁の文字列の時のみ
        If excSubjectNum <> "" And Len(excSubjectNum) = 19 Then
            '19桁から23桁へ
            excSubjectNum = excSubjectNum.Substring(0, 2) & SEPARATOR & _
                            excSubjectNum.Substring(2, 2) & SEPARATOR & _
                            excSubjectNum.Substring(4, 6) & SEPARATOR & _
                            excSubjectNum.Substring(10, 3) & SEPARATOR & _
                            excSubjectNum.Substring(13, 6)
            strExcSubjectNumArrayList.Add("'" & excSubjectNum & "'")
        End If

    End Sub
#End Region

#Region "納品時刻の取得"
    Private Function GetDeliveryDate() As String
        Dim stbSQL As New StringBuilder(String.Empty)
        Try
            Dim dtNow As DataTable = mobjCommonDB.DB_ExecuteQuery("SELECT TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS') FROM DUAL")
            Dim strNow As String = Convert.ToString(dtNow.Rows(0).Item(0))

            Dim dtDlv As DataTable = mobjCommonDB.DB_ExecuteQuery("SELECT * FROM M_CM_DELIVERY_DATE WHERE TO_CHAR(SYSDATE,'HH24MI') BETWEEN DELIVERY_TIME_START AND DELIVERY_TIME_END")
            If dtDlv Is Nothing OrElse dtDlv.Rows.Count = 0 Then
                Return strNow
            Else
                strNow = strNow.Substring(0, 8) & Convert.ToString(dtDlv.Rows(0).Item("DELIVERY_TIME"))
            End If

            Return strNow
        Catch ex As Exception
            ' ログファイルにエラー内容を出力します。
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(MyBase.mobjCommonDB.GetInfoMessage, EventLogEntryType.Error)
            Throw ex
        End Try
    End Function
#End Region

#Region "帳票ID統一後のテーブル作成"
    Private Sub MakeSlipConvertTable(dt As DataTable)
        Try
            Dim stbSQL As New StringBuilder(String.Empty)
            stbSQL.AppendLine("SELECT")
            stbSQL.AppendLine("    I.IMAGE_ID,")
            stbSQL.AppendLine("    R.ITEM_002")
            stbSQL.AppendLine("FROM")
            stbSQL.AppendLine("    T_JJ_IMAGE I")
            stbSQL.AppendLine("    INNER JOIN T_JJ_OCR_RESULT R")
            stbSQL.AppendLine("        ON")
            stbSQL.AppendLine("            R.DELETE_FLG = '0'")
            stbSQL.AppendLine("            AND")
            stbSQL.AppendLine("            R.ITEM_004 = REPLACE(I.EXC_SUBJECT_NO, '-')")
            stbSQL.AppendLine("WHERE")
            stbSQL.AppendLine("    I.IMAGE_STATUS = %STATUS%")
            stbSQL.AppendLine("    AND")
            stbSQL.AppendLine("    I.DELETE_FLG = '0'")
            stbSQL.Replace("%STATUS%", mdicConfig("INPUT_STATUS"))
            Dim dtDiv As DataTable = mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)

            For Each dr As DataRow In dt.Rows
                Dim strImageID As String = Convert.ToString(dr.Item("IMAGE_ID"))
                Dim drDiv() As DataRow = dtDiv.Select("IMAGE_ID = " & strImageID)

                Dim strSlip As String = Convert.ToString(dr.Item("SLIP_DEFINE_ID"))
                Dim strSlipDiv As String = String.Empty
                If drDiv.Length = 1 Then
                    strSlipDiv = Convert.ToString(drDiv(0).Item("ITEM_002"))
                End If

                ' 新帳票の元号で変換が必要とされている項目は変換を行います
                If mdicEraConv.ContainsKey(strSlip) Then
                    For Each strItemID As String In mdicEraConv(strSlip).Keys
                        Dim strEratype As String = mdicEraConv(strSlip)(strItemID)
                        Dim strValue As String = Convert.ToString(dr.Item(strItemID))
                        If strEratype.Equals("3") Then
                            Select Case strValue
                                Case "1"
                                    dr.Item(strItemID) = "3"
                                Case "2"
                                    dr.Item(strItemID) = "4"
                                Case "3"
                                    dr.Item(strItemID) = "5"
                            End Select
                        ElseIf strEratype.Equals("4") Then
                            Select Case strValue
                                Case "1"
                                    dr.Item(strItemID) = "4"
                                Case "2"
                                    dr.Item(strItemID) = "5"
                            End Select
                        End If
                    Next
                End If

                If mdicSlipConv.ContainsKey(strSlip) Then
                    If strSlipDiv.Equals("062") Then
                        Select Case strSlip
                            Case "661119"
                                dr.Item("SLIP_DEFINE_ID") = "661669"
                            Case "661218"
                                dr.Item("SLIP_DEFINE_ID") = "661768"
                            Case "661126"
                                dr.Item("SLIP_DEFINE_ID") = "661676"
                            Case "661225"
                                dr.Item("SLIP_DEFINE_ID") = "661775"
                            Case Else
                                dr.Item("SLIP_DEFINE_ID") = mdicSlipConv(strSlip)
                        End Select
                    Else
                        dr.Item("SLIP_DEFINE_ID") = mdicSlipConv(strSlip)
                    End If
                End If
            Next
        Catch ex As Exception
            CommonLog.WriteLog("帳票IDの読み替え処理でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            Throw ex
        End Try
    End Sub
#End Region

End Class
