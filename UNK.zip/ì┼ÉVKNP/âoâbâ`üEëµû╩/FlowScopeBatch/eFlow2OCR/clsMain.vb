﻿Imports CommonSystem
Imports CommonBase
Imports System
Imports System.IO
Imports System.Text

Public Class clsMain
    Inherits clsBatchBase

#Region "共通変数"

    ''' <summary>
    ''' 自端末処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Shared mainProc As clsMain

#End Region

#Region "内部変数定義"

    ''' <summary>
    ''' 正常ステータス辞書
    ''' </summary>
    ''' <remarks></remarks>
    Private mdicOutputSttaus As New Dictionary(Of String, String)

    ''' <summary>
    ''' エラーステータス辞書
    ''' </summary>
    ''' <remarks></remarks>
    Private mdicErrorSttaus As New Dictionary(Of String, String)

    Private mdicWideConv As New Dictionary(Of String, String)
    Private mdicHalfConv As New Dictionary(Of String, String)
    Private mstrIchiYomi() As String
    Private mdicSkio As New Dictionary(Of Integer, Integer)

    Private mdicSlip As New Dictionary(Of String, Dictionary(Of String, String()))

#Region "列挙子"
    '変換タイプ
    Public Enum ChangeType
        StoLKanaHerf = 0
        StoLKataKana = 1
        StoLHiraGana = 2
        LtoSKanaHerf = 3
        LtoSKataKana = 4
        LtoSHiraGana = 5
        SmallToLarge = 6
        LargeToSmall = 7
    End Enum
#End Region

#Region "定数"
    'かな小文字の定義
    Private KATAKANA_H_SMALL() As String = {"ｯ", "ｧ", "ｨ", "ｩ", "ｪ", "ｫ", "ｬ", "ｭ", "ｮ"}
    Private KATAKANA_SMALL() As String = {"ッ", "ァ", "ィ", "ゥ", "ェ", "ォ", "ャ", "ュ", "ョ"}
    Private HIRAGANA_SMALL() As String = {"っ", "ぁ", "ぃ", "ぅ", "ぇ", "ぉ", "ゃ", "ゅ", "ょ"}
    'かな大文字の定義
    Private KATAKANA_H_LARGE() As String = {"ﾂ", "ｱ", "ｲ", "ｳ", "ｴ", "ｵ", "ﾔ", "ﾕ", "ﾖ"}
    Private KATAKANA_LARGE() As String = {"ツ", "ア", "イ", "ウ", "エ", "オ", "ヤ", "ユ", "ヨ"}
    Private HIRAGANA_LARGE() As String = {"つ", "あ", "い", "う", "え", "お", "や", "ゆ", "よ"}
#End Region

#End Region

#Region "メイン処理[Main]"

    ''' ======================================================================
    ''' メソッド名：Main
    ''' <summary>
    ''' メイン処理
    ''' </summary>
    ''' <remarks></remarks>
    ''' ======================================================================
    Shared Function Main(ByVal CmdArgs() As String) As Integer

        mainProc = New clsMain

        ' 処理の戻り値を返却
        Return mainProc.Run()

    End Function

#End Region

#Region "バッチ処理本体"
    ''' ======================================================================
    ''' メソッド名：Execute
    ''' <summary>
    ''' バッチ処理本体
    ''' </summary>
    ''' <remarks></remarks>
    ''' ======================================================================
    Protected Overrides Sub Execute()
        Try
            ' ステータス辞書の作成を行います。
            Call MakeStatusDictionary()

            ' 帳票ID定義を読み込みます。
            Call LoadSlipDefine()

            ' 処理対象データを取得します。
            Dim dtbImage As DataTable = GetData()
            If dtbImage Is Nothing OrElse dtbImage.Rows.Count = 0 Then
                Return
            End If

            Dim dicRes As New Dictionary(Of String, Dictionary(Of String, String))
            Dim dicSts As New Dictionary(Of String, String)
            Dim dicSlp As New Dictionary(Of String, String)
            For Each dr As DataRow In dtbImage.Rows
                ' イメージIDを取得します。
                Dim strImageID As String = Convert.ToString(dr.Item("IMAGE_ID"))
                ' イメージ状態を取得します。
                Dim strInputStatus As String = Convert.ToString(dr.Item("IMAGE_STATUS"))
                ' 帳票IDを取得します。
                Dim strSlipID As String = Convert.ToString(dr.Item("SLIP_DEFINE_ID"))

                ' 初見のイメージIDなら辞書に追加します。
                If Not dicRes.ContainsKey(strImageID) Then
                    Dim dic As New Dictionary(Of String, String)
                    dicRes.Add(strImageID, dic)
                    dicSts.Add(strImageID, strInputStatus)
                End If

                Dim strResultID As String = Convert.ToString(dr.Item("RESULT_ID"))
                If strResultID.Length > 0 Then
                    Dim strItemID As String = Convert.ToString(dr.Item("ITEM_ID"))
                    Dim strResult As String = Convert.ToString(dr.Item("OCR_STR"))
                    dicRes(strImageID).Add(strItemID, strResult)
                End If

                If Not dicSlp.ContainsKey(strImageID) Then
                    dicSlp.Add(strImageID, strSlipID)
                End If
            Next

            ' DBトランザクションを開始します。
            mobjCommonDB.DB_Transaction()
            Try

                For Each strImageID As String In dicRes.Keys

                    Dim strSlipID As String = dicSlp(strImageID)

                    ' バッファを初期化します。
                    Dim strItem(400) As String
                    For i As Integer = 0 To 400 Step 1
                        strItem(i) = String.Empty
                    Next

                    strItem(0) = strImageID

                    If dicRes(strImageID).Count > 0 Then

                        For i As Integer = 1 To 400 Step 1
                            Dim strNum As String = GetOcrResult("F" & i.ToString("000"), dicRes(strImageID))
                            If Not strNum = String.Empty Then
                                ' 不読文字の"?"置換
                                strNum = strNum.Replace("●", "?")
                                strItem(i) = strNum

                                If mdicSlip.ContainsKey(strSlipID) Then
                                    Dim strFID As String = "F" & i.ToString("000")
                                    If mdicSlip(strSlipID).ContainsKey(strFID) Then
                                        Dim strDef() As String = mdicSlip(strSlipID)(strFID)
                                        Dim intIndex As Integer = Convert.ToInt32(strDef(1).Substring(1))
                                        strItem(intIndex) = strDef(2)
                                    End If
                                End If
                            End If
                        Next
                    Else
                        Dim intQC As Integer = Convert.ToInt32(mdicConfig("QUESTION_COUNT"))
                        For i As Integer = 1 To intQC Step 1
                            strItem(i) = "?"
                        Next
                    End If

                    If CheckOCR(strImageID) Then
                        If dicRes(strImageID).Count > 0 Then
                            ' OCRデータを更新します。
                            Call UpdateOCR(strItem)
                        End If
                    Else
                        ' OCRデータを登録します。
                        Call InsertOCR(strItem)
                    End If

                    ' 出力ステータスを取得します。
                    Dim strStatus As String = mdicOutputSttaus(dicSts(strImageID))
                    ' イメージステータスを更新します。
                    Call UpdateImageData(strImageID, strStatus)
                    ' ステータス履歴を登録します。
                    Call InsertHistory(strImageID, strStatus)
                Next

                ' DBトランザクションを確定します。
                mobjCommonDB.DB_Commit()

            Catch ex As Exception
                ' DBトランザクションを破棄します。
                mobjCommonDB.DB_Rollback()
                Throw ex
            End Try

        Catch ex As Exception
            MyBase.WriteLog(ex.ToString, EventLogEntryType.Error)
        Finally
        End Try
    End Sub
#End Region

#Region "ステータス辞書の作成"
    ''' <summary>
    ''' ステータス辞書の作成
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub MakeStatusDictionary()
        Try
            Dim strIN() As String = Split(mdicConfig("INPUT_STATUS"), ",")
            Dim strOUT() As String = Split(mdicConfig("OUTPUT_STATUS"), ",")
            Dim strERR() As String = Split(mdicConfig("OUTPUT_STATUS_ERROR"), ",")
            For i As Integer = 0 To strIN.Count - 1 Step 1
                mdicOutputSttaus.Add(strIN(i), strOUT(i))
                mdicErrorSttaus.Add(strIN(i), strERR(i))
            Next

        Catch ex As Exception
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            Throw ex
        End Try
    End Sub
#End Region

#Region "処理対象イメージデータ取得"
    ''' <summary>
    ''' 処理対象イメージデータ取得
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetData() As DataTable
        Dim stbSQL As New StringBuilder(String.Empty)
        Try
            ' configの入力ステータスをSQLに加えるために"'"括りのカンマ区切りに変換します。
            Dim strIN() As String = Split(mdicConfig("INPUT_STATUS"), ",")
            Dim lst As New List(Of String)
            For Each s As String In strIN
                lst.Add("'" & s & "'")
            Next
            Dim strInputStatus As String = Join(lst.ToArray, ",")

            ' T_JJ_IMAGEからイメージ状態が『OCR結果変換待ち』になっているレコード
            ' を抽出します。
            stbSQL.AppendLine("SELECT")
            stbSQL.AppendLine("    I.*")
            stbSQL.AppendLine("    ,R.*")
            stbSQL.AppendLine("    ,R.IMAGE_ID AS RESULT_ID")
            stbSQL.AppendLine("FROM")
            stbSQL.AppendLine("    T_JJ_IMAGE I")
            stbSQL.AppendLine("    LEFT JOIN T_JJ_EFLOW_RESULT R")
            stbSQL.AppendLine("    ON")
            stbSQL.AppendLine("        I.IMAGE_ID = R.IMAGE_ID")
            stbSQL.AppendLine("        AND")
            stbSQL.AppendLine("        R.DELETE_FLG = '0'")
            stbSQL.AppendLine("WHERE")
            stbSQL.AppendLine("    I.IMAGE_STATUS IN (%STATUS%)")
            stbSQL.AppendLine("    AND")
            stbSQL.AppendLine("    MOD(I.IMAGE_ID , 10) IN (%MOD%)")
            stbSQL.AppendLine("    AND")
            stbSQL.AppendLine("    I.DELETE_FLG = '0'")
            stbSQL.AppendLine("    AND")
            stbSQL.AppendLine("    NOT SUBSTR(I.IMAGE_FILE_NAME,1,23) IN (")
            stbSQL.AppendLine("        SELECT")
            stbSQL.AppendLine("            SUBSTR(IMAGE_FILE_NAME,1,23)")
            stbSQL.AppendLine("        FROM")
            stbSQL.AppendLine("            T_JJ_IMAGE")
            stbSQL.AppendLine("        WHERE")
            stbSQL.AppendLine("            NOT IMAGE_STATUS IN (%STATUS%)")
            stbSQL.AppendLine("            AND")
            stbSQL.AppendLine("            DELETE_FLG = '0'")
            stbSQL.AppendLine("    )")
            stbSQL.AppendLine("ORDER BY")
            stbSQL.AppendLine("     I.IMAGE_ID")
            stbSQL.AppendLine("    ,R.ITEM_ID")

            stbSQL.Replace("%STATUS%", strInputStatus)
            stbSQL.Replace("%MOD%", mdicConfig("IMAGE_ID_TAIL"))

            Dim dt As DataTable = mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)
            Return dt

        Catch ex As Exception
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(stbSQL.ToString, EventLogEntryType.Error)
            Throw ex
        End Try
    End Function
#End Region

#Region "T_JJ_IMAGEの更新"
    ''' <summary>
    ''' T_JJ_IMAGEの更新
    ''' </summary>
    ''' <param name="strImageID">更新対象イメージID</param>
    ''' <param name="strStatus">更新ステータス</param>
    ''' <remarks></remarks>
    Private Sub UpdateImageData(ByVal strImageID As String, ByVal strStatus As String)
        Dim stbUpdateSQL As New StringBuilder(String.Empty)
        Try
            ' T_RECEIPT_IMAGE更新用SQLを作成します。
            stbUpdateSQL.AppendLine("UPDATE")
            stbUpdateSQL.AppendLine("    T_JJ_IMAGE")
            stbUpdateSQL.AppendLine("SET")
            stbUpdateSQL.AppendLine("     IMAGE_STATUS             = '__IMAGE_STATUS__'")
            stbUpdateSQL.AppendLine("    ,BEFORE_IMAGE_STATUS      = IMAGE_STATUS")
            stbUpdateSQL.AppendLine("    ,UPDATE_USER              = 'eFlow2OCR'")
            stbUpdateSQL.AppendLine("    ,UPDATE_DATE              = SYSDATE")
            stbUpdateSQL.AppendLine("WHERE")
            stbUpdateSQL.AppendLine("    IMAGE_ID = __IMAGE_ID__")

            ' 作成したSQLの設定値の部分を実際の値に置換します。
            stbUpdateSQL.Replace("__IMAGE_STATUS__", strStatus)
            stbUpdateSQL.Replace("__IMAGE_ID__", strImageID)

            ' 作成したSQLを実行してT_RECEIPT_IMAGEを更新します。
            Dim intInsertRet As Integer = MyBase.mobjCommonDB.DB_ExecuteNonQuery(stbUpdateSQL.ToString)
            If Not intInsertRet = 1 Then
                Throw New Exception("イメージデータの更新に失敗しました。")
            End If

        Catch ex As Exception
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(stbUpdateSQL.ToString, EventLogEntryType.Error)
            Throw ex
        End Try
    End Sub
#End Region

#Region "T_JJ_IMAGE_HISTORYの登録"
    ''' <summary>
    ''' T_JJ_IMAGE_HISTORYの登録
    ''' </summary>
    ''' <param name="strImageID">対象のイメージID</param>
    ''' <param name="strStatus">更新したイメージステータス</param>
    ''' <remarks></remarks>
    Private Sub InsertHistory(ByVal strImageID As String, ByVal strStatus As String)
        Dim stbInsertSQL As New System.Text.StringBuilder(String.Empty)
        Try
            ' イメージ状態履歴登録用SQLを作成します。
            stbInsertSQL.AppendLine("INSERT INTO T_JJ_IMAGE_HISTORY (")
            stbInsertSQL.AppendLine("     IMAGE_ID")
            stbInsertSQL.AppendLine("    ,IMAGE_STATUS")
            stbInsertSQL.AppendLine("    ,CREATE_DATE")
            stbInsertSQL.AppendLine("    ,CREATE_USER")
            stbInsertSQL.AppendLine(") VALUES (")
            stbInsertSQL.AppendLine("     __IMAGE_ID__")
            stbInsertSQL.AppendLine("    ,'__IMAGE_STATUS__'")
            stbInsertSQL.AppendLine("    ,SYSTIMESTAMP")
            stbInsertSQL.AppendLine("    ,'eFlow2OCR'")
            stbInsertSQL.AppendLine(")")

            stbInsertSQL.Replace("__IMAGE_ID__", strImageID)
            stbInsertSQL.Replace("__IMAGE_STATUS__", strStatus)

            ' イメージ状態履歴を登録します。
            Dim intInsertRet As Integer = MyBase.mobjCommonDB.DB_ExecuteNonQuery(stbInsertSQL.ToString)
            If Not intInsertRet = 1 Then
                Throw New Exception("イメージ履歴の登録に失敗しました。")
            End If

        Catch ex As Exception
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(stbInsertSQL.ToString, EventLogEntryType.Error)
            Throw ex
        End Try
    End Sub
#End Region

#Region "OCR結果の取得"
    Private Function GetOcrResult(id As String, dic As Dictionary(Of String, String)) As String
        Try
            If Not dic.ContainsKey(id) Then
                Return String.Empty
            End If
            Return (dic(id))
        Catch ex As Exception
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            Throw ex
        End Try
    End Function
#End Region

#Region "有料フラグ取得"
    Private Function GetYuryo(id As String, dic As Dictionary(Of String, String), intNum As Integer) As String
        Try
            Dim strResult As String = GetOcrResult(id, dic)
            Dim strItem() As String = Split(strResult, ",")
            If strItem.Length <> 10 Then
                Return String.Empty
            End If
            If strItem(intNum).Length = 0 Then
                Return String.Empty
            End If
            Return "1"
        Catch ex As Exception
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            Throw ex
        End Try
    End Function
#End Region

#Region "年月日取得"
    Private Function GetYYYYMMDD(id As String, dic As Dictionary(Of String, String), intNum As Integer) As String
        Try
            Dim strResult As String = GetOcrResult(id, dic)
            Dim strItem() As String = Split(strResult, ",")
            If strItem.Length <> 3 Then
                Return String.Empty
            End If
            If strItem(intNum).Length = 0 Then
                Return String.Empty
            End If

            Select Case intNum
                Case 0
                    Return strItem(intNum).PadLeft(4, "0").Substring(0, 4)
                Case Else
                    Return strItem(intNum).PadLeft(2, "0").Substring(0, 2).Replace("00", String.Empty)
            End Select

        Catch ex As Exception
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            Throw ex
        End Try
    End Function
#End Region

#Region "T_JJ_OCRの削除"
    ''' <summary>
    ''' T_JJ_OCRの削除
    ''' </summary>
    ''' <param name="strImageID">更新対象イメージID</param>
    ''' <remarks></remarks>
    Private Sub DeleteOcrData(ByVal strImageID As String)
        Dim stbDeleteSQL As New StringBuilder(String.Empty)
        Try
            stbDeleteSQL.AppendLine("DELETE FROM")
            stbDeleteSQL.AppendLine("    T_JJ_OCR")
            stbDeleteSQL.AppendLine("WHERE")
            stbDeleteSQL.AppendLine("    IMAGE_ID = __IMAGE_ID__")

            ' 作成したSQLの設定値の部分を実際の値に置換します。
            stbDeleteSQL.Replace("__IMAGE_ID__", strImageID)

            ' 作成したSQLを実行してT_JJ_OCRを更新します。
            Dim intInsertRet As Integer = MyBase.mobjCommonDB.DB_ExecuteNonQuery(stbDeleteSQL.ToString)

        Catch ex As Exception
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(stbDeleteSQL.ToString, EventLogEntryType.Error)
            Throw ex
        End Try
    End Sub
#End Region

#Region "T_JJ_OCRの登録"
    ''' <summary>
    ''' T_JJ_OCRの登録
    ''' </summary>
    ''' <param name="strItem">更新するデータ</param>
    ''' <remarks></remarks>
    Private Sub InsertOCR(strItem() As String)
        Dim stbInsertSQL As New System.Text.StringBuilder(String.Empty)
        Try
            ' イメージ状態履歴登録用SQLを作成します。
            stbInsertSQL.AppendLine("INSERT INTO T_JJ_OCR (")
            stbInsertSQL.AppendLine("     IMAGE_ID")
            For i As Integer = 1 To 400 Step 1
                stbInsertSQL.AppendLine("    ,ITEM_" & i.ToString("000"))
            Next
            stbInsertSQL.AppendLine("    ,CREATE_DATE")
            stbInsertSQL.AppendLine("    ,CREATE_USER")
            stbInsertSQL.AppendLine("    ,UPDATE_DATE")
            stbInsertSQL.AppendLine("    ,UPDATE_USER")
            stbInsertSQL.AppendLine(") VALUES (")
            stbInsertSQL.AppendLine("     __IMAGE_ID__")
            For i As Integer = 1 To 400 Step 1
                stbInsertSQL.AppendLine("    ,'" & strItem(i) & "'")
            Next
            stbInsertSQL.AppendLine("    ,SYSDATE")
            stbInsertSQL.AppendLine("    ,'eFlow2OCR'")
            stbInsertSQL.AppendLine("    ,SYSDATE")
            stbInsertSQL.AppendLine("    ,'eFlow2OCR'")
            stbInsertSQL.AppendLine(")")

            stbInsertSQL.Replace("__IMAGE_ID__", strItem(0))

            ' イメージ状態履歴を登録します。
            Dim intInsertRet As Integer = MyBase.mobjCommonDB.DB_ExecuteNonQuery(stbInsertSQL.ToString)
            If Not intInsertRet = 1 Then
                Throw New Exception("OCRデータの登録に失敗しました。")
            End If

        Catch ex As Exception
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(stbInsertSQL.ToString, EventLogEntryType.Error)
            Throw ex
        End Try
    End Sub
#End Region

#Region "T_JJ_OCRの更新"
    ''' <summary>
    ''' T_JJ_OCRの更新
    ''' </summary>
    ''' <param name="strItem">更新するデータ</param>
    ''' <remarks></remarks>
    Private Sub UpdateOCR(strItem() As String)
        Dim stbSQL As New System.Text.StringBuilder(String.Empty)
        Try
            ' イメージ状態履歴登録用SQLを作成します。
            stbSQL.AppendLine("UPDATE T_JJ_OCR ")
            stbSQL.AppendLine("SET")
            stbSQL.AppendLine("     UPDATE_DATE = SYSDATE")
            stbSQL.AppendLine("    ,UPDATE_USER = 'eFlow2OCR'")
            For i As Integer = 1 To 400 Step 1
                If mdicSkio.ContainsKey(i) Then
                    Continue For
                End If
                stbSQL.AppendLine("    ,ITEM_" & i.ToString("000") & " = '" & strItem(i) & "'")
            Next
            stbSQL.AppendLine("WHERE")
            stbSQL.AppendLine("    IMAGE_ID = " & strItem(0))

            ' OCR結果を更新します。
            Dim intRet As Integer = MyBase.mobjCommonDB.DB_ExecuteNonQuery(stbSQL.ToString)
            If Not intRet = 1 Then
                Throw New Exception("OCRデータの更新に失敗しました。")
            End If

        Catch ex As Exception
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(stbSQL.ToString, EventLogEntryType.Error)
            Throw ex
        End Try
    End Sub
#End Region

#Region "T_JJ_OCR存在チェック"
    Private Function CheckOCR(strImageID As String) As Boolean
        Dim stbSQL As New System.Text.StringBuilder(String.Empty)
        Try
            stbSQL.AppendLine("SELECT IMAGE_ID FROM T_JJ_OCR WHERE IMAGE_ID = %ID%")
            stbSQL.Replace("%ID%", strImageID)
            Dim dt As DataTable = mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)
            If dt Is Nothing OrElse dt.Rows.Count = 0 Then
                Return False
            End If
            Return True
        Catch ex As Exception
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(stbSQL.ToString, EventLogEntryType.Error)
            Throw ex
        End Try
    End Function
#End Region

#Region "帳票定義ファイルの読込み"
    Private Sub LoadSlipDefine()
        Try
            Dim strFiles() As String = Directory.GetFiles(mdicConfig("SLIP_DEFINE_PATH"), "*.txt")
            For Each strFile As String In strFiles

                Dim strSlipID As String = Path.GetFileNameWithoutExtension(strFile)
                If Not mdicSlip.ContainsKey(strSlipID) Then
                    Dim dic As New Dictionary(Of String, String())
                    mdicSlip.Add(strSlipID, dic)
                End If

                Using sr As New StreamReader(strFile, Encoding.GetEncoding("shift-jis"))
                    Do Until sr.EndOfStream

                        Dim strLine As String = sr.ReadLine
                        If strLine.StartsWith("#") Then
                            Continue Do
                        End If

                        Dim strItem() As String = Split(strLine, ",")
                        If mdicSlip(strSlipID).ContainsKey(strItem(0)) Then
                            Continue Do
                        End If

                        mdicSlip(strSlipID).Add(strItem(0), strItem)
                    Loop
                End Using
            Next

        Catch ex As Exception
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            Throw ex
        End Try
    End Sub
#End Region



#Region "メソッド"
    Private Function KanjiToKana(ByVal kanji As String) As String
        Dim objExcel As New Microsoft.Office.Interop.Excel.Application
        Dim strKana As String = String.Empty
        '漢字→カナ変換
        strKana = StrConv(objExcel.GetPhonetic(kanji), VbStrConv.Narrow)
        'カナ小文字→カナ大文字変換
        strKana = StrConv2(strKana, ChangeType.StoLKanaHerf)
        Return strKana
    End Function


    '指定した形式に従って、かな小文字→かな大文字に変換する
    Public Function StrConv2(ByVal str As String, ByVal Conversion As ChangeType) As String
        Dim buffer As New System.Text.StringBuilder
        Select Case Conversion
            Case ChangeType.StoLKanaHerf  '半角カナ（小→大）
                buffer.Append(ChangeString(str, KATAKANA_H_SMALL, KATAKANA_H_LARGE))
            Case ChangeType.StoLKataKana  'カタカナ（小→大）
                buffer.Append(ChangeString(str, KATAKANA_SMALL, KATAKANA_LARGE))
            Case ChangeType.StoLHiraGana  'ひらがな（小→大）
                buffer.Append(ChangeString(str, HIRAGANA_SMALL, HIRAGANA_LARGE))
            Case ChangeType.LtoSKanaHerf  '半角カナ（大→小）
                buffer.Append(ChangeString(str, KATAKANA_H_LARGE, KATAKANA_H_SMALL))
            Case ChangeType.LtoSKataKana  'カタカナ（大→小）
                buffer.Append(ChangeString(str, KATAKANA_LARGE, KATAKANA_SMALL))
            Case ChangeType.LtoSHiraGana  'ひらがな（大→小）
                buffer.Append(ChangeString(str, HIRAGANA_LARGE, HIRAGANA_SMALL))
            Case ChangeType.SmallToLarge
                buffer.Append(ChangeSmallToLarge(str))
            Case ChangeType.LargeToSmall
                buffer.Append(ChangeLargeToSmall(str))
            Case Else
                buffer.Length = 0
        End Select
        Return buffer.ToString
    End Function

    '指定した形式に従って文字列を置き換える
    Public Function ChangeString(ByVal str As String, ByVal oldStrings() As String, ByVal newStrings() As String) As String
        Dim buffer As New System.Text.StringBuilder
        buffer.Append(str)
        '変換処理（処理速度が悪くならないようにStringBuilderで処理する）
        For idx As Integer = 0 To oldStrings.GetLength(0) - 1
            buffer = buffer.Replace(oldStrings(idx), newStrings(idx))
        Next
        Return buffer.ToString
    End Function

    '小文字を大文字に変換する（半角カナ、カタカナ、ひらがな）
    Public Function ChangeSmallToLarge(ByVal str As String) As String
        Dim buffer As New System.Text.StringBuilder
        buffer.Append(str)
        '変換処理（処理速度が悪くならないようにStringBuilderで処理する）
        '半角カナ
        For idx As Integer = 0 To KATAKANA_H_SMALL.GetLength(0) - 1
            buffer = buffer.Replace(KATAKANA_H_SMALL(idx), KATAKANA_H_LARGE(idx))
        Next
        'カタカナ
        For idx As Integer = 0 To KATAKANA_SMALL.GetLength(0) - 1
            buffer = buffer.Replace(KATAKANA_SMALL(idx), KATAKANA_LARGE(idx))
        Next
        'ひらがな
        For idx As Integer = 0 To HIRAGANA_SMALL.GetLength(0) - 1
            buffer = buffer.Replace(HIRAGANA_SMALL(idx), HIRAGANA_LARGE(idx))
        Next
        Return buffer.ToString
    End Function

    '大文字を小文字に変換する（半角カナ、カタカナ、ひらがな）
    Public Function ChangeLargeToSmall(ByVal str As String) As String
        Dim buffer As New System.Text.StringBuilder
        buffer.Append(str)
        '変換処理（処理速度が悪くならないようにStringBuilderで処理する）
        '半角カナ
        For idx As Integer = 0 To KATAKANA_H_SMALL.GetLength(0) - 1
            buffer = buffer.Replace(KATAKANA_H_LARGE(idx), KATAKANA_H_SMALL(idx))
        Next
        'カタカナ
        For idx As Integer = 0 To KATAKANA_SMALL.GetLength(0) - 1
            buffer = buffer.Replace(KATAKANA_LARGE(idx), KATAKANA_SMALL(idx))
        Next
        'ひらがな
        For idx As Integer = 0 To HIRAGANA_SMALL.GetLength(0) - 1
            buffer = buffer.Replace(HIRAGANA_LARGE(idx), HIRAGANA_SMALL(idx))
        Next
        Return buffer.ToString()
    End Function
#End Region


End Class
