﻿Imports CommonSystem
Imports CommonBase
Imports System
Imports System.IO
Imports System.Text

Public Class clsPrioritySetMain
    Inherits clsBatchBase

#Region "共通変数"

    ''' <summary>
    ''' 自端末処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Shared mainProc As clsPrioritySetMain

#End Region

#Region "内部変数定義"

    ' 経過時間一覧（ソート用）
    Private mlstMinute As New List(Of Integer)
    ' 経過時間による優先度設定辞書
    Private mdicMinute As New Dictionary(Of Integer, Integer)

#End Region

#Region "メイン処理[Main]"

    ''' ======================================================================
    ''' メソッド名：Main
    ''' <summary>
    ''' メイン処理
    ''' </summary>
    ''' <remarks></remarks>
    ''' ======================================================================
    Shared Function Main(ByVal CmdArgs() As String) As Integer

        mainProc = New clsPrioritySetMain

        ' 処理の戻り値を返却
        Return mainProc.Run()

    End Function

#End Region

#Region "バッチ処理本体"
    ''' ======================================================================
    ''' メソッド名：Execute
    ''' <summary>
    ''' バッチ処理本体
    ''' </summary>
    ''' <remarks></remarks>
    ''' ======================================================================
    Protected Overrides Sub Execute()

        Try
            ' コンフィグから『PRIORITY_DEFINE_』で始まる定義を読込みます。
            For Each strKey As String In mdicConfig.Keys
                If strKey.StartsWith("PRIORITY_DEFINE_") Then
                    ' 定義内容を経過時間と設定優先度に分割します。
                    Dim strVal() As String = Split(mdicConfig(strKey), ",")
                    ' ソート用一覧に経過時間を登録します。
                    mlstMinute.Add(Convert.ToInt32(strVal(0)))
                    ' 優先度更新用辞書に経過時間と優先度を登録します。
                    mdicMinute.Add(Convert.ToInt32(strVal(0)), Convert.ToInt32(strVal(1)))
                End If
            Next

            ' 読込んだ定義内容を経過時間でソートします。
            mlstMinute.Sort()

            ' 経過時間が短い順に処理を行います。
            For i As Integer = 0 To mlstMinute.Count - 1 Step 1
                ' 対象経過時間を取得します。
                Dim intMin As Integer = mlstMinute(i)
                ' 処理対象の経過時間の次の経過時間があれば取得します。
                Dim intMax As Integer = -1
                If i < (mlstMinute.Count - 1) Then
                    intMax = mlstMinute(i + 1)
                End If
                ' DBトランザクションを開始します。
                mobjCommonDB.DB_Transaction()
                Try
                    ' イメージ状態履歴を登録します。
                    Call InsertHistory(intMin, intMax, mdicMinute(intMin))
                    ' イメージテーブルを更新します。
                    Call UpdatePriority(intMin, intMax, mdicMinute(intMin))
                    ' DBトランザクションを確定します。
                    mobjCommonDB.DB_Commit()
                    ' 履歴のKey重複を避けるために１秒待機します。
                    System.Threading.Thread.Sleep(1000)
                Catch ex As Exception
                    ' DBトランザクションを破棄します。
                    mobjCommonDB.DB_Rollback()
                    Throw ex
                End Try
            Next

            mobjCommonDB.DB_Transaction()
            Try
                ' 優先度更新対象にならなかったイメージの履歴を登録します。
                Call InsertHistory2()
                ' 優先度更新対象にならなかったイメージの状態更新します。
                Call UpdateOtherStatus()
                ' DBトランザクションを確定します。
                mobjCommonDB.DB_Commit()
            Catch ex As Exception
                ' DBトランザクションを破棄します。
                mobjCommonDB.DB_Rollback()
                Throw ex
            End Try

        Catch ex As Exception

            MyBase.WriteLog(ex.ToString, EventLogEntryType.Error)

        Finally

        End Try

    End Sub
#End Region

#Region "イメージ履歴登録処理"
    Private Sub InsertHistory(ByVal intMin As Integer, ByVal intMax As Integer, ByVal intPri As Integer)
        Dim stbSQL As New StringBuilder(String.Empty)
        Try
            stbSQL.AppendLine("INSERT INTO T_JJ_IMAGE_HISTORY (")
            stbSQL.AppendLine("    IMAGE_ID")
            stbSQL.AppendLine("    ,IMAGE_STATUS")
            stbSQL.AppendLine("    ,CREATE_DATE")
            stbSQL.AppendLine("    ,CREATE_USER")
            stbSQL.AppendLine(")")
            stbSQL.AppendLine("SELECT")
            stbSQL.AppendLine("     IMAGE_ID      AS IMAGE_ID")
            stbSQL.AppendLine("    ,'%FIN%'       AS IMAGE_STATUS")
            stbSQL.AppendLine("    ,SYSTIMESTAMP  AS CREATE_DATE")
            stbSQL.AppendLine("    ,'PrioritySet' AS CREATE_USER")
            stbSQL.AppendLine("FROM")
            stbSQL.AppendLine("    T_JJ_IMAGE")
            stbSQL.AppendLine("WHERE")
            stbSQL.AppendLine("    DELETE_FLG = '0'")
            stbSQL.AppendLine("    AND")
            stbSQL.AppendLine("    IMAGE_STATUS IN (%STS%)")
            stbSQL.AppendLine("    AND")
            stbSQL.AppendLine("   (CREATE_DATE + %MIN%/1440) < SYSDATE")
            If intMax > 0 Then
                stbSQL.AppendLine("    AND")
                stbSQL.AppendLine("    (CREATE_DATE + %MAX%/1440) >= SYSDATE")
            End If

            stbSQL.Replace("%FIN%", mdicConfig("FINISH_STATUS"))
            stbSQL.Replace("%STS%", mdicConfig("UPDATE_STATUS"))
            stbSQL.Replace("%PRI%", intPri.ToString)
            stbSQL.Replace("%MIN%", intMin.ToString)
            stbSQL.Replace("%MAX%", intMax.ToString)

            mobjCommonDB.DB_ExecuteNonQuery(stbSQL.ToString)

        Catch ex As Exception
            CommonLog.WriteLog("SQL実行エラー", EventLogEntryType.Error)
            CommonLog.WriteLog(stbSQL.ToString, EventLogEntryType.Error)
            Throw ex
        End Try
    End Sub
#End Region

#Region "優先度更新処理"
    Private Sub UpdatePriority(ByVal intMin As Integer, ByVal intMax As Integer, ByVal intPri As Integer)
        Dim stbSQL As New StringBuilder(String.Empty)
        Try
            stbSQL.AppendLine("UPDATE")
            stbSQL.AppendLine("    T_JJ_IMAGE")
            stbSQL.AppendLine("SET")
            stbSQL.AppendLine("     BEFORE_IMAGE_STATUS = IMAGE_STATUS")
            stbSQL.AppendLine("    ,IMAGE_STATUS        = '%FIN%'")
            stbSQL.AppendLine("    ,PRIORITY            = '%PRI%'")
            stbSQL.AppendLine("WHERE")
            stbSQL.AppendLine("    DELETE_FLG = '0'")
            stbSQL.AppendLine("    AND")
            stbSQL.AppendLine("    IMAGE_STATUS IN (%STS%)")
            stbSQL.AppendLine("    AND")
            stbSQL.AppendLine("    (CREATE_DATE + %MIN%/1440) < SYSDATE")
            If intMax > 0 Then
                stbSQL.AppendLine("    AND")
                stbSQL.AppendLine("    (CREATE_DATE + %MAX%/1440) >= SYSDATE")
            End If

            stbSQL.Replace("%FIN%", mdicConfig("FINISH_STATUS"))
            stbSQL.Replace("%STS%", mdicConfig("UPDATE_STATUS"))
            stbSQL.Replace("%PRI%", intPri.ToString)
            stbSQL.Replace("%MIN%", intMin.ToString)
            stbSQL.Replace("%MAX%", intMax.ToString)

            mobjCommonDB.DB_ExecuteNonQuery(stbSQL.ToString)

        Catch ex As Exception
            CommonLog.WriteLog("SQL実行エラー", EventLogEntryType.Error)
            CommonLog.WriteLog(stbSQL.ToString, EventLogEntryType.Error)
            Throw ex
        End Try
    End Sub
#End Region

#Region "イメージ履歴登録処理２"
    Private Sub InsertHistory2()
        Dim stbSQL As New StringBuilder(String.Empty)
        Try
            stbSQL.AppendLine("INSERT INTO T_JJ_IMAGE_HISTORY (")
            stbSQL.AppendLine("    IMAGE_ID")
            stbSQL.AppendLine("    ,IMAGE_STATUS")
            stbSQL.AppendLine("    ,CREATE_DATE")
            stbSQL.AppendLine("    ,CREATE_USER")
            stbSQL.AppendLine(")")
            stbSQL.AppendLine("SELECT")
            stbSQL.AppendLine("     IMAGE_ID      AS IMAGE_ID")
            stbSQL.AppendLine("    ,'%FIN%'       AS IMAGE_STATUS")
            stbSQL.AppendLine("    ,SYSTIMESTAMP  AS CREATE_DATE")
            stbSQL.AppendLine("    ,'PrioritySet' AS CREATE_USER")
            stbSQL.AppendLine("FROM")
            stbSQL.AppendLine("    T_JJ_IMAGE")
            stbSQL.AppendLine("WHERE")
            stbSQL.AppendLine("    DELETE_FLG = '0'")
            stbSQL.AppendLine("    AND")
            stbSQL.AppendLine("    IMAGE_STATUS IN (%STS%)")

            stbSQL.Replace("%FIN%", mdicConfig("FINISH_STATUS"))
            stbSQL.Replace("%STS%", mdicConfig("UPDATE_STATUS"))

            mobjCommonDB.DB_ExecuteNonQuery(stbSQL.ToString)

        Catch ex As Exception
            CommonLog.WriteLog("SQL実行エラー", EventLogEntryType.Error)
            CommonLog.WriteLog(stbSQL.ToString, EventLogEntryType.Error)
            Throw ex
        End Try
    End Sub
#End Region

#Region "イメージ状態更新処理"
    Private Sub UpdateOtherStatus()
        Dim stbSQL As New StringBuilder(String.Empty)
        Try
            stbSQL.AppendLine("UPDATE")
            stbSQL.AppendLine("    T_JJ_IMAGE")
            stbSQL.AppendLine("SET")
            stbSQL.AppendLine("     BEFORE_IMAGE_STATUS = IMAGE_STATUS")
            stbSQL.AppendLine("    ,IMAGE_STATUS        = '%FIN%'")
            stbSQL.AppendLine("WHERE")
            stbSQL.AppendLine("    DELETE_FLG = '0'")
            stbSQL.AppendLine("    AND")
            stbSQL.AppendLine("    IMAGE_STATUS IN (%STS%)")

            stbSQL.Replace("%FIN%", mdicConfig("FINISH_STATUS"))
            stbSQL.Replace("%STS%", mdicConfig("UPDATE_STATUS"))

            mobjCommonDB.DB_ExecuteNonQuery(stbSQL.ToString)

        Catch ex As Exception
            CommonLog.WriteLog("SQL実行エラー", EventLogEntryType.Error)
            CommonLog.WriteLog(stbSQL.ToString, EventLogEntryType.Error)
            Throw ex
        End Try
    End Sub
#End Region

End Class
