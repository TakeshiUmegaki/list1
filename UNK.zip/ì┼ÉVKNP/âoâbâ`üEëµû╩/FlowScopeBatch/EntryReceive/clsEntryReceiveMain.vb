﻿Imports CommonSystem
Imports CommonBase
Imports System
Imports System.IO
Imports System.Text
Imports Oracle.DataAccess.Client

Public Class clsReceiveEntry
    Inherits clsBatchBase

#Region "共通変数"

    ''' <summary>
    ''' 自端末処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Shared mainProc As clsReceiveEntry

#End Region


#Region "定数定義"
    ''' <summary>
    ''' エントリデータ格納ファイル（イメージID.txt）の拡張子
    ''' </summary>
    ''' <remarks></remarks>
    Private Const TXT_EXTENTION As String = ".txt"

    ''' <summary>
    ''' イメージ状態：不鮮明
    ''' </summary>
    ''' <remarks></remarks>
    Private Const IMAGE_JOTAI_FUSENMEI As String = "1"

    ''' <summary>
    ''' イメージ状態：保留
    ''' </summary>
    ''' <remarks></remarks>
    Private Const IMAGE_JOTAI_HORYU As String = "7"

    ''' <summary>
    ''' イメージ状態：対象外
    ''' </summary>
    ''' <remarks></remarks>
    Private Const IMAGE_JOTAI_TAISHOGAI As String = "9"


#End Region


#Region "外部定義（コンフィグ）取得用定数"

    ' *************************************
    ' DBアクセス情報関連
    ' *************************************

    ''' <summary>
    ''' T_JJ_ENT_REQ_MANAGEへのアクセスKey
    ''' </summary>
    ''' <remarks></remarks>
    Private Const CONF_ENT_REQ_MANAGE_KEY As String = "ENT_REQ_MANAGE_KEY"


    ' *************************************
    ' 取得ファイル情報関連
    ' *************************************

    ''' <summary>
    ''' 結果ファイル取得先ルートフォルダ
    ''' </summary>
    ''' <remarks></remarks>
    Private Const CONF_RECEIVE_PATH As String = "RECEIVE_PATH"

    ''' <summary>
    ''' トリガーファイル名
    ''' </summary>
    ''' <remarks></remarks>
    Private Const CONF_TRIGGER_FILE As String = "TRIGGER_FILE"

    ''' <summary>
    ''' NG結果ファイル移動先ルートフォルダ
    ''' </summary>
    ''' <remarks></remarks>
    Private Const CONF_NG_PATH As String = "NG_PATH"

    ''' <summary>
    ''' OK結果ファイル移動先ルートフォルダ
    ''' </summary>
    ''' <remarks></remarks>
    Private Const CONF_OK_PATH As String = "OK_PATH"


    ' *************************************
    ' Upload.txtファイル内の定義情報
    ' *************************************

    ''' <summary>
    ''' Upload.txt内のイメージIDの位置
    ''' </summary>
    ''' <remarks></remarks>
    Private Const CONF_UPD_IMG_ID As String = "UPD_IMG_ID"

    ''' <summary>
    ''' Upload.txt内のブロック開始位置
    ''' </summary>
    ''' <remarks></remarks>
    Private Const CONF_UPD_BLK_ST As String = "UPD_BLK_ST"

    ''' <summary>
    ''' Upload.txt内のブロック内の項目数
    ''' </summary>
    ''' <remarks></remarks>
    Private Const CONF_UPD_BLK_CT As String = "UPD_BLK_CT"

    ''' <summary>
    ''' Upload.txt内の拠点ID開始位置
    ''' </summary>
    ''' <remarks></remarks>
    Private Const CONF_UPD_POS_ID As String = "UPD_POS_ID"

    ''' <summary>
    ''' Upload.txt内の工程ID開始位置
    ''' </summary>
    ''' <remarks></remarks>
    Private Const CONF_UPD_PRJ_ID As String = "UPD_PRJ_ID"

    ''' <summary>
    ''' Upload.txt内の処理完了日時開始位置
    ''' </summary>
    ''' <remarks></remarks>
    Private Const CONF_UPD_END_DT As String = "UPD_END_DT"

    ''' <summary>
    ''' Upload.txt内のオペレータID開始位置
    ''' </summary>
    ''' <remarks></remarks>
    Private Const CONF_UPD_OPR_ID As String = "UPD_OPR_ID"



    ' *************************************
    ' イメージID.txtファイル内(ヘッダ)の位置情報
    ' *************************************

    ''' <summary>
    ''' イメージID.txtファイル内(ヘッダ)のイメージ状態の位置
    ''' </summary>
    ''' <remarks></remarks>
    Private Const CONF_ENT_IMG_JT As String = "ENT_IMG_JT"
    ''' <summary>
    ''' イメージID.txtファイル内(ヘッダ)のイメージ状態不備フラグの位置
    ''' </summary>
    ''' <remarks></remarks>
    Private Const CONF_ENT_IMG_JT_DEF As String = "ENT_IMG_JT_DEF"



    ' *************************************
    ' T_RECEIPT_MNGの状態
    ' *************************************

    ''' <summary>
    ''' 結果ファイル取得可能なイメージ状態
    ''' </summary>
    ''' <remarks></remarks>
    Private Const CONF_INPUT_STATUS As String = "INPUT_STATUS"

    ''' <summary>
    ''' 正常イメージ状態
    ''' </summary>
    ''' <remarks></remarks>
    Private Const CONF_OUTPUT_STATUS As String = "OUTPUT_STATUS_T"

#End Region

#Region "列挙体"

    ' 本クラスで利用する列挙体を記述します。

    ''' <summary>
    ''' エントリ結果の詳細値
    ''' </summary>
    ''' <remarks></remarks>
    Private Enum enmEntryResults
        OK = 0          ' 正常データ
        FUSENMEI        ' 画像不鮮明
        HORYU           ' 保留対象画像
        TAISHOGAI       ' 対象外画像
        UNKNOWN_ERROR   ' 不明なエラー
    End Enum

#End Region

#Region "内部変数定義"

    ''' <summary>
    ''' 取得可能状態の案件データの工程記憶領域
    ''' </summary>
    ''' <remarks></remarks>
    Private mhshStatus As New Hashtable

    ''' <summary>
    ''' 受信フォルダの名前の年月日時分＋"00"
    ''' </summary>
    ''' <remarks></remarks>
    Private mstrFolderDateTime As String = String.Empty


    ' ********************************************
    ' Upload.txtファイル内の項目位置 格納用変数
    ' ********************************************

    ''' <summary>
    ''' Upload.txtファイル内のイメージIDの位置
    ''' </summary>
    ''' <remarks></remarks>
    Private mintUPD_IMG_ID As Integer = -1

    ''' <summary>
    ''' Upload.txt内のブロック開始位置
    ''' </summary>
    ''' <remarks></remarks>
    Private mintUPD_BLK_ST As Integer = -1

    ''' <summary>
    ''' Upload.txt内のブロック内の項目数
    ''' </summary>
    ''' <remarks></remarks>
    Private mintUPD_BLK_CT As Integer = -1

    ''' <summary>
    ''' Upload.txt内の拠点ID開始位置
    ''' </summary>
    ''' <remarks></remarks>
    Private mintUPD_POS_ID As Integer = -1

    ''' <summary>
    ''' Upload.txt内の工程ID開始位置
    ''' </summary>
    ''' <remarks></remarks>
    Private mintUPD_PRJ_ID As Integer = -1

    ''' <summary>
    ''' Upload.txt内の処理完了日時開始位置
    ''' </summary>
    ''' <remarks></remarks>
    Private mintUPD_END_DT As Integer = -1

    ''' <summary>
    ''' Upload.txt内のオペレータID開始位置
    ''' </summary>
    ''' <remarks></remarks>
    Private mintUPD_OPR_ID As Integer = -1



    ' ********************************************
    ' イメージID.txtファイル内(ヘッダ)の項目位置 格納用変数
    ' ********************************************

    ''' <summary>
    ''' イメージID.txtファイル内(ヘッダ)のイメージ状態の位置
    ''' </summary>
    ''' <remarks></remarks>
    Private mintENT_IMG_JT As Integer = -1
    ''' <summary>
    ''' イメージID.txtファイル内(ヘッダ)のイメージ状態不備フラグの位置
    ''' </summary>
    ''' <remarks></remarks>
    Private mintENT_IMG_JT_DEF As Integer = -1



    ''' <summary>
    ''' イメージ不備フラグとイメージステータスの対応辞書
    ''' </summary>
    ''' <remarks></remarks>
    Private mdicImageDef As New Dictionary(Of String, String)
    Private mdicImageDefH As New Dictionary(Of String, String)

    ''' <summary>
    ''' 定型帳票ID辞書
    ''' </summary>
    ''' <remarks></remarks>
    Private mdicTeikei As New Dictionary(Of String, Object)

    ''' <summary>
    ''' 帳票再識別に送る場合のイメージステータス辞書
    ''' </summary>
    ''' <remarks></remarks>
    Private mdicCountUpStatus As New Dictionary(Of String, Object)

    ''' <summary>
    ''' TA帳票ID辞書
    ''' </summary>
    ''' <remarks></remarks>
    Private mdicTA As New Dictionary(Of String, Object)

#End Region

#Region "メイン処理[Main]"

    ''' ======================================================================
    ''' メソッド名：Main
    ''' <summary>
    ''' メイン処理
    ''' </summary>
    ''' <remarks></remarks>
    ''' ======================================================================
    Shared Function Main(ByVal CmdArgs() As String) As Integer

        mainProc = New clsReceiveEntry

        ' 処理の戻り値を返却
        Return mainProc.Run()

    End Function

#End Region

#Region "バッチ処理本体"
    ''' ======================================================================
    ''' メソッド名：Execute
    ''' <summary>
    ''' バッチ処理本体
    ''' </summary>
    ''' <remarks></remarks>
    ''' ======================================================================
    Protected Overrides Sub Execute()

        Try
            ' イメージ不備フラグ対応辞書を外部定義（コンフィグ）から設定します。
            For Each strKey As String In mdicConfig.Keys
                If strKey.StartsWith("IMAGE_DEFECT_") Then
                    Dim strItem() As String = Split(mdicConfig(strKey), ",")
                    mdicImageDef.Add(strItem(0), strItem(1))
                End If
                If strKey.StartsWith("IMAGE_H_DEFECT_") Then
                    Dim strItem() As String = Split(mdicConfig(strKey), ",")
                    mdicImageDefH.Add(strItem(0), strItem(1))
                End If
            Next
            ' 帳票再識別に遷移させるイメージステータスの辞書を外部定義（コンフィグ）から作成します。
            Dim strCUpStat As String = mdicConfig("COUNT_UP_STATUS")
            Dim strCS() As String = Split(strCUpStat, ",")
            For Each s As String In strCS
                mdicCountUpStatus.Add(s, Nothing)
            Next

            ' 定型帳票IDの辞書を作成
            For Each s As String In Split(mdicConfig("TEIKEI_SLIP"), ",")
                mdicTeikei.Add(s, Nothing)
            Next

            ' TA帳票IDの辞書を作成
            For Each s As String In Split(mdicConfig("TA_SLIP"), ",")
                mdicTA.Add(s, Nothing)
            Next

            ' 外部定義（コンフィグ）から定義内容を取得します。
            Dim strNGRootFolder As String = mdicConfig(CONF_NG_PATH) 'NGフォルダ移動先ルートフォルダ
            Dim strOKRootFolder As String = mdicConfig(CONF_OK_PATH) 'OKフォルダ移動先ルートフォルダ

            ' 外部定義（コンフィグ）から結果ファイル内の項目位置を取得します。
            Call SetEntryDataPosition()

            ' 外部定義（コンフィグ）から取得可能なイメージ状態のリストを作成します。
            Call MakeStatusList()

            ' 取得対象データの存在するフォルダのリストを取得します。
            Dim strFolders As List(Of String) = GetTargetFolders()

            ' リストにあるフォルダを一つずつ処理します。
            For Each strFolder As String In strFolders

                ' DBトランザクションを開始します。
                MyBase.mobjCommonDB.DB_Transaction()

                Try

                    ' 受信した結果ファイルの格納されているフォルダ名を取得しておきます。（処理後の移動or削除のため）
                    Dim strFolderName As String = Path.GetFileName(strFolder)

                    ' フォルダ名の先頭１４桁（YYYYMMDDHHMMSS）を記憶します。（イメージ更新時に利用します）
                    mstrFolderDateTime = strFolderName.Substring(0, 14)


                    ' *************************************************************************
                    ' エントリ結果ファイルをDBに登録します。（戻り値は登録したイメージ数です。）
                    ' *************************************************************************
                    Dim intImageCount As Integer = Receive(strFolder)


                    If intImageCount < 0 Then

                        ' 処理対象のフォルダをNGフォルダ内に移動します。
                        Dim strNGFolder As String = Path.Combine(strNGRootFolder, strFolderName)
                        Directory.Move(strFolder, strNGFolder)

                        ' 登録イメージ数がゼロ未満ならトランザクションを巻き戻します。
                        MyBase.mobjCommonDB.DB_Rollback()

                    Else

                        If strOKRootFolder.Trim.Equals(String.Empty) Then

                            ' 外部定義（コンフィグ）にOKフォルダの移動先が定義されていない場合はOKフォルダを削除します。
                            Directory.Delete(strFolder, True)

                        Else

                            ' 処理対象のフォルダをOKフォルダ内に移動します。
                            Dim strOKFolder As String = Path.Combine(strOKRootFolder, strFolderName.Substring(0, 10))
                            If Not Directory.Exists(strOKFolder) Then
                                Directory.CreateDirectory(strOKFolder)
                            End If
                            strOKFolder = Path.Combine(strOKFolder, strFolderName)
                            'Directory.Move(strFolder, strOKFolder)
                            CommonFunctions.CopyDirectory(strFolder, strOKFolder)
                            Directory.Delete(strFolder, True)

                        End If

                        ' トランザクションを完了します。
                        MyBase.mobjCommonDB.DB_Commit()

                    End If

                Catch ex As Exception

                    ' トランザクションを巻き戻します。
                    MyBase.mobjCommonDB.DB_Rollback()
                    CommonLog.WriteLog("エラーを検知したためDBトランザクションを破棄しました。", EventLogEntryType.Error)
                    CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
                    CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)

                    ' エラー検知時の処理対象フォルダーがまだ存在するかチェックします。
                    If Directory.Exists(strFolder) Then
                        ' 処理対象のフォルダをNGフォルダ内に移動します。
                        Dim strFolderName As String = Path.GetFileName(strFolder)
                        Dim strNGFolder As String = Path.Combine(strNGRootFolder, strFolderName)
                        'Directory.Move(strFolder, strNGFolder)
                        CommonFunctions.CopyDirectory(strFolder, strNGFolder)
                        Directory.Delete(strFolder)
                        CommonLog.WriteLog("処理中だったファイルは[" & strNGFolder & "]に移動されました。", EventLogEntryType.Error)
                    End If

                    Throw New Exception("エントリ結果取得中にエラーを検出しました。")

                End Try
            Next

        Catch ex As Exception

            MyBase.WriteLog(ex.ToString, EventLogEntryType.Error)

        Finally

        End Try

    End Sub
#End Region

#Region "結果ファイル内の項目位置情報を取得"
    ''' ======================================================================
    ''' メソッド名：SetEntryDataPosition
    ''' <summary>
    ''' 結果ファイル内の項目位置情報を取得
    ''' </summary>
    ''' <remarks></remarks>
    ''' ======================================================================
    Private Sub SetEntryDataPosition()

        '* Upload.txt　データレコード

        ' Upload.txtファイル内のイメージIDの位置
        mintUPD_IMG_ID = Convert.ToInt32(mdicConfig(CONF_UPD_IMG_ID))

        ' Upload.txt内のブロック開始位置
        mintUPD_BLK_ST = Convert.ToInt32(mdicConfig(CONF_UPD_BLK_ST))

        ' Upload.txt内のブロック内の項目数
        mintUPD_BLK_CT = Convert.ToInt32(mdicConfig(CONF_UPD_BLK_CT))

        ' Upload.txt内の拠点ID開始位置
        mintUPD_POS_ID = Convert.ToInt32(mdicConfig(CONF_UPD_POS_ID))

        ' Upload.txt内の工程ID開始位置
        mintUPD_PRJ_ID = Convert.ToInt32(mdicConfig(CONF_UPD_PRJ_ID))

        ' Upload.txt内の処理完了日時開始位置
        mintUPD_END_DT = Convert.ToInt32(mdicConfig(CONF_UPD_END_DT))

        ' Upload.txt内のオペレータID開始位置
        mintUPD_OPR_ID = Convert.ToInt32(mdicConfig(CONF_UPD_OPR_ID))


        '* イメージID.txt ヘッダレコード

        ' イメージID.txtファイル内(ヘッダ)のイメージ状態の位置
        mintENT_IMG_JT = Convert.ToInt32(mdicConfig(CONF_ENT_IMG_JT))

        ' イメージID.txtファイル内(ヘッダ)のイメージ状態不備フラグの位置
        mintENT_IMG_JT_DEF = Convert.ToInt32(mdicConfig(CONF_ENT_IMG_JT_DEF))




    End Sub
#End Region

#Region "取得可能ステータスリスト作成"
    ''' ======================================================================
    ''' メソッド名：MakeStatusList
    ''' <summary>
    ''' 取得可能ステータスリスト作成
    ''' </summary>
    ''' <remarks></remarks>
    ''' ======================================================================
    Private Sub MakeStatusList()

        ' 外部定義（コンフィグ）からステータス定義（カンマ区切り）を取得します。
        Dim strConfig As String = MyBase.mdicConfig(CONF_INPUT_STATUS)

        ' カンマで分割して個別のステータスにします。
        Dim strStatus() As String = Split(strConfig, ","c)

        'ステータスのリスト（ハッシュ）をクリアして分割した各ステータスを登録します。
        mhshStatus.Clear()
        For intIndex As Integer = 0 To strStatus.Length - 1 Step 1
            mhshStatus.Add(strStatus(intIndex), intIndex)
        Next

    End Sub
#End Region

#Region "処理対象フォルダのリスト作成"
    ''' ======================================================================
    ''' メソッド名：GetTargetFolders
    ''' <summary>
    ''' 処理対象フォルダのリスト作成
    ''' </summary>
    ''' <returns>作成したヘ処理対象フォルダのリスト</returns>
    ''' <remarks></remarks>
    ''' ======================================================================
    Private Function GetTargetFolders() As List(Of String)

        ' 外部定義（コンフィグ）から定義内容を取得します。
        Dim strRootFolder As String = mdicConfig(CONF_RECEIVE_PATH) 'ルートフォルダ
        Dim strTrigger As String = mdicConfig(CONF_TRIGGER_FILE)    'トリガーファイルの名前

        Dim FolderList As New List(Of String)

        ' ルートフォルダの直下にあるフォルダ名を全て取得します。
        Dim strFolders() As String = Directory.GetDirectories(strRootFolder)

        ' 取得したフォルダ名を一つずつ精査します。
        For Each strFolder As String In strFolders

            ' トリガーファイルPathを作成します。
            Dim strTRG As String = Path.Combine(strFolder, strTrigger)

            ' 取得したフォルダ内にトリガーファイルが存在する場合に
            ' そのフォルダを処理対象フォルダのリストに追加します。
            If File.Exists(strTRG) Then
                FolderList.Add(strFolder)
            End If

        Next

        ' 全ての処理対象フォルダがリストに登録されたらフォルダ名で整列します。
        FolderList.Sort()

        Return FolderList

    End Function
#End Region

#Region "フォルダ単位のデータ取得"
    ''' ======================================================================
    ''' メソッド名：Receive
    ''' <summary>
    ''' フォルダ単位のデータ取得
    ''' </summary>
    ''' <param name="strFolder">処理対象フォルダ</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    ''' ======================================================================
    Private Function Receive(ByVal strFolder As String) As Integer

        Dim strUpload As String = Path.Combine(strFolder, clsConst.CNST_UPLOAD_FILE)
        If Not File.Exists(strUpload) Then
            Return -1
        End If

        Dim strDlm As String = ","
        Select Case mdicConfig("DELIMITTER")
            Case "1"
                strDlm = ","
            Case "2"
                strDlm = vbTab
        End Select

        Dim intImageCount As Integer = 0
        Using sr As New StreamReader(strUpload, Encoding.GetEncoding(mdicConfig("DOWNLOAD_ENC")))

            Try

                Do While sr.Peek() >= 0

                    Dim strLine As String = sr.ReadLine()
                    Dim strItem() As String = Split(strLine, strDlm)

                    'レコード種別によって処理を分岐します。
                    Select Case strItem(0)

                        Case "1", "2", "3", "4", "9"
                            ' レコード種別が、"1", "2", "3", "4", "9"の場合は処理はありません。

                        Case "5"
                            intImageCount += 1
                            Dim strImageId As String = strItem(mintUPD_IMG_ID)
                            Dim strReceiptNo As String = String.Empty
                            Dim strSlipID As String = String.Empty
                            Dim strExImg1 As String = String.Empty
                            Dim strExImg9 As String = String.Empty
                            Dim strNohinDate As String = String.Empty
                            If Not ImageCheck(strFolder, strImageId, strReceiptNo, strSlipID, strExImg1, strExImg9, strNohinDate) Then
                                CommonLog.WriteLog("対象ディレクトリ:" & strFolder, EventLogEntryType.Error)
                                Return -1
                            End If

                            ' エントリーデータのDB登録
                            Dim strStatus As String = String.Empty
                            Dim strJtai As String = String.Empty
                            Dim strJtaiFubi As String = String.Empty
                            Dim enmResult As enmEntryResults = enmEntryResults.OK
                            Dim intEntryCount As Integer = InsertEntryData(strFolder, _
                                                                           strImageId, _
                                                                           strSlipID, _
                                                                           strStatus, _
                                                                           strJtai, _
                                                                           strJtaiFubi, _
                                                                           enmResult)

                            ' 処理不能データの場合は処理を中断します。
                            If enmResult = enmEntryResults.UNKNOWN_ERROR Then
                                Return -1
                            End If

                            ' イメージデータの更新
                            Call UpdateImageData(strItem, _
                                                 strStatus, _
                                                 strJtai, _
                                                 strExImg1, _
                                                 strExImg9, _
                                                 strNohinDate)

                            ' イメージ状態履歴の登録
                            Call InsertHistory(strImageId, strStatus)

                            ' オペレータ履歴の登録
                            Call InsertEntryHistory(strItem)

                        Case Else
                            MyBase.WriteLog("Upload.txtの内容が不正です。", EventLogEntryType.Error)
                            CommonLog.WriteLog("対象ディレクトリ:" & strFolder, EventLogEntryType.Error)
                            Return -1

                    End Select

                Loop

            Catch ex As Exception

                MyBase.WriteLog("処理不能なエラーを検知しました。", EventLogEntryType.Error)
                CommonLog.WriteLog(ex.ToString, EventLogEntryType.Error)
                Return -1

            End Try

        End Using

        ' 依頼中件数を減算します。
        Call UpdateEntReqManage(intImageCount)

        Return intImageCount

    End Function
#End Region

#Region "イメージ状態チェック"
    ''' ======================================================================
    ''' メソッド名：ImageCheck
    ''' <summary>
    ''' イメージ状態チェック
    ''' </summary>
    ''' <param name="strFolder">処理対象フォルダ</param>
    ''' <param name="strImageId">イメージID</param>
    ''' <returns>True：処理可能　False：処理不能</returns>
    ''' <remarks>イメージIDからDBを検索て結果受信可能な状態であればイメージ区分と処理区分を取得します。</remarks>
    ''' ======================================================================
    Private Function ImageCheck(ByVal strFolder As String, _
                                ByVal strImageId As String, _
                                ByRef strReceiptNo As String, _
                                ByRef strSlipID As String, _
                                ByRef strExImg1 As String, _
                                ByRef strExImg9 As String, _
                                ByRef strNohinDate As String) As Boolean

        ' イメージID.txtの存在チェック
        Dim strImageTxt As String = Path.Combine(strFolder, strImageId & TXT_EXTENTION)
        If Not File.Exists(strImageTxt) Then
            MyBase.WriteLog("Upload.txt内にあるイメージIDに対応するイメージID.txtが存在しません。", EventLogEntryType.Error)
            CommonLog.WriteLog("イメージID:" & strImageId, EventLogEntryType.Error)
            Return False
        End If

        ' イメージIDからイメージ情報を取得します。
        Dim dtbImage As DataTable = GetImageInfo(strImageId)
        ' イメージ情報が取得できない場合はエラーです。
        If dtbImage Is Nothing OrElse dtbImage.Rows.Count <> 1 Then
            MyBase.WriteLog("Upload.txt内にあるイメージIDがDBに存在しません。", EventLogEntryType.Error)
            CommonLog.WriteLog("イメージID:" & strImageId, EventLogEntryType.Error)
            Return False
        End If

        ' 案件状態を取得します。
        Dim strStatus As String = Convert.ToString(dtbImage.Rows(0).Item("IMAGE_STATUS"))
        ' 取得した案件状態が結果受信可能な状態でなければエラーです。
        ' （結果受信可能な状態であるかは外部定義（コンフィグ）からハッシュに取得されています。
        If Not mhshStatus.ContainsKey(strStatus) Then
            MyBase.WriteLog("Upload.txt内にあるイメージIDが結果受信不可能なSTATUSです。", EventLogEntryType.Error)
            CommonLog.WriteLog("イメージID:" & strImageId, EventLogEntryType.Error)
            CommonLog.WriteLog("STATUS:" & strStatus, EventLogEntryType.Error)
            Return False
        End If

        strReceiptNo = Convert.ToString(dtbImage.Rows(0).Item("RECEIPT_ID"))
        strSlipID = Convert.ToString(dtbImage.Rows(0).Item("SLIP_DEFINE_ID"))
        strExImg1 = Convert.ToString(dtbImage.Rows(0).Item("DEF_REV_COUNT"))
        strExImg9 = Convert.ToString(dtbImage.Rows(0).Item("EXC_IMAGE_KEY09"))

        'Dim stbSQL As New StringBuilder("SELECT DELIVERY_PLAN_TIME FROM T_JJ_RECEIPT WHERE DELETE_FLG = '0' AND RECEIPT_ID = %ID%")
        'stbSQL.Replace("%ID%", strReceiptNo)
        'Dim dt As DataTable = mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)
        'strNohinDate = Convert.ToString(dt.Rows(0).Item(0))

        Return True

    End Function
#End Region

#Region "イメージ情報の取得"
    ''' ======================================================================
    ''' メソッド名：GetImageInfo
    ''' <summary>
    ''' イメージ情報の取得
    ''' </summary>
    ''' <param name="strImageId">イメージID</param>
    ''' <returns>取得したイメージ情報</returns>
    ''' <remarks></remarks>
    ''' ======================================================================
    Private Function GetImageInfo(ByVal strImageId As String) As DataTable

        Dim stbSQL As New StringBuilder(String.Empty)
        stbSQL.AppendLine("SELECT")
        stbSQL.AppendLine("     M.RECEIPT_ID     ")
        stbSQL.AppendLine("    ,I.IMAGE_ID       ")
        stbSQL.AppendLine("    ,I.SLIP_DEFINE_ID")
        stbSQL.AppendLine("    ,I.IMAGE_STATUS   ")
        stbSQL.AppendLine("    ,I.IMAGE_FILE_NAME")
        stbSQL.AppendLine("    ,I.IMAGE_FILE_PATH")
        stbSQL.AppendLine("    ,I.EXC_IMAGE_KEY01")
        stbSQL.AppendLine("    ,I.DEF_REV_COUNT")
        stbSQL.AppendLine("    ,I.EXC_IMAGE_KEY09")
        stbSQL.AppendLine("FROM")
        stbSQL.AppendLine("    T_JJ_IMAGE I")
        stbSQL.AppendLine("    INNER JOIN")
        stbSQL.AppendLine("        T_JJ_RECEIPT M")
        stbSQL.AppendLine("    ON")
        stbSQL.AppendLine("        M.DELETE_FLG = '0'")
        stbSQL.AppendLine("        AND")
        stbSQL.AppendLine("        M.RECEIPT_ID = I.RECEIPT_ID")
        stbSQL.AppendLine("WHERE")
        stbSQL.AppendLine("    I.DELETE_FLG   = '0'")
        stbSQL.AppendLine("    AND")
        stbSQL.AppendLine("    I.IMAGE_ID  = '%IMAGE_ID%'")
        stbSQL.Replace("%IMAGE_ID%", strImageId)

        Return MyBase.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)

    End Function
#End Region

#Region "エントリデータをDBへ投入"
    ''' ======================================================================
    ''' メソッド名：InsertEntryData
    ''' <summary>
    ''' エントリデータをDBへ投入
    ''' </summary>
    ''' <param name="strFolder">処理対象フォルダ</param>
    ''' <param name="strImageId">イメージID</param>
    ''' <param name="strJtai">イメージ状態</param>
    ''' <param name="strJtaiFubi">イメージ状態不備フラグ</param>
    ''' <param name="strStatus">状態</param>
    ''' <param name="enmResult">エントリ結果の詳細</param>
    ''' <returns>エントリ行数</returns>
    ''' <remarks></remarks>
    ''' ======================================================================
    Private Function InsertEntryData(ByVal strFolder As String, _
                                     ByVal strImageId As String, _
                                     ByVal strSlipID As String, _
                                     ByRef strStatus As String, _
                                     ByRef strJtai As String, _
                                     ByRef strJtaiFubi As String, _
                                     ByRef enmResult As enmEntryResults) As Integer

        Dim strDlm As String = ","
        Select Case mdicConfig("DELIMITTER")
            Case "1"
                strDlm = ","
            Case "2"
                strDlm = vbTab
        End Select

        ' エントリ結果ファイル（イメージID.txt）を開きます。
        Dim strImageTxt As String = Path.Combine(strFolder, strImageId & TXT_EXTENTION)
        Using sr As New StreamReader(strImageTxt, Encoding.GetEncoding(mdicConfig("IMAGEID_ENC")))

            ' ヘッダレコードを読み込んで必要な情報を取得します。
            Dim strLineHed As String = sr.ReadLine
            Dim strItemHed() As String = Split(strLineHed, strDlm)
            ' DBに登録するイメージ状態フラグの作成
            strJtai = strItemHed(mintENT_IMG_JT)    ' イメージ状態
            If strJtai.Trim.Length = 0 Then
                strJtai = "0"
            End If
            strJtaiFubi = String.Empty              ' イメージ状態不備フラグ(未使用なのでEmpty設定）

            Dim blnEntry As Boolean = IsEntry(strSlipID, strJtai, strStatus, enmResult)
            Select Case enmResult
                Case enmEntryResults.UNKNOWN_ERROR
                    MyBase.WriteLog("イメージID.txt 内に不正なデータがあります。", EventLogEntryType.Error)
                    CommonLog.WriteLog("イメージID:" & strImageId, EventLogEntryType.Error)
                    CommonLog.WriteLog("対象ディレクトリ:" & strFolder, EventLogEntryType.Error)
                    Return 0
            End Select

            ' エントリ結果のDB登録が不要な場合はここで正常終了させます。
            If Not blnEntry Then
                Return 1
            End If

            ' データレコード登録
            If sr.EndOfStream Then
                ' イメージID｡txt内に２行目（エントリ結果）が無い場合は空のエントリ結果として
                ' DBに登録します。

                ' エントリバック項目数（不備フラグ以外
                Dim intItems As Integer = Convert.ToInt32(Me.mdicConfig("ENTRY_ITEMS"))
                intItems = ((intItems * 2) - 1) + 2
                Dim strItemDat(intItems) As String
                For i As Integer = 0 To strItemDat.Length - 1 Step 1
                    strItemDat(i) = String.Empty
                Next

                ' DBに登録します。
                Call InsertEntryDataExec(strImageId, strItemDat, "T_JJ_ENTRY")
                Call InsertEntryDataExec(strImageId, strItemDat, "T_JJ_ENTRY_CORRECTION")

            Else
                'データレコードを１件読みます。
                Dim strLineDat As String = sr.ReadLine

                ' データレコードの内容をカンマで分割します。
                Dim strItemDat() As String = Split(strLineDat, strDlm)

                ' DBに登録します。
                Call InsertEntryDataExec(strImageId, strItemDat, "T_JJ_ENTRY")
                Call InsertEntryDataExec(strImageId, strItemDat, "T_JJ_ENTRY_CORRECTION")

                If mdicTeikei.ContainsKey(strSlipID) Then
                    ' 定型帳票
                    ' エントリ結果に不備がありイメージ不備でない場合はエントリ不備ステータスを設定します。
                    If strStatus.Equals(mdicConfig("OUTPUT_STATUS_T")) Then
                        For i As Integer = 3 To strItemDat.Length - 1 Step 2
                            If Not strItemDat(i).Equals(String.Empty) AndAlso _
                               Not strItemDat(i).Equals("00") Then

                                strStatus = mdicConfig("OUTPUT_STATUS_T_ERROR")
                                Exit For
                            End If
                        Next
                    End If
                ElseIf mdicTA.ContainsKey(strSlipID) Then
                    ' TA帳票
                    ' エントリ結果に不備がありイメージ不備でない場合はエントリ不備ステータスを設定します。
                    If strStatus.Equals(mdicConfig("OUTPUT_STATUS_TA")) Then
                        For i As Integer = 3 To strItemDat.Length - 1 Step 2
                            If Not strItemDat(i).Equals(String.Empty) AndAlso _
                               Not strItemDat(i).Equals("00") Then

                                strStatus = mdicConfig("OUTPUT_STATUS_TA_ERROR")
                                Exit For
                            End If
                        Next
                    End If

                Else
                    ' 非定型帳票
                    ' エントリ結果に不備がありイメージ不備でない場合はエントリ不備ステータスを設定します。
                    If strStatus.Equals(mdicConfig("OUTPUT_STATUS_H")) Then
                        For i As Integer = 3 To strItemDat.Length - 1 Step 2
                            If Not strItemDat(i).Equals(String.Empty) AndAlso _
                               Not strItemDat(i).Equals("00") Then

                                strStatus = mdicConfig("OUTPUT_STATUS_H_ERROR")
                                Exit For
                            End If
                        Next
                    End If
                End If

            End If

        End Using

        Return 1

    End Function
#End Region

#Region "エントリデータ登録可否判定"
    ''' ======================================================================
    ''' メソッド名：ImageCheck
    ''' <summary>
    ''' イメージ状態チェック
    ''' </summary>
    ''' <param name="strJtai">イメージ状態フラグ</param>
    ''' <param name="strStatus">T_JJ_IMAGEの状態</param>
    ''' <param name="enmResult">判定結果の詳細</param>
    ''' <returns>True：エントリ内容を登録する　False：エントリ内容を登録しない</returns>
    ''' <remarks></remarks>
    ''' ======================================================================
    Private Function IsEntry(ByVal strSlipID As String, _
                             ByRef strJtai As String, _
                             ByRef strStatus As String, _
                             ByRef enmResult As enmEntryResults) As Boolean

        ' エントリ結果DB登録許可フラグ
        Dim blnEntry As Boolean = True

        If mdicTeikei.ContainsKey(strSlipID) Then
            ' 定型帳票
            ' 外部定義に指定されているイメージ不備フラグなら指定されたイメージステータスにします。
            If mdicImageDef.ContainsKey(strJtai) Then
                strStatus = mdicImageDef(strJtai)
            Else
                strStatus = mdicConfig("OUTPUT_STATUS_T")
            End If
        ElseIf mdicTA.ContainsKey(strSlipID) Then
            ' TA帳票
            ' 外部定義に指定されているイメージ不備フラグなら指定されたイメージステータスにします。
            If mdicImageDef.ContainsKey(strJtai) Then
                strStatus = mdicImageDef(strJtai)
            Else
                strStatus = mdicConfig("OUTPUT_STATUS_TA")
            End If
        Else
            ' 非定型帳票
            ' 外部定義に指定されているイメージ不備フラグなら指定されたイメージステータスにします。
            If mdicImageDefH.ContainsKey(strJtai) Then
                strStatus = mdicImageDefH(strJtai)
            Else
                strStatus = mdicConfig("OUTPUT_STATUS_H")
            End If
        End If
        enmResult = enmEntryResults.OK
        ' strJtai = "0"

        Return blnEntry

    End Function
#End Region

#Region "T_ENTRY_RESULTの登録"
    ''' ======================================================================
    ''' メソッド名：InsertEntryDataExec
    ''' <summary>
    ''' T_ENTRY_RESULTへの登録
    ''' </summary>
    ''' <param name="strImageId">イメージID</param>
    ''' <param name="strItemDat">イメージID.txtのデータレコードをカンマで分割した情報</param>
    ''' <param name="strTable">登録対象テーブル名</param>
    ''' <remarks>イメージIDからDBを検索て結果受信可能な状態であればイメージ区分を取得します。</remarks>
    ''' ======================================================================
    Private Sub InsertEntryDataExec(ByVal strImageId As String, ByVal strItemDat() As String, ByVal strTable As String)

        Try
            ' 登録するk項目数はエントリした用紙の表裏で異なります。
            Dim intColumns As Integer = Convert.ToInt32(Me.mdicConfig("ENTRY_ITEMS"))

            ' 既にエントリ結果が存在するかをチェックします。（再エントリ対応）
            Dim strSelect As String = "SELECT * FROM " & strTable & " WHERE IMAGE_ID = " & strImageId
            Dim dtbSelect As DataTable = mobjCommonDB.DB_ExecuteQuery(strSelect)
            If Not dtbSelect Is Nothing AndAlso dtbSelect.Rows.Count > 0 Then
                ' 既にエントリ結果がある場合
                If strTable.Equals("T_JJ_ENTRY") Then
                    ' 登録先テーブルがT_JJ_ENTRYのときは登録しません。（最初の結果を残す）
                    Return
                End If
                ' 既存のエントリ結果を削除します。
                Dim strDelete As String = "DELETE FROM " & strTable & " WHERE IMAGE_ID = " & strImageId
                mobjCommonDB.DB_ExecuteNonQuery(strDelete)
            End If

            Dim stbSQL As New StringBuilder(String.Empty)
            stbSQL.AppendLine("INSERT INTO " & strTable & " (")
            stbSQL.AppendLine("     IMAGE_ID")
            stbSQL.AppendLine("    ,CREATE_DATE")
            stbSQL.AppendLine("    ,CREATE_USER")
            stbSQL.AppendLine("    ,UPDATE_DATE")
            stbSQL.AppendLine("    ,UPDATE_USER")
            For i As Integer = 1 To intColumns Step 1
                stbSQL.AppendLine("    ,ITEM_" & i.ToString("000"))
                stbSQL.AppendLine("    ,ITEM_" & i.ToString("000") & "_DEF")
            Next

            stbSQL.AppendLine(") VALUES (")
            stbSQL.AppendLine("     " & strImageId)
            stbSQL.AppendLine("    ,SYSDATE")
            stbSQL.AppendLine("    ,'EntryReceive'")
            stbSQL.AppendLine("    ,SYSDATE")
            stbSQL.AppendLine("    ,'EntryReceive'")

            ' イメージID.txt内のデータレコードの先頭２項目は制御情報なので実際のエントリ結果は
            ' ３項目（配列の要素番号の２番目）から始まります。
            Dim intItemCount As Integer = 2
            For j As Integer = 1 To intColumns Step 1
                stbSQL.AppendLine("    ,'" & strItemDat(intItemCount).Replace("'", "''") & "'")
                intItemCount += 1
                stbSQL.AppendLine("    ,'" & strItemDat(intItemCount).Trim.PadLeft(2, "0"c) & "'")
                intItemCount += 1
            Next

            stbSQL.AppendLine(")")

            Dim intInsertRet As Integer = MyBase.mobjCommonDB.DB_ExecuteNonQuery(stbSQL.ToString)
            If Not intInsertRet = 1 Then
                Throw New Exception("エントリー結果の登録に失敗しました。")
            End If

        Catch ex As Exception

            CommonLog.WriteLog(MyBase.mobjCommonDB.GetInfoMessage, EventLogEntryType.Error)
            Throw ex

        End Try

    End Sub
#End Region

#Region "T_JJ_IMAGEの更新"
    ''' ======================================================================
    ''' メソッド名：UpdateImageData
    ''' <summary>
    ''' T_JJ_IMAGEの更新
    ''' </summary>
    ''' <param name="strItem">Upload.txtのデータレコードをカンマで分解して情報</param>
    ''' <param name="strJtai">イメージ状態</param>
    ''' <remarks></remarks>
    ''' ======================================================================
    Private Sub UpdateImageData(ByVal strItem() As String, _
                                ByVal strStatus As String, _
                                ByVal strJtai As String, _
                                ByVal strExImg1 As String, _
                                ByVal strExImg9 As String, _
                                ByVal strNohinDate As String)

        Try
            ' 新しい納品予定日時
            'Dim strExtendDate As String = strNohinDate

            ' 遷移先が帳票再識別ならExcImageKey01をカウントアップ
            ' 同時に納品予定日時を延長します。
            If mdicCountUpStatus.ContainsKey(strStatus) Then
                Dim intEx As Integer = Convert.ToInt32(strExImg1)
                intEx += 1
                strExImg1 = intEx.ToString
                'strExtendDate = DeliveryPlanDate(strNohinDate)
            End If

            ' T_RECEIPT_IMAGE更新用SQLを作成します。
            Dim stbUpdateSQL As New StringBuilder(String.Empty)
            stbUpdateSQL.AppendLine("UPDATE")
            stbUpdateSQL.AppendLine("    T_JJ_IMAGE")
            stbUpdateSQL.AppendLine("SET")
            stbUpdateSQL.AppendLine("     IMAGE_STATUS    = '__IMAGE_STATUS__'")
            stbUpdateSQL.AppendLine("    ,IMAGE_STATE_FLG = '__IMAGE_STATE_FLG__'")
            stbUpdateSQL.AppendLine("    ,ENTRY_DATE      = TO_DATE('__ENTRY_RES_DATE__','YYYYMMDDHH24MISS')")
            stbUpdateSQL.AppendLine("    ,DEF_REV_COUNT = __EXC_IMAGE_KEY01__")
            'stbUpdateSQL.AppendLine("    ,DELIVERY_PLAN_TIME = '__DELIVERY_PLAN_TIME__'")
            stbUpdateSQL.AppendLine("    ,UPDATE_USER     = 'EntryReceive'")
            stbUpdateSQL.AppendLine("    ,UPDATE_DATE     = SYSDATE")

            If Not strJtai.Equals("0") Then
                stbUpdateSQL.AppendLine("    ,PRIORITY     = '__PRIORITY__'")
                stbUpdateSQL.Replace("__PRIORITY__", mdicConfig("IMAGE_FUBI_PRIORITY"))
            End If
            If Not strStatus.Equals(mdicConfig("OUTPUT_STATUS_T")) AndAlso _
               Not strStatus.Equals(mdicConfig("OUTPUT_STATUS_H")) AndAlso _
               Not strStatus.Equals(mdicConfig("OUTPUT_STATUS_TA")) AndAlso _
               strExImg9.Length > 0 Then
                stbUpdateSQL.AppendLine("    ,EXC_IMAGE_KEY09    = ''")
            End If


            stbUpdateSQL.AppendLine("WHERE")
            stbUpdateSQL.AppendLine("    IMAGE_ID = __IMAGE_ID__")

            ' 作成したSQLの設定値の部分を実際の値に置換します。
            stbUpdateSQL.Replace("__IMAGE_STATUS__", strStatus)
            stbUpdateSQL.Replace("__IMAGE_STATE_FLG__", strJtai)
            stbUpdateSQL.Replace("__EXC_IMAGE_KEY01__", strExImg1)
            'stbUpdateSQL.Replace("__DELIVERY_PLAN_TIME__", strExtendDate)
            stbUpdateSQL.Replace("__ENTRY_RES_DATE__", mstrFolderDateTime)
            stbUpdateSQL.Replace("__IMAGE_ID__", strItem(mintUPD_IMG_ID))

            ' 作成したSQLを実行してT_RECEIPT_IMAGEを更新します。
            Dim intInsertRet As Integer = MyBase.mobjCommonDB.DB_ExecuteNonQuery(stbUpdateSQL.ToString)
            If Not intInsertRet = 1 Then
                Throw New Exception("イメージデータの更新に失敗しました。")
            End If

        Catch ex As Exception

            CommonLog.WriteLog(MyBase.mobjCommonDB.GetInfoMessage, EventLogEntryType.Error)
            Throw ex

        End Try

    End Sub

#End Region


#Region "オペレータ履歴の登録"
    ''' ======================================================================
    ''' メソッド名：InsertEntryHistory
    ''' <summary>
    ''' オペレータ履歴の登録
    ''' </summary>
    ''' <param name="strItem">Upload.txtのデータレコードをカンマで分解した情報</param>
    ''' <remarks></remarks>
    ''' ======================================================================
    Private Sub InsertEntryHistory(ByVal strItem() As String)

        ' 履歴の登録対象イメージの最大ブロック番号＋１を取得します。
        Dim strImageID As String = strItem(mintUPD_IMG_ID)
        Dim stbSQL As New StringBuilder(String.Empty)
        stbSQL.AppendLine("SELECT (NVL(MAX(HISTORY_SEQ),0) + 1) AS HISTORY_SEQ")
        stbSQL.AppendLine("FROM T_JJ_ENT_HISTORY WHERE IMAGE_ID = __ID__")
        stbSQL.Replace("__ID__", strImageID)
        Dim dtbBlock As DataTable = Me.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)
        Dim intBlockNo As Integer = 1
        If Not dtbBlock Is Nothing AndAlso dtbBlock.Rows.Count = 1 Then
            intBlockNo = Convert.ToInt32(dtbBlock.Rows(0).Item("HISTORY_SEQ"))
        End If

        ' 外部定義（コンフィグ）から取得した位置情報を使って最終の拠点、工程、オペレータ、日時を取得します。
        For intIndex As Integer = mintUPD_BLK_ST To strItem.Length - 1 Step mintUPD_BLK_CT

            Dim strPos As String = strItem(intIndex + mintUPD_POS_ID)
            Dim strPrj As String = strItem(intIndex + mintUPD_PRJ_ID)
            Dim strOpr As String = strItem(intIndex + mintUPD_OPR_ID)
            Dim strDatE As String = strItem(intIndex + mintUPD_END_DT)

            If (strPos.Trim & strPrj.Trim & strOpr.Trim & strDatE.Trim).Length <> 0 Then

                ' オペレータ履歴の登録を行います。
                Call InsertOparatorHistory(strItem(mintUPD_IMG_ID), _
                                           intBlockNo, _
                                           strPos, _
                                           strPrj, _
                                           strDatE, _
                                           strOpr)
            End If

            intBlockNo += 1
        Next

    End Sub
#End Region

#Region "T_JJ_ENT_HISTORYの登録"
    ''' ======================================================================
    ''' メソッド名：InsertOparatorHistory
    ''' <summary>
    ''' T_JJ_ENT_HISTORYの登録
    ''' </summary>
    ''' <param name="strImageId">イメージID</param>
    ''' <param name="intHistSeq">履歴の</param>
    ''' <param name="strPosition">拠点</param>
    ''' <param name="strProject">工程</param>
    ''' <param name="strDate">日付</param>
    ''' <param name="strOperator">オペレータ</param>
    ''' <remarks></remarks>
    ''' ======================================================================
    Private Sub InsertOparatorHistory(ByVal strImageId As String, _
                                      ByVal intHistSeq As Integer, _
                                      ByVal strPosition As String, _
                                      ByVal strProject As String, _
                                      ByVal strDate As String, _
                                      ByVal strOperator As String)

        Try

            Dim stbInsertSQL As New System.Text.StringBuilder(String.Empty)

            ' オペレータ履歴登録用SQLを作成します。
            stbInsertSQL.AppendLine("INSERT INTO T_JJ_ENT_HISTORY (")
            stbInsertSQL.AppendLine("     IMAGE_ID")
            stbInsertSQL.AppendLine("    ,HISTORY_SEQ")
            stbInsertSQL.AppendLine("    ,LOCATION_ID")
            stbInsertSQL.AppendLine("    ,PROJECT_ID")
            stbInsertSQL.AppendLine("    ,OPERETOR_ID")
            stbInsertSQL.AppendLine("    ,END_TIME")
            stbInsertSQL.AppendLine("    ,DELETE_FLG")
            stbInsertSQL.AppendLine("    ,UPDATE_DATE")
            stbInsertSQL.AppendLine("    ,UPDATE_USER")
            stbInsertSQL.AppendLine(") VALUES (")
            stbInsertSQL.AppendLine("     :pIMAGE_ID")
            stbInsertSQL.AppendLine("    ,:pHISTORY_SEQ")
            stbInsertSQL.AppendLine("    ,:pLOCATION_ID")
            stbInsertSQL.AppendLine("    ,:pPROJECT_ID")
            stbInsertSQL.AppendLine("    ,:pOPERETOR_ID")
            stbInsertSQL.AppendLine("    ,:pEND_TIME")
            stbInsertSQL.AppendLine("    ,'0'")
            stbInsertSQL.AppendLine("    ,SYSDATE")
            stbInsertSQL.AppendLine("    ,'EntryReceive'")
            stbInsertSQL.AppendLine(")")

            ' オペレータ履歴登録用パラメータ宣言
            Dim oraInsertParam(5) As OracleParameter
            oraInsertParam(0) = New OracleParameter("pIMAGE_ID", OracleDbType.Decimal)
            oraInsertParam(1) = New OracleParameter("pHISTORY_SEQ", OracleDbType.Decimal)
            oraInsertParam(2) = New OracleParameter("pLOCATION_ID", OracleDbType.Varchar2)
            oraInsertParam(3) = New OracleParameter("pPROJECT_ID", OracleDbType.Varchar2)
            oraInsertParam(4) = New OracleParameter("pOPERETOR_ID", OracleDbType.Varchar2)
            oraInsertParam(5) = New OracleParameter("pEND_TIME", OracleDbType.Date)

            oraInsertParam(0).Value = Convert.ToInt64(strImageId)
            oraInsertParam(1).Value = intHistSeq
            oraInsertParam(2).Value = strPosition
            oraInsertParam(3).Value = strProject
            oraInsertParam(4).Value = strOperator

            If strDate.Trim.Length <> 0 Then
                Dim dteEnd As Date = Convert.ToDateTime(strDate)
                oraInsertParam(5).Value = dteEnd
            Else
                oraInsertParam(5).Value = DBNull.Value
            End If


            ' オペレータ履歴を登録します。
            Dim intInsertRet As Integer = MyBase.mobjCommonDB.DB_ExecuteNonQuery(stbInsertSQL.ToString, oraInsertParam)
            If Not intInsertRet = 1 Then
                Throw New Exception("オペレータ履歴の登録に失敗しました。")
            End If

        Catch ex As Exception

            CommonLog.WriteLog(MyBase.mobjCommonDB.GetInfoMessage, EventLogEntryType.Error)
            Throw ex

        End Try

    End Sub
#End Region

#Region "T_STATUS_HISTORYの登録"
    ''' ======================================================================
    ''' メソッド名：InsertHistory
    ''' <summary>
    ''' T_STATUS_HISTORYの登録
    ''' </summary>
    ''' <param name="strDocumentId">書類ID</param>
    ''' <remarks></remarks>
    ''' ======================================================================
    Private Sub InsertHistory(ByVal strDocumentId As String, ByVal strStatus As String)

        Try

            Dim strUpdateStatus As String = strStatus

            ' イメージ状態履歴登録用SQLを作成します。
            Dim stbInsertSQL As New System.Text.StringBuilder(String.Empty)
            stbInsertSQL.AppendLine("INSERT INTO T_JJ_IMAGE_HISTORY (")
            stbInsertSQL.AppendLine("     IMAGE_ID")
            stbInsertSQL.AppendLine("    ,IMAGE_STATUS")
            stbInsertSQL.AppendLine("    ,CREATE_DATE")
            stbInsertSQL.AppendLine("    ,CREATE_USER")
            stbInsertSQL.AppendLine(") VALUES (")
            stbInsertSQL.AppendLine("     :DocumentID")
            stbInsertSQL.AppendLine("    ,:OutStatus")
            stbInsertSQL.AppendLine("    ,SYSTIMESTAMP")
            stbInsertSQL.AppendLine("    ,'EntryReceive'")
            stbInsertSQL.AppendLine(")")

            ' イメージ状態履歴登録用パラメータ宣言
            Dim oraInsertParam(1) As OracleParameter
            oraInsertParam(0) = New OracleParameter("DocumentID", OracleDbType.Decimal)
            oraInsertParam(0).Value = Convert.ToInt64(strDocumentId)
            oraInsertParam(1) = New OracleParameter("OutStatus", OracleDbType.Char)
            oraInsertParam(1).Value = strUpdateStatus
            ' イメージ状態履歴を登録します。
            Dim intInsertRet As Integer = MyBase.mobjCommonDB.DB_ExecuteNonQuery(stbInsertSQL.ToString, oraInsertParam)
            If Not intInsertRet = 1 Then
                Throw New Exception("イメージ履歴の登録に失敗しました。")
            End If

        Catch ex As Exception

            CommonLog.WriteLog(MyBase.mobjCommonDB.GetInfoMessage, EventLogEntryType.Error)
            Throw ex

        End Try

    End Sub
#End Region

#Region "T_ENTRY_REQ_MANAGEの更新"
    ''' ======================================================================
    ''' メソッド名：UpdateEntReqManage
    ''' <summary>
    ''' 依頼件数管理情報の依頼数更新
    ''' </summary>
    ''' <param name="intEntryCount">減算するイメージ数</param>
    ''' <remarks></remarks>
    ''' ======================================================================
    Private Sub UpdateEntReqManage(ByVal intEntryCount As Integer)
        Try

            ' イメージ状態更新用SQLを作成します。
            Dim stbUpdateSQL As New System.Text.StringBuilder(String.Empty)
            stbUpdateSQL.AppendLine("UPDATE")
            stbUpdateSQL.AppendLine("  T_JJ_ENT_REQ_MANAGE")
            stbUpdateSQL.AppendLine("SET")
            stbUpdateSQL.AppendLine("  REQUEST_COUNT = REQUEST_COUNT - __COUNT__ ")
            stbUpdateSQL.AppendLine(" ,UPDATE_DATE   = SYSDATE")

            ' 作成したSQLの更新部分を置換します。
            stbUpdateSQL.Replace("__COUNT__", intEntryCount.ToString)

            ' 依頼件数管理情報の依頼数を更新します。
            Dim intUpdateRet As Integer = MyBase.mobjCommonDB.DB_ExecuteNonQuery(stbUpdateSQL.ToString)
            If Not intUpdateRet = 1 Then
                Throw New Exception("依頼件数管理情報の依頼数の更新に失敗しました。")
            End If

        Catch ex As Exception

            CommonLog.WriteLog(MyBase.mobjCommonDB.GetInfoMessage, EventLogEntryType.Error)
            Throw ex

        End Try

    End Sub
#End Region

#Region "納品予定日時の取得"
    ''' <summary>
    ''' 納品予定日時の取得
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function DeliveryPlanDate(ByVal strNohindate As String) As String
        Try
            ' 納品加算時間（分）を取得します。
            Dim intMinutes As Integer = Convert.ToInt32(mdicConfig("DELIVERY_MINUTES"))

            ' 基本の納品日時を算出します。
            Dim intYea As Integer = Convert.ToInt32(strNohindate.Substring(0, 4))
            Dim intMon As Integer = Convert.ToInt32(strNohindate.Substring(4, 2))
            Dim intDay As Integer = Convert.ToInt32(strNohindate.Substring(6, 2))
            Dim intHor As Integer = Convert.ToInt32(strNohindate.Substring(8, 2))
            Dim intMin As Integer = Convert.ToInt32(strNohindate.Substring(10, 2))
            Dim dt As New DateTime(intYea, intMon, intDay, intHor, intMin, 0)

            ' 納品開始時刻を外部定義（コンフィグ）から取得します。
            Dim strOpen() As String = Split(mdicConfig("DELIVERY_OPEN_TIME"), ":")
            Dim dtOpen As New DateTime(intYea, intMon, intDay, Convert.ToInt32(strOpen(0)), Convert.ToInt32(strOpen(1)), 0)

            ' 納品終了時刻を外部定義（コンフィグ）から取得します。
            Dim strClose() As String = Split(mdicConfig("DELIVERY_CLOSE_TIME"), ":")
            Dim dtClose As New DateTime(intYea, intMon, intDay, Convert.ToInt32(strClose(0)), Convert.ToInt32(strClose(1)), 0)

            ' 経過日数を初期化しておきます。
            Dim intDays As Integer = 0

            ' 受付時刻が納品終了時刻を超えていた場合は経過日数を１加算して
            ' 計算上の受付時刻を翌日の納品開始時刻とします。
            If dt < dtOpen Then
                dt = dtOpen
            ElseIf dt > dtClose Then
                dt = dtOpen.AddDays(1)
                dtOpen = dtOpen.AddDays(1)
                dtClose = dtClose.AddDays(1)
                intDays += 1
            End If

            ' 計算上の受付時刻に納品所要時間を加算して納品予定日時を算出します。
            Dim dtPlan As DateTime = dt.AddMinutes(Convert.ToDouble(intMinutes))

            ' 納品予定日時が納品可能時間帯に収まるまで営業日数を加算します。
            For i As Integer = 0 To Integer.MaxValue Step 1
                Dim ts As TimeSpan = dtPlan.Subtract(dtClose)
                If ts.TotalMinutes <= 0 Then
                    Exit For
                End If
                dtOpen = dtOpen.AddDays(1)
                dtClose = dtClose.AddDays(1)
                intDays += 1
                dtPlan = dtOpen + ts
            Next

            ' 納品予定の営業日を取得します。
            Dim stbSQL As New StringBuilder(String.Empty)
            stbSQL.AppendLine("SELECT")
            stbSQL.AppendLine("    YYYYMMDD")
            stbSQL.AppendLine("FROM")
            stbSQL.AppendLine("    (")
            stbSQL.AppendLine("        SELECT")
            stbSQL.AppendLine("            YYYYMMDD")
            stbSQL.AppendLine("        FROM")
            stbSQL.AppendLine("            M_CM_HOLIDAY")
            stbSQL.AppendLine("        WHERE")
            stbSQL.AppendLine("            HOLIDAY = '0'")
            stbSQL.AppendLine("            AND")
            stbSQL.AppendLine("            YYYYMMDD >= '%YMD%'")
            stbSQL.AppendLine("        ORDER BY")
            stbSQL.AppendLine("            YYYYMMDD")
            stbSQL.AppendLine("    )")
            stbSQL.AppendLine("WHERE")
            stbSQL.AppendLine("    ROWNUM <= %NUM%")
            stbSQL.AppendLine("ORDER BY")
            stbSQL.AppendLine("    YYYYMMDD")
            stbSQL.Replace("%YMD%", mstrFolderDateTime.Substring(0, 8))
            stbSQL.Replace("%NUM%", (intDays + 1).ToString)
            Dim dtbHoliday As DataTable = mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)

            ' 取得した営業日に納品予定時刻をくっつけて納品予定日時にします。
            Dim strPlanDate As String = Convert.ToString(dtbHoliday.Rows(intDays).Item("YYYYMMDD"))
            strPlanDate = strPlanDate & dtPlan.ToString("HHmm")

            ' 納品予定日時を返します。
            Return strPlanDate

        Catch ex As Exception

            MyBase.WriteLog("DeliveryPlanDateでエラーを検知しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.ToString, EventLogEntryType.Error)
            Throw ex

        End Try
    End Function
#End Region

End Class
