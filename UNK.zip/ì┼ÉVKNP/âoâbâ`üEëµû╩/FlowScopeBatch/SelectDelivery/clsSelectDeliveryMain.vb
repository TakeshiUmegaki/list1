﻿Imports CommonSystem
Imports CommonBase
Imports System
Imports System.Configuration
Imports System.IO
Imports System.Text
Imports Oracle.DataAccess.Client
Public Class clsSelectDeliveryMain
    Inherits clsBatchBase

#Region "共通変数"

    ''' <summary>
    ''' 自端末処理
    ''' 帳票出力上限数を東西４種(計８種)追加  *** [2015/06/24] 追加 ***
    ''' </summary>
    ''' <remarks></remarks>
    Private Shared mainProc As clsSelectDeliveryMain

#End Region
#Region "固有定数 app.Config取得用"
    Private Const CONF_SLIP_ID As String = "SLIP_ID"
    Private Const CONF_INPUT_STATUS As String = "INPUT_STATUS"
    Private Const CONF_PUNCH_EAST As String = "PUNCH_EAST"
    Private Const CONF_PUNCH_WEST As String = "PUNCH_WEST"
    Private Const CONF_OUTPUT_STATUS As String = "OUTPUT_STATUS"
    Private Const CONF_OUT_LIMIT_COUNT As String = "OUT_LIMIT_COUNT"
    Private Const CONF_DELIVERY_CLASS As String = "DELIVERY_CLASS"
    Private Const CONF_DELIVERY_CLASS_EW As String = "0"
    Private Const CONF_DELIVERY_CLASS_ALL As String = "1"
#End Region

#Region "メイン処理[Main]"
    ''' ======================================================================
    ''' メソッド名：Main
    ''' <summary>
    ''' メイン処理
    ''' </summary>
    ''' <remarks></remarks>
    ''' ======================================================================
    Shared Function Main(ByVal CmdArgs() As String) As Integer

        mainProc = New clsSelectDeliveryMain

        ' 処理の戻り値を返却
        Return mainProc.Run()

    End Function

#End Region
#Region "バッチ処理本体"
    ''' <summary>
    ''' バッチ処理本体
    ''' </summary>
    ''' <remarks></remarks>
    Protected Overrides Sub Execute()
        Dim ret As Integer
        Dim maxKensu As Decimal = 0
        Dim dt As DataTable
        'StrConv("ゼンカクの文字列", VbStrConv.Narrow)
        Try
            ' DBトランザクションの開始
            mobjCommonDB.DB_Transaction()
            'Add Start 2019/05/23
            dt = New DataTable
            If mdicConfig("PROC_DIV").Equals("0") Then
                dt = mobjCommonDB.DB_ExecuteQuery("select CONFIG_VALUE from M_CM_CONFIG Where CONFIG_DIV='09' And CONFIG_ID='01'")
            Else
                dt = mobjCommonDB.DB_ExecuteQuery("select CONFIG_VALUE from M_CM_CONFIG Where CONFIG_DIV='09' And CONFIG_ID='02'")
            End If
            If dt Is Nothing OrElse dt.Rows.Count = 0 Then
                If IsNumeric(StrConv(Me.mdicConfig(CONF_OUT_LIMIT_COUNT), VbStrConv.Narrow).Trim) Then
                    maxKensu = Decimal.Parse(StrConv(Me.mdicConfig(CONF_OUT_LIMIT_COUNT), VbStrConv.Narrow).Trim)
                Else
                    Throw New Exception("納品件数設定誤り。DB無し、Config無し")
                End If
            ElseIf IsNumeric(StrConv(dt.Rows(0)(0).ToString, VbStrConv.Narrow).Trim) Then
                maxKensu = Decimal.Parse(StrConv(dt.Rows(0)(0).ToString, VbStrConv.Narrow).Trim)
            ElseIf IsNumeric(StrConv(Me.mdicConfig(CONF_OUT_LIMIT_COUNT), VbStrConv.Narrow).Trim) Then
                maxKensu = Decimal.Parse(StrConv(Me.mdicConfig(CONF_OUT_LIMIT_COUNT), VbStrConv.Narrow).Trim)
            Else
                Throw New Exception("納品件数設定誤り。DB不正、Config不正")
            End If
            dt = Nothing
            'Add End 2019/05/23
            Select Case Me.mdicConfig(CONF_DELIVERY_CLASS)
                Case CONF_DELIVERY_CLASS_EW
                    ret = mobjCommonDB.DB_ExecuteNonQuery(Me.GetSelectDeliverySqlEW(maxKensu))
                Case CONF_DELIVERY_CLASS_ALL
                    ret = mobjCommonDB.DB_ExecuteNonQuery(Me.GetSelectDeliverySqlAll(maxKensu))
                Case Else
                    Throw New Exception("納品区分の設定誤り。データ未作成")
            End Select

            mobjCommonDB.DB_Commit()

        Catch ex As Exception
            Try
                ' トランザクションロールバック
                mobjCommonDB.DB_Rollback()
            Catch nfex As NullReferenceException
                CommonLog.WriteLog("ロールバック実施時のNull Reference Exceptionが発生", EventLogEntryType.Error)
                CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            End Try

            ' イベントログを出力します。
            MyBase.WriteLog("納品対象作成中にエラーを検出しました。", EventLogEntryType.Error)
            ' ログファイルにエラー内容を出力します。
            Throw ex
        Finally
            If Not IsNothing(mobjCommonDB) AndAlso Not IsDBNull(mobjCommonDB) Then
                ' データベース接続クローズ
                mobjCommonDB.DB_Close()
            End If
        End Try
    End Sub
#End Region
#Region "納品件数設定"

    Private Function GetSelectDeliverySqlEW(ByRef maxKensu As Decimal) As String
        Dim sb As New StringBuilder("")
        With sb
            sb.Append("Declare ").Append(Environment.NewLine)
            sb.Append("wk_DlvEastMax Number(10) :=0; ").Append(Environment.NewLine)
            sb.Append("wk_DlvWestMax Number(10) :=0; ").Append(Environment.NewLine)
            sb.Append("wk_DlvTtlMax Number(10) :=@KENSU@; ").Append(Environment.NewLine)
            sb.Append("wk_DlvEast Number(10) :=0; ").Append(Environment.NewLine)
            sb.Append("wk_DlvWest Number(10) :=0; ").Append(Environment.NewLine)
            sb.Append("wk_Date date := sysdate; ").Append(Environment.NewLine)
            sb.Append("wk_timestamp Timestamp := systimestamp; ").Append(Environment.NewLine)
            sb.Append("CNST_EW_EAST Varchar2(2) := '@PE@'; ").Append(Environment.NewLine)
            sb.Append("CNST_EW_WEST Varchar2(2) := '@PW@'; ").Append(Environment.NewLine)
            sb.Append("PROCEDURE DELIVARY_TARGET_UPDATE(eastwest in varchar2, limit In number) As ").Append(Environment.NewLine)
            sb.Append("Begin ").Append(Environment.NewLine)
            sb.Append("    For MainRec in (select EXC_SUBJECT_NO from ( ").Append(Environment.NewLine)
            sb.Append("                       select  EXC_SUBJECT_NO,min(IMAGE_ID) As IMG_ID ").Append(Environment.NewLine)
            sb.Append("                       From T_JJ_IMAGE ").Append(Environment.NewLine)
            sb.Append("                       Where EXC_SUBJECT_NO In ( ").Append(Environment.NewLine)
            sb.Append("                           Select A.EXC_SUBJECT_NO　FROM ").Append(Environment.NewLine)
            sb.Append("                             (Select EXC_SUBJECT_NO ").Append(Environment.NewLine)
            sb.Append("                              From T_JJ_IMAGE ").Append(Environment.NewLine)
            sb.Append("                              WHERE DELETE_FLG = '0' ").Append(Environment.NewLine)
            sb.Append("                              And EXC_IMAGE_KEY01 = eastwest ").Append(Environment.NewLine)
            sb.Append("                              GROUP BY EXC_SUBJECT_NO ").Append(Environment.NewLine)
            sb.Append("                              HAVING MIN(IMAGE_STATUS) = '@SELSTS@' ").Append(Environment.NewLine)
            sb.Append("                             ) A, ").Append(Environment.NewLine)
            sb.Append("                            ( ").Append(Environment.NewLine)
            sb.Append("                           SELECT EXC_SUBJECT_NO ").Append(Environment.NewLine)
            sb.Append("                            FROM T_JJ_IMAGE ").Append(Environment.NewLine)
            sb.Append("                            WHERE DELETE_FLG = '0' ").Append(Environment.NewLine)
            sb.Append("                            And EXC_IMAGE_KEY01 = eastwest ").Append(Environment.NewLine)
            sb.Append("                            And SLIP_DEFINE_ID IN (@SLIPID@)  ").Append(Environment.NewLine)
            sb.Append("                            And IMAGE_STATUS ='@SELSTS@' ").Append(Environment.NewLine)
            sb.Append("                            GROUP BY EXC_SUBJECT_NO ").Append(Environment.NewLine)
            sb.Append("                            ) B ").Append(Environment.NewLine)
            sb.Append("                           WHERE A.EXC_SUBJECT_NO = B.EXC_SUBJECT_NO ").Append(Environment.NewLine)
            sb.Append("                           ) ").Append(Environment.NewLine)
            sb.Append("                          GROUP BY EXC_SUBJECT_NO ").Append(Environment.NewLine)
            sb.Append("                          ORDER BY 2,1) ").Append(Environment.NewLine)
            sb.Append("                      Where ROWNUM <= limit) Loop ").Append(Environment.NewLine)
            sb.Append("          update T_JJ_IMAGE Set BEFORE_IMAGE_STATUS=IMAGE_STATUS,IMAGE_STATUS='@UPDSTS@',UPDATE_USER='SelectDelivery',UPDATE_DATE=wk_Date ").Append(Environment.NewLine)
            sb.Append("                 Where EXC_SUBJECT_NO = MainRec.EXC_SUBJECT_NO; ").Append(Environment.NewLine)
            sb.Append("          insert into T_JJ_IMAGE_HISTORY (IMAGE_ID,IMAGE_STATUS,CREATE_DATE,CREATE_USER)  ").Append(Environment.NewLine)
            sb.Append("                 (select IMAGE_ID,'@UPDSTS@',wk_timestamp,'SelectDelivery' from T_JJ_IMAGE Where EXC_SUBJECT_NO = MainRec.EXC_SUBJECT_NO); ").Append(Environment.NewLine)
            sb.Append("    End Loop; ").Append(Environment.NewLine)
            sb.Append("End; ").Append(Environment.NewLine)
            sb.Append("Begin ").Append(Environment.NewLine)
            sb.Append("    wk_DlvEastMax := wk_DlvTtlMax / 2; ").Append(Environment.NewLine)
            sb.Append("    If Mod (wk_DlvTtlMax, 2) = 0 Then ").Append(Environment.NewLine)
            sb.Append("        wk_DlvWestMax := wk_DlvEastMax; ").Append(Environment.NewLine)
            sb.Append("    Else ").Append(Environment.NewLine)
            sb.Append("        wk_DlvWestMax := wk_DlvTtlMax - wk_DlvEastMax; ").Append(Environment.NewLine)
            sb.Append("    End If; ").Append(Environment.NewLine)
            sb.Append("    Select  nvl(count(distinct EXC_SUBJECT_NO), 0) into wk_DlvEast  ").Append(Environment.NewLine)
            sb.Append("            from T_JJ_IMAGE ").Append(Environment.NewLine)
            sb.Append("            Where EXC_SUBJECT_NO In ( ").Append(Environment.NewLine)
            sb.Append("                   Select  ").Append(Environment.NewLine)
            sb.Append("                    A.EXC_SUBJECT_NO ").Append(Environment.NewLine)
            sb.Append("                   FROM ").Append(Environment.NewLine)
            sb.Append("                   ( ").Append(Environment.NewLine)
            sb.Append("                      Select  EXC_SUBJECT_NO ").Append(Environment.NewLine)
            sb.Append("                       FROM T_JJ_IMAGE ").Append(Environment.NewLine)
            sb.Append("                       WHERE DELETE_FLG = '0' ").Append(Environment.NewLine)
            sb.Append("                       And EXC_IMAGE_KEY01 = CNST_EW_EAST ").Append(Environment.NewLine)
            sb.Append("                       GROUP BY EXC_SUBJECT_NO ").Append(Environment.NewLine)
            sb.Append("                       HAVING MIN(IMAGE_STATUS) = '@SELSTS@' ").Append(Environment.NewLine)
            sb.Append("                       ) A, ").Append(Environment.NewLine)
            sb.Append("                      ( ").Append(Environment.NewLine)
            sb.Append("                      SELECT EXC_SUBJECT_NO ").Append(Environment.NewLine)
            sb.Append("                       FROM T_JJ_IMAGE ").Append(Environment.NewLine)
            sb.Append("                       WHERE DELETE_FLG = '0' ").Append(Environment.NewLine)
            sb.Append("                       And EXC_IMAGE_KEY01 = CNST_EW_EAST ").Append(Environment.NewLine)
            sb.Append("                       And SLIP_DEFINE_ID IN (@SLIPID@)  ").Append(Environment.NewLine)
            sb.Append("                       And IMAGE_STATUS ='@SELSTS@' ").Append(Environment.NewLine)
            sb.Append("                       GROUP BY EXC_SUBJECT_NO ").Append(Environment.NewLine)
            sb.Append("                       ) B ").Append(Environment.NewLine)
            sb.Append("                      WHERE A.EXC_SUBJECT_NO = B.EXC_SUBJECT_NO ").Append(Environment.NewLine)
            sb.Append("                      ); ").Append(Environment.NewLine)
            sb.Append("    Select  nvl(count(distinct EXC_SUBJECT_NO), 0) into wk_DlvWest ").Append(Environment.NewLine)
            sb.Append("        from T_JJ_IMAGE ").Append(Environment.NewLine)
            sb.Append("        Where EXC_SUBJECT_NO In ( ").Append(Environment.NewLine)
            sb.Append("              Select  ").Append(Environment.NewLine)
            sb.Append("                  A.EXC_SUBJECT_NO ").Append(Environment.NewLine)
            sb.Append("                  FROM ").Append(Environment.NewLine)
            sb.Append("                 ( ").Append(Environment.NewLine)
            sb.Append("                      Select  EXC_SUBJECT_NO ").Append(Environment.NewLine)
            sb.Append("                          FROM T_JJ_IMAGE ").Append(Environment.NewLine)
            sb.Append("                          WHERE DELETE_FLG = '0' ").Append(Environment.NewLine)
            sb.Append("                          And EXC_IMAGE_KEY01 = CNST_EW_WEST ").Append(Environment.NewLine)
            sb.Append("                          GROUP BY EXC_SUBJECT_NO ").Append(Environment.NewLine)
            sb.Append("                          HAVING MIN(IMAGE_STATUS) = '@SELSTS@' ").Append(Environment.NewLine)
            sb.Append("                  ) A, ").Append(Environment.NewLine)
            sb.Append("                 ( ").Append(Environment.NewLine)
            sb.Append("                      SELECT EXC_SUBJECT_NO ").Append(Environment.NewLine)
            sb.Append("                          FROM T_JJ_IMAGE ").Append(Environment.NewLine)
            sb.Append("                          WHERE DELETE_FLG = '0' ").Append(Environment.NewLine)
            sb.Append("                          And EXC_IMAGE_KEY01 = CNST_EW_WEST ").Append(Environment.NewLine)
            sb.Append("                          And SLIP_DEFINE_ID IN (@SLIPID@)  ").Append(Environment.NewLine)
            sb.Append("                          And IMAGE_STATUS ='@SELSTS@' ").Append(Environment.NewLine)
            sb.Append("                          GROUP BY EXC_SUBJECT_NO ").Append(Environment.NewLine)
            sb.Append("                  ) B ").Append(Environment.NewLine)
            sb.Append("                  WHERE A.EXC_SUBJECT_NO = B.EXC_SUBJECT_NO ").Append(Environment.NewLine)
            sb.Append("                  ); ").Append(Environment.NewLine)
            sb.Append("    If wk_DlvEastMax >= wk_DlvEast Then ").Append(Environment.NewLine)
            sb.Append("        If wk_DlvWestMax >= wk_DlvWest Then ").Append(Environment.NewLine)
            sb.Append("            Null; ").Append(Environment.NewLine)
            sb.Append("        Else ").Append(Environment.NewLine)
            sb.Append("            wk_DlvEastMax := wk_DlvEast; ").Append(Environment.NewLine)
            sb.Append("            wk_DlvWestMax := wk_DlvTtlMax - wk_DlvEast; ").Append(Environment.NewLine)
            sb.Append("        End If; ").Append(Environment.NewLine)
            sb.Append("    ElsIf wk_DlvWestMax > wk_DlvWest Then ").Append(Environment.NewLine)
            sb.Append("        wk_DlvWestMax := wk_DlvWest; ").Append(Environment.NewLine)
            sb.Append("        wk_DlvEastMax := wk_DlvTtlMax - wk_DlvWest;	 ").Append(Environment.NewLine)
            sb.Append("    End If; ").Append(Environment.NewLine)
            sb.Append("    DELIVARY_TARGET_UPDATE(CNST_EW_EAST,wk_DlvEastMax); ").Append(Environment.NewLine)
            sb.Append("    DELIVARY_TARGET_UPDATE(CNST_EW_WEST,wk_DlvWestMax); ").Append(Environment.NewLine)
            sb.Append("End; ")
            sb.Replace("@SELSTS@", Me.mdicConfig(CONF_INPUT_STATUS))
            sb.Replace("@UPDSTS@", Me.mdicConfig(CONF_OUTPUT_STATUS))
            sb.Replace("@SLIPID@", Me.mdicConfig(CONF_SLIP_ID))
            sb.Replace("@PE@", Me.mdicConfig(CONF_PUNCH_EAST))
            sb.Replace("@PW@", Me.mdicConfig(CONF_PUNCH_WEST))
            sb.Replace("@KENSU@", maxKensu)

        End With
        MyBase.WriteLog(sb.ToString, EventLogEntryType.Information)
        Return sb.ToString
    End Function
    Private Function GetSelectDeliverySqlAll(ByRef maxKensu As Decimal) As String
        Dim sb As New StringBuilder("")
        With sb
            sb.Append("Declare ").Append(Environment.NewLine)
            sb.Append("wk_DlvTtlMax Number(10) :=@KENSU@; ").Append(Environment.NewLine)
            sb.Append("wk_Date date := sysdate; ").Append(Environment.NewLine)
            sb.Append("wk_timestamp Timestamp := systimestamp; ").Append(Environment.NewLine)
            sb.Append("Begin ").Append(Environment.NewLine)
            sb.Append("    For MainRec in (select EXC_SUBJECT_NO from ( ").Append(Environment.NewLine)
            sb.Append("                       select  EXC_SUBJECT_NO,min(IMAGE_ID) As IMG_ID ").Append(Environment.NewLine)
            sb.Append("                       From T_JJ_IMAGE ").Append(Environment.NewLine)
            sb.Append("                       Where EXC_SUBJECT_NO In ( ").Append(Environment.NewLine)
            sb.Append("                           Select A.EXC_SUBJECT_NO　FROM ").Append(Environment.NewLine)
            sb.Append("                             (Select EXC_SUBJECT_NO ").Append(Environment.NewLine)
            sb.Append("                              From T_JJ_IMAGE ").Append(Environment.NewLine)
            sb.Append("                              WHERE DELETE_FLG = '0' ").Append(Environment.NewLine)
            sb.Append("                              GROUP BY EXC_SUBJECT_NO ").Append(Environment.NewLine)
            sb.Append("                              HAVING MIN(IMAGE_STATUS) = '@SELSTS@' ").Append(Environment.NewLine)
            sb.Append("                             ) A, ").Append(Environment.NewLine)
            sb.Append("                            ( ").Append(Environment.NewLine)
            sb.Append("                           SELECT EXC_SUBJECT_NO ").Append(Environment.NewLine)
            sb.Append("                            FROM T_JJ_IMAGE ").Append(Environment.NewLine)
            sb.Append("                            WHERE DELETE_FLG = '0' ").Append(Environment.NewLine)
            sb.Append("                            And SLIP_DEFINE_ID IN (@SLIPID@)  ").Append(Environment.NewLine)
            sb.Append("                            And IMAGE_STATUS ='@SELSTS@' ").Append(Environment.NewLine)
            sb.Append("                            GROUP BY EXC_SUBJECT_NO ").Append(Environment.NewLine)
            sb.Append("                            ) B ").Append(Environment.NewLine)
            sb.Append("                           WHERE A.EXC_SUBJECT_NO = B.EXC_SUBJECT_NO ").Append(Environment.NewLine)
            sb.Append("                           ) ").Append(Environment.NewLine)
            sb.Append("                          GROUP BY EXC_SUBJECT_NO ").Append(Environment.NewLine)
            sb.Append("                          ORDER BY 2,1) ").Append(Environment.NewLine)
            sb.Append("                      Where ROWNUM <= wk_DlvTtlMax) Loop ").Append(Environment.NewLine)
            sb.Append("          update T_JJ_IMAGE Set BEFORE_IMAGE_STATUS=IMAGE_STATUS,IMAGE_STATUS='@UPDSTS@',UPDATE_USER='SelectDelivery',UPDATE_DATE=wk_Date ").Append(Environment.NewLine)
            sb.Append("                 Where EXC_SUBJECT_NO = MainRec.EXC_SUBJECT_NO; ").Append(Environment.NewLine)
            sb.Append("          insert into T_JJ_IMAGE_HISTORY (IMAGE_ID,IMAGE_STATUS,CREATE_DATE,CREATE_USER)  ").Append(Environment.NewLine)
            sb.Append("                 (select IMAGE_ID,'@UPDSTS@',wk_timestamp,'SelectDelivery' from T_JJ_IMAGE Where EXC_SUBJECT_NO = MainRec.EXC_SUBJECT_NO); ").Append(Environment.NewLine)
            sb.Append("    End Loop; ").Append(Environment.NewLine)
            sb.Append("End; ")
            sb.Replace("@SELSTS@", Me.mdicConfig(CONF_INPUT_STATUS))
            sb.Replace("@UPDSTS@", Me.mdicConfig(CONF_OUTPUT_STATUS))
            sb.Replace("@SLIPID@", Me.mdicConfig(CONF_SLIP_ID))
            sb.Replace("@KENSU@", maxKensu)
        End With
        MyBase.WriteLog(sb.ToString, EventLogEntryType.Information)
        Return sb.ToString
    End Function
#End Region
End Class
