﻿Imports CommonSystem
Imports CommonBase
Imports System
Imports System.IO
Imports System.Text
Imports Oracle.DataAccess.Client

Public Class clsDefectCheckMain
    Inherits clsBatchBase

#Region "共通変数"

    ''' <summary>
    ''' 自端末処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Shared mainProc As clsDefectCheckMain

#End Region

#Region "内部定数定義"

    ''' <summary>
    ''' エントリ結果が保持する最大項目数
    ''' </summary>
    ''' <remarks></remarks>
    Private Const MAX_ITEM As Integer = 100

#End Region

#Region "内部変数定義"

    ''' <summary>
    ''' 不備項目と不備フラグ値による次遷移先の定義
    ''' </summary>
    ''' <remarks></remarks>
    Private mdicNextDefine As New Dictionary(Of String, String)

    ''' <summary>
    ''' 有効不備フラグマスタ
    ''' </summary>
    ''' <remarks></remarks>
    Private mdicDefect As New Dictionary(Of String, Object)

    ''' <summary>
    ''' 機械チェックメソッド定義格納用構造体
    ''' </summary>
    ''' <remarks></remarks>
    Public Structure CheckLogic
        Dim strSlipID As String             ' 帳票コード
        Dim strSeq As String                ' 連番
        Dim strInf As String                ' チェック概要
        Dim strDefectItem As String         ' 不部フラグ設定項目ID
        Dim strDefectFlag As String         ' 設定不備フラグ
        Dim strMethodCode As String         ' チェックメソッドID
        Dim strItem() As String             ' チェックに使用する項目の項目ID
        Dim strPara() As String             ' チェックに使用する引数
    End Structure

    ''' <summary>
    ''' 機械チェック定義を帳票ID単位に記憶する辞書
    ''' </summary>
    ''' <remarks></remarks>
    Private mdicLogic As New Dictionary(Of String, List(Of CheckLogic))

    ''' <summary>
    ''' 商品マスタファイルレイアウト
    ''' </summary>
    ''' <remarks></remarks>
    Private mstrCsvHed() As String = {"SRV", "CS", "C3", "C7"}

    ''' <summary>
    ''' 契約コースマスタファイルレイアウト
    ''' </summary>
    ''' <remarks></remarks>
    Private mstrCsvHed2() As String = {"SRV_CTRCT_KIND_CD", _
                                       "PRS_CTRCT_CRSE", _
                                       "APLY_STRT_D", _
                                       "APLY_END_D", _
                                       "PRS_CTRCT_CRSE_NAME", _
                                       "GMST_CTRCT_KIND", _
                                       "SPAR01", _
                                       "SPAR02", _
                                       "SPAR03", _
                                       "SPAR04", _
                                       "SPAR05"}

    ''' <summary>
    ''' 機械チェックの各種チェック処理の実装クラス
    ''' </summary>
    ''' <remarks></remarks>
    Private mclsCheck As New clsMethod


    Private Shared mdicGoods16 As Dictionary(Of String, String)
    Private Shared mdicGoods20 As Dictionary(Of String, String)

    Private Shared mdicConvert16 As Dictionary(Of String, String)
    Private Shared mdicConvert20 As Dictionary(Of String, String)


    Private mdicPassDefect As New Dictionary(Of String, String)

#End Region

#Region "メイン処理[Main]"

    ''' ======================================================================
    ''' メソッド名：Main
    ''' <summary>
    ''' メイン処理
    ''' </summary>
    ''' <remarks></remarks>
    ''' ======================================================================
    Shared Function Main(ByVal CmdArgs() As String) As Integer

        mainProc = New clsDefectCheckMain

        ' 処理の戻り値を返却
        Return mainProc.Run()

    End Function

#End Region

#Region "バッチ処理本体"
    Protected Overrides Sub Execute()
        Try
            Dim strPasDef() As String = Split(mdicConfig("PASS_DEFECT_LIST"), ",")
            For Each s As String In strPasDef
                mdicPassDefect.Add(s, String.Empty)
            Next

            ' 外部定義辞書をチェックメソッドクラスに設定
            clsMethod.mdicConfig = Me.mdicConfig

            ' 機械チェック定義ファイルの読込
            Call LoadCheckDefine()

            ' 不備遷移先定義ファイルの読込
            Call LoadDefList()

            ' 不備フラグマスタの読込
            Call GetDefectMaster()

            ' チェックメソッドクラスにDB接続情報を設定
            clsMethod.comDB = mobjCommonDB

            '' 商品マスタの取得
            'Call LoadShohinMaster()
            'mdicGoods16 = LoadShohinMaster99(mdicConfig("SHOHIN_MASTER_FILE_16"))
            'mdicGoods20 = LoadShohinMaster99(mdicConfig("SHOHIN_MASTER_FILE_20"))
            'mdicConvert16 = LoadConvertMaster(mdicConfig("SHOHIN_CONVERT_FILE_16"))
            'mdicConvert20 = LoadConvertMaster(mdicConfig("SHOHIN_CONVERT_FILE_20"))

            '' 契約コースマスタの取得
            'Call LoadCourseMaster()

            Do

                ' 処理対象となるイメージデータを取得します。
                Dim dtbAllImage As DataTable = GetImageData()
                If dtbAllImage Is Nothing OrElse dtbAllImage.Rows.Count = 0 Then
                    '対象となるデータが取得できない場合は処理を終了します。
                    Exit Do
                End If

                For Each dr As DataRow In dtbAllImage.Rows
                    ' イメージIDの取得
                    Dim strImageID As String = Convert.ToString(dr.Item("IMAGE_ID"))
                    ' 帳票IDの取得
                    Dim strSlipID As String = Convert.ToString(dr.Item("SLIP_DEFINE_ID"))
                    ' イメージステータスの取得
                    Dim strImageStatus As String = Convert.ToString(dr.Item("IMAGE_STATUS"))

                    ' 不備補正で更新された不備フラグをリセット
                    Call ResetDefectFlg(dr)


                    ' 不備チェック実施
                    Call DefectCheck(mdicLogic(strSlipID), dr)


                    ' 更新イメージステータスを設定
                    Dim strStatus As String = GetImageStatus(strSlipID, dr)

                    ' データベース更新
                    mobjCommonDB.DB_Transaction()
                    Try
                        ' エントリ補正テーブル更新
                        Call UpdateEntryCorrection(dr)

                        ' イメージテーブルの更新と履歴の登録
                        Call UpdateImage(strImageID, strStatus, strImageStatus)

                        ' トランザクション確定
                        mobjCommonDB.DB_Commit()

                    Catch ex As Exception

                        ' トランザクション破棄
                        mobjCommonDB.DB_Rollback()
                        Throw ex

                    End Try

                Next

            Loop

        Catch ex As Exception

            MyBase.WriteLog("機械チェック中にエラーを検出しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.ToString, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)

        Finally


        End Try
    End Sub
#End Region

#Region "不備フラグマスタ取得"
    Private Sub GetDefectMaster()
        Try

            Dim stbSQL As New StringBuilder(String.Empty)
            stbSQL.AppendLine("SELECT")
            stbSQL.AppendLine("    DEF_FLG_ID")
            stbSQL.AppendLine("FROM")
            stbSQL.AppendLine("    M_DEF_FLG")
            stbSQL.AppendLine("WHERE")
            stbSQL.AppendLine("    DELETE_FLG = '0'")
            stbSQL.AppendLine("    AND")
            stbSQL.AppendLine("    DEFECT_CHECK_FLG = '1'")

            Dim dtbDef As DataTable = mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)
            For Each dr As DataRow In dtbDef.Rows
                mdicDefect.Add(Convert.ToString(dr.Item("DEF_FLG_ID")), Nothing)
            Next

        Catch ex As Exception

            CommonLog.WriteLog("不備フラグマスタの取得に失敗しました", EventLogEntryType.Error)
            Throw ex

        End Try
    End Sub
#End Region

#Region "商品マスタの取得"
    Private Sub LoadShohinMaster()
        Try
            ' チェックメソッドクラスの商品マスタ用CSVクラスを初期化して
            ' マスターファイルを読み込みます
            Dim clsCSV As New CommonCsv(mstrCsvHed)
            If Not File.Exists(mdicConfig("SHOHIN_MASTER_FILE")) Then
                Throw New Exception("商品マスタが見つかりません")
            End If
            clsCSV.LoadCsv(mdicConfig("SHOHIN_MASTER_FILE"), True, True)
            If clsCSV.Count < 2 Then
                Throw New Exception("商品マスタに有効なデータがありません")
            End If
            ' マスターファイルのヘッダー行も読み込んでしまっているので削除
            clsCSV.DelRow(0)
            ' マスタデータをチェックメソッドクラスに渡します。
            clsMethod.mdtbMaster = clsCSV.Table
        Catch ex As Exception

            CommonLog.WriteLog("商品マスタの取得に失敗しました", EventLogEntryType.Error)
            Throw ex

        End Try
    End Sub
#End Region

#Region "契約コースマスタの取得"
    Private Sub LoadCourseMaster()
        Try
            ' チェックメソッドクラスの契約コースマスタ用CSVクラスを初期化して
            ' マスターファイルを読み込みます
            Dim clsCSV As New CommonCsv(mstrCsvHed2)
            If Not File.Exists(mdicConfig("COURSE_MASTER_FILE")) Then
                Throw New Exception("契約コースマスタが見つかりません")
            End If
            clsCSV.LoadCsv(mdicConfig("COURSE_MASTER_FILE"), True, True)
            If clsCSV.Count < 2 Then
                Throw New Exception("契約コースマスタに有効なデータがありません")
            End If
            ' マスターファイルのヘッダー行も読み込んでしまっているので削除
            clsCSV.DelRow(0)
            ' マスタデータをチェックメソッドクラスに渡します。
            clsMethod.mdtbMaster2 = clsCSV.Table
        Catch ex As Exception

            CommonLog.WriteLog("契約コースマスタの取得に失敗しました", EventLogEntryType.Error)
            Throw ex

        End Try
    End Sub
#End Region

#Region "機械チェック外部定義の読込"
    Private Sub LoadCheckDefine()
        Try
            ' 外部定義（今ふぃ具にあるチェック定義ファイル保存フォルダを取得
            Dim strFolder As String = mdicConfig("CHECK_DEFINE_PATH")
            If Not Directory.Exists(strFolder) Then
                Throw New Exception("外部定義で指定されたチェック定義フォルダが存在しません")
            End If

            ' 保存フォルダの下にある拡張子が「.def」のファイルを取得
            Dim strFiles() As String = Directory.GetFiles(strFolder, "*.def")
            ' 取得したファイルを１つずづ読み込む
            For Each strF As String In strFiles

                ' ファイル名の拡張子を除いた部分が帳票IDになっている
                Dim strSlipID As String = Path.GetFileNameWithoutExtension(strF)
                ' 読み込んだチェック定義を格納するリスト
                Dim lstDef As New List(Of CheckLogic)

                ' 定義ファイルを開く
                Using sr As New StreamReader(strF, Encoding.GetEncoding("shift-jis"))
                    ' ファイルの終端まで１行ずつ読み込む
                    While Not sr.EndOfStream
                        Dim strLine As String = sr.ReadLine
                        If strLine.StartsWith("#") Then
                            Continue While
                        End If
                        ' 読み込んだ１行をカンマで分解
                        Dim strDef() As String = Split(strLine, ",")
                        If strDef.Length <> 7 Then
                            Throw New Exception(strF & "の中に項目数が不正な行が存在します")
                        End If

                        ' チェック定義格納構造体に分解した定義内容を設定
                        Dim stcLogic As New CheckLogic
                        stcLogic.strSlipID = strSlipID
                        stcLogic.strSeq = strDef(0)
                        stcLogic.strInf = strDef(1)
                        stcLogic.strDefectItem = strDef(2)
                        stcLogic.strDefectFlag = strDef(3)
                        stcLogic.strMethodCode = strDef(4)
                        stcLogic.strItem = Split(strDef(5), "|")
                        stcLogic.strPara = Split(strDef(6), "|")
                        ' チャック構造体をリストに追加
                        lstDef.Add(stcLogic)

                    End While
                End Using

                ' 出来上がった１ファイル分のチェック構造体のリストを帳票IDをKeyにして辞書に登録
                mdicLogic.Add(strSlipID, lstDef)

            Next

        Catch ex As Exception

            CommonLog.WriteLog("機械チェック定義ファイルの読込ができません", EventLogEntryType.Error)
            Throw ex

        End Try
    End Sub
#End Region

#Region "不備遷移先定義ファイルの読込"
    Private Sub LoadDefList()
        Try

            ' 外部定義に記述されている不備遷移先定義ファイルのPATHが存在するかチェックします。
            Dim strPath As String = mdicConfig("DEFECT_DEFINE_FILE")
            If Not File.Exists(strPath) Then
                Throw New Exception(strPath & "画存在しません")
            End If

            ' 不備遷移先定義ファイルを読み込んで辞書に登録します。
            Using sr As New StreamReader(strPath, Encoding.GetEncoding("shift-jis"))
                While Not sr.EndOfStream
                    Dim strLine As String = sr.ReadLine
                    Dim strItem() As String = Split(strLine, ",")
                    ' 辞書のKeyは帳票ID+不備フラグ項目ID＋不備フラグ値
                    Dim strKey As String = strItem(0) & strItem(1) & strItem(2)
                    ' 辞書の内容は不備遷移先コード
                    Dim strVal As String = strItem(3)
                    ' 辞書登録
                    mdicNextDefine.Add(strKey, strVal)
                End While
            End Using

        Catch ex As Exception

            CommonLog.WriteLog("不備遷移先定義ファイルの読込ができません", EventLogEntryType.Error)
            Throw ex

        End Try
    End Sub
#End Region

#Region "チェック対象イメージデータの取得"
    ''' ======================================================================
    ''' メソッド名：GetImageData
    ''' <summary>
    ''' チェック対象イメージデータの取得
    ''' </summary>
    ''' <remarks></remarks>
    ''' ======================================================================
    Private Function GetImageData() As DataTable
        Try

            ' チェック対象データを抽出するためのSQLを作成します。
            Dim stbSQL As New StringBuilder(String.Empty)
            stbSQL.AppendLine("SELECT")
            stbSQL.AppendLine("     I.SLIP_DEFINE_ID")
            stbSQL.AppendLine("    ,I.IMAGE_STATUS")
            stbSQL.AppendLine("    ,I.PRIORITY")
            stbSQL.AppendLine("    ,R.DELIVERY_PLAN_TIME")
            stbSQL.AppendLine("    ,E.*")
            stbSQL.AppendLine("FROM")
            stbSQL.AppendLine("     T_JJ_IMAGE            I")
            stbSQL.AppendLine("    ,T_JJ_RECEIPT          R")
            stbSQL.AppendLine("    ,T_JJ_ENTRY_CORRECTION E")
            stbSQL.AppendLine("WHERE")
            stbSQL.AppendLine("    I.DELETE_FLG = '0'")
            stbSQL.AppendLine("    AND")
            stbSQL.AppendLine("    I.IMAGE_STATUS IN (%IMGSTS%)")
            stbSQL.AppendLine("    AND")
            stbSQL.AppendLine("    E.DELETE_FLG = '0'")
            stbSQL.AppendLine("    AND")
            stbSQL.AppendLine("    E.IMAGE_ID = I.IMAGE_ID")
            stbSQL.AppendLine("    AND")
            stbSQL.AppendLine("    R.DELETE_FLG = '0'")
            stbSQL.AppendLine("    AND")
            stbSQL.AppendLine("    R.RECEIPT_ID = I.RECEIPT_ID")
            stbSQL.AppendLine("ORDER BY")
            stbSQL.AppendLine("     I.PRIORITY")
            stbSQL.AppendLine("    ,R.DELIVERY_PLAN_TIME")
            stbSQL.AppendLine("    ,I.IMAGE_ID")

            ' 作成したSQLの抽出条件部分をコンフィグから取得した値に置換します。
            stbSQL.Replace("%IMGSTS%", mdicConfig("INPUT_STATUS"))

            ' OracleDBに作成したSQLを送信して結果を得ます。
            Return MyBase.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)

        Catch ex As Exception

            CommonLog.WriteLog("処理対象イメージデータが取得できません", EventLogEntryType.Error)
            Throw ex

        End Try
    End Function
#End Region

#Region "更新不備フラグのリセット"
    Private Sub ResetDefectFlg(ByVal drwEnt As DataRow)
        Try
            ' 不備補正で更新された不備状態（不備フラグ）を正常な不備フラグに更新します。
            For intItem As Integer = 1 To MAX_ITEM Step 1
                Dim strItemName As String = "ITEM_" & intItem.ToString("000") & "_DEF"
                Dim strDef As String = Convert.ToString(drwEnt.Item(strItemName))
                If strDef.Equals(mdicConfig("DEFECT_UP")) Then
                    drwEnt.Item(strItemName) = mdicConfig("DEFECT_OK")
                End If
            Next
        Catch ex As Exception

            CommonLog.WriteLog("更新不備フラグのリセットに失敗しました。", EventLogEntryType.Error)
            Throw ex

        End Try
    End Sub
#End Region

#Region "イメージステータス判定"
    Private Function GetImageStatus(ByVal strSlipID As String, ByVal drwEntry As DataRow) As String
        Try
            Dim blnFindSap As Boolean = False

            ' 不備補正で更新された不備状態（不備フラグ）を正常な不備フラグに更新します。
            For intItem As Integer = 1 To MAX_ITEM Step 1
                Dim strItemName As String = "ITEM_" & intItem.ToString("000") & "_DEF"
                Dim strDef As String = Convert.ToString(drwEntry.Item(strItemName))
                Dim strKey As String = strSlipID & strItemName & strDef

                ' 不備フラグがNULLの場合は不備なしと判定
                If strDef.Equals(String.Empty) Then
                    Continue For
                End If

                ' 不備フラグがコンフィグで指定された値の場合は不備としない
                If mdicPassDefect.ContainsKey(strDef) Then
                    Continue For
                End If

                If strDef.Equals(mdicConfig("DEFECT_OK")) OrElse strDef.Equals(mdicConfig("DEFECT_FS")) Then
                    ' 不備フラグ 00 と Z1 は正常とみなす
                    Continue For
                End If

                If Not mdicNextDefine.ContainsKey(strKey) Then
                    If strSlipID.Equals("005002") Then
                        ' 口頭分に不明な連携先があった場合は札幌連携と判断する
                        blnFindSap = True
                    Else
                        ' バッチ分に不明な連携先があった場合はオンサイト連携する
                        Return mdicConfig("OUTPUT_STATUS_DEFECT")
                    End If
                Else
                    Select Case mdicNextDefine(strKey)
                        Case "OST"
                            ' オンサイト連携があった場合はオンサイトで確定
                            Return mdicConfig("OUTPUT_STATUS_DEFECT")
                        Case "SAP"
                            ' 札幌連携フラグをONにする
                            blnFindSap = True
                        Case Else
                            If strSlipID.Equals("005002") Then
                                ' 口頭分に不明な連携先があった場合は札幌連携と判断する
                                blnFindSap = True
                            Else
                                ' バッチ分に不明な連携先があった場合はオンサイト連携する
                                Return mdicConfig("OUTPUT_STATUS_DEFECT")
                            End If
                    End Select
                End If
            Next

            If blnFindSap Then
                ' 札幌連携項目が１つ以上あった場合は札幌連携とする
                Return mdicConfig("OUTPUT_STATUS_SAPPORO")
            End If

            ' 納品データ作成に遷移する
            Return mdicConfig("OUTPUT_STATUS_NORMAL")

        Catch ex As Exception

            CommonLog.WriteLog("イメージステータスの判定に失敗しました。", EventLogEntryType.Error)
            Throw ex

        End Try
    End Function
#End Region

#Region "エントリー補正テーブル更新"
    Private Sub UpdateEntryCorrection(ByVal drwENtry As DataRow)
        Try

            ' エントリ補正テーブルの更新SQLを作成
            Dim stbSQL As New StringBuilder(String.Empty)
            stbSQL.AppendLine("UPDATE")
            stbSQL.AppendLine("    T_JJ_ENTRY_CORRECTION")
            stbSQL.AppendLine("SET")
            For i As Integer = 1 To MAX_ITEM Step 1
                Dim strField As String = "ITEM_" & i.ToString("000") & "_DEF"
                If i = 1 Then
                    stbSQL.Append("     ")
                Else
                    stbSQL.Append("    ,")
                End If
                stbSQL.Append(strField)
                stbSQL.AppendLine(" = '" & Convert.ToString(drwENtry.Item(strField) & "'"))

            Next
            stbSQL.AppendLine("WHERE")
            stbSQL.AppendLine("    IMAGE_ID = " & Convert.ToString(drwENtry("IMAGE_ID")))
            stbSQL.AppendLine("    AND")
            stbSQL.AppendLine("    DELETE_FLG = '0'")

            ' 作成したSQLを実行
            Dim intRet As Integer = mobjCommonDB.DB_ExecuteNonQuery(stbSQL.ToString)
            If intRet <> 1 Then
                Throw New Exception("エントリ補正テーブルがUpdateできません")
            End If

        Catch ex As Exception

            CommonLog.WriteLog("エントリ補正テーブルの更新に失敗しました。", EventLogEntryType.Error)
            Throw ex

        End Try
    End Sub
#End Region

#Region "イメージデータの状態更新"
    Private Sub UpdateImage(ByVal strImageID As String, _
                            ByVal strNewStatus As String, _
                            ByVal strOldStatus As String)

        Dim stbUpdateSQL As New System.Text.StringBuilder(String.Empty)
        Dim stbInsertSQL As New System.Text.StringBuilder(String.Empty)

        Try

            ' イメージ状態更新用SQLを作成します。
            stbUpdateSQL.AppendLine("UPDATE")
            stbUpdateSQL.AppendLine("  T_JJ_IMAGE")
            stbUpdateSQL.AppendLine("SET")
            stbUpdateSQL.AppendLine("   IMAGE_STATUS   =:Status ")
            If strOldStatus.Equals(mdicConfig("INPUT_STATUS_FIRST")) AndAlso _
               Not strNewStatus.Equals(mdicConfig("OUTPUT_STATUS_NORMAL")) Then
                stbUpdateSQL.AppendLine("  ,DEF_DIV = '1'")
            End If
            stbUpdateSQL.AppendLine("  ,UPDATE_USER    = 'DefectCheck'")
            stbUpdateSQL.AppendLine("  ,UPDATE_DATE    = SYSDATE")
            stbUpdateSQL.AppendLine("WHERE")
            stbUpdateSQL.AppendLine("  IMAGE_ID = :DocumentId")

            ' イメージ状態更新用パラメータ宣言
            Dim oraUpdateParam(1) As OracleParameter
            oraUpdateParam(0) = New OracleParameter("DocumentId", OracleDbType.Decimal)
            oraUpdateParam(0).Value = Convert.ToInt64(strImageID)
            oraUpdateParam(1) = New OracleParameter("Status", OracleDbType.Char)
            oraUpdateParam(1).Value = strNewStatus
            ' イメージ状態を更新します。
            Dim intUpdateRet As Integer = MyBase.mobjCommonDB.DB_ExecuteNonQuery(stbUpdateSQL.ToString, oraUpdateParam)
            If Not intUpdateRet = 1 Then
                Throw New Exception("イメージテーブルの更新に失敗しました。")
            End If

            ' イメージ状態履歴登録用SQLを作成します。
            stbInsertSQL.AppendLine("INSERT INTO T_JJ_IMAGE_HISTORY (")
            stbInsertSQL.AppendLine("     IMAGE_ID")
            stbInsertSQL.AppendLine("    ,IMAGE_STATUS")
            stbInsertSQL.AppendLine("    ,CREATE_DATE")
            stbInsertSQL.AppendLine("    ,CREATE_USER")
            stbInsertSQL.AppendLine(") VALUES (")
            stbInsertSQL.AppendLine("     :DocumentId")
            stbInsertSQL.AppendLine("    ,:OutStatus")
            stbInsertSQL.AppendLine("    ,SYSTIMESTAMP")
            stbInsertSQL.AppendLine("    ,'DefectCheck'")
            stbInsertSQL.AppendLine(")")

            ' イメージ状態履歴登録用パラメータ宣言
            Dim oraInsertParam(1) As OracleParameter
            oraInsertParam(0) = New OracleParameter("DocumentId", OracleDbType.Decimal)
            oraInsertParam(0).Value = Convert.ToInt64(strImageID)
            oraInsertParam(1) = New OracleParameter("OutStatus", OracleDbType.Char)
            oraInsertParam(1).Value = strNewStatus
            ' イメージ状態履歴を登録します。
            Dim intInsertRet As Integer = MyBase.mobjCommonDB.DB_ExecuteNonQuery(stbInsertSQL.ToString, oraInsertParam)
            If Not intInsertRet = 1 Then
                Throw New Exception("イメージ状態履歴の登録に失敗しました。")
            End If

        Catch ex As Exception

            CommonLog.WriteLog(MyBase.mobjCommonDB.GetInfoMessage, EventLogEntryType.Error)
            Throw ex

        End Try

    End Sub
#End Region

#Region "機械チェック処理解析"
    Private Sub DefectCheck(ByVal lstLogic As List(Of CheckLogic), ByVal drwEntry As DataRow)
        Try

            For Each stcL As CheckLogic In lstLogic
                ' 既にマスターで有効とされている不備フラグが設定されている項目についてはチェックは行わない
                Dim strNowDefect As String = Convert.ToString(drwEntry.Item(stcL.strDefectItem))
                If mdicDefect.ContainsKey(strNowDefect) Then
                    Continue For
                End If

                ' メソッドIDによりチェック処理を呼び出す
                Dim blnCheck As Boolean = True
                blnCheck = Convert.ToBoolean(CallByName(mclsCheck, stcL.strMethodCode, CallType.Method, stcL, drwEntry))

                ' チェック結果がエラーなら不備フラグを設定
                If Not blnCheck Then
                    drwEntry.Item(stcL.strDefectItem) = stcL.strDefectFlag
                End If

            Next

        Catch ex As Exception

            CommonLog.WriteLog("機械チェック処理解析に失敗しました。", EventLogEntryType.Error)
            Throw ex

        End Try
    End Sub
#End Region

#Region "ダミーのチェックメソッド"
    Private Function DUMMY001(ByVal stcLogic As CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try

            Return True

        Catch ex As Exception

            CommonLog.WriteLog("DUMMY001でエラーを検出しました。", EventLogEntryType.Error)
            Throw ex

        End Try
    End Function

    Private Function DUMMY002(ByVal stcLogic As CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try

            Return False

        Catch ex As Exception

            CommonLog.WriteLog("DUMMY001でエラーを検出しました。", EventLogEntryType.Error)
            Throw ex

        End Try
    End Function
#End Region

#Region "商品マスタの取得"
    Private Function LoadShohinMaster99(ByVal strPath As String) As Dictionary(Of String, String)
        Try
            ' チェックメソッドクラスの商品マスタ用CSVクラスを初期化して
            ' マスターファイルを読み込みます
            Dim clsCSV As New CommonCsv(mstrCsvHed)
            If Not File.Exists(strPath) Then
                Throw New Exception("マスタが見つかりません。[" & strPath & "]")
            End If

            Dim dicGoods As New Dictionary(Of String, String)
            Using sr As New StreamReader(strPath, Encoding.GetEncoding("shift-jis"))
                Do Until sr.EndOfStream
                    Dim strLine As String = sr.ReadLine
                    Dim strItem() As String = Split(strLine, ",")
                    If strItem.Length <> 2 Then
                        Continue Do
                    End If
                    Dim strCode() As String = Split(strItem(0), "-")
                    If strCode.Length <> 3 Then
                        Continue Do
                    End If
                    dicGoods.Add(strCode(1), strItem(0).Replace("-", String.Empty))
                Loop
            End Using

            Return dicGoods

        Catch ex As Exception

            CommonLog.WriteLog("商品マスタの取得に失敗しました", EventLogEntryType.Error)
            Throw ex

        End Try
    End Function
#End Region

#Region "商品kコード変換マスタの取得"
    Private Function LoadConvertMaster(ByVal strPath As String) As Dictionary(Of String, String)
        Try
            ' チェックメソッドクラスの商品マスタ用CSVクラスを初期化して
            ' マスターファイルを読み込みます
            Dim clsCSV As New CommonCsv(mstrCsvHed)
            If Not File.Exists(strPath) Then
                Throw New Exception("マスタが見つかりません。[" & strPath & "]")
            End If

            Dim dicGoods As New Dictionary(Of String, String)
            Using sr As New StreamReader(strPath, Encoding.GetEncoding("shift-jis"))
                Do Until sr.EndOfStream
                    Dim strLine As String = sr.ReadLine
                    Dim strItem() As String = Split(strLine, ",")
                    If strItem.Length <> 2 Then
                        Continue Do
                    End If
                    dicGoods.Add(strItem(0), strItem(1))
                Loop
            End Using

            Return dicGoods

        Catch ex As Exception

            CommonLog.WriteLog("商品コード変換マスタの取得に失敗しました", EventLogEntryType.Error)
            Throw ex

        End Try
    End Function
#End Region

#Region "商品マスタ検索(16桁)"
    Public Shared Function Get16(ByVal strCode As String) As String
        Try
            Dim strConv As String
            If mdicConvert16.ContainsKey(strCode) Then
                strConv = mdicConvert16(strCode)
            Else
                strConv = strCode
            End If
            If mdicGoods16.ContainsKey(strConv) Then
                Return mdicGoods16(strConv)
            End If

            Return String.Empty
        Catch ex As Exception

            CommonLog.WriteLog("[" & strCode & "] 商品マスタ16の取得に失敗", EventLogEntryType.Error)
            Throw ex

        End Try
    End Function
#End Region

#Region "商品マスタ検索(20桁)"
    Public Shared Function Get20(ByVal strCode As String) As String
        Try
            Dim strConv As String
            If mdicConvert20.ContainsKey(strCode) Then
                strConv = mdicConvert20(strCode)
            Else
                strConv = strCode
            End If
            If mdicGoods20.ContainsKey(strConv) Then
                Return mdicGoods20(strConv)
            End If

            Return String.Empty
        Catch ex As Exception

            CommonLog.WriteLog("[" & strCode & "] 商品マスタ20の取得に失敗", EventLogEntryType.Error)
            Throw ex

        End Try
    End Function
#End Region

End Class
