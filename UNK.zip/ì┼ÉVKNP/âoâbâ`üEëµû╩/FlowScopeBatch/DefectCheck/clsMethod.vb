﻿Imports CommonSystem
Imports System
Imports System.IO
Imports System.Text
Imports Oracle.DataAccess.Client
Imports EntryExCharTool

Public Class clsMethod

    ' DB接続情報
    Public Shared comDB As CommonDB
    ' 商品マスタデータ
    Public Shared mdtbMaster As DataTable
    ' 契約コースマスタデータ
    Public Shared mdtbMaster2 As DataTable

    '半角数字Regexオブジェクトを作成 
    Private Shared rNum As New System.Text.RegularExpressions.Regex("[0-9 ]")
    '半角英字Regexオブジェクトを作成 
    Private Shared rAlpha As New System.Text.RegularExpressions.Regex("[a-zA-Z ]")
    '半角ｶﾅRegexオブジェクトを作成 
    Private Shared rKana As New System.Text.RegularExpressions.Regex("[\uFF61-\uFF9F ]")
    '全角数字Regexオブジェクトを作成 
    Private Shared rNumZ As New System.Text.RegularExpressions.Regex("[０-９　]")
    '全角英字Regexオブジェクトを作成 
    Private Shared rAlphaZ As New System.Text.RegularExpressions.Regex("[ａ-ｚＡ-Ｚ　]")
    '全角カナRegexオブジェクトを作成 
    Private Shared rKanaZ As New System.Text.RegularExpressions.Regex("[ア-ン　]")

    '半角記号一覧を作成 
    Private Shared mstrMark As String = "!#$%&()*+-./:;<=>?@[\]^_`{|}~｡｢｣､･ｰ "

    ' JIS第2水準判定用
    Private Shared mobjOperChar As New OperateCharacterClass

    ' 外部定義辞書
    Public Shared mdicConfig As Dictionary(Of String, String)

#Region "E001(禁則文字チェック)"
    ''' <summary>
    ''' 禁則文字チェック
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E001(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try

            Dim strValue As String = GetValue(drwEntry, stcLogic.strItem(0))
            For Each strP As String In stcLogic.strPara
                Dim intIndex As Integer = strValue.IndexOf(strP)
                If intIndex > -1 Then
                    Return False
                End If
            Next

            Return True

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E002(最大桁数チェック)"
    ''' <summary>
    ''' 最大桁数チェック
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E002(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try

            Dim strValue As String = GetValue(drwEntry, stcLogic.strItem(0))
            Dim intParam As Integer = Convert.ToInt32(stcLogic.strPara(0))
            If CommonFunctions.LenB(strValue) > intParam Then
                Return False
            End If

            Return True

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E003(複数記入チェック)"
    ''' <summary>
    ''' 複数記入チェック
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E003(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try

            Dim intParam As Integer = Convert.ToInt32(stcLogic.strPara(0))
            Dim intCount As Integer = 0
            For Each strI As String In stcLogic.strItem
                Dim strValue As String = GetValue(drwEntry, strI)
                If Not strValue.Trim.Equals(String.Empty) Then
                    intCount += 1
                End If
                If intCount > intParam Then
                    Return False
                End If
            Next

            Return True

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E004(文字タイプチェック)"
    ''' <summary>
    ''' 文字タイプチェック
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E004(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try


            Dim strValue As String = GetValue(drwEntry, stcLogic.strItem(0))
            For Each c As Char In strValue.ToCharArray
                Dim blnC As Boolean = False
                For Each strP As String In stcLogic.strPara
                    Select Case strP
                        Case "10"   ' 半角すべて
                            Dim intLen As Integer = CommonFunctions.LenB(Convert.ToString(c))
                            If intLen = 1 Then
                                blnC = True
                                Exit For
                            End If
                        Case "11"   ' 半角数字
                            If rNum.IsMatch(Convert.ToString(c)) Then
                                blnC = True
                                Exit For
                            End If
                        Case "12"   ' 半角英字
                            If rAlpha.IsMatch(Convert.ToString(c)) Then
                                blnC = True
                                Exit For
                            End If
                        Case "13"   ' 半角カナ
                            If rKana.IsMatch(Convert.ToString(c)) Then
                                blnC = True
                                Exit For
                            End If
                        Case "14"   ' 半角記号
                            If mstrMark.IndexOf(Convert.ToString(c)) >= 0 Then
                                blnC = True
                                Exit For
                            End If
                        Case "20"   ' 全角すべて
                            Dim intLen As Integer = CommonFunctions.LenB(Convert.ToString(c))
                            If intLen <> 1 Then
                                blnC = True
                                Exit For
                            End If
                        Case "21"   ' 全角数字
                            If rNumZ.IsMatch(Convert.ToString(c)) Then
                                blnC = True
                                Exit For
                            End If
                        Case "22"   ' 全角英字
                            If rAlphaZ.IsMatch(Convert.ToString(c)) Then
                                blnC = True
                                Exit For
                            End If
                        Case "23"   ' 全角カナ
                            If rKanaZ.IsMatch(Convert.ToString(c)) Then
                                blnC = True
                                Exit For
                            End If
                        Case Else
                            CommonLog.WriteLog("不明なパラメータを検知しました。", EventLogEntryType.Error)
                            WriteDefine(stcLogic)
                            Return False
                    End Select
                Next

                If Not blnC Then
                    Return False
                End If
            Next

            Return True

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E051(必須チェック)"
    ''' <summary>
    ''' 必須チェック
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E051(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try

            Dim intCount As Integer = 0
            For Each strI As String In stcLogic.strItem
                Dim strValue As String = GetValue(drwEntry, strI)
                If Not strValue.Trim.Equals(String.Empty) Then
                    intCount += 1
                End If
            Next

            If intCount = 0 Then
                Return False
            End If

            Return True

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E052(半角・全角チェック)"
    ''' <summary>
    ''' 半角・全角チェック
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E052(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try

            Dim strValue As String = GetValue(drwEntry, stcLogic.strItem(0))
            If strValue.Trim.Length = 0 Then
                Return True
            End If

            For Each c As Char In strValue.ToCharArray
                Select Case stcLogic.strPara(0)
                    Case "1"   ' 半角
                        Dim intLen As Integer = CommonFunctions.LenB(Convert.ToString(c))
                        If intLen <> 1 Then
                            Return False
                        End If
                    Case "2"   ' 全角
                        Dim intLen As Integer = CommonFunctions.LenB(Convert.ToString(c))
                        If intLen = 1 Then
                            Return False
                        End If
                    Case Else
                        CommonLog.WriteLog("不明なパラメータを検知しました。", EventLogEntryType.Error)
                        WriteDefine(stcLogic)
                        Return False
                End Select
            Next

            Return True

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E053(全桁入力チェック)"
    ''' <summary>
    ''' 全桁入力チェック
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E053(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try

            Dim strValue As String = GetValue(drwEntry, stcLogic.strItem(0))
            If strValue.Trim.Length = 0 Then
                Return True
            End If

            Dim intParam As Integer = Convert.ToInt32(stcLogic.strPara(0))
            If CommonFunctions.LenB(strValue) < intParam Then
                Return False
            End If

            Return True

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E054(範囲チェック)"
    ''' <summary>
    ''' 範囲チェック
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E054(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try

            Dim strValue As String = GetValue(drwEntry, stcLogic.strItem(0))
            If strValue.Trim.Equals(String.Empty) Then
                ' 入力が空欄ならチェックしない
                Return True
            End If
            If Not rNum.IsMatch(strValue) Then
                ' 入力が数字以外ならエラー
                Return False
            End If
            Dim intValue As Integer = Convert.ToInt32(strValue)

            Dim strParam() As String = Split(stcLogic.strPara(1), "-")
            If strParam.Length <> 2 Then
                CommonLog.WriteLog("範囲の指定方法が不正です", EventLogEntryType.Error)
                WriteDefine(stcLogic)
                Return False
            End If
            If Not rNum.IsMatch(strParam(0)) Then
                CommonLog.WriteLog("範囲に半角数値以外があります", EventLogEntryType.Error)
                WriteDefine(stcLogic)
                Return False
            End If
            If Not rNum.IsMatch(strParam(1)) Then
                CommonLog.WriteLog("範囲に半角数値以外があります", EventLogEntryType.Error)
                WriteDefine(stcLogic)
                Return False
            End If

            Dim intFrom As Integer = Convert.ToInt32(strParam(0))
            Dim intTo As Integer = Convert.ToInt32(strParam(1))

            Select Case stcLogic.strPara(0)
                Case "1"    ' 範囲外はNG
                    If intValue < intFrom OrElse intValue > intTo Then
                        Return False
                    End If
                Case "2"    ' 範囲内はNG
                    If intValue >= intFrom AndAlso intValue <= intTo Then
                        Return False
                    End If
                Case Else
                    CommonLog.WriteLog("第１引数に不明な値があります。", EventLogEntryType.Error)
                    WriteDefine(stcLogic)
            End Select

            Return True

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E056(未入力チェック)"
    ''' <summary>
    ''' 未入力チェック
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E056(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try
            For Each strI As String In stcLogic.strItem
                Dim strValue As String = GetValue(drwEntry, strI)
                If strValue.Trim.Length > 0 Then
                    Return False
                End If
            Next

            Return True

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E057(数値比較チェック)"
    ''' <summary>
    ''' 数値比較チェック
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E057(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try
            Dim strI1 As String = GetValue(drwEntry, stcLogic.strItem(0))
            Dim strI2 As String = GetValue(drwEntry, stcLogic.strItem(1))
            If strI1.Length = 0 OrElse strI2.Length = 0 Then
                Return True
            End If

            Dim intI1 As Integer
            Dim intI2 As Integer
            Try
                intI1 = Convert.ToInt32(strI1)
                intI2 = Convert.ToInt32(strI2)
            Catch ex As Exception
                Return False
            End Try

            Select Case stcLogic.strPara(0)
                Case ">"
                    If intI1 > intI2 Then
                        Return True
                    End If
                Case "<"
                    If intI1 < intI2 Then
                        Return True
                    End If
                Case "="
                    If intI1 = intI2 Then
                        Return True
                    End If
                Case ">="
                    If intI1 >= intI2 Then
                        Return True
                    End If
                Case "<="
                    If intI1 <= intI2 Then
                        Return True
                    End If
                Case Else
                    CommonLog.WriteLog("不明なパラメータを検知しました。", EventLogEntryType.Error)
                    WriteDefine(stcLogic)
                    Return False
            End Select

            Return False

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E059(非必須チェック)"
    ''' <summary>
    ''' 非必須チェック
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E059(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try

            Dim strValue As String = GetValue(drwEntry, stcLogic.strItem(0))
            If strValue.Trim.Equals(stcLogic.strPara(0)) Then
                ' 指定文字なら不備
                Return False
            End If

            Return True

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E055(存在チェック)"
    ''' <summary>
    ''' 存在チェック
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E055(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try

            Dim strValue As String = GetValue(drwEntry, stcLogic.strItem(0))
            If strValue.Trim.Length = 0 Then
                Return True
            End If

            For Each strP As String In stcLogic.strPara
                If strValue.Equals(strP) Then
                    Return True
                End If
            Next

            Return False

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E060(文字列比較チェック)"
    ''' <summary>
    ''' 文字列比較チェック
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E060(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try

            Dim strValue1 As String = GetValue(drwEntry, stcLogic.strItem(0))
            Dim strValue2 As String = GetValue(drwEntry, stcLogic.strItem(1))
            If strValue1.Length = 0 OrElse strValue2.Length = 0 Then
                Return True
            End If

            Select Case stcLogic.strPara(0)
                Case "="
                    If strValue1 = strValue2 Then
                        Return True
                    End If
                Case "<>"
                    If strValue1 <> strValue2 Then
                        Return True
                    End If
            End Select

            Return False

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E061(JIS第二水準外文字チェック)"
    ''' <summary>
    ''' JIS第二水準外文字チェック
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E061(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try

            Dim strValue As String = GetValue(drwEntry, stcLogic.strItem(0))
            For Each c As Char In strValue.ToCharArray
                Dim intLen As Integer = CommonFunctions.LenB(Convert.ToString(c))
                If intLen = 1 Then
                    Continue For
                End If

                If Not mobjOperChar.CheckJISX0208(Convert.ToString(c), 0) Then
                    Return False
                End If
            Next

            Return True

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E063(指定文字個数チェック)"
    ''' <summary>
    ''' 指定文字個数チェック
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E063(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try

            Dim strValue As String = GetValue(drwEntry, stcLogic.strItem(0))
            Dim intMax As Integer = Convert.ToInt32(stcLogic.strPara(0))
            Dim strKey As String = stcLogic.strPara(1)
            Dim intCount As Integer = 0
            Dim intIndex As Integer = 0
            If strValue.Length = 0 Then
                Return True
            End If
            Do
                If intIndex >= strValue.Length Then
                    Exit Do
                End If

                Dim intI As Integer = strValue.IndexOf(strKey, intIndex)
                If intI < 0 Then
                    Exit Do
                Else
                    intCount += 1
                End If

                intIndex = intI + strKey.Length
            Loop

            If intCount <> intMax Then
                Return False
            End If

            Return True

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E064(指定桁数チェック)"
    ''' <summary>
    ''' 指定桁数チェック
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E064(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try

            Dim strValue As String = GetValue(drwEntry, stcLogic.strItem(0))
            If strValue.Trim.Equals(String.Empty) Then
                Return True
            End If

            Dim intBytes As Integer = CommonFunctions.LenB(strValue.Trim)

            For Each strP As String In stcLogic.strPara
                Dim intP As Integer = Convert.ToInt32(strP)
                If intP = intBytes Then
                    Return True
                End If
            Next

            Return False

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E065(指定カラム入力値チェック)"
    ''' <summary>
    ''' 指定カラム入力値チェック
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E065(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try

            Dim strValue As String = GetValue(drwEntry, stcLogic.strItem(0))
            If strValue.Trim.Equals(String.Empty) Then
                Return True
            End If

            Dim intP1 As Integer = Convert.ToInt32(stcLogic.strPara(0))
            intP1 -= 1
            Dim intP2 As Integer = Convert.ToInt32(stcLogic.strPara(1))
            If strValue.Length < (intP1 + intP2) Then
                Return False
            End If

            Dim strComp As String = strValue.Substring(intP1, intP2)
            For i As Integer = 2 To stcLogic.strPara.Length - 1 Step 1
                If strComp.Equals(stcLogic.strPara(i)) Then
                    Return True
                End If
            Next

            Return False

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E066(桁数条件指定カラム入力値チェック)"
    ''' <summary>
    ''' 指定カラム入力値チェック
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E066(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try

            Dim strValue As String = GetValue(drwEntry, stcLogic.strItem(0))
            If strValue.Trim.Equals(String.Empty) Then
                Return True
            End If

            Dim intP0 As Integer = Convert.ToInt32(stcLogic.strPara(0))
            If CommonFunctions.LenB(strValue) <> intP0 Then
                Return True
            End If

            Dim intP1 As Integer = Convert.ToInt32(stcLogic.strPara(1))
            intP1 -= 1
            Dim intP2 As Integer = Convert.ToInt32(stcLogic.strPara(2))
            If strValue.Length < (intP1 + intP2) Then
                Return False
            End If

            Dim strComp As String = strValue.Substring(intP1, intP2)
            For i As Integer = 3 To stcLogic.strPara.Length - 1 Step 1
                If strComp.Equals(stcLogic.strPara(i)) Then
                    Return True
                End If
            Next

            Return False

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E067(桁数条件指定カラム入力値チェック2)"
    ''' <summary>
    ''' 桁数条件指定カラム入力値チェック2
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E067(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try

            Dim strValue1 As String = GetValue(drwEntry, stcLogic.strItem(0))
            Dim strValue2 As String = GetValue(drwEntry, stcLogic.strItem(1))

            If strValue1.Trim.Equals(String.Empty) Then
                Return True
            End If
            If strValue2.Trim.Equals(String.Empty) Then
                Return True
            End If

            Dim intP0 As Integer = Convert.ToInt32(stcLogic.strPara(0))
            If CommonFunctions.LenB(strValue1) <> intP0 Then
                Return True
            End If

            For i As Integer = 1 To stcLogic.strPara.Length - 1 Step 1
                If strValue2.Equals(stcLogic.strPara(i)) Then
                    Return True
                End If
            Next

            Return False

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E068(指定文字個数チェック2)"
    ''' <summary>
    ''' 指定文字個数チェック2
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E068(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try

            Dim strValue As String = GetValue(drwEntry, stcLogic.strItem(0))
            If strValue.Length = 0 Then
                Return True
            End If

            Dim intCount As Integer = 0
            For Each c As String In strValue.ToCharArray
                If c.Equals(stcLogic.strPara(1)) Then
                    intCount += 1
                End If
            Next

            If Convert.ToInt32(stcLogic.strPara(0)) > intCount Then
                Return False
            End If

            Return True

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E071(チェックデジット1)"
    ''' <summary>
    ''' チェックデジット1
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E071(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try
            Dim intX() As Integer = {4, 3, 2, 7, 6, 5, 4, 3, 2, 7, 6, 5, 4, 3, 2}

            Dim strValue As String = GetValue(drwEntry, stcLogic.strItem(0))
            If strValue.Trim.Equals(String.Empty) Then
                Return True
            End If

            If strValue.Length <> 16 Then
                Return False
            End If

            Dim intA As Integer = 0
            For i As Integer = 0 To 14 Step 1
                intA += Convert.ToInt32(strValue.Substring(i, 1)) * intX(i)
            Next

            Dim intB As Integer = intA Mod 11
            Dim intC As Integer = 11 - intB

            Dim int16 As Integer = Convert.ToInt32(strValue.Substring(15, 1))
            If intC < 10 Then
                If intC = int16 Then
                    Return True
                End If
            Else
                If int16 = (intC - 10) Then
                    Return True
                End If
            End If

            Return False

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E072(チェックデジット2)"
    ''' <summary>
    ''' チェックデジット2
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E072(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try
            Dim strValue As String = GetValue(drwEntry, stcLogic.strItem(0))
            If strValue.Trim.Equals(String.Empty) Then
                Return True
            End If

            If strValue.Length <> 20 Then
                Return False
            End If

            Dim lngValue As Long = Convert.ToInt64(strValue.Substring(0, 15))
            Dim strA As String = Convert.ToString(lngValue, 16).PadLeft(12, "0")
            Dim intA1 As Integer = Convert.ToInt32(strA.Substring(0, 4), 16)
            Dim intA2 As Integer = Convert.ToInt32(strA.Substring(4, 4), 16)
            Dim intA3 As Integer = Convert.ToInt32(strA.Substring(8, 4), 16)
            Dim intB As Integer = intA1 Xor intA2
            Dim strC As String = (intB Xor intA3).ToString("00000")

            If strValue.EndsWith(strC) Then
                Return True
            End If

            Return False

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E073(クレジット番号桁数エラー)"
    ''' <summary>
    ''' クレジット番号桁数エラー
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E073(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try

            Dim strValue As String = GetValue(drwEntry, stcLogic.strItem(0))
            If strValue.Trim.Equals(String.Empty) Then
                Return True
            End If

            Dim intP1 As Integer = Convert.ToInt32(stcLogic.strPara(0))
            intP1 -= 1
            Dim intP2 As Integer = Convert.ToInt32(stcLogic.strPara(1))
            If strValue.Length < (intP1 + intP2) Then
                Return False
            End If

            Dim strP3() As String = Split(stcLogic.strPara(2), "-")
            Dim intP4 As Integer = Convert.ToInt32(stcLogic.strPara(3))
            If strP3.Length = 1 Then
                If strValue.Substring(intP1, intP2).Equals(stcLogic.strPara(2)) AndAlso _
                   strValue.Length <> intP4 Then
                    Return False
                End If
            Else
                Select Case strValue.Substring(intP1, intP2)
                    Case strP3(0) To strP3(1)
                        If strValue.Length <> intP4 Then
                            Return False
                        End If
                End Select
            End If

            Return True

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E074(桁数条件チェックデジット1)"
    ''' <summary>
    ''' 桁数条件チェックデジット1
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E074(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try
            Dim intX() As Integer = {4, 3, 2, 7, 6, 5, 4, 3, 2, 7, 6, 5, 4, 3, 2}

            Dim strValue As String = GetValue(drwEntry, stcLogic.strItem(0))
            If strValue.Trim.Equals(String.Empty) Then
                Return True
            End If

            Dim intP0 As Integer = Convert.ToInt32(stcLogic.strPara(0))
            If CommonFunctions.LenB(strValue) <> intP0 Then
                Return True
            End If

            If strValue.Length <> 16 Then
                Return False
            End If

            Dim intA As Integer = 0
            For i As Integer = 0 To 14 Step 1
                intA += Convert.ToInt32(strValue.Substring(i, 1)) * intX(i)
            Next

            Dim intB As Integer = intA Mod 11
            Dim intC As Integer = 11 - intB

            Dim int16 As Integer = Convert.ToInt32(strValue.Substring(15, 1))
            If intC < 10 Then
                If intC = int16 Then
                    Return True
                End If
            Else
                If int16 = (intC - 10) Then
                    Return True
                End If
            End If

            Return False

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E075(桁数条件チェックデジット2)"
    ''' <summary>
    ''' 桁数条件チェックデジット2
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E075(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try
            Dim strValue As String = GetValue(drwEntry, stcLogic.strItem(0))
            If strValue.Trim.Equals(String.Empty) Then
                Return True
            End If

            Dim intP0 As Integer = Convert.ToInt32(stcLogic.strPara(0))
            If CommonFunctions.LenB(strValue) <> intP0 Then
                Return True
            End If

            If strValue.Length <> 20 Then
                Return False
            End If

            Dim lngValue As Long = Convert.ToInt64(strValue.Substring(0, 15))
            Dim strA As String = Convert.ToString(lngValue, 16).PadLeft(12, "0")
            Dim intA1 As Integer = Convert.ToInt32(strA.Substring(0, 4), 16)
            Dim intA2 As Integer = Convert.ToInt32(strA.Substring(4, 4), 16)
            Dim intA3 As Integer = Convert.ToInt32(strA.Substring(8, 4), 16)
            Dim intB As Integer = intA1 Xor intA2
            Dim strC As String = (intB Xor intA3).ToString("00000")

            If strValue.EndsWith(strC) Then
                Return True
            End If

            Return False

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E076(入力値条件入力数チェック)"
    ''' <summary>
    ''' 入力値条件入力数チェック
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E076(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try
            Dim strI0 As String = GetValue(drwEntry, stcLogic.strItem(0))
            Dim strP0 As String = stcLogic.strPara(0)
            If Not strI0.Equals(strP0) Then
                Return True
            End If

            Dim intP1 As Integer = Convert.ToInt32(stcLogic.strPara(1))
            Dim intCount As Integer = 0
            For i As Integer = 1 To stcLogic.strItem.Length - 1 Step 1
                Dim strI As String = GetValue(drwEntry, stcLogic.strItem(i))
                If strI.Length > 0 Then
                    intCount += 1
                End If
            Next

            If intCount = intP1 Then
                Return True
            End If

            Return False

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E077(桁数条件入力数チェック)"
    ''' <summary>
    ''' 桁数条件入力数チェック
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E077(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try
            Dim strI0 As String = GetValue(drwEntry, stcLogic.strItem(0))
            Dim intP0 As Integer = Convert.ToInt32(stcLogic.strPara(0))
            If strI0.Length <> intP0 Then
                Return True
            End If

            Dim strI1 As String = GetValue(drwEntry, stcLogic.strItem(1))
            Dim intP1 As Integer = Convert.ToInt32(stcLogic.strPara(1))
            If strI1.Length <> intP1 Then
                Return True
            End If

            Dim intP2 As Integer = Convert.ToInt32(stcLogic.strPara(2))
            Dim intCount As Integer = 0
            For i As Integer = 2 To stcLogic.strItem.Length - 1 Step 1
                Dim strI As String = GetValue(drwEntry, stcLogic.strItem(i))
                If strI.Length > 0 Then
                    intCount += 1
                End If
            Next

            If intCount = intP2 Then
                Return True
            End If

            Return False

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region



#Region "E0A2(支払方法不要項目入力チェック)"
    ''' <summary>
    ''' 支払方法不要項目入力チェック
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E0A2(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try

            Dim strValue1 As String = GetValue(drwEntry, stcLogic.strItem(0))
            Dim strValue2 As String = GetValue(drwEntry, stcLogic.strItem(1))

            For Each strP As String In stcLogic.strPara
                Select Case strP.ToUpper
                    Case "NULL"
                        If strValue1.Trim.Length = 0 Then
                            If strValue2.Trim.Length > 0 Then
                                Return False
                            End If
                        End If
                    Case Else
                        If strValue1.Equals(strP) Then
                            If strValue2.Trim.Length > 0 Then
                                Return False
                            End If
                        End If
                End Select
            Next

            Return True

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E0A3(支払方法必須項目未入力チェック)"
    ''' <summary>
    ''' 支払方法必須項目未入力チェック
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E0A3(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try

            Dim strValue1 As String = GetValue(drwEntry, stcLogic.strItem(0))
            Dim strValue2 As String = GetValue(drwEntry, stcLogic.strItem(1))

            For Each strP As String In stcLogic.strPara
                Select Case strP.ToUpper
                    Case "NULL"
                        If strValue1.Trim.Length = 0 Then
                            If strValue2.Trim.Length = 0 Then
                                Return False
                            End If
                        End If
                    Case Else
                        If strValue1.Equals(strP) Then
                            If strValue2.Trim.Length = 0 Then
                                Return False
                            End If
                        End If
                End Select
            Next

            Return True

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E0A5(支払方法必須項目未入力チェック)"
    ''' <summary>
    ''' 支払方法必須項目未入力チェック
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E0A5(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try

            Dim strValue1 As String = GetValue(drwEntry, stcLogic.strItem(0))
            Dim blnAllNull As Boolean = True
            Dim blnNullFound As Boolean = False
            For i As Integer = 1 To stcLogic.strItem.Length - 1 Step 1
                Dim strValue2 As String = GetValue(drwEntry, stcLogic.strItem(i))
                If strValue2.Trim.Length > 0 Then
                    blnAllNull = False
                Else
                    blnNullFound = True
                End If
            Next
            ' 入力対象項目に１つも入力がない場合は例外的に正常扱い
            If blnAllNull Then
                Return True
            End If

            For Each strP As String In stcLogic.strPara
                Select Case strP.ToUpper
                    Case "NULL"
                        If strValue1.Trim.Length = 0 Then
                            If blnNullFound Then
                                Return False
                            End If
                        End If
                    Case Else
                        If strValue1.Equals(strP) Then
                            If blnNullFound Then
                                Return False
                            End If
                        End If
                End Select
            Next

            Return True

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E0A9(チャンネル重複チェック)"
    ''' <summary>
    ''' チャンネル重複チェック
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E0A9(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try

            Dim strValue1 As String = GetValue(drwEntry, stcLogic.strItem(0))
            Dim strValue2 As String = GetValue(drwEntry, stcLogic.strItem(1))
            If strValue1.Trim.Length = 0 Then
                Return True
            End If

            If strValue1.Equals(strValue2) Then
                Return False
            End If

            Return True

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E0B1(キャンペーンコードチェック)"
    ''' <summary>
    ''' キャンペーンコードチェック
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E0B1(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try

            Dim intCount As Integer = 0
            For i As Integer = 1 To stcLogic.strItem.Length - 1 Step 1
                Dim strV As String = GetValue(drwEntry, stcLogic.strItem(i))
                If strV.Trim.Length > 0 Then
                    intCount += 1
                End If
            Next

            Dim strValue As String = GetValue(drwEntry, stcLogic.strItem(0))

            For Each strP As String In stcLogic.strPara
                If strValue.Equals(strP) AndAlso intCount = 0 Then
                    Return False
                End If
            Next

            Return True

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E0B2(未成年チェック)"
    ''' <summary>
    ''' 未成年チェック
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E0B2(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try
            Dim intCount As Integer = 0
            For Each strI As String In stcLogic.strItem
                Dim strV As String = GetValue(drwEntry, strI)
                If strV.Trim.Length > 0 Then
                    intCount += 1
                End If
            Next
            If intCount < 4 Then
                Return True
            End If

            Dim strEra As String = GetValue(drwEntry, stcLogic.strItem(0))
            Dim strYea As String = GetValue(drwEntry, stcLogic.strItem(1))
            Dim strMon As String = GetValue(drwEntry, stcLogic.strItem(2))
            Dim strDay As String = GetValue(drwEntry, stcLogic.strItem(3))

            Dim blnConv As Boolean = False
            Dim datBirth As DateTime = ConvDate(strEra, strYea, strMon, strDay, blnConv)
            If Not blnConv Then
                ' 和暦⇒西暦に失敗した場合は不備
                Return False
            End If

            ' 二十歳になるときの年月日を取得
            Dim str20 As String = datBirth.AddYears(20).ToString("yyyyMMdd")
            ' 現在の年月日を取得
            Dim strNow As String = DateTime.Now.ToString("yyyyMMdd")

            If strNow >= str20 Then
                ' 二十歳になっている
                Return True
            End If

            ' 二十歳になっていない
            For Each strI As String In stcLogic.strPara
                Dim strV As String = GetValue(drwEntry, strI)
                If strV.Trim.Length = 0 Then
                    ' 未入力項目あり
                    Return False
                End If
            Next

            Return True

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E0B3(特定チャンネル複数選択チェック)"
    ''' <summary>
    ''' 特定チャンネル複数選択チェック
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E0B3(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try

            Dim strValue1 As String = GetValue(drwEntry, stcLogic.strItem(0))
            Dim strValue2 As String = GetValue(drwEntry, stcLogic.strItem(1))
            If strValue1.Equals(strValue2) Then
                Return True
            End If

            Dim blnHit1 As Boolean = False
            Dim blnHit2 As Boolean = False
            For Each strP As String In stcLogic.strPara
                If strValue1.Equals(strP) Then
                    blnHit1 = True
                End If
                If strValue2.Equals(strP) Then
                    blnHit2 = True
                End If
            Next

            If blnHit1 AndAlso blnHit2 Then
                Return False
            End If

            Return True

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E0B4(条件桁数チェック)"
    ''' <summary>
    ''' 条件桁数チェック
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E0B4(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try

            Dim strValue1 As String = GetValue(drwEntry, stcLogic.strItem(0))
            If strValue1.Trim.Length > 0 Then
                Return True
            End If

            Dim strValue2 As String = GetValue(drwEntry, stcLogic.strItem(1))
            If strValue2.Trim.Length = 0 Then
                Return True
            End If
            Dim intBytes As Integer = CommonFunctions.LenB(strValue2)

            For Each strP As String In stcLogic.strPara
                Dim intP As Integer = Convert.ToInt32(strP)
                If intP = intBytes Then
                    Return True
                End If
            Next

            Return False

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E0B5(条件不備チェック)"
    ''' <summary>
    ''' 条件不備チェック
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E0B5(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try

            Dim strValue1 As String = GetValue(drwEntry, stcLogic.strItem(0))
            If strValue1.Trim.Length > 0 Then
                Return True
            End If

            Dim strValue2 As String = GetValue(drwEntry, stcLogic.strItem(1))

            For Each strP As String In stcLogic.strPara
                If strValue2.Equals(strP) Then
                    Return False
                End If
            Next

            Return True

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E0B6(条件必須チェック)"
    ''' <summary>
    ''' 条件必須チェック
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E0B6(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try

            Dim strValue1 As String = GetValue(drwEntry, stcLogic.strItem(0))
            If strValue1.Trim.Length > 0 Then
                Return True
            End If

            Dim strValue2 As String = GetValue(drwEntry, stcLogic.strItem(1))
            If strValue2.Trim.Length = 0 Then
                Return False
            End If

            Return True

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E0B7(条件必須チェック)"
    ''' <summary>
    ''' 条件必須チェック
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E0B7(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try

            Dim strValue1 As String = GetValue(drwEntry, stcLogic.strItem(0))
            If strValue1.Trim.Length = 0 Then
                Return True
            End If

            For i As Integer = 1 To stcLogic.strItem.Length - 1 Step 1
                Dim strValue2 As String = GetValue(drwEntry, stcLogic.strItem(i))
                If strValue2.Trim.Length > 0 Then
                    Return True
                End If
            Next

            Return False

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E0B8(桁数条件不要項目入力チェック)"
    ''' <summary>
    ''' 桁数条件不要項目入力チェック
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E0B8(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try

            Dim strValue1 As String = GetValue(drwEntry, stcLogic.strItem(0))
            Dim strValue2 As String = GetValue(drwEntry, stcLogic.strItem(1))

            Dim intP1 As Integer = Convert.ToInt32(stcLogic.strPara(0))

            If CommonFunctions.LenB(strValue1) = intP1 Then
                If strValue2.Length > 0 Then
                    Return False
                End If
            End If

            Return True

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E0B9(条件必須チェック２)"
    ''' <summary>
    ''' 条件必須チェック２
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E0B9(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try

            Dim strValue1 As String = GetValue(drwEntry, stcLogic.strItem(0))
            If strValue1.Trim.Length = 0 Then
                Return True
            End If

            For i As Integer = 1 To stcLogic.strItem.Length - 1 Step 1
                Dim strValue2 As String = GetValue(drwEntry, stcLogic.strItem(i))
                If strValue2.Trim.Length = 0 Then
                    Return True
                End If
            Next

            Return False

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E0BA(条件必須チェック4)"
    ''' <summary>
    ''' 条件必須チェック4
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E0BA(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try

            Dim strValue1 As String = GetValue(drwEntry, stcLogic.strItem(0))
            Dim strValue2 As String = GetValue(drwEntry, stcLogic.strItem(1))

            For Each p As String In stcLogic.strPara
                Dim intP As Integer = Convert.ToInt32(p)
                If strValue1.Length = intP AndAlso strValue2.Length = 0 Then
                    Return False
                End If
            Next

            Return True

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E0BB(条件必須チェック5)"
    ''' <summary>
    ''' 条件必須チェック5
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E0BB(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try

            Dim strValue1 As String = GetValue(drwEntry, stcLogic.strItem(0))
            Dim strValue2 As String = GetValue(drwEntry, stcLogic.strItem(1))

            For Each p As String In stcLogic.strPara
                If strValue1.Equals(p) AndAlso strValue2.Length = 0 Then
                    Return False
                End If
            Next

            Return True

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E0BC(条件必須チェック6)"
    ''' <summary>
    ''' 条件必須チェック6
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E0BC(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try

            Dim strValue1 As String = GetValue(drwEntry, stcLogic.strItem(0))
            Dim strValue2 As String = GetValue(drwEntry, stcLogic.strItem(1))
            Dim strValue3 As String = GetValue(drwEntry, stcLogic.strItem(2))

            If strValue1.Equals(stcLogic.strPara(0)) OrElse strValue1.Equals(stcLogic.strPara(1)) Then
                If strValue2.Equals(stcLogic.strPara(2)) AndAlso strValue3.Length = 0 Then
                    Return False
                End If
            End If

            Return True

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E0BD(条件必須チェック7)"
    ''' <summary>
    ''' 条件必須チェック7
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E0BD(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try

            Dim strValue1 As String = GetValue(drwEntry, stcLogic.strItem(0))
            Dim blnMatchFlg As Boolean = False

            For Each p As String In stcLogic.strPara
                If strValue1.Equals(p) Then
                    blnMatchFlg = True
                End If
            Next

            If blnMatchFlg Then
                For i As Integer = 1 To stcLogic.strItem.Length - 1 Step 1
                    If stcLogic.strItem(i).Length > 0 Then
                        Return True
                    End If
                Next
            Else
                Return True
            End If

            Return False

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E0D2(未来日付チェック)"
    ''' <summary>
    ''' 未来日付チェック
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E0D2(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try
            Dim intCount As Integer = 0
            For Each strI As String In stcLogic.strItem
                Dim strV As String = GetValue(drwEntry, strI)
                If strV.Trim.Length > 0 Then
                    intCount += 1
                End If
            Next
            If intCount < 4 Then
                Return True
            End If

            Dim strEra As String = GetValue(drwEntry, stcLogic.strItem(0))
            Dim strYea As String = GetValue(drwEntry, stcLogic.strItem(1))
            Dim strMon As String = GetValue(drwEntry, stcLogic.strItem(2))
            Dim strDay As String = GetValue(drwEntry, stcLogic.strItem(3))

            Dim blnConv As Boolean = False
            Dim datCheck As DateTime = ConvDate(strEra, strYea, strMon, strDay, blnConv)
            If Not blnConv Then
                ' 和暦⇒西暦に失敗した場合は不備
                Return False
            End If

            ' 入力された日付を西暦のStringへ変換
            Dim strChk As String = datCheck.ToString("yyyyMMdd")
            ' 現在の年月日を取得
            Dim strNow As String = DateTime.Now.ToString("yyyyMMdd")

            If strNow < strChk Then
                ' 未来の日付
                Return False
            End If

            Return True

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E0D3(日付存在チェック元号年月日)"
    ''' <summary>
    ''' 日付存在チェック元号年月日
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E0D3(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try
            'Dim intCount As Integer = 0
            'For Each strI As String In stcLogic.strItem
            '    Dim strV As String = GetValue(drwEntry, strI)
            '    If strV.Trim.Length > 0 Then
            '        intCount += 1
            '    End If
            'Next
            'If intCount < 4 Then
            '    Return False
            'End If

            Dim strEra As String = GetValue(drwEntry, stcLogic.strItem(0))
            Dim strYea As String = GetValue(drwEntry, stcLogic.strItem(1))
            Dim strMon As String = GetValue(drwEntry, stcLogic.strItem(2))
            Dim strDay As String = GetValue(drwEntry, stcLogic.strItem(3))

            If strEra.Length = 0 OrElse _
               strYea.Length = 0 OrElse _
               strYea.Length = 0 OrElse _
               strYea.Length = 0 Then
                Return True
            End If

            Dim blnConv As Boolean = False
            blnConv = CheckDate(strEra, strYea, strMon, strDay)
            If Not blnConv Then
                Return False
            End If

            Return True

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E0D7(過去日付チェック)"
    ''' <summary>
    ''' 過去日付チェック
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E0D7(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try
            Dim intCount As Integer = 0
            For Each strI As String In stcLogic.strItem
                Dim strV As String = GetValue(drwEntry, strI)
                If strV.Trim.Length > 0 Then
                    intCount += 1
                End If
            Next
            If intCount < 4 Then
                Return True
            End If

            Dim strEra As String = GetValue(drwEntry, stcLogic.strItem(0))
            Dim strYea As String = GetValue(drwEntry, stcLogic.strItem(1))
            Dim strMon As String = GetValue(drwEntry, stcLogic.strItem(2))
            Dim strDay As String = GetValue(drwEntry, stcLogic.strItem(3))

            If strEra.Length = 0 OrElse _
               strYea.Length = 0 OrElse _
               strYea.Length = 0 OrElse _
               strYea.Length = 0 Then
                Return True
            End If

            Dim blnConv As Boolean = False
            Dim datCheck As DateTime = ConvDate(strEra, strYea, strMon, strDay, blnConv)
            If Not blnConv Then
                ' 和暦⇒西暦に失敗した場合は不備
                Return False
            End If

            ' 入力された日付を西暦のStringへ変換
            Dim strChk As String = datCheck.ToString("yyyyMMdd")
            ' 現在の年月日を取得
            Dim strNow As String = DateTime.Now.ToString("yyyyMMdd")

            If strNow <= strChk Then
                ' 未来の日付
                Return False
            End If

            Return True

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E0M1(住所マスタ存在チェック)"
    ''' <summary>
    ''' 住所マスタ存在チェック
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E0M1(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try
            Dim strValue1 As String = GetValue(drwEntry, stcLogic.strItem(0))
            Dim strValue2 As String = GetValue(drwEntry, stcLogic.strItem(1))
            Dim strValue3 As String = GetValue(drwEntry, stcLogic.strItem(2))
            Dim strValue4 As String = GetValue(drwEntry, stcLogic.strItem(3))

            Select Case stcLogic.strPara(0)
                Case "ADDRESS_CODE"
                    If strValue2.Length < 6 OrElse strValue2.EndsWith("000000") Then
                        Return False
                    End If
                    Dim dtbADR As DataTable = GetAdressMaster(strValue2)
                    If dtbADR Is Nothing OrElse dtbADR.Rows.Count = 0 Then
                        Return False
                    End If

                Case "ZIP_CODE"
                    Dim dtbADR As DataTable = GetAdressMaster(strValue2)
                    If dtbADR Is Nothing OrElse dtbADR.Rows.Count = 0 Then
                        Return True
                    End If
                    Dim strZip As String = GetValue(dtbADR.Rows(0), "ZIP_CODE")
                    If Not strValue1.Equals(strZip) Then
                        Return False
                    End If

                Case "ADDRESS_KANA"
                    Dim dtbADR As DataTable = GetAdressMaster(strValue2)
                    If dtbADR Is Nothing OrElse dtbADR.Rows.Count = 0 Then
                        Return True
                    End If
                    Dim strKana1 As String = GetValue(dtbADR.Rows(0), "ADDRESS1_KANA").Replace(" ", String.Empty).Replace("　", String.Empty)
                    Dim strKana2 As String = GetValue(dtbADR.Rows(0), "ADDRESS2_KANA").Replace(" ", String.Empty).Replace("　", String.Empty)
                    Dim strKana3 As String = GetValue(dtbADR.Rows(0), "ADDRESS3_KANA").Replace(" ", String.Empty).Replace("　", String.Empty)
                    Dim strKana4 As String = GetValue(dtbADR.Rows(0), "ADDRESS4_KANA").Replace(" ", String.Empty).Replace("　", String.Empty)
                    Dim strKana As String = strKana1 & strKana2 & strKana3 & strKana4
                    Dim strItem As String = strValue3.Replace(" ", String.Empty).Replace("　", String.Empty)
                    If Not strItem.Equals(strKana) Then
                        Return False
                    End If

                Case "ADDRESS_KANJI"
                    Dim dtbADR As DataTable = GetAdressMaster(strValue2)
                    If dtbADR Is Nothing OrElse dtbADR.Rows.Count = 0 Then
                        Return True
                    End If
                    Dim strKanji1 As String = GetValue(dtbADR.Rows(0), "ADDRESS1_KANJI").Replace(" ", String.Empty).Replace("　", String.Empty)
                    Dim strKanji2 As String = GetValue(dtbADR.Rows(0), "ADDRESS2_KANJI").Replace(" ", String.Empty).Replace("　", String.Empty)
                    Dim strKanji3 As String = GetValue(dtbADR.Rows(0), "ADDRESS3_KANJI").Replace(" ", String.Empty).Replace("　", String.Empty)
                    Dim strKanji4 As String = GetValue(dtbADR.Rows(0), "ADDRESS4_KANJI").Replace(" ", String.Empty).Replace("　", String.Empty)
                    Dim strKanji As String = strKanji1 & strKanji2 & strKanji3 & strKanji4
                    Dim strItem As String = strValue4.Replace(" ", String.Empty).Replace("　", String.Empty)
                    If Not strItem.Equals(strKanji) Then
                        Return False
                    End If

                Case Else
                    CommonLog.WriteLog("不明なパラメータを検知しました。", EventLogEntryType.Error)
                    WriteDefine(stcLogic)
                    Return False
            End Select

            Return True

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E0M2(金融機関マスタ存在チェック1)"
    ''' <summary>
    ''' 金融機関マスタ存在チェック1
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E0M2(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try
            Dim intCount As Integer = 0
            For Each strI As String In stcLogic.strItem
                Dim strV As String = GetValue(drwEntry, strI)
                If strV.Trim.Length > 0 Then
                    intCount += 1
                End If
            Next
            If intCount = 0 Then
                Return True
            End If

            Dim strValue1 As String = GetValue(drwEntry, stcLogic.strItem(0))
            Dim strValue2 As String = GetValue(drwEntry, stcLogic.strItem(1))
            Dim strValue3 As String = GetValue(drwEntry, stcLogic.strItem(2))
            Dim strValue4 As String = GetValue(drwEntry, stcLogic.strItem(3))

            If strValue1.Trim.Equals(String.Empty) OrElse strValue2.Trim.Equals(String.Empty) Then
                Return False
            End If

            Dim dtbBNK As DataTable = GetBankMaster(strValue1, strValue2)
            If dtbBNK Is Nothing OrElse dtbBNK.Rows.Count = 0 Then
                Return False
            End If

            For Each dr As DataRow In dtbBNK.Rows
                Dim strNameG As String = GetValue(dr, "BANK_KANJI")
                Dim strNameS As String = GetValue(dr, "BRANCH_KANJI")
                If strNameG.Equals(strValue3) AndAlso strNameS.Equals(strValue4) Then
                    Return True
                End If
            Next

            Return False

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E0M3(金融機関マスタ存在チェック2)"
    ''' <summary>
    ''' 金融機関マスタ存在チェック2
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E0M3(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try
            Dim intCount As Integer = 0
            For Each strI As String In stcLogic.strItem
                Dim strV As String = GetValue(drwEntry, strI)
                If strV.Trim.Length > 0 Then
                    intCount += 1
                End If
            Next
            If intCount = 0 Then
                Return True
            End If

            Dim strValue1 As String = GetValue(drwEntry, stcLogic.strItem(0))
            Dim strValue2 As String = GetValue(drwEntry, stcLogic.strItem(1))

            If strValue1.Trim.Equals(String.Empty) OrElse strValue2.Trim.Equals(String.Empty) Then
                Return False
            End If

            Dim dtbBNK As DataTable = GetBankMaster(strValue1, strValue2)
            If dtbBNK Is Nothing OrElse dtbBNK.Rows.Count = 0 Then
                Return False
            End If

            Return True

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E0M4(商品マスタ存在チェック)"
    ''' <summary>
    ''' 商品マスタ存在チェック
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E0M4(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try

            Dim strValue As String = GetValue(drwEntry, stcLogic.strItem(0))
            If strValue.Trim.Length = 0 Then
                Return True
            End If

            Dim strParam As String = stcLogic.strPara(0)

            Dim stbCond As New StringBuilder(String.Empty)
            stbCond.Append("SRV = '%SRV%' AND C3 = '%C3%'")
            stbCond.Replace("%SRV%", strParam)
            stbCond.Replace("%C3%", strValue)
            Dim drw() As DataRow = mdtbMaster.Select(stbCond.ToString)
            If drw.Length = 0 Then
                Return False
            End If

            Return True

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E0M5(商品マスタ存在チェック2)"
    ''' <summary>
    ''' 商品マスタ存在チェック2
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E0M5(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try

            Dim strValue1 As String = GetValue(drwEntry, stcLogic.strItem(0))
            If strValue1.Trim.Length = 0 Then
                Return True
            End If

            Dim strValue2 As String = GetValue(drwEntry, stcLogic.strItem(1))
            If strValue2.Trim.Length = 0 Then
                Return True
            End If

            Dim strParam As String = stcLogic.strPara(0)
            Dim strKey As String = String.Empty
            Select Case strParam
                Case "111"  ' スカパー
                    If strValue2.Trim.Length = 1 Then
                        Return True
                    End If
                    strKey = "E0M5_MSTKEY_" & strParam & "_" & strValue2.Substring(0, 2)
                Case "121"  ' ｅ２
                    strKey = "E0M5_MSTKEY_" & strParam & "_" & strValue2
                Case Else
                    Throw New Exception("使用できない引数があります。")
            End Select

            If Not mdicConfig.ContainsKey(strKey) Then
                Return True
            End If

            Dim strName As String = String.Empty
            strName = mdicConfig(strKey)

            ' システム日付
            Dim strSysDate As String = SysDate()

            ' 契約コースマスタからデータ取得
            Dim stbSel As New StringBuilder(String.Empty)
            stbSel.Append("SRV_CTRCT_KIND_CD   = '%KIND%' ")
            stbSel.Append("AND ")
            stbSel.Append("PRS_CTRCT_CRSE_NAME = '%NAME%' ")
            stbSel.Append("AND ")
            stbSel.Append("APLY_STRT_D        <= '%DATE%' ")
            stbSel.Append("AND ")
            stbSel.Append("APLY_END_D         >= '%DATE%' ")
            stbSel.Replace("%KIND%", strParam)
            stbSel.Replace("%NAME%", strName)
            stbSel.Replace("%DATE%", strSysDate)
            Dim drwC() As DataRow
            drwC = mdtbMaster2.Select(stbSel.ToString)
            If drwC.Length = 0 Then
                stbSel.Length = 0
                stbSel.Append("SRV_CTRCT_KIND_CD   = '%KIND%' ")
                stbSel.Append("AND ")
                stbSel.Append("PRS_CTRCT_CRSE_NAME = '%NAME%' ")
                stbSel.Replace("%KIND%", strParam)
                stbSel.Replace("%NAME%", strName)
                drwC = mdtbMaster2.Select(stbSel.ToString)
                If drwC.Length = 0 Then
                    Return False
                End If
            End If

            ' 個人契約コース
            Dim strC3 As String = Convert.ToString(drwC(0).Item("PRS_CTRCT_CRSE"))

            ' 商品マスタ存在チェック
            Dim stbCond As New StringBuilder(String.Empty)
            stbCond.Append("SRV = '%SRV%' AND CS = '%CS%' AND C3 = '%C3%'")
            stbCond.Replace("%SRV%", strParam)
            stbCond.Replace("%CS%", strC3)
            stbCond.Replace("%C3%", strValue1)
            Dim drw() As DataRow = mdtbMaster.Select(stbCond.ToString)
            If drw.Length = 0 Then
                Return False
            End If

            Return True

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E0M6(商品マスタ存在チェック3)"
    ''' <summary>
    ''' 商品マスタ存在チェック3
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E0M6(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try

            Dim strValue1 As String = GetValue(drwEntry, stcLogic.strItem(0))
            If strValue1.Trim.Length = 0 Then
                CommonLog.WriteLog("Value1がNULLです[" & stcLogic.strItem(0) & "]", EventLogEntryType.Information)
                Return True
            End If

            Dim strValue2 As String = GetValue(drwEntry, stcLogic.strItem(1))
            If strValue2.Trim.Length = 0 Then
                CommonLog.WriteLog("Value2がNULLです[" & stcLogic.strItem(1) & "]", EventLogEntryType.Information)
                Return True
            End If

            Dim strParam As String = stcLogic.strPara(0)
            Dim strKey As String = String.Empty
            Select Case strParam
                Case "111"  ' スカパー
                    If strValue2.Trim.Length = 1 Then
                        CommonLog.WriteLog("Value2が1桁です[" & stcLogic.strItem(1) & "]", EventLogEntryType.Information)
                        Return True
                    End If
                    strKey = "E0M6_MSTKEY_" & strParam & "_" & strValue2.Substring(0, 2)
                Case "121"  ' ｅ２
                    strKey = "E0M6_MSTKEY_" & strParam & "_" & strValue2
                Case Else
                    Throw New Exception("使用できない引数があります。")
            End Select

            If Not mdicConfig.ContainsKey(strKey) Then
                CommonLog.WriteLog("KeyがConfigに存在しません[" & strKey & "]", EventLogEntryType.Information)
                Return True
            End If

            Dim strName As String = String.Empty
            strName = mdicConfig(strKey)

            ' システム日付
            Dim strSysDate As String = SysDate()

            ' 契約コースマスタからデータ取得
            Dim stbSel As New StringBuilder(String.Empty)
            stbSel.Append("SRV_CTRCT_KIND_CD   = '%KIND%' ")
            stbSel.Append("AND ")
            stbSel.Append("PRS_CTRCT_CRSE_NAME = '%NAME%' ")
            stbSel.Append("AND ")
            stbSel.Append("APLY_STRT_D        <= '%DATE%' ")
            stbSel.Append("AND ")
            stbSel.Append("APLY_END_D         >= '%DATE%' ")
            stbSel.Replace("%KIND%", strParam)
            stbSel.Replace("%NAME%", strName)
            stbSel.Replace("%DATE%", strSysDate)
            Dim drwC() As DataRow
            drwC = mdtbMaster2.Select(stbSel.ToString)
            If drwC.Length = 0 Then
                stbSel.Length = 0
                stbSel.Append("SRV_CTRCT_KIND_CD   = '%KIND%' ")
                stbSel.Append("AND ")
                stbSel.Append("PRS_CTRCT_CRSE_NAME = '%NAME%' ")
                stbSel.Replace("%KIND%", strParam)
                stbSel.Replace("%NAME%", strName)
                drwC = mdtbMaster2.Select(stbSel.ToString)
                If drwC.Length = 0 Then
                    Dim a As String = strParam & "|" & strName
                    CommonLog.WriteLog("契約コースマスタに存在しません[" & a & "]", EventLogEntryType.Information)
                    Return False
                End If
            End If

            ' 個人契約コース
            Dim strC3 As String = Convert.ToString(drwC(0).Item("PRS_CTRCT_CRSE"))

            ' 商品マスタ存在チェック
            Dim stbCond As New StringBuilder(String.Empty)
            stbCond.Append("SRV = '%SRV%' AND CS = '%CS%' AND C3 = '%C3%'")
            stbCond.Replace("%SRV%", strParam)
            stbCond.Replace("%CS%", strC3)
            stbCond.Replace("%C3%", strValue1)
            Dim drw() As DataRow = mdtbMaster.Select(stbCond.ToString)
            If drw.Length = 0 Then
                Dim a As String = strParam & "|" & strC3 & strValue1
                CommonLog.WriteLog("商品マスタに存在しません[" & a & "]", EventLogEntryType.Information)
                Return False
            End If

            CommonLog.WriteLog("E0M6正常完了", EventLogEntryType.Information)
            Return True

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E0M7(住所マスタ存在チェック)"
    ''' <summary>
    ''' 住所マスタ存在チェック
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E0M7(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try
            Dim strValue1 As String = GetValue(drwEntry, stcLogic.strItem(0))
            Dim strValue2 As String = GetValue(drwEntry, stcLogic.strItem(1))
            Dim strValue3 As String = GetValue(drwEntry, stcLogic.strItem(2))
            Dim strValue4 As String = GetValue(drwEntry, stcLogic.strItem(3))

            If strValue1.Length = 0 AndAlso _
               strValue2.Length = 0 AndAlso _
               strValue3.Length = 0 AndAlso _
               strValue4.Length = 0 Then
                Return True
            End If

            Select Case stcLogic.strPara(0)
                Case "ADDRESS_CODE"
                    If strValue2.Length < 6 OrElse strValue2.EndsWith("000000") Then
                        Return False
                    End If
                    Dim dtbADR As DataTable = GetAdressMaster(strValue2)
                    If dtbADR Is Nothing OrElse dtbADR.Rows.Count = 0 Then
                        Return False
                    End If

                Case "ZIP_CODE"
                    Dim dtbADR As DataTable = GetAdressMaster(strValue2)
                    If dtbADR Is Nothing OrElse dtbADR.Rows.Count = 0 Then
                        Return True
                    End If
                    Dim strZip As String = GetValue(dtbADR.Rows(0), "ZIP_CODE")
                    If Not strValue1.Equals(strZip) Then
                        Return False
                    End If

                Case "ADDRESS_KANA"
                    Dim dtbADR As DataTable = GetAdressMaster(strValue2)
                    If dtbADR Is Nothing OrElse dtbADR.Rows.Count = 0 Then
                        Return True
                    End If
                    Dim strKana1 As String = GetValue(dtbADR.Rows(0), "ADDRESS1_KANA").Replace(" ", String.Empty).Replace("　", String.Empty)
                    Dim strKana2 As String = GetValue(dtbADR.Rows(0), "ADDRESS2_KANA").Replace(" ", String.Empty).Replace("　", String.Empty)
                    Dim strKana3 As String = GetValue(dtbADR.Rows(0), "ADDRESS3_KANA").Replace(" ", String.Empty).Replace("　", String.Empty)
                    Dim strKana4 As String = GetValue(dtbADR.Rows(0), "ADDRESS4_KANA").Replace(" ", String.Empty).Replace("　", String.Empty)
                    Dim strKana As String = strKana1 & strKana2 & strKana3 & strKana4
                    Dim strItem As String = strValue3.Replace(" ", String.Empty).Replace("　", String.Empty)
                    If Not strItem.Equals(strKana) Then
                        Return False
                    End If

                Case "ADDRESS_KANJI"
                    Dim dtbADR As DataTable = GetAdressMaster(strValue2)
                    If dtbADR Is Nothing OrElse dtbADR.Rows.Count = 0 Then
                        Return True
                    End If
                    Dim strKanji1 As String = GetValue(dtbADR.Rows(0), "ADDRESS1_KANJI").Replace(" ", String.Empty).Replace("　", String.Empty)
                    Dim strKanji2 As String = GetValue(dtbADR.Rows(0), "ADDRESS2_KANJI").Replace(" ", String.Empty).Replace("　", String.Empty)
                    Dim strKanji3 As String = GetValue(dtbADR.Rows(0), "ADDRESS3_KANJI").Replace(" ", String.Empty).Replace("　", String.Empty)
                    Dim strKanji4 As String = GetValue(dtbADR.Rows(0), "ADDRESS4_KANJI").Replace(" ", String.Empty).Replace("　", String.Empty)
                    Dim strKanji As String = strKanji1 & strKanji2 & strKanji3 & strKanji4
                    Dim strItem As String = strValue4.Replace(" ", String.Empty).Replace("　", String.Empty)
                    If Not strItem.Equals(strKanji) Then
                        Return False
                    End If

                Case Else
                    CommonLog.WriteLog("不明なパラメータを検知しました。", EventLogEntryType.Error)
                    WriteDefine(stcLogic)
                    Return False
            End Select

            Return True

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E0MA(住所マスタ存在チェック)"
    ''' <summary>
    ''' 住所マスタ存在チェック
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E0MA(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try
            Dim strValue1 As String = GetValue(drwEntry, stcLogic.strItem(0))
            Dim strValue2 As String = GetValue(drwEntry, stcLogic.strItem(1))

            If strValue1.Length = 0 Then
                Return True
            End If

            ' システム日付
            Dim strSysDate As String = SysDate()

            Select Case strValue2.Length
                Case 16
                    Dim strName As String
                    Select Case strValue2.Substring(0, 2)
                        Case "00"
                            strName = "一般個人（標準画質）"
                        Case "03"
                            strName = "一般個人（標準画質）"
                        Case "05"
                            strName = "一般個人（標準画質）"
                        Case "06"
                            strName = "一般個人（標準画質）"
                        Case "20"
                            strName = "一般個人"
                        Case "21"
                            strName = "一般個人（Ｈ．２６４）"
                        Case Else
                            Return False
                    End Select
                    Dim strKey As String = String.Empty
                    ' 契約コースマスタからデータ取得
                    Dim stbSel As New StringBuilder(String.Empty)
                    stbSel.Append("SRV_CTRCT_KIND_CD   = '111' ")
                    stbSel.Append("AND ")
                    stbSel.Append("PRS_CTRCT_CRSE_NAME = '%NAME%' ")
                    stbSel.Append("AND ")
                    stbSel.Append("APLY_STRT_D        <= '%DATE%' ")
                    stbSel.Append("AND ")
                    stbSel.Append("APLY_END_D         >= '%DATE%' ")
                    stbSel.Replace("%NAME%", strName)
                    stbSel.Replace("%DATE%", strSysDate)
                    Dim drwC() As DataRow
                    drwC = mdtbMaster2.Select(stbSel.ToString)
                    If drwC.Length = 0 Then
                        Return False
                    End If
                    ' 個人契約コース
                    Dim strC3 As String = Convert.ToString(drwC(0).Item("PRS_CTRCT_CRSE"))
                    ' 商品マスタ存在チェック
                    Dim stbCond As New StringBuilder(String.Empty)
                    stbCond.Append("SRV = '111' AND CS = '%CS%' AND C3 = '%C3%'")
                    stbCond.Replace("%CS%", strC3)
                    stbCond.Replace("%C3%", strValue1)
                    Dim drw() As DataRow = mdtbMaster.Select(stbCond.ToString)
                    If drw.Length = 0 Then
                        Return False
                    End If

                Case 20
                    ' 商品マスタ存在チェック
                    Dim stbCond As New StringBuilder(String.Empty)
                    stbCond.Append("SRV = '121' AND C3 = '%C3%'")
                    stbCond.Replace("%C3%", strValue1)
                    Dim drw() As DataRow = mdtbMaster.Select(stbCond.ToString)
                    If drw.Length = 0 Then
                        Return False
                    End If

                Case Else
                    Return True

            End Select

            Return True

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region

#Region "E0MB(商品マスタ存在チェック)"
    ''' <summary>
    ''' 商品マスタ存在チェック
    ''' </summary>
    ''' <param name="stcLogic">チェック定義情報</param>
    ''' <param name="drwEntry">エントリ結果</param>
    ''' <returns>不備なし:True　不備あり:False</returns>
    ''' <remarks>
    ''' </remarks>
    Public Shared Function E0MB(ByVal stcLogic As clsDefectCheckMain.CheckLogic, ByVal drwEntry As DataRow) As Boolean
        Try
            Dim strValue1 As String = GetValue(drwEntry, stcLogic.strItem(0))
            Dim strValue2 As String = GetValue(drwEntry, stcLogic.strItem(1))

            If strValue1.Length = 0 Then
                Return True
            End If
            If strValue2.Length = 0 Then
                Return True
            End If

            Select Case strValue1.Length
                Case 16
                    If clsDefectCheckMain.Get16(strValue2).Length = 0 Then
                        Return False
                    End If
                Case 20
                    If clsDefectCheckMain.Get20(strValue2).Length = 0 Then
                        Return False
                    End If
            End Select

            Return True

        Catch ex As Exception

            CommonLog.WriteLog("エラーを検出しました。", EventLogEntryType.Error)
            WriteDefine(stcLogic)
            Throw ex

        End Try
    End Function
#End Region



#Region "エントリ内容の取得"
    Private Shared Function GetValue(ByVal dr As DataRow, ByVal cd As String) As String
        Return Convert.ToString(dr.Item(cd))
    End Function
#End Region

#Region "チェック定義ログ出力"
    Private Shared Sub WriteDefine(ByVal stcLogic As clsDefectCheckMain.CheckLogic)
        CommonLog.WriteLog("帳票ID      = " & stcLogic.strSlipID, EventLogEntryType.Error)
        CommonLog.WriteLog("連番        = " & stcLogic.strSeq, EventLogEntryType.Error)
        CommonLog.WriteLog("チェック概要= " & stcLogic.strInf, EventLogEntryType.Error)
        CommonLog.WriteLog("メソッドID  = " & stcLogic.strMethodCode, EventLogEntryType.Error)
    End Sub
#End Region

#Region "和暦→西暦変換"
    ''' ======================================================================
    ''' メソッド名：ConvDate
    ''' <summary>
    ''' 和暦→西暦変換
    ''' </summary>
    ''' <param name="strEra">元号</param>
    ''' <param name="strYear">年</param>
    ''' <param name="strMonth">月</param>
    ''' <param name="strDay">日</param>
    ''' <param name="blnConvertFlg">変換結果</param>
    ''' <remarks>
    ''' 元号・年・月・日の整合性をチェックしてから西暦に変換します。
    ''' </remarks>
    ''' ======================================================================
    Private Shared Function ConvDate(ByVal strEra As String, _
                                     ByVal strYear As String, _
                                     ByVal strMonth As String, _
                                     ByVal strDay As String, _
                                     ByRef blnConvertFlg As Boolean) As DateTime

        Try
            Dim sysDate As DateTime

            If strEra.Trim.Equals(String.Empty) Then
                blnConvertFlg = False
                Return Nothing
            End If

            Try
                Dim intYear As Integer = Convert.ToInt32(strYear)
                Dim intMonth As Integer = Convert.ToInt32(strMonth)
                Dim intDay As Integer = Convert.ToInt32(strDay)
                Dim intEra As Integer = Convert.ToInt32(strEra)
                If intEra = 9 Then
                    sysDate = New DateTime(intYear, intMonth, intDay)
                Else
                    ' 和暦カレンダクラス
                    Dim clsJCal As New System.Globalization.JapaneseCalendar
                    sysDate = clsJCal.ToDateTime(intYear, intMonth, intDay, 0, 0, 0, 0, intEra)
                End If
                blnConvertFlg = True
            Catch ex As Exception
                ' 変換エラーの場合、エラー判定フラグにFalseを設定
                blnConvertFlg = False
                sysDate = Nothing

            End Try

            Return sysDate

        Catch ex As Exception

            ' ログ出力
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            Throw New Exception("日付変換エラー")

        End Try

    End Function
#End Region

#Region "和暦→西暦チェック"
    ''' ======================================================================
    ''' メソッド名：ConvDate
    ''' <summary>
    ''' 和暦→西暦チェック
    ''' </summary>
    ''' <param name="strEra">元号</param>
    ''' <param name="strYear">年</param>
    ''' <param name="strMonth">月</param>
    ''' <param name="strDay">日</param>
    ''' <remarks>
    ''' 元号・年・月・日の整合性をチェックする
    ''' </remarks>
    ''' ======================================================================
    Private Shared Function CheckDate(ByVal strEra As String, _
                                      ByVal strYear As String, _
                                      ByVal strMonth As String, _
                                      ByVal strDay As String) As Boolean

        Try
            Dim sysDate As DateTime

            Select Case strEra
                Case "1", "2", "3", "4", "9"
                Case Else
                    Return False
            End Select

            ' 和暦カレンダクラス
            Dim clsJCal As New System.Globalization.JapaneseCalendar

            Try
                Dim intYear As Integer = Convert.ToInt32(strYear)
                Dim intMonth As Integer = Convert.ToInt32(strMonth)
                Dim intDay As Integer = Convert.ToInt32(strDay)
                Dim intEra As Integer = Convert.ToInt32(strEra)
                If intEra = 9 Then
                    sysDate = New DateTime(intYear, intMonth, intDay)
                Else
                    sysDate = clsJCal.ToDateTime(intYear, intMonth, intDay, 0, 0, 0, 0, intEra)
                End If
            Catch ex As Exception
                ' 変換エラーの場合
                Return False
            End Try

            Dim intSubEra As Integer = clsJCal.GetEra(sysDate)
            Select Case strEra
                Case "1", "2", "3", "4"
                    Dim intEra As Integer = Convert.ToInt32(strEra)
                    If intSubEra <> intEra Then
                        Return False
                    End If
                Case "9"
                    If intSubEra < 1 OrElse intSubEra > 4 Then
                        Return False
                    End If
            End Select

            Return True

        Catch ex As Exception

            ' ログ出力
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            Throw New Exception("日付チェックエラー")

        End Try

    End Function
#End Region

#Region "住所マスタ検索"
    Private Shared Function GetAdressMaster(ByVal strKey As String) As DataTable
        Try
            Dim stbSQL As New StringBuilder(String.Empty)
            stbSQL.AppendLine("SELECT * FROM M_CM_ADDRESS WHERE ADDRESS_CODE = '%CODE%'")
            stbSQL.Replace("%CODE%", strKey)
            Dim dtbAdr As DataTable = comDB.DB_ExecuteQuery(stbSQL.ToString)
            Return dtbAdr

        Catch ex As Exception
            ' ログ出力
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            Throw New Exception("住所マスタ検索エラー")
        End Try
    End Function
#End Region

#Region "金融機関マスタ検索"
    Private Shared Function GetBankMaster(ByVal strKey1 As String, ByVal strKey2 As String) As DataTable
        Try
            Dim stbSQL As New StringBuilder(String.Empty)
            stbSQL.AppendLine("SELECT * FROM M_CM_BANK")
            stbSQL.AppendLine("WHERE BANK_CODE = '%BANK%' AND BRANCH_CODE = '%BRNC%'")
            stbSQL.Replace("%BANK%", strKey1)
            stbSQL.Replace("%BRNC%", strKey2)
            Dim dtbBnk As DataTable = comDB.DB_ExecuteQuery(stbSQL.ToString)
            Return dtbBnk

        Catch ex As Exception
            ' ログ出力
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            Throw New Exception("住所マスタ検索エラー")
        End Try
    End Function
#End Region

#Region "システム日付の取得"
    Private Shared Function SysDate() As String
        Try
            Dim dt As DataTable = comDB.DB_ExecuteQuery("SELECT TO_CHAR(SYSDATE,'YYYYMMDD') FROM DUAL")
            Return Convert.ToString(dt.Rows(0).Item(0))
        Catch ex As Exception
            ' ログ出力
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            Throw New Exception("システム日付取得エラー")
        End Try
    End Function
#End Region

End Class
