﻿Imports CommonSystem
Imports System
Imports System.Text

Imports Oracle.DataAccess.Client

''' ======================================================================
''' クラス名：clsBatchBase
''' <summary>
''' 継承元クラス
''' </summary>
''' <remarks>
''' 処理の初期化処理等々
''' </remarks>
''' ======================================================================
Public MustInherit Class clsBatchBase

#Region "変数域"

    ''' <summary>
    ''' DBアクセスクラス
    ''' </summary>
    ''' <remarks></remarks>
    Protected mobjCommonDB As CommonDB

    ''' <summary>
    ''' DB接続設定PreFix
    ''' </summary>
    ''' <remarks></remarks>
    Protected mstrCompanyCode As String


    ''' <summary>
    ''' 起動引数
    ''' </summary>
    ''' <remarks></remarks>
    Protected mstrArgs() As String

    ''' <summary>
    ''' App構成ファイル
    ''' </summary>
    ''' <remarks></remarks>
    Protected mdicConfig As New Dictionary(Of String, String)


#End Region

#Region "[Execute]"

    ''' ======================================================================
    ''' メソッド名：Execute
    ''' <summary>
    ''' メイン処理
    ''' </summary>
    ''' <remarks></remarks>
    ''' ======================================================================
    Protected MustOverride Sub Execute()

#End Region

#Region "初期処理[Run]"

    ''' ======================================================================
    ''' メソッド名：Run
    ''' <summary>
    ''' 継承元初期処理
    ''' </summary>
    ''' <remarks></remarks>
    ''' ======================================================================
    Protected Overridable Overloads Function Run() As Integer

        Try

            If CommonProcess.ProcessExecCheck = False Then
                Return 0
            End If

            ' コマンドライン引数取得
            Call setCommandLine()

            ' App構成ファイル情報取得
            Call setConfig()

            ' DB接続
            Call setDataBase()

            ' ログ情報設定
            Call setLogOutput()

            WriteLog("★処理開始★", EventLogEntryType.SuccessAudit)

            ' 各メソッド毎の処理を行う
            Call Execute()

            WriteLog("★処理終了★", EventLogEntryType.SuccessAudit)

            Return 0

        Catch ex As Exception
            ' イベントログ出力処理
            WriteLog(ex.Message, EventLogEntryType.Error)
            WriteLog(ex.StackTrace, EventLogEntryType.Error)
            Return 1
        End Try

    End Function

#End Region

#Region "初期処理[Run]"

    ''' ======================================================================
    ''' メソッド名：Run
    ''' <summary>
    ''' 継承元初期処理
    ''' </summary>
    ''' <remarks></remarks>
    ''' ======================================================================
    Protected Overridable Overloads Function Run(ByVal intRun As Boolean) As Integer

        Try

            If CommonProcess.ProcessExecCheck = False Then
                Return 0
            End If

            ' コマンドライン引数取得
            Call setCommandLine()

            ' App構成ファイル情報取得
            Call setConfig()

            ' ログ情報設定
            Call setLogOutput()

            WriteLog("☆処理開始☆", EventLogEntryType.SuccessAudit)

            ' 各メソッド毎の処理を行う
            Call Execute()

            WriteLog("☆処理終了☆", EventLogEntryType.SuccessAudit)

            Return 0

        Catch ex As Exception
            ' イベントログ出力処理
            WriteLog(ex.Message, EventLogEntryType.Error)
            WriteLog(ex.StackTrace, EventLogEntryType.Error)
            Return 1
        End Try

    End Function

#End Region

#Region "コマンドライン取得[setCommandLine]"

    ''' ======================================================================
    ''' メソッド名：setCommandLine
    ''' <summary>
    ''' コマンドライン取得処理
    ''' </summary>
    ''' <remarks></remarks>
    ''' ======================================================================
    Protected Overridable Overloads Sub setCommandLine()

        'コマンドラインを配列で取得する
        mstrArgs = System.Environment.GetCommandLineArgs()

        '' コマンドライン引数チェック
        'If mstrArgs.Length <> getArgSize() Then
        '    Throw New Exception("コマンドライン引数が[" & mstrArgs.Length.ToString & "]件です。")
        'End If

    End Sub

#End Region

#Region "App構成ファイル情報取得[setConfig]"
    ''' ======================================================================
    ''' メソッド名：setConfig
    ''' <summary>
    ''' DB接続処理
    ''' </summary>
    ''' <remarks>不要時はオーバーライドし、空メソッド作成してね</remarks>
    ''' ======================================================================

    Protected Overridable Overloads Sub setConfig()

        Dim key As String

        For Each key In System.Configuration.ConfigurationManager.AppSettings.AllKeys
            mdicConfig.Add(key, System.Configuration.ConfigurationManager.AppSettings(key))
        Next

    End Sub

#End Region

#Region "データベース接続[setDataBase]"

    ''' ======================================================================
    ''' メソッド名：setDataBase
    ''' <summary>
    ''' DB接続処理
    ''' </summary>
    ''' <remarks>DB非接続時はオーバーライドし、空メソッド作成してね</remarks>
    ''' ======================================================================
    Protected Overridable Overloads Sub setDataBase()

        mobjCommonDB = New CommonDB

        If mobjCommonDB.DB_Open(mdicConfig(clsConst.CONF_DB_CONFIG_PREFIX)) = False Then
            Throw New Exception("DB接続に失敗しました")
        End If

    End Sub

#End Region

#Region "データベース接続[setDataBase]"

    ''' ======================================================================
    ''' メソッド名：getArgSize
    ''' <summary>
    ''' DB接続処理
    ''' </summary>
    ''' <remarks>起動引数の数を返す</remarks>
    ''' ======================================================================
    Protected Overridable Overloads Function getArgSize() As Integer

        Return 1

    End Function

#End Region

#Region "ログ出力モード設定"

    ''' ======================================================================
    ''' メソッド名：setLogOutput
    ''' <summary>
    ''' Log出力モード設定処理
    ''' </summary>
    ''' <remarks></remarks>
    ''' ======================================================================
    Private Sub setLogOutput()

        'ログ出力レベル設定
        If mdicConfig.ContainsKey(clsConst.CONF_LOG_OUTPUT_LEVEL) Then
            CommonLog.SetLogOutputMode = System.Int32.Parse(mdicConfig(clsConst.CONF_LOG_OUTPUT_LEVEL))
        Else
            CommonLog.SetLogOutputMode = CommonLog.LogOutputMode.Silent
        End If

        'ログ日時分割出力モード設定
        If mdicConfig.ContainsKey(clsConst.CONF_LOG_DIVIDE_MODE) Then
            CommonLog.SetLogDateHourDivideMode = System.Int32.Parse(mdicConfig(clsConst.CONF_LOG_DIVIDE_MODE))
        Else
            CommonLog.SetLogDateHourDivideMode = CommonLog.LogDateHourDivideMode.Normal
        End If

        ' 2011/02/02 shinohara
        ' ログの出力先を実行ファイルPath＋"LOG"にします。
        Dim strExecutePath As String = IO.Path.GetDirectoryName(Windows.Forms.Application.ExecutablePath)
        Dim strLogOutputPath As String = IO.Path.Combine(strExecutePath, "log")
        CommonLog.SetLogFileOutputPath = strLogOutputPath

        ' 2011/02/02 shinohara
        ' コンフィグに削除期間が指定されている場合は該当期間のログファイルを削除します。
        If mdicConfig.ContainsKey(clsConst.CONF_LOG_KEEP_DAYS_CODE) Then
            Dim intDays As Integer = Convert.ToInt32(mdicConfig(clsConst.CONF_LOG_KEEP_DAYS_CODE))
            CommonLog.DeleteLogFile(intDays)
        End If


    End Sub

#End Region

#Region "ログ出力"
    ''' <summary>
    ''' ログ出力
    ''' </summary>
    ''' <param name="strMessage"></param>
    ''' <param name="EntryType"></param>
    ''' <remarks></remarks>
    Protected Sub WriteLog(ByVal strMessage As String, ByVal EntryType As Diagnostics.EventLogEntryType)

        CommonLog.WriteLog(strMessage, EntryType)
        If EntryType = EventLogEntryType.Error Or EntryType = EventLogEntryType.Warning Then
            WriteEventLog(strMessage, EntryType)
        End If

    End Sub
#End Region

#Region "イベントログ書き込み処理[WriteEventLog]"
    ''' ======================================================================
    ''' メソッド名：WriteEventLog
    ''' <summary>
    ''' イベントログに書き込む
    ''' </summary>
    ''' <remarks></remarks>
    ''' ======================================================================
    Protected Sub WriteEventLog(ByVal strMsg As String, ByVal EntryType As Diagnostics.EventLogEntryType)

        Dim sbEvent As New System.Text.StringBuilder
        Call sbEvent.AppendLine("処理区分：[COMPANY=" & mdicConfig(clsConst.CONF_COMPANY_CODE) & "]")
        Call sbEvent.AppendLine("機能名：[" & Me.GetType.Assembly.GetName.Name & "]")
        Call sbEvent.AppendLine("通知内容：" & strMsg & "")
        'アプリケーションログに出力する
        Call Diagnostics.EventLog.WriteEntry(mdicConfig(clsConst.CONF_COMPANY_CODE), sbEvent.ToString, EntryType)

    End Sub

#End Region

    '#Region "イメージステータス更新"
    '    ''' <summary>
    '    ''' イメージステータス更新
    '    ''' </summary>
    '    ''' <param name="strImageID">イメージID</param>
    '    ''' <param name="strAuthoriStatus">オーソリステータス</param>
    '    ''' <param name="strImageStatus">イメージステータス</param>
    '    ''' <remarks></remarks>
    '    Protected Sub UpdateImageStatus(ByVal strImageID As String, ByVal strAuthoriStatus As String, Optional ByVal strImageStatus As String = Nothing)

    '        Try
    '            ' T_JJ_IMAGE更新SQL作成
    '            Dim stbUpdateSQL As New StringBuilder(String.Empty)
    '            stbUpdateSQL.AppendLine("UPDATE")
    '            stbUpdateSQL.AppendLine("    T_JJ_IMAGE")
    '            stbUpdateSQL.AppendLine("SET")
    '            If Not String.IsNullOrEmpty(strImageStatus) Then
    '                stbUpdateSQL.AppendLine("    IMAGE_STATUS = :ImageStatus,")
    '            End If
    '            stbUpdateSQL.AppendLine("    EXC_IMAGE_KEY04 = :AuthoriStatus,")
    '            stbUpdateSQL.AppendLine("    UPDATE_USER  = :UserID,")
    '            stbUpdateSQL.AppendLine("    UPDATE_DATE  = SYSDATE")
    '            stbUpdateSQL.AppendLine("WHERE")
    '            stbUpdateSQL.AppendLine("    IMAGE_ID = :ImageID")

    '            'イメージテーブル更新用パラメータ設定
    '            Dim lstUpdateParam As New List(Of OracleParameter)
    '            If Not String.IsNullOrEmpty(strImageStatus) Then
    '                lstUpdateParam.Add(New OracleParameter("ImageStatus", OracleDbType.Char, strImageStatus, ParameterDirection.Input))
    '            End If
    '            lstUpdateParam.Add(New OracleParameter("AuthoriStatus", OracleDbType.Char, strAuthoriStatus, ParameterDirection.Input))
    '            lstUpdateParam.Add(New OracleParameter("UserID", OracleDbType.Varchar2, My.Application.Info.AssemblyName, ParameterDirection.Input))
    '            lstUpdateParam.Add(New OracleParameter("ImageID", OracleDbType.Decimal, strImageID, ParameterDirection.Input))

    '            'SQL実行
    '            If Me.mobjCommonDB.DB_ExecuteNonQuery(stbUpdateSQL.ToString(), lstUpdateParam.ToArray()) < 1 Then
    '                Throw New Exception("イメージデータテーブルの更新に失敗しました。")
    '            End If

    '            If Not String.IsNullOrEmpty(strImageStatus) Then
    '                'イメージ状態履歴登録(オーソリステータスの更だけの場合は不要！！)
    '                Me.InsertImageHistory(strImageID, strImageStatus)
    '            End If

    '        Catch
    '            ' ログファイルにエラー内容を出力します。
    '            CommonLog.WriteLog(Me.mobjCommonDB.GetInfoMessage, EventLogEntryType.Error)
    '            Throw

    '        End Try
    '    End Sub

    '#End Region

    '#Region "成約データコピー"
    '    ''' <summary>
    '    ''' 成約データコピー
    '    ''' </summary>
    '    ''' <param name="strCopyImageID">イメージステータス(コピー元)</param>
    '    ''' <param name="strStatus">イメージステータス</param>
    '    ''' <param name="strAuthoriStatus">オーソリステータス</param>
    '    ''' <param name="strCancelFlg">キャンセルフラグ</param>
    '    ''' <remarks></remarks>
    '    Protected Sub CopyAgreementData(ByVal strCopyImageID As String, ByVal strStatus As String, ByVal strAuthoriStatus As String, ByVal strCancelFlg As String)
    '        'イメージＩＤ取得
    '        Dim strImageID As String = Me.GetImageID()

    '        'イメージテーブル登録
    '        Me.InsertImage(strImageID, strStatus, strAuthoriStatus, strCopyImageID)

    '        'イメージ履歴テーブル登録
    '        Me.InsertImageHistory(strImageID, strStatus)

    '        'エントリーテーブル登録
    '        Me.InsertEntry(strImageID, strCancelFlg, strCopyImageID, "T_JJ_ENTRY")

    '        'エントリーコレクションテーブル登録
    '        Me.InsertEntry(strImageID, strCancelFlg, strCopyImageID, "T_JJ_ENTRY_CORRECTION")

    '    End Sub
    '#End Region

    '#Region "イメージIDの作成"
    '    ''' <summary>
    '    ''' イメージIDの作成
    '    ''' </summary>
    '    ''' <returns></returns>
    '    ''' <remarks></remarks>
    '    Private Function GetImageID() As String
    '        ' シーケンスから新規イメージIDを取得します。
    '        Dim dtbImage As DataTable = mobjCommonDB.DB_ExecuteQuery("SELECT S_JJ_IMAGE.NEXTVAL FROM DUAL")
    '        If dtbImage Is Nothing OrElse dtbImage.Rows.Count <> 1 Then
    '            Throw New Exception("新規イメージIDを生成できません。")
    '        End If
    '        Return dtbImage.Rows(0)(0).ToString()
    '    End Function
    '#End Region

    '#Region "イメージテーブルの登録"
    '    ''' <summary>
    '    ''' イメージテーブルの登録
    '    ''' </summary>
    '    ''' <param name="strImageID">イメージID</param>
    '    ''' <param name="strStatus">イメージステータス</param>
    '    ''' <param name="strAuthoriStatus">オーソリステータス</param>
    '    ''' <param name="strCopyImageID">コピー対象イメージID</param>
    '    ''' <remarks></remarks>
    '    Private Sub InsertImage(ByVal strImageID As String, ByVal strStatus As String, ByVal strAuthoriStatus As String, ByVal strCopyImageID As String)

    '        ' イメージテーブル登録用のSQLを作成します。
    '        Dim stbSQL As New StringBuilder(String.Empty)
    '        stbSQL.AppendLine("INSERT INTO T_JJ_IMAGE")
    '        stbSQL.AppendLine("(")
    '        stbSQL.AppendLine("SELECT")
    '        stbSQL.AppendLine("    :ImageID AS IMAGE_ID,")
    '        stbSQL.AppendLine("    RECEIPT_ID,")
    '        stbSQL.AppendLine("    :ImageStatus AS IMAGE_STATUS,")
    '        stbSQL.AppendLine("    BEFORE_IMAGE_STATUS,")
    '        stbSQL.AppendLine("    IMAGE_FILE_NAME,")
    '        stbSQL.AppendLine("    IMAGE_FILE_PATH,")
    '        stbSQL.AppendLine("    SLIP_DEFINE_ID,")
    '        stbSQL.AppendLine("    SLIP_KIND_ID,")
    '        stbSQL.AppendLine("    PRIORITY,")
    '        stbSQL.AppendLine("    EXC_SUBJECT_NO,")
    '        stbSQL.AppendLine("    DEF_REV_COUNT, DELIVERY_DATE,")
    '        stbSQL.AppendLine("    EXC_IMAGE_KEY01,")
    '        stbSQL.AppendLine("    EXC_IMAGE_KEY02,")
    '        stbSQL.AppendLine("    EXC_IMAGE_KEY03,")
    '        stbSQL.AppendLine("    :AuthoriStatus AS EXC_IMAGE_KEY04,")
    '        stbSQL.AppendLine("    EXC_IMAGE_KEY05,")
    '        stbSQL.AppendLine("    EXC_IMAGE_KEY06,")
    '        stbSQL.AppendLine("    EXC_IMAGE_KEY07,")
    '        stbSQL.AppendLine("    EXC_IMAGE_KEY08,")
    '        stbSQL.AppendLine("    EXC_IMAGE_KEY09,")
    '        stbSQL.AppendLine("    EXC_IMAGE_KEY10,")
    '        stbSQL.AppendLine("    DELETE_FLG,")
    '        stbSQL.AppendLine("    SYSDATE AS CREATE_DATE,")
    '        stbSQL.AppendLine("    :UserID AS CREATE_USER,")
    '        stbSQL.AppendLine("    SYSDATE AS UPDATE_DATE,")
    '        stbSQL.AppendLine("    :UserID AS UPDATE_USER")
    '        stbSQL.AppendLine("FROM")
    '        stbSQL.AppendLine("    T_JJ_IMAGE")
    '        stbSQL.AppendLine("WHERE")
    '        stbSQL.AppendLine("    IMAGE_ID = :CopyImageID")
    '        stbSQL.AppendLine(")                         ")

    '        'エントリーコレクション登録用パラメータ宣言
    '        Dim lstInsertParam As New List(Of OracleParameter)
    '        lstInsertParam.Add(New OracleParameter("ImageID", OracleDbType.Decimal, strImageID, ParameterDirection.Input))
    '        lstInsertParam.Add(New OracleParameter("ImageStatus", OracleDbType.Char, strStatus, ParameterDirection.Input))
    '        lstInsertParam.Add(New OracleParameter("AuthoriStatus", OracleDbType.Char, strAuthoriStatus, ParameterDirection.Input))
    '        lstInsertParam.Add(New OracleParameter("UserID", OracleDbType.Varchar2, My.Application.Info.AssemblyName, ParameterDirection.Input))
    '        lstInsertParam.Add(New OracleParameter("CopyImageID", OracleDbType.Decimal, strCopyImageID, ParameterDirection.Input))

    '        'SQL実行
    '        If mobjCommonDB.DB_ExecuteNonQuery(stbSQL.ToString(), lstInsertParam.ToArray()) < 1 Then
    '            Throw New Exception("イメージテーブルの登録に失敗しました。")
    '        End If

    '    End Sub
    '#End Region

    '#Region "イメージ履歴登録"
    '    ''' <summary>
    '    ''' イメージ履歴登録
    '    ''' </summary>
    '    ''' <param name="strImageID">イメージID</param>
    '    ''' <param name="strStatus">イメージステータス</param>
    '    ''' <remarks></remarks>
    '    Private Sub InsertImageHistory(ByVal strImageID As String, ByVal strStatus As String)

    '        ' イメージ状態履歴登録用SQL作成
    '        Dim stbInsertSQL As New System.Text.StringBuilder(String.Empty)
    '        stbInsertSQL.AppendLine("INSERT INTO T_JJ_IMAGE_HISTORY (")
    '        stbInsertSQL.AppendLine("    IMAGE_ID,")
    '        stbInsertSQL.AppendLine("    IMAGE_STATUS,")
    '        stbInsertSQL.AppendLine("    CREATE_DATE,")
    '        stbInsertSQL.AppendLine("    CREATE_USER")
    '        stbInsertSQL.AppendLine(") (")
    '        stbInsertSQL.AppendLine("SELECT")
    '        stbInsertSQL.AppendLine("    IMAGE_ID,")
    '        stbInsertSQL.AppendLine("    :ImageStatus AS IMAGE_STATUS,")
    '        stbInsertSQL.AppendLine("    SYSDATE AS CREATE_DATE,")
    '        stbInsertSQL.AppendLine("    :UserID AS CREATE_USER")
    '        stbInsertSQL.AppendLine("FROM")
    '        stbInsertSQL.AppendLine("    T_JJ_IMAGE")
    '        stbInsertSQL.AppendLine("WHERE")
    '        stbInsertSQL.AppendLine("    IMAGE_ID = :ImageID")
    '        stbInsertSQL.AppendLine(")")

    '        'イメージ状態履歴テーブル登録用パラメータ設定
    '        Dim lstInsertParam As New List(Of OracleParameter)
    '        lstInsertParam.Add(New OracleParameter("ImageStatus", OracleDbType.Char, strStatus, ParameterDirection.Input))
    '        lstInsertParam.Add(New OracleParameter("UserID", OracleDbType.Varchar2, My.Application.Info.AssemblyName, ParameterDirection.Input))
    '        lstInsertParam.Add(New OracleParameter("ImageID", OracleDbType.Decimal, strImageID, ParameterDirection.Input))

    '        'SQL実行
    '        If Me.mobjCommonDB.DB_ExecuteNonQuery(stbInsertSQL.ToString(), lstInsertParam.ToArray()) < 1 Then
    '            Throw New Exception("イメージ履歴テーブルの登録に失敗しました。")
    '        End If

    '    End Sub
    '#End Region

    '#Region "エントリー登録"
    '    ''' <summary>
    '    ''' エントリー登録
    '    ''' </summary>
    '    ''' <param name="strImageId">イメージID</param>
    '    ''' <param name="strCancelFlg">キャンセルフラグ</param>
    '    ''' <param name="strCopyImageID">コピー対象イメージID</param>
    '    ''' <param name="tblName">テーブル名</param>
    '    ''' <remarks></remarks>
    '    Private Sub InsertEntry(ByVal strImageID As String, ByVal strCancelFlg As String, ByVal strCopyImageID As String, ByVal tblName As String)

    '        Try
    '            Dim stbSQL As New StringBuilder(String.Empty)

    '            stbSQL.AppendLine("INSERT INTO " & tblName)
    '            stbSQL.AppendLine("(")
    '            stbSQL.AppendLine("    IMAGE_ID,")
    '            For i As Integer = 1 To 150
    '                stbSQL.AppendLine("    ITEM_" & i.ToString("000") & ",")
    '                stbSQL.AppendLine("    ITEM_" & i.ToString("000") & "_DEF,")
    '            Next
    '            stbSQL.AppendLine("    DELETE_FLG,")
    '            stbSQL.AppendLine("    CREATE_DATE,")
    '            stbSQL.AppendLine("    CREATE_USER,")
    '            stbSQL.AppendLine("    UPDATE_DATE,")
    '            stbSQL.AppendLine("    UPDATE_USER")
    '            stbSQL.AppendLine(") (")
    '            stbSQL.AppendLine("SELECT")
    '            stbSQL.AppendLine("    :ImageID AS IMAGE_ID,")
    '            For i As Integer = 1 To 150
    '                If i = 62 AndAlso tblName = "T_JJ_ENTRY_CORRECTION" Then
    '                    'キャンセルフラグ(エントリーコレクション)の場合
    '                    stbSQL.AppendLine("    :CancelFlg AS ITEM_" & i.ToString("000") & ",")
    '                Else
    '                    stbSQL.AppendLine("    ITEM_" & i.ToString("000") & ",")
    '                End If
    '                stbSQL.AppendLine("    ITEM_" & i.ToString("000") & "_DEF,")
    '            Next
    '            stbSQL.AppendLine("    DELETE_FLG,")
    '            stbSQL.AppendLine("    SYSDATE AS CREATE_DATE,")
    '            stbSQL.AppendLine("    :UserID AS CREATE_USER,")
    '            stbSQL.AppendLine("    SYSDATE AS UPDATE_DATE,")
    '            stbSQL.AppendLine("    :UserID AS UPDATE_USER")
    '            stbSQL.AppendLine("FROM")
    '            stbSQL.AppendLine("    " & tblName)
    '            stbSQL.AppendLine("WHERE")
    '            stbSQL.AppendLine("    IMAGE_ID = :CopyImageID")
    '            stbSQL.AppendLine(")")

    '            'エントリー登録用パラメータ宣言
    '            Dim lstInsertParam As New List(Of OracleParameter)
    '            lstInsertParam.Add(New OracleParameter("ImageID", OracleDbType.Decimal, strImageID, ParameterDirection.Input))
    '            If tblName = "T_JJ_ENTRY_CORRECTION" Then
    '                'エントリーコレクションの場合
    '                lstInsertParam.Add(New OracleParameter("CancelFlg", OracleDbType.NVarchar2, strCancelFlg, ParameterDirection.Input))
    '            End If
    '            lstInsertParam.Add(New OracleParameter("UserID", OracleDbType.Varchar2, My.Application.Info.AssemblyName, ParameterDirection.Input))
    '            lstInsertParam.Add(New OracleParameter("CopyImageID", OracleDbType.Decimal, strCopyImageID, ParameterDirection.Input))

    '            'SQL実行
    '            If Me.mobjCommonDB.DB_ExecuteNonQuery(stbSQL.ToString(), lstInsertParam.ToArray()) < 1 Then
    '                Throw New Exception("エントリーテーブルの登録に失敗しました。")
    '            End If

    '        Catch

    '            CommonLog.WriteLog(mobjCommonDB.GetInfoMessage, EventLogEntryType.Error)
    '            Throw

    '        End Try

    '    End Sub
    '#End Region

    '#Region "FreeのイメージID取得"
    '    ''' <summary>
    '    ''' FreeのイメージID取得
    '    ''' </summary>
    '    ''' <param name="strImageID">イメージID</param>
    '    ''' <returns></returns>
    '    ''' <remarks></remarks>
    '    Protected Function GetImageIdFree(ByVal strImageID As String) As String

    '        Dim stbSQL As String = " SELECT IMAGE_ID FROM T_JJ_ENTRY_CORRECTION WHERE ITEM_124 = :IMAGE_ID "

    '        Dim orSelectParam(0) As OracleParameter
    '        orSelectParam(0) = New OracleParameter("IMAGE_ID", OracleDbType.NVarchar2)
    '        orSelectParam(0).Value = strImageID

    '        Dim dt As DataTable = mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString(), orSelectParam)
    '        If dt.Rows.Count > 0 Then
    '            Return dt.Rows(0)("IMAGE_ID").ToString()
    '        End If

    '        Return Nothing

    '    End Function
    '#End Region

End Class
