﻿Imports System
Imports System.Text
Imports System.IO
Imports System.Text.Encoding

Public Class CommonCsv

    'CSVから読み込んだデータを格納するテーブル
    Private _dtbCSV As DataTable

    'CSVの列名とその順番
    Private _strCSV() As String

    Private strDelimiter As String = ","

    'コンストラクタ
    Public Sub New(ByVal strCsvItems() As String)
        _dtbCSV = New DataTable
        ReDim _strCSV(strCsvItems.Length - 1)
        For intIndex As Integer = 0 To strCsvItems.Length - 1 Step 1
            _dtbCSV.Columns.Add(strCsvItems(intIndex), GetType(System.String))
            _strCSV(intIndex) = strCsvItems(intIndex)
        Next
    End Sub

    Public Sub New(ByVal dtCsv As DataTable)
        _dtbCSV = New DataTable
        ReDim _strCSV(dtCsv.Columns.Count - 1)
        For intIndex As Integer = 0 To dtCsv.Columns.Count - 1 Step 1
            _dtbCSV.Columns.Add(dtCsv.Columns(intIndex).ColumnName, GetType(System.String))
            _strCSV(intIndex) = dtCsv.Columns(intIndex).ColumnName
        Next
        For Each dr As DataRow In dtCsv.Rows
            Dim drNew As DataRow = _dtbCSV.NewRow
            For Each c As DataColumn In _dtbCSV.Columns
                drNew.Item(c.ColumnName) = System.Convert.ToString(dr.Item(c.ColumnName))
            Next
            _dtbCSV.Rows.Add(drNew)
        Next
    End Sub

    ' CSVファイル内の区切り文字
    Public Property Delimiter() As String
        Get
            Return strDelimiter
        End Get
        Set(ByVal value As String)
            strDelimiter = value
        End Set
    End Property

    '読み込んだCSVデータ全体を取得
    Public ReadOnly Property Table() As DataTable
        Get
            Return _dtbCSV.Copy
        End Get
    End Property

    'CSVの中の項目の位置（０基点）
    Public ReadOnly Property ItemIndex(ByVal strItem As String) As Integer
        Get
            Return Array.IndexOf(_strCSV, strItem)
        End Get
    End Property

    'データ構造をクローンした新しいCommonCsvインスタンスを返します。
    Public ReadOnly Property Clone() As CommonCsv
        Get
            Dim clsNew As New CommonCsv(_strCSV)
            Return clsNew
        End Get
    End Property

    'データ構造とデータをコピーした新しいCommonCsvインスタンスを返します。
    Public ReadOnly Property Copy() As CommonCsv
        Get
            Dim clsNew As New CommonCsv(_strCSV)
            For intRow As Integer = 0 To Count - 1 Step 1
                Dim strData() As String = Nothing
                If GetRow(intRow, strData) Then
                    clsNew.AddRow(strData)
                End If
            Next

            Return clsNew
        End Get
    End Property

    '現在の行数を取得
    Public ReadOnly Property Count() As Integer
        Get
            Return _dtbCSV.Rows.Count
        End Get
    End Property

    '個別の項目へのアクセス
    '   intRow:アクセスしたい行番号（０基点）
    '   strItem:アクセスしたい項目名
    Public Property Item(ByVal intRow As Integer, ByVal strItem As String) As String
        Get
            Return System.Convert.ToString(_dtbCSV.Rows(intRow).Item(strItem))
        End Get
        Set(ByVal Value As String)
            _dtbCSV.Rows(intRow).Item(strItem) = Value
        End Set
    End Property

    '個別の項目へのアクセス
    '   intRow:アクセスしたい行番号（０基点）
    '   intCol:アクセスしたい項目番号（０基点）
    Public Property Item(ByVal intRow As Integer, ByVal intCol As Integer) As String
        Get
            Return Item(intRow, _strCSV(intCol))
        End Get
        Set(ByVal Value As String)
            Item(intRow, _strCSV(intCol)) = Value
        End Set
    End Property

    '読み込んだCSVデータを全て消去
    Public Sub Clear()
        _dtbCSV.Rows.Clear()
    End Sub

    '１行分のデータを一括で取得
    '   intRow:取得したい行番号（０基点）
    '   strData:取得したデータを格納する返却領域
    Public Function GetRow(ByVal intRow As Integer, ByRef strData() As String) As Boolean

        '指定された行までデータがない場合はエラー
        If intRow >= _dtbCSV.Rows.Count Then
            Return False
        End If

        '行データを１項目ずつ返却領域に移送します。
        ReDim strData(_strCSV.Length - 1)
        For intIndex As Integer = 0 To _strCSV.Length - 1 Step 1
            strData(intIndex) = System.Convert.ToString(_dtbCSV.Rows(intRow).Item(_strCSV(intIndex)))
        Next

        Return True
    End Function

    '１行分のデータを一括で更新
    '   intRow:取得したい行番号（０基点）
    '   strData:更新したいデータ
    Public Function SetRow(ByVal intRow As Integer, ByVal strData() As String) As Boolean

        '指定された行までデータがない場合はエラー
        If intRow >= _dtbCSV.Rows.Count Then
            Return False
        End If

        '設定項目数が対象CSVの項目数に満たない場合はエラー
        If strData.Length < _strCSV.Length Then
            Return False
        End If

        '行データを１項目ずつ指定された内容で更新します。
        For intIndex As Integer = 0 To _strCSV.Length - 1 Step 1
            _dtbCSV.Rows(intRow).Item(_strCSV(intIndex)) = strData(intIndex)
        Next

        Return True
    End Function

    '１行分のデータを追加
    '   strData:追加したいデータ
    Public Function AddRow(ByVal strData() As String) As Boolean

        '設定項目数が対象CSVの項目数に満たない場合はエラー
        If strData.Length < _strCSV.Length Then
            Return False
        End If

        '新しい行データを作成して、指定された内容を設定します。
        Dim drwData As DataRow = _dtbCSV.NewRow
        For intIndex As Integer = 0 To _strCSV.Length - 1 Step 1
            drwData.Item(_strCSV(intIndex)) = strData(intIndex)
        Next

        '出来上がったデータをテーブルに追加します。
        _dtbCSV.Rows.Add(drwData)

        Return True
    End Function

    '１行分のデータを追加
    Public Function AddRow() As Boolean
        Dim strData(_strCSV.Length - 1) As String
        For intIndex As Integer = 0 To _strCSV.Length - 1 Step 1
            strData(intIndex) = String.Empty
        Next

        Return AddRow(strData)
    End Function

    '１行分のデータを削除
    '   intRow:削除したい行番号（０基点）
    Public Function DelRow(ByVal intRow As Integer) As Boolean

        '指定された行までデータがない場合はエラー
        If intRow >= _dtbCSV.Rows.Count Then
            Return False
        End If

        _dtbCSV.Rows(intRow).Delete()
        '_dtbCSV.AcceptChanges()

        Return False
    End Function

    'CSVファイルからデータを読み込み
    Public Function LoadCsv(ByVal strPath As String) As Boolean

        Return LoadCsv(strPath, False)

    End Function

    'CSVファイルからデータを読み込み(エンコード指定)
    Public Function LoadCsv(ByVal strPath As String, ByVal blnMode As Boolean) As Boolean

        Return LoadCsv(strPath, blnMode, False)

    End Function

    'CSVファイルからデータを読み込み(エンコード指定，ダブルクォーテーション対応指定)
    Public Function LoadCsv(ByVal strPath As String, ByVal blnMode As Boolean, ByVal blnLocal As Boolean) As Boolean
        Try
            '読み込んだ行データを一時的に格納する領域です。
            '---------回復　2008/10/09　by 盛　開始　-----------------
            '削除　200810/07　Ｂｙ大湖
            'Dim aryDataRow As New ArrayList
            Dim aryDataRow As New ArrayList
            '---------回復　2008/10/09　by 盛　終了　-----------------

            '入力CSVを開きます。
            Dim sr As StreamReader
            If blnMode Then
                sr = New StreamReader(strPath, Encoding.GetEncoding("shift-jis"))
            Else
                sr = New StreamReader(strPath)
            End If

            Dim strLine As String
            Do
                '入力CSVから一件読込
                strLine = sr.ReadLine()
                If Not strLine Is Nothing Then

                    'CSV１行分のデータを各項目ごとに切り出します。
                    Dim strSplit() As String
                    If blnLocal Then
                        strSplit = LocalSplit(strLine)
                    Else
                        strSplit = Split(strLine, strDelimiter)
                    End If

                    '項目数が一致しない場合はエラーとします。
                    If strSplit.Length <> _strCSV.Length Then
                        sr.Close()
                        Return False
                    End If

                    '読み込んだデータを一次作業領域に追加します。
                    Dim drwLine As DataRow = _dtbCSV.NewRow
                    For intIndex As Integer = 0 To _strCSV.Length - 1 Step 1
                        drwLine.Item(_strCSV(intIndex)) = strSplit(intIndex)
                    Next

                    '---------回復　2008/10/09　by 盛　開始　-----------------
                    '削除　200810/07　Ｂｙ大湖
                    'aryDataRow.Add(drwLine)
                    '_dtbCSV.Rows.Add(drwLine)
                    aryDataRow.Add(drwLine)
                    '---------回復　2008/10/09　by 盛　終了　-----------------

                End If
            Loop Until strLine Is Nothing

            '入力CSVを閉じます。
            sr.Close()

            '---------修正　2008/10/09　by 盛　開始　-----------------
            '削除　200810/07　Ｂｙ大湖
            ''''エラーがなく全てのデータが読み込めた場合は作業領域の内容をテーブルに転送します。
            'For intIndex As Integer = 0 To aryDataRow.Count - 1 Step 1
            '    _dtbCSV.Rows.Add(aryDataRow(intindex))
            'Next
            'エラーがなく全てのデータが読み込めた場合は作業領域の内容をテーブルに転送します。
            For intIndex As Integer = 0 To aryDataRow.Count - 1 Step 1
                _dtbCSV.Rows.Add(CType(aryDataRow(intIndex), DataRow))
            Next
            '---------修正　2008/10/09　by 盛　終了　-----------------

            Return True

        Catch ex As Exception

            Return False

        End Try
    End Function

    'テーブル中のデータをCSVに出力します。
    Public Function SaveCsv(ByVal strPath As String, Optional ByVal blnMode As Boolean = True) As Boolean

        Return SaveCsv(strPath, blnMode, False)

    End Function

    'テーブル中のデータをCSVに出力します。
    Public Function SaveCsv(ByVal strPath As String, ByVal blnMode As Boolean, ByVal blnSjis As Boolean) As Boolean
        Try
            '出力CSVを開きます。
            Dim sw As StreamWriter
            If blnSjis Then
                sw = New StreamWriter(strPath, blnMode, Encoding.GetEncoding("shift-jis"))
            Else
                sw = New StreamWriter(strPath, blnMode)
            End If

            Dim strItems(_strCSV.Length) As String

            'テーブルの中身を１行ずつ出力CSVに書き出します。
            For Each dr As DataRow In _dtbCSV.Rows

                If Not dr.RowState.Equals(DataRowState.Deleted) Then
                    '一行分の項目を格納する作業領域です。
                    Dim strCSV(_strCSV.Length - 1) As String

                    '作業領域にテーブルの一行分のデータを設定します。
                    For intIndex As Integer = 0 To _strCSV.Length - 1 Step 1
                        strCSV(intIndex) = System.Convert.ToString(dr.Item(_strCSV(intIndex)))
                    Next

                    '作業領域のデータをカンマ区切りの１つのStringに纏めます。
                    Dim strLine As String = String.Join(strDelimiter, strCSV)

                    '出力CSVに書き出します。
                    sw.WriteLine(strLine)
                End If

            Next

            '出力CSVを閉じます。
            sw.Close()
            Return True

        Catch ex As Exception

            Return False

        End Try

    End Function

    'テーブル中のデータをCSVに出力します。
    Public Function SaveCsvWithHeader(ByVal strPath As String, ByVal blnMode As Boolean, ByVal blnSjis As Boolean) As Boolean
        Try
            '出力CSVを開きます。
            Dim sw As StreamWriter
            If blnSjis Then
                sw = New StreamWriter(strPath, blnMode, Encoding.GetEncoding("shift-jis"))
            Else
                sw = New StreamWriter(strPath, blnMode)
            End If


            ' ヘッダ（タイトル）を書き出します。
            Dim strHedLine As String = String.Join(strDelimiter, _strCSV)
            sw.WriteLine(strHedLine)


            Dim strItems(_strCSV.Length) As String

            'テーブルの中身を１行ずつ出力CSVに書き出します。
            For Each dr As DataRow In _dtbCSV.Rows

                If Not dr.RowState.Equals(DataRowState.Deleted) Then
                    '一行分の項目を格納する作業領域です。
                    Dim strCSV(_strCSV.Length - 1) As String

                    '作業領域にテーブルの一行分のデータを設定します。
                    For intIndex As Integer = 0 To _strCSV.Length - 1 Step 1
                        strCSV(intIndex) = System.Convert.ToString(dr.Item(_strCSV(intIndex)))
                    Next

                    '作業領域のデータをカンマ区切りの１つのStringに纏めます。
                    Dim strLine As String = String.Join(strDelimiter, strCSV)

                    '出力CSVに書き出します。
                    sw.WriteLine(strLine)
                End If

            Next

            '出力CSVを閉じます。
            sw.Close()
            Return True

        Catch ex As Exception

            Return False

        End Try

    End Function


    'ダブルクォーテーションを意識したカンマによる文字列展開
    Private Function LocalSplit(ByVal strSRC As String) As String()

        Dim intStrLength As Integer = strSRC.Length         'ベースとなる文字列の全文字数
        Dim intStrPosition As Integer = 0                   '現在処理中の文字の位置
        Dim stbItem As New StringBuilder(String.Empty)      '展開後の文字列編集バッファ
        Dim arySplit As New ArrayList                       '展開結果一次格納領域

        '１文字ずつ切り出してその内容を判定します。
        Do
            '最後の文字まで達してしまった場合は編集中の最後の項目を一次格納領域に追加して
            'ループを抜け出します。（編集完了）
            If intStrPosition >= intStrLength Then
                arySplit.Add(stbItem.ToString)
                Exit Do
            End If

            'ベースとなる文字列から一文字切り出します。
            '切り出したら切り出し位置を１つ進めておきます。
            Dim strWord As String = strSRC.Substring(intStrPosition, 1)
            intStrPosition += 1

            Select Case strWord
                Case strDelimiter
                    '区切り文字を発見したらその手前までの編集結果を一次格納領域に追加して
                    '編集結果を初期化します。
                    arySplit.Add(stbItem.ToString)
                    stbItem.Length = 0

                Case """"
                    'ダブルクォーテーションを発見したら終端のダブルクォーテーションまでの文字列を
                    '切り出します。
                    Dim stbSubItem As New StringBuilder(String.Empty)
                    Do
                        '最後の文字まで達してしまった場合はループを抜け出します。
                        '（ダブルクォーテーション内の文字切り出し完了）
                        If intStrPosition >= intStrLength Then
                            Exit Do
                        End If

                        'ベースとなる文字列から一文字切り出します。
                        '切り出したら切り出し位置を１つ進めておきます。
                        Dim strSubWord As String = strSRC.Substring(intStrPosition, 1)
                        intStrPosition += 1

                        '切り出した文字の後ろにもまだ文字がある場合はその文字も取得しておきます。
                        Dim strSubWordNext As String = String.Empty
                        If intStrPosition < intStrLength - 1 Then
                            strSubWordNext = strSRC.Substring(intStrPosition, 1)
                        End If

                        Select Case strSubWord
                            Case """"
                                If strSubWordNext.Equals("""") Then
                                    'ダブルクォーテーションの後ろもダブルクォーテーションだった場合は
                                    'ダブルクォーテーションをひとつだけ編集文字列に加えます。
                                    stbSubItem.Append(strSubWord)
                                    intStrPosition += 1
                                Else
                                    'ダブルクォーテーションの後ろがダブルクォーテーション以外の場合は
                                    '切り出しを完了します。（ループを抜け出します）
                                    Exit Do
                                End If
                            Case Else
                                'ダブルクォーテーション以外の文字の場合は編集文字列に加えます。
                                stbSubItem.Append(strSubWord)
                        End Select
                    Loop
                    '編集した文字列（ダブルクォーテーションの内側の文字列）を現在の編集項目の後ろに追加します。
                    stbItem.Append(stbSubItem.ToString)

                Case Else
                    'カンマ、ダブルクォーテーション以外の文字の場合は編集項目の後ろにそのまま追加します。
                    stbItem.Append(strWord)

            End Select
        Loop

        '一次格納領域の内容をString配列に転送してそれを返します。
        Dim strSplit(arySplit.Count - 1) As String
        For intLoop As Integer = 0 To arySplit.Count - 1 Step 1
            strSplit(intLoop) = arySplit(intLoop)
        Next

        Return strSplit
    End Function
End Class
