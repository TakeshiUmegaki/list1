﻿Imports CommonSystem
Imports System.Text
Imports Oracle.DataAccess
Imports System.IO

Public Class frmMain

#Region "定数定義"
    Private Const APP_NAME As String = "外字検索"
#End Region

#Region "内部クラス"
    Private Class SlipCount
        Public strSlipId As String = String.Empty
        Public intTotal As Integer = 0
        Public intInput As Integer = 0
        Public intNoInput As Integer = 0
        Public intGaiji As Integer = 0
        Public intGaijiWords As Integer = 0
        Public intTotalWords As Integer = 0
    End Class
#End Region

#Region "内部変数定義"

    ''' <summary>
    ''' 外字辞書
    ''' </summary>
    ''' <remarks></remarks>
    Private mdicGaiji As New Dictionary(Of String, Object)

    ''' <summary>
    ''' 検索結果
    ''' </summary>
    ''' <remarks></remarks>
    Private mdicKekka As Dictionary(Of String, SlipCount)

#End Region

#Region "画面ロード時の処理"
    ''' <summary>
    ''' 画面ロード時の処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles Me.Load

        Try

            ' 帳票IDリスト取得
            Me.lstSlipId.DataSource = GetSlipList()

            ' 入力項目リスト取得
            Me.cmbItem.DataSource = GetItemList()

            ' 外字ファイル読込み
            Call ReadGaijiTeigi()

        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try

    End Sub
#End Region

#Region "終了ボタン処理"
    ''' <summary>
    ''' 終了ボタン処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnEnd_Click(sender As Object, e As EventArgs) Handles btnEnd.Click

        Try

            Me.Close()

        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try

    End Sub
#End Region

#Region "外字定義ファイル読込み"
    Private Sub ReadGaijiTeigi()
        Try
            Dim strFile As String = String.Empty
            Using sr As New StreamReader(My.Application.mdicConfig("GAIJI_TEIGI"), Encoding.GetEncoding(My.Application.mdicConfig("GAIJI_ENC")))
                strFile = sr.ReadToEnd
            End Using

            For Each c As Char In strFile.ToCharArray
                Dim s As String = Convert.ToString(c)
                If Not mdicGaiji.ContainsKey(s) Then
                    mdicGaiji.Add(s, Nothing)
                End If
            Next

        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

#Region "帳票IDリスト取得"
    ''' <summary>
    ''' 帳票IDリスト取得
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetSlipList() As DataTable

        Try

            Dim stbSQL As New StringBuilder(String.Empty)

            stbSQL.AppendLine("   SELECT SLIP_DEFINE_ID,")
            stbSQL.AppendLine("          SLIP_DEFINE_ID || ':' || SLIP_DEFINE_NAME AS SLIP_DEFINE_NAME")
            stbSQL.AppendLine("     FROM M_SLIP_DEFINE")
            stbSQL.AppendLine("    WHERE SORT_NO IS NOT NULL")
            stbSQL.AppendLine("      AND DELETE_FLG = '0'")
            stbSQL.AppendLine(" ORDER BY SORT_NO")

            Dim dt As DataTable = My.Application.comDB.DB_ExecuteQuery(stbSQL.ToString)

            Return dt

        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try

    End Function
#End Region

#Region "入力項目リスト取得"
    ''' <summary>
    ''' 入力項目リスト取得
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetItemList() As DataTable

        Try

            Dim dt As New DataTable
            Dim dr As DataRow
            Dim i As Integer

            dt.Columns.Add("ITEM_ID", Type.GetType("System.String"))
            dt.Columns.Add("ITEM_NAME", Type.GetType("System.String"))

            For i = 1 To 450 Step 1
                dr = dt.NewRow

                dr("ITEM_ID") = "ITEM_" & i.ToString.PadLeft(3, "0")
                dr("ITEM_NAME") = "ITEM_" & i.ToString.PadLeft(3, "0")

                dt.Rows.Add(dr)
            Next

            Return dt

        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try

    End Function
#End Region

#Region "検索ボタン処理"
    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        Try
            Dim dicHit As New Dictionary(Of String, Integer)

            mdicKekka = New Dictionary(Of String, SlipCount)
            Dim lstKey As New List(Of String)
            For Each i As Integer In Me.lstSlipId.SelectedIndices
                Dim v As DataRowView = Me.lstSlipId.Items(i)
                Dim dic As New SlipCount
                dic.strSlipId = Convert.ToString(v.Item(0))
                mdicKekka.Add(dic.strSlipId, dic)
                lstKey.Add(dic.strSlipId)
            Next
            lstKey.Sort()

            Dim dt As DataTable = GetData()
            For Each dr As DataRow In dt.Rows
                Dim strImgId As String = Convert.ToString(dr.Item("IMAGE_ID"))
                Dim strSlip As String = Convert.ToString(dr.Item("SLIP_DEFINE_ID"))
                Dim strItem As String = Convert.ToString(dr.Item("ITEM"))

                '' 新規の帳票IDなら辞書に登録します。
                'If Not mdicKekka.ContainsKey(strSlip) Then
                '    Dim dic As New SlipCount
                '    dic.strSlipId = strSlip
                '    mdicKekka.Add(strSlip, dic)
                'End If

                mdicKekka(strSlip).intTotal += 1
                If strItem.Length > 0 Then
                    mdicKekka(strSlip).intInput += 1
                Else
                    mdicKekka(strSlip).intNoInput += 1
                End If
                mdicKekka(strSlip).intTotalWords += strItem.Length

                Dim intGaiji As Integer = 0
                For Each c As Char In strItem.ToCharArray
                    Dim s As String = Convert.ToString(c)
                    If mdicGaiji.ContainsKey(s) Then
                        intGaiji += 1

                        If Not dicHit.ContainsKey(s) Then
                            dicHit.Add(s, 0)
                        End If
                        dicHit(s) += 1
                    End If
                Next
                If intGaiji > 0 Then
                    mdicKekka(strSlip).intGaiji += 1
                    mdicKekka(strSlip).intGaijiWords += intGaiji
                    CommonLog.WriteLog(strImgId & ":外字あり", EventLogEntryType.SuccessAudit)
                End If
            Next

            Dim strCsvName As String = "output_" & Now.ToString("yyyyMMddHHmmss") & ".csv"
            Dim strCsvPath As String = Path.Combine(My.Application.mdicConfig("OUTPUT_CSV_PATH"), strCsvName)
            Using sw As New StreamWriter(strCsvPath, False, Encoding.GetEncoding(My.Application.mdicConfig("OUTPUT_CSV_ENC")))
                sw.WriteLine("""外字抽出結果""")
                sw.WriteLine("""No."",""帳票ID"",""総件数"",""入力あり件数"",""入力なし件数"",""外字入力あり件数"",""外字文字入力数"",""総文字入力数""")
                Dim intNo As Integer = 1
                For Each strSlip As String In lstKey
                    sw.Write(intNo.ToString)
                    sw.Write(",")
                    sw.Write("""")
                    sw.Write(mdicKekka(strSlip).strSlipId)
                    sw.Write("""")
                    sw.Write(",")
                    sw.Write(mdicKekka(strSlip).intTotal.ToString)
                    sw.Write(",")
                    sw.Write(mdicKekka(strSlip).intInput.ToString)
                    sw.Write(",")
                    sw.Write(mdicKekka(strSlip).intNoInput.ToString)
                    sw.Write(",")
                    sw.Write(mdicKekka(strSlip).intGaiji.ToString)
                    sw.Write(",")
                    sw.Write(mdicKekka(strSlip).intGaijiWords.ToString)
                    sw.Write(",")
                    sw.Write(mdicKekka(strSlip).intTotalWords.ToString)
                    sw.WriteLine(String.Empty)
                    intNo += 1
                Next
            End Using

            Dim strHitName As String = "hit_words_" & Now.ToString("yyyyMMddHHmmss") & ".csv"
            Dim strHitPath As String = Path.Combine(My.Application.mdicConfig("OUTPUT_CSV_PATH"), strHitName)
            Using sw As New StreamWriter(strHitPath, False, Encoding.GetEncoding(My.Application.mdicConfig("OUTPUT_CSV_ENC")))
                For Each s As String In dicHit.Keys
                    sw.WriteLine("""" & s & """" & "," & dicHit(s).ToString)
                Next
            End Using


            MessageBox.Show("処理が完了しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Information)

        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

#Region "データ取得"
    Private Function GetData() As DataTable
        Try
            Dim lstSlip As New List(Of String)
            For Each i As Integer In Me.lstSlipId.SelectedIndices
                Dim v As DataRowView = Me.lstSlipId.Items(i)
                lstSlip.Add("'" & Convert.ToString(v.Item(0)) & "'")
            Next

            Dim stbSQL As New StringBuilder(String.Empty)
            stbSQL.AppendLine("SELECT")
            stbSQL.AppendLine("     I.IMAGE_ID       AS IMAGE_ID")
            stbSQL.AppendLine("    ,I.SLIP_DEFINE_ID AS SLIP_DEFINE_ID")
            stbSQL.AppendLine("    ,E.%ITEM%         AS ITEM")
            stbSQL.AppendLine("FROM")
            stbSQL.AppendLine("    T_JJ_IMAGE I")
            stbSQL.AppendLine("    INNER JOIN")
            stbSQL.AppendLine("        T_JJ_ENTRY_CORRECTION E")
            stbSQL.AppendLine("        ON")
            stbSQL.AppendLine("            E.IMAGE_ID = I.IMAGE_ID")
            stbSQL.AppendLine("WHERE")
            stbSQL.AppendLine("    I.DELETE_FLG = '0'")
            stbSQL.AppendLine("    AND")
            stbSQL.AppendLine("    TO_CHAR(I.CREATE_DATE,'YYYYMMDD') >= '%F_DATE%'")
            stbSQL.AppendLine("    AND")
            stbSQL.AppendLine("    TO_CHAR(I.CREATE_DATE,'YYYYMMDD') <= '%T_DATE%'")
            stbSQL.AppendLine("    AND")
            stbSQL.AppendLine("    I.SLIP_DEFINE_ID IN (%SLIP%)")
            stbSQL.AppendLine("ORDER BY")
            stbSQL.AppendLine("    I.IMAGE_ID")

            stbSQL.Replace("%ITEM%", Me.cmbItem.SelectedValue)
            stbSQL.Replace("%F_DATE%", Me.dtpFrom.Value.ToString("yyyyMMdd"))
            stbSQL.Replace("%T_DATE%", Me.dtpTo.Value.ToString("yyyyMMdd"))
            stbSQL.Replace("%SLIP%", Join(lstSlip.ToArray, ","))

            Dim dt As DataTable = My.Application.comDB.DB_ExecuteQuery(stbSQL.ToString)
            Return dt

        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Function
#End Region

End Class