﻿Imports CommonSystem
Imports System
Imports System.Text
Imports System.IO
Imports Oracle.DataAccess

Public Class frmOpeTou

#Region "定数定義"
    Private Const APP_NAME As String = "協会けんぽ　帳票再識別　- オペレータ統計出力 -"
#End Region

#Region "ウインドウ初期表示処理"
    ''' <summary>
    ''' ウインドウ初期表示処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub frmOpeTou_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Me.Text = "協会けんぽ　" & My.Application.mdicConfig("FORM_TITLE") & "　- オペレータ統計出力 -"
        Me.ActiveControl = Btn終了

    End Sub
#End Region

#Region "終了ボタン処理"
    ''' <summary>
    ''' 終了ボタン処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Btn終了_Click(sender As Object, e As EventArgs) Handles Btn終了.Click
        Try
            Me.Close()
        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

#Region "出力ボタン処理"
    Private Sub btn出力_Click(sender As Object, e As EventArgs) Handles btn出力.Click
        Dim dtbオペレータ統計 As DataTable = Nothing
        Dim dlg保存ファイル名指定 As FileDialog = Nothing
        Dim str出力ファイル名接頭語 As String = String.Empty
        Dim str出力ファイル名フルパス As String = String.Empty
        Dim strヘッダーレコード出力 As String = "0"
        Try
            '初期処理をおこなう。
            ToolStripStatusLabel1.Text = String.Empty
            Me.Cursor = Cursors.WaitCursor
            Try
                str出力ファイル名接頭語 = My.Application.mdicConfig("OPE_EFFICIENCY_FILE_NAME")

            Catch ex As Exception
                MessageBox.Show( _
                    "コンフィグに出力ファイル名定義「OPE_EFFICIENCY_FILE_NAME」が定義されていません。" & vbCrLf & _
                    "定義を追加後、再実施してください。" _
                    , APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error _
                )
                Exit Sub
            End Try
            str出力ファイル名接頭語 = str出力ファイル名接頭語 & Now().ToString("yyyyMMddHHmmss") & ".csv"
            Try
                strヘッダーレコード出力 = My.Application.mdicConfig("OPE_EFFICIENCY_OUT_HEADER_RECORD")
            Catch ex As Exception
            End Try

            '指定条件に合致するオペレータ統計データを取得する。
            ToolStripStatusLabel1.Text = "オペレータ統計データ取得中"
            dtbオペレータ統計 = Getオペレータ統計情報(dtp開始日.Value.ToString("yyyyMMdd"), dtp終了日.Value.ToString("yyyyMMdd"))
            If dtbオペレータ統計 Is Nothing OrElse dtbオペレータ統計.Rows.Count < 1 Then
                MessageBox.Show("対象となるオペレータ統計データはありません。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Exit Sub
            End If

            '取得したオペレータ統計データの出力先ファイルを指定する。
            dlg保存ファイル名指定 = New SaveFileDialog()
            dlg保存ファイル名指定.DefaultExt = ".csv"
            dlg保存ファイル名指定.FileName = str出力ファイル名接頭語
            dlg保存ファイル名指定.Filter = "csvファイル(*.csv)|" & str出力ファイル名接頭語
            dlg保存ファイル名指定.Title = APP_NAME & "(名前を付けて保存)"
            dlg保存ファイル名指定.CheckFileExists = False
            If dlg保存ファイル名指定.ShowDialog() <> Windows.Forms.DialogResult.OK Then
                MessageBox.Show( _
                    "オペレータ統計出力ファイル名指定がキャンセルされました。" & vbCrLf & _
                    "処理を中止します。" _
                    , APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Information _
                )
                Exit Sub
            End If
            str出力ファイル名フルパス = dlg保存ファイル名指定.FileName()

            '取得したオペレータ統計データをファイルに出力する。
            Call オペレータ統計ファイル出力(dtbオペレータ統計, str出力ファイル名フルパス, My.Application.mdicConfig("OPE_EFFICIENCY_OUT_HEADER_RECORD"))

            '正常終了処理をおこなう。
            MessageBox.Show( _
                "処理が完了しました。" & vbCrLf &
                "出力ファイル[" & str出力ファイル名フルパス & "]" _
                , APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Information _
            )

            Exit Sub
        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        Finally
            ToolStripStatusLabel1.Text = String.Empty
            Me.Cursor = Cursors.Default
            If Not dtbオペレータ統計 Is Nothing Then
                dtbオペレータ統計.Clear()
                dtbオペレータ統計 = Nothing
            End If
            If Not dlg保存ファイル名指定 Is Nothing Then
                dlg保存ファイル名指定.Dispose()
                dlg保存ファイル名指定 = Nothing
            End If
        End Try

    End Sub
#End Region

#Region "データ取得"
    Private Function Getオペレータ統計情報(str開始日 As String, str終了日 As String) As DataTable
        Try

            Dim stbSQL As New StringBuilder(String.Empty)
            stbSQL.AppendLine("select ")
            stbSQL.AppendLine("    SHORI_DATE ""処理日"", ")
            stbSQL.AppendLine("    LOCATION_ID ""拠点ID"", ")
            stbSQL.AppendLine("    DEP_CODE ""所属ID"", ")
            stbSQL.AppendLine("    OPERATOR_ID ""オペレーターID"", ")
            stbSQL.AppendLine("    COMPANY_ID ""個社ID"", ")
            stbSQL.AppendLine("    BUSINESS_ID ""業務ID"", ")
            stbSQL.AppendLine("    PROJECT_ID ""工程ID"", ")
            stbSQL.AppendLine("    SUBJECT_NO ""案件番号"", ")
            stbSQL.AppendLine("    WORK_LEVEL ""作業レベル"", ")
            stbSQL.AppendLine("    SLIP_DEF ""帳票ID"", ")
            stbSQL.AppendLine("    to_char(nvl(sum(WORK_TIME),0),'FM99999999999') ""実働時間"", ")
            stbSQL.AppendLine("    to_char(nvl(sum(OPE_TIME),0),'FM99999999999') ""稼働時間"", ")
            stbSQL.AppendLine("    to_char(nvl(sum(OPE_CNT),0),'FM99999999999') ""作業回数"", ")
            stbSQL.AppendLine("    to_char(nvl(sum(KNJI_INPT_CHAR_CNT),0),'FM99999999999') ""漢字入力文字数"", ")
            stbSQL.AppendLine("    to_char(nvl(sum(KNJI_UNRE_CHAR_CNT),0),'FM99999999999') ""漢字不読文字数"", ")
            stbSQL.AppendLine("    to_char(nvl(sum(KNJI_MISS_ITEM_CNT),0),'FM99999999999') ""漢字ミス項目数"", ")
            stbSQL.AppendLine("    to_char(nvl(sum(KNJI_TOTL_ITEM_CNT),0),'FM99999999999') ""漢字全項目数"", ")
            stbSQL.AppendLine("    to_char(nvl(sum(KNJI_VALD_ITEM_CNT),0),'FM99999999999') ""漢字有効項目数"", ")
            stbSQL.AppendLine("    to_char(nvl(sum(KANA_INPT_CHAR_CNT),0),'FM99999999999') ""カナ入力文字数"", ")
            stbSQL.AppendLine("    to_char(nvl(sum(KANA_UNRE_CHAR_CNT),0),'FM99999999999') ""カナ不読文字数"", ")
            stbSQL.AppendLine("    to_char(nvl(sum(KANA_MISS_ITEM_CNT),0),'FM99999999999') ""カナミス項目数"", ")
            stbSQL.AppendLine("    to_char(nvl(sum(KANA_TOTL_ITEM_CNT),0),'FM99999999999') ""カナ全項目数"", ")
            stbSQL.AppendLine("    to_char(nvl(sum(KANA_VALD_ITEM_CNT),0),'FM99999999999') ""カナ有効項目数"", ")
            stbSQL.AppendLine("    to_char(nvl(sum(EIJI_INPT_CHAR_CNT),0),'FM99999999999') ""英字入力文字数"", ")
            stbSQL.AppendLine("    to_char(nvl(sum(EIJI_UNRE_CHAR_CNT),0),'FM99999999999') ""英字不読文字数"", ")
            stbSQL.AppendLine("    to_char(nvl(sum(EIJI_MISS_ITEM_CNT),0),'FM99999999999') ""英字ミス項目数"", ")
            stbSQL.AppendLine("    to_char(nvl(sum(EIJI_TOTL_ITEM_CNT),0),'FM99999999999') ""英字全項目数"", ")
            stbSQL.AppendLine("    to_char(nvl(sum(EIJI_VALD_ITEM_CNT),0),'FM99999999999') ""英字有効項目数"", ")
            stbSQL.AppendLine("    to_char(nvl(sum(SUJI_INPT_CHAR_CNT),0),'FM99999999999') ""数字入力文字数"", ")
            stbSQL.AppendLine("    to_char(nvl(sum(SUJI_UNRE_CHAR_CNT),0),'FM99999999999') ""数字不読文字数"", ")
            stbSQL.AppendLine("    to_char(nvl(sum(SUJI_MISS_ITEM_CNT),0),'FM99999999999') ""数字ミス項目数"", ")
            stbSQL.AppendLine("    to_char(nvl(sum(SUJI_TOTL_ITEM_CNT),0),'FM99999999999') ""数字全項目数"", ")
            stbSQL.AppendLine("    to_char(nvl(sum(SUJI_VALD_ITEM_CNT),0),'FM99999999999') ""数字有効項目数"", ")
            stbSQL.AppendLine("    to_char(nvl(sum(UNREAD_ITEM_CNT),0),'FM99999999999') ""不読項目数"", ")
            stbSQL.AppendLine("    to_char(nvl(sum(UNREAD_AVERAGE),0) / count(UNREAD_AVERAGE),'FM99999.999') ""不読率"", ")
            stbSQL.AppendLine("    to_char(nvl(sum(MISS_ITEM_CNT),0),'FM99999999999') ""ミス項目数"", ")
            stbSQL.AppendLine("    to_char(nvl(sum(MISS_AVERAGE),0) / count(UNREAD_AVERAGE),'FM99999.999') ""ミス率"", ")
            stbSQL.AppendLine("    to_char(nvl(sum(OPE_AVERAGE),0) / count(UNREAD_AVERAGE),'FM99999.999') ""稼働率"", ")
            stbSQL.AppendLine("    to_char(nvl(sum(CHANGE_PAGE_CNT),0),'FM99999999999') ""変更ページ数"", ")
            stbSQL.AppendLine("    to_char(nvl(sum(TOTAL_PAGE_CNT),0),'FM99999999999') ""総ページ数""  ")
            stbSQL.AppendLine(" from T_JJ_OPE_EFFICIENCY ")
            stbSQL.AppendLine(" where SHORI_DATE between %START_DATE% and %END_DATE% ")
            stbSQL.AppendLine("   and delete_flg = '0'")
            stbSQL.AppendLine("group by ")
            stbSQL.AppendLine("         SHORI_DATE, ")
            stbSQL.AppendLine("         LOCATION_ID, ")
            stbSQL.AppendLine("         DEP_CODE, ")
            stbSQL.AppendLine("         OPERATOR_ID, ")
            stbSQL.AppendLine("         COMPANY_ID, ")
            stbSQL.AppendLine("         BUSINESS_ID, ")
            stbSQL.AppendLine("         PROJECT_ID, ")
            stbSQL.AppendLine("         SUBJECT_NO, ")
            stbSQL.AppendLine("         WORK_LEVEL, ")
            stbSQL.AppendLine("         SLIP_DEF  ")
            stbSQL.AppendLine("order by ")
            stbSQL.AppendLine("         SHORI_DATE, ")
            stbSQL.AppendLine("         LOCATION_ID, ")
            stbSQL.AppendLine("         DEP_CODE, ")
            stbSQL.AppendLine("         OPERATOR_ID, ")
            stbSQL.AppendLine("         COMPANY_ID, ")
            stbSQL.AppendLine("         BUSINESS_ID, ")
            stbSQL.AppendLine("         PROJECT_ID, ")
            stbSQL.AppendLine("         SUBJECT_NO, ")
            stbSQL.AppendLine("         WORK_LEVEL, ")
            stbSQL.AppendLine("         SLIP_DEF  ")

            stbSQL.Replace("%START_DATE%", str開始日)
            stbSQL.Replace("%END_DATE%", str終了日)

            Dim dt As DataTable = My.Application.comDB.DB_ExecuteQuery(stbSQL.ToString)
            Return dt

        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Function
#End Region


#Region "オペレータ統計ファイル出力"
    Private Sub オペレータ統計ファイル出力(dtbオペレータ統計 As DataTable, strオペレータ統計ファイル名 As String, strヘッダーレコード出力 As String)

        Dim idx1 As Integer = -1
        Dim idx2 As Integer = -1
        Dim sr As StreamWriter = Nothing
        Dim enc As System.Text.Encoding = Nothing
        Dim sb出力データ As StringBuilder = Nothing
        Dim strデリミタ As String = String.Empty

        Try
            ToolStripStatusLabel1.Text = "ファイル作成前処理中"

            enc = Encoding.GetEncoding("Shift-JIS")
            sr = New StreamWriter(strオペレータ統計ファイル名, False, enc)

            sb出力データ = New StringBuilder

            '指定がある場合はヘッダーレコードを出力する。
            If strヘッダーレコード出力.Equals("1") Then
                strデリミタ = String.Empty
                sb出力データ.Clear()
                For idx1 = 0 To dtbオペレータ統計.Columns.Count - 1
                    sb出力データ.Append(strデリミタ & dtbオペレータ統計.Columns(idx1).ColumnName)
                    strデリミタ = ","
                Next
                sr.WriteLine(sb出力データ.ToString)
            End If

            'オペレータ統計データを出力する。
            For idx1 = 0 To dtbオペレータ統計.Rows.Count - 1
                ToolStripStatusLabel1.Text = "ファイル出力中" & (idx1 + 1).ToString & " / " & dtbオペレータ統計.Rows.Count.ToString
                strデリミタ = String.Empty
                sb出力データ.Clear()
                For idx2 = 0 To dtbオペレータ統計.Columns.Count - 1
                    sb出力データ.Append(strデリミタ & dtbオペレータ統計.Rows(idx1).Item(idx2))
                    strデリミタ = ","
                Next
                sr.WriteLine(sb出力データ.ToString)
            Next

            sr.Close()

            Exit Sub

        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        Finally
            If Not sr Is Nothing Then
                sr.Dispose()
                sr = Nothing
            End If
            If Not enc Is Nothing Then
                enc = Nothing
            End If
            If Not sb出力データ Is Nothing Then
                sb出力データ = Nothing
            End If

        End Try
    End Sub
#End Region

End Class