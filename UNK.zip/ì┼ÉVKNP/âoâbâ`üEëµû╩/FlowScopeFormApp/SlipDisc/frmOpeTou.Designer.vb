﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmOpeTou
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmOpeTou))
        Me.Btn終了 = New System.Windows.Forms.Button()
        Me.dtp終了日 = New System.Windows.Forms.DateTimePicker()
        Me.dtp開始日 = New System.Windows.Forms.DateTimePicker()
        Me.lbl開始日 = New System.Windows.Forms.Label()
        Me.lbl終了日 = New System.Windows.Forms.Label()
        Me.btn出力 = New System.Windows.Forms.Button()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.StatusStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Btn終了
        '
        Me.Btn終了.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Btn終了.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Btn終了.Location = New System.Drawing.Point(447, 148)
        Me.Btn終了.Name = "Btn終了"
        Me.Btn終了.Size = New System.Drawing.Size(121, 40)
        Me.Btn終了.TabIndex = 25
        Me.Btn終了.Text = "終了"
        Me.Btn終了.UseVisualStyleBackColor = True
        '
        'dtp終了日
        '
        Me.dtp終了日.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.dtp終了日.Location = New System.Drawing.Point(160, 98)
        Me.dtp終了日.Name = "dtp終了日"
        Me.dtp終了日.Size = New System.Drawing.Size(134, 23)
        Me.dtp終了日.TabIndex = 28
        '
        'dtp開始日
        '
        Me.dtp開始日.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.dtp開始日.Location = New System.Drawing.Point(160, 41)
        Me.dtp開始日.Name = "dtp開始日"
        Me.dtp開始日.Size = New System.Drawing.Size(134, 23)
        Me.dtp開始日.TabIndex = 27
        '
        'lbl開始日
        '
        Me.lbl開始日.AutoSize = True
        Me.lbl開始日.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lbl開始日.Location = New System.Drawing.Point(41, 41)
        Me.lbl開始日.Name = "lbl開始日"
        Me.lbl開始日.Size = New System.Drawing.Size(76, 16)
        Me.lbl開始日.TabIndex = 26
        Me.lbl開始日.Text = "開始日："
        '
        'lbl終了日
        '
        Me.lbl終了日.AutoSize = True
        Me.lbl終了日.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lbl終了日.Location = New System.Drawing.Point(41, 105)
        Me.lbl終了日.Name = "lbl終了日"
        Me.lbl終了日.Size = New System.Drawing.Size(76, 16)
        Me.lbl終了日.TabIndex = 29
        Me.lbl終了日.Text = "終了日："
        '
        'btn出力
        '
        Me.btn出力.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn出力.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.btn出力.Location = New System.Drawing.Point(12, 148)
        Me.btn出力.Name = "btn出力"
        Me.btn出力.Size = New System.Drawing.Size(121, 40)
        Me.btn出力.TabIndex = 30
        Me.btn出力.Text = "出力"
        Me.btn出力.UseVisualStyleBackColor = True
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 196)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(580, 23)
        Me.StatusStrip1.TabIndex = 31
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(136, 18)
        Me.ToolStripStatusLabel1.Text = "ToolStripStatusLabel1"
        '
        'frmOpeTou
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(580, 219)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.btn出力)
        Me.Controls.Add(Me.lbl終了日)
        Me.Controls.Add(Me.dtp終了日)
        Me.Controls.Add(Me.dtp開始日)
        Me.Controls.Add(Me.lbl開始日)
        Me.Controls.Add(Me.Btn終了)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmOpeTou"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "協会けんぽ　帳票再識別　- オペレータ統計出力 -"
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Btn終了 As System.Windows.Forms.Button
    Friend WithEvents dtp終了日 As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtp開始日 As System.Windows.Forms.DateTimePicker
    Friend WithEvents lbl開始日 As System.Windows.Forms.Label
    Friend WithEvents lbl終了日 As System.Windows.Forms.Label
    Friend WithEvents btn出力 As System.Windows.Forms.Button
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
End Class
