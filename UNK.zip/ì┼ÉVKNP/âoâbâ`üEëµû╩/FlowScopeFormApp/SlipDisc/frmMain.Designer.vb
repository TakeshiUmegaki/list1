﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtSubCount = New System.Windows.Forms.TextBox()
        Me.txtFileName = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtReceiptDate = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtDeliveryPlan = New System.Windows.Forms.TextBox()
        Me.btnPrevPage = New System.Windows.Forms.Button()
        Me.btnNextPage = New System.Windows.Forms.Button()
        Me.txtPageNum = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.dgvList = New System.Windows.Forms.DataGridView()
        Me.SLIP_DEFINE_ID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SLIP_DEFINE_NAME = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.btnZoomDown = New System.Windows.Forms.Button()
        Me.btnZoomUp = New System.Windows.Forms.Button()
        Me.btnDisplayFit = New System.Windows.Forms.Button()
        Me.btnRotate = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtSlipPrefix = New System.Windows.Forms.TextBox()
        Me.txtSlipSurfix = New System.Windows.Forms.TextBox()
        Me.btnPageCommit = New System.Windows.Forms.Button()
        Me.btnBreak = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtNowPage = New System.Windows.Forms.TextBox()
        Me.txtErrorInfo = New System.Windows.Forms.TextBox()
        Me.btnProCommit = New System.Windows.Forms.Button()
        Me.chk4Over = New System.Windows.Forms.CheckBox()
        Me.rdoSS = New System.Windows.Forms.RadioButton()
        Me.rdoNonSS = New System.Windows.Forms.RadioButton()
        Me.CtlImage1 = New SlipDisc.ctlImage()
        Me.CtlImage2 = New SlipDisc.ctlImage()
        Me.Panel1.SuspendLayout()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.dgvList, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label1.Location = New System.Drawing.Point(92, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(88, 16)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "残案件数："
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label2.Location = New System.Drawing.Point(12, 37)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(168, 16)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "イメージファイル名："
        '
        'txtSubCount
        '
        Me.txtSubCount.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.txtSubCount.Location = New System.Drawing.Point(186, 6)
        Me.txtSubCount.Name = "txtSubCount"
        Me.txtSubCount.ReadOnly = True
        Me.txtSubCount.Size = New System.Drawing.Size(100, 23)
        Me.txtSubCount.TabIndex = 1
        Me.txtSubCount.TabStop = False
        '
        'txtFileName
        '
        Me.txtFileName.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.txtFileName.Location = New System.Drawing.Point(186, 34)
        Me.txtFileName.Name = "txtFileName"
        Me.txtFileName.ReadOnly = True
        Me.txtFileName.Size = New System.Drawing.Size(366, 23)
        Me.txtFileName.TabIndex = 3
        Me.txtFileName.TabStop = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label3.Location = New System.Drawing.Point(559, 37)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(88, 16)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "受付日時："
        '
        'txtReceiptDate
        '
        Me.txtReceiptDate.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.txtReceiptDate.Location = New System.Drawing.Point(653, 34)
        Me.txtReceiptDate.Name = "txtReceiptDate"
        Me.txtReceiptDate.ReadOnly = True
        Me.txtReceiptDate.Size = New System.Drawing.Size(171, 23)
        Me.txtReceiptDate.TabIndex = 5
        Me.txtReceiptDate.TabStop = False
        Me.txtReceiptDate.Text = "9999/99/99 99:99:99"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label4.Location = New System.Drawing.Point(832, 37)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(120, 16)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "納品予定日時："
        '
        'txtDeliveryPlan
        '
        Me.txtDeliveryPlan.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.txtDeliveryPlan.Location = New System.Drawing.Point(958, 34)
        Me.txtDeliveryPlan.Name = "txtDeliveryPlan"
        Me.txtDeliveryPlan.ReadOnly = True
        Me.txtDeliveryPlan.Size = New System.Drawing.Size(171, 23)
        Me.txtDeliveryPlan.TabIndex = 7
        Me.txtDeliveryPlan.TabStop = False
        Me.txtDeliveryPlan.Text = "9999/99/99 99:99:99"
        '
        'btnPrevPage
        '
        Me.btnPrevPage.Location = New System.Drawing.Point(835, 8)
        Me.btnPrevPage.Name = "btnPrevPage"
        Me.btnPrevPage.Size = New System.Drawing.Size(32, 23)
        Me.btnPrevPage.TabIndex = 8
        Me.btnPrevPage.Text = "←"
        Me.btnPrevPage.UseVisualStyleBackColor = True
        '
        'btnNextPage
        '
        Me.btnNextPage.Location = New System.Drawing.Point(867, 8)
        Me.btnNextPage.Name = "btnNextPage"
        Me.btnNextPage.Size = New System.Drawing.Size(32, 23)
        Me.btnNextPage.TabIndex = 9
        Me.btnNextPage.Text = "→"
        Me.btnNextPage.UseVisualStyleBackColor = True
        '
        'txtPageNum
        '
        Me.txtPageNum.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.txtPageNum.Location = New System.Drawing.Point(954, 8)
        Me.txtPageNum.Name = "txtPageNum"
        Me.txtPageNum.ReadOnly = True
        Me.txtPageNum.Size = New System.Drawing.Size(39, 23)
        Me.txtPageNum.TabIndex = 12
        Me.txtPageNum.TabStop = False
        Me.txtPageNum.Text = "999"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label5.Location = New System.Drawing.Point(995, 11)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(56, 16)
        Me.Label5.TabIndex = 13
        Me.Label5.Text = "ページ"
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.Controls.Add(Me.SplitContainer1)
        Me.Panel1.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Panel1.Location = New System.Drawing.Point(12, 63)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1027, 511)
        Me.Panel1.TabIndex = 12
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.CtlImage1)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.CtlImage2)
        Me.SplitContainer1.Size = New System.Drawing.Size(1027, 511)
        Me.SplitContainer1.SplitterDistance = 510
        Me.SplitContainer1.TabIndex = 0
        '
        'Panel2
        '
        Me.Panel2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel2.Controls.Add(Me.dgvList)
        Me.Panel2.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Panel2.Location = New System.Drawing.Point(1045, 63)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(403, 383)
        Me.Panel2.TabIndex = 13
        '
        'dgvList
        '
        Me.dgvList.AllowUserToAddRows = False
        Me.dgvList.AllowUserToDeleteRows = False
        Me.dgvList.AllowUserToResizeColumns = False
        Me.dgvList.AllowUserToResizeRows = False
        Me.dgvList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvList.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.SLIP_DEFINE_ID, Me.SLIP_DEFINE_NAME})
        Me.dgvList.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgvList.Location = New System.Drawing.Point(0, 0)
        Me.dgvList.MultiSelect = False
        Me.dgvList.Name = "dgvList"
        Me.dgvList.ReadOnly = True
        Me.dgvList.RowHeadersVisible = False
        Me.dgvList.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.dgvList.RowTemplate.Height = 21
        Me.dgvList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvList.Size = New System.Drawing.Size(403, 383)
        Me.dgvList.TabIndex = 0
        '
        'SLIP_DEFINE_ID
        '
        Me.SLIP_DEFINE_ID.DataPropertyName = "SLIP_DEFINE_ID"
        Me.SLIP_DEFINE_ID.HeaderText = "様式番号"
        Me.SLIP_DEFINE_ID.Name = "SLIP_DEFINE_ID"
        Me.SLIP_DEFINE_ID.ReadOnly = True
        '
        'SLIP_DEFINE_NAME
        '
        Me.SLIP_DEFINE_NAME.DataPropertyName = "SLIP_DEFINE_NAME"
        Me.SLIP_DEFINE_NAME.HeaderText = "帳票名"
        Me.SLIP_DEFINE_NAME.Name = "SLIP_DEFINE_NAME"
        Me.SLIP_DEFINE_NAME.ReadOnly = True
        Me.SLIP_DEFINE_NAME.Width = 275
        '
        'btnZoomDown
        '
        Me.btnZoomDown.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnZoomDown.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.btnZoomDown.Location = New System.Drawing.Point(15, 580)
        Me.btnZoomDown.Name = "btnZoomDown"
        Me.btnZoomDown.Size = New System.Drawing.Size(114, 34)
        Me.btnZoomDown.TabIndex = 14
        Me.btnZoomDown.Text = "縮小[F1]"
        Me.btnZoomDown.UseVisualStyleBackColor = True
        '
        'btnZoomUp
        '
        Me.btnZoomUp.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnZoomUp.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.btnZoomUp.Location = New System.Drawing.Point(135, 580)
        Me.btnZoomUp.Name = "btnZoomUp"
        Me.btnZoomUp.Size = New System.Drawing.Size(114, 34)
        Me.btnZoomUp.TabIndex = 15
        Me.btnZoomUp.Text = "拡大[F2]"
        Me.btnZoomUp.UseVisualStyleBackColor = True
        '
        'btnDisplayFit
        '
        Me.btnDisplayFit.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnDisplayFit.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.btnDisplayFit.Location = New System.Drawing.Point(255, 580)
        Me.btnDisplayFit.Name = "btnDisplayFit"
        Me.btnDisplayFit.Size = New System.Drawing.Size(114, 34)
        Me.btnDisplayFit.TabIndex = 16
        Me.btnDisplayFit.Text = "元に戻す[F3]"
        Me.btnDisplayFit.UseVisualStyleBackColor = True
        '
        'btnRotate
        '
        Me.btnRotate.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnRotate.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.btnRotate.Location = New System.Drawing.Point(375, 580)
        Me.btnRotate.Name = "btnRotate"
        Me.btnRotate.Size = New System.Drawing.Size(114, 34)
        Me.btnRotate.TabIndex = 17
        Me.btnRotate.Text = "右回転[F4]"
        Me.btnRotate.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label6.Location = New System.Drawing.Point(523, 589)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(88, 16)
        Me.Label6.TabIndex = 18
        Me.Label6.Text = "様式番号："
        '
        'txtSlipPrefix
        '
        Me.txtSlipPrefix.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtSlipPrefix.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.txtSlipPrefix.Location = New System.Drawing.Point(611, 586)
        Me.txtSlipPrefix.Name = "txtSlipPrefix"
        Me.txtSlipPrefix.ReadOnly = True
        Me.txtSlipPrefix.Size = New System.Drawing.Size(40, 23)
        Me.txtSlipPrefix.TabIndex = 19
        Me.txtSlipPrefix.TabStop = False
        Me.txtSlipPrefix.Text = "999"
        Me.txtSlipPrefix.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtSlipSurfix
        '
        Me.txtSlipSurfix.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtSlipSurfix.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.txtSlipSurfix.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me.txtSlipSurfix.Location = New System.Drawing.Point(654, 586)
        Me.txtSlipSurfix.MaxLength = 3
        Me.txtSlipSurfix.Name = "txtSlipSurfix"
        Me.txtSlipSurfix.Size = New System.Drawing.Size(40, 23)
        Me.txtSlipSurfix.TabIndex = 20
        Me.txtSlipSurfix.Text = "999"
        Me.txtSlipSurfix.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btnPageCommit
        '
        Me.btnPageCommit.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnPageCommit.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.btnPageCommit.Location = New System.Drawing.Point(910, 580)
        Me.btnPageCommit.Name = "btnPageCommit"
        Me.btnPageCommit.Size = New System.Drawing.Size(129, 34)
        Me.btnPageCommit.TabIndex = 21
        Me.btnPageCommit.Text = "ページ確定[F6]"
        Me.btnPageCommit.UseVisualStyleBackColor = True
        '
        'btnBreak
        '
        Me.btnBreak.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnBreak.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.btnBreak.Location = New System.Drawing.Point(1334, 580)
        Me.btnBreak.Name = "btnBreak"
        Me.btnBreak.Size = New System.Drawing.Size(114, 34)
        Me.btnBreak.TabIndex = 22
        Me.btnBreak.Text = "中断[F12]"
        Me.btnBreak.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label7.Location = New System.Drawing.Point(937, 11)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(16, 16)
        Me.Label7.TabIndex = 11
        Me.Label7.Text = "/"
        '
        'txtNowPage
        '
        Me.txtNowPage.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.txtNowPage.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me.txtNowPage.Location = New System.Drawing.Point(904, 8)
        Me.txtNowPage.MaxLength = 3
        Me.txtNowPage.Name = "txtNowPage"
        Me.txtNowPage.Size = New System.Drawing.Size(30, 23)
        Me.txtNowPage.TabIndex = 10
        Me.txtNowPage.Text = "999"
        Me.txtNowPage.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtErrorInfo
        '
        Me.txtErrorInfo.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtErrorInfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtErrorInfo.Location = New System.Drawing.Point(1046, 452)
        Me.txtErrorInfo.Multiline = True
        Me.txtErrorInfo.Name = "txtErrorInfo"
        Me.txtErrorInfo.ReadOnly = True
        Me.txtErrorInfo.Size = New System.Drawing.Size(402, 118)
        Me.txtErrorInfo.TabIndex = 23
        '
        'btnProCommit
        '
        Me.btnProCommit.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnProCommit.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.btnProCommit.Location = New System.Drawing.Point(1045, 580)
        Me.btnProCommit.Name = "btnProCommit"
        Me.btnProCommit.Size = New System.Drawing.Size(129, 34)
        Me.btnProCommit.TabIndex = 24
        Me.btnProCommit.Text = "案件確定[F9]"
        Me.btnProCommit.UseVisualStyleBackColor = True
        '
        'chk4Over
        '
        Me.chk4Over.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.chk4Over.AutoSize = True
        Me.chk4Over.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.chk4Over.Location = New System.Drawing.Point(727, 588)
        Me.chk4Over.Name = "chk4Over"
        Me.chk4Over.Size = New System.Drawing.Size(163, 20)
        Me.chk4Over.TabIndex = 25
        Me.chk4Over.Text = "4件目以降データ有"
        Me.chk4Over.UseVisualStyleBackColor = True
        '
        'rdoSS
        '
        Me.rdoSS.AutoSize = True
        Me.rdoSS.Location = New System.Drawing.Point(341, 9)
        Me.rdoSS.Name = "rdoSS"
        Me.rdoSS.Size = New System.Drawing.Size(61, 16)
        Me.rdoSS.TabIndex = 26
        Me.rdoSS.TabStop = True
        Me.rdoSS.Text = "SS帳票"
        Me.rdoSS.UseVisualStyleBackColor = True
        '
        'rdoNonSS
        '
        Me.rdoNonSS.AutoSize = True
        Me.rdoNonSS.Location = New System.Drawing.Point(408, 9)
        Me.rdoNonSS.Name = "rdoNonSS"
        Me.rdoNonSS.Size = New System.Drawing.Size(73, 16)
        Me.rdoNonSS.TabIndex = 27
        Me.rdoNonSS.TabStop = True
        Me.rdoNonSS.Text = "非SS帳票"
        Me.rdoNonSS.UseVisualStyleBackColor = True
        '
        'CtlImage1
        '
        Me.CtlImage1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.CtlImage1.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.CtlImage1.Location = New System.Drawing.Point(0, 0)
        Me.CtlImage1.Margin = New System.Windows.Forms.Padding(4)
        Me.CtlImage1.Name = "CtlImage1"
        Me.CtlImage1.Size = New System.Drawing.Size(510, 511)
        Me.CtlImage1.TabIndex = 0
        '
        'CtlImage2
        '
        Me.CtlImage2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.CtlImage2.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.CtlImage2.Location = New System.Drawing.Point(0, 0)
        Me.CtlImage2.Margin = New System.Windows.Forms.Padding(4)
        Me.CtlImage2.Name = "CtlImage2"
        Me.CtlImage2.Size = New System.Drawing.Size(513, 511)
        Me.CtlImage2.TabIndex = 0
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1460, 626)
        Me.Controls.Add(Me.rdoNonSS)
        Me.Controls.Add(Me.rdoSS)
        Me.Controls.Add(Me.chk4Over)
        Me.Controls.Add(Me.btnProCommit)
        Me.Controls.Add(Me.txtErrorInfo)
        Me.Controls.Add(Me.txtNowPage)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.btnBreak)
        Me.Controls.Add(Me.btnPageCommit)
        Me.Controls.Add(Me.txtSlipSurfix)
        Me.Controls.Add(Me.txtSlipPrefix)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.btnRotate)
        Me.Controls.Add(Me.btnDisplayFit)
        Me.Controls.Add(Me.btnZoomUp)
        Me.Controls.Add(Me.btnZoomDown)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtPageNum)
        Me.Controls.Add(Me.btnNextPage)
        Me.Controls.Add(Me.btnPrevPage)
        Me.Controls.Add(Me.txtDeliveryPlan)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtReceiptDate)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtFileName)
        Me.Controls.Add(Me.txtSubCount)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "協会けんぽ　帳票再識別　- 再識別処理 -"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        CType(Me.dgvList, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtSubCount As System.Windows.Forms.TextBox
    Friend WithEvents txtFileName As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtReceiptDate As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtDeliveryPlan As System.Windows.Forms.TextBox
    Friend WithEvents btnPrevPage As System.Windows.Forms.Button
    Friend WithEvents btnNextPage As System.Windows.Forms.Button
    Friend WithEvents txtPageNum As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents CtlImage1 As SlipDisc.ctlImage
    Friend WithEvents CtlImage2 As SlipDisc.ctlImage
    Friend WithEvents dgvList As System.Windows.Forms.DataGridView
    Friend WithEvents btnZoomDown As System.Windows.Forms.Button
    Friend WithEvents btnZoomUp As System.Windows.Forms.Button
    Friend WithEvents btnDisplayFit As System.Windows.Forms.Button
    Friend WithEvents btnRotate As System.Windows.Forms.Button
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtSlipPrefix As System.Windows.Forms.TextBox
    Friend WithEvents txtSlipSurfix As System.Windows.Forms.TextBox
    Friend WithEvents btnPageCommit As System.Windows.Forms.Button
    Friend WithEvents btnBreak As System.Windows.Forms.Button
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtNowPage As System.Windows.Forms.TextBox
    Friend WithEvents SLIP_DEFINE_ID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SLIP_DEFINE_NAME As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents txtErrorInfo As System.Windows.Forms.TextBox
    Friend WithEvents btnProCommit As System.Windows.Forms.Button
    Friend WithEvents chk4Over As System.Windows.Forms.CheckBox
    Friend WithEvents rdoSS As System.Windows.Forms.RadioButton
    Friend WithEvents rdoNonSS As System.Windows.Forms.RadioButton
End Class
