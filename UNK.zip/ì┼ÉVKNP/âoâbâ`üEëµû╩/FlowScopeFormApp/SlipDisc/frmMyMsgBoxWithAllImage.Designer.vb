﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMyMsgBoxWithAllImage
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnYes = New System.Windows.Forms.Button()
        Me.btnNo = New System.Windows.Forms.Button()
        Me.pnlSlipList = New System.Windows.Forms.Panel()
        Me.lblColorEntry = New System.Windows.Forms.Label()
        Me.lblColorNotEntry = New System.Windows.Forms.Label()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Location = New System.Drawing.Point(12, 21)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(32, 32)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(50, 28)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(184, 16)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "登録してよろしいですか"
        '
        'btnYes
        '
        Me.btnYes.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnYes.Location = New System.Drawing.Point(12, 773)
        Me.btnYes.Name = "btnYes"
        Me.btnYes.Size = New System.Drawing.Size(75, 32)
        Me.btnYes.TabIndex = 2
        Me.btnYes.Text = "はい"
        Me.btnYes.UseVisualStyleBackColor = True
        '
        'btnNo
        '
        Me.btnNo.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnNo.Location = New System.Drawing.Point(1737, 773)
        Me.btnNo.Name = "btnNo"
        Me.btnNo.Size = New System.Drawing.Size(75, 32)
        Me.btnNo.TabIndex = 3
        Me.btnNo.Text = "いいえ"
        Me.btnNo.UseVisualStyleBackColor = True
        '
        'pnlSlipList
        '
        Me.pnlSlipList.AutoScroll = True
        Me.pnlSlipList.Location = New System.Drawing.Point(12, 58)
        Me.pnlSlipList.Name = "pnlSlipList"
        Me.pnlSlipList.Size = New System.Drawing.Size(1800, 709)
        Me.pnlSlipList.TabIndex = 7
        '
        'lblColorEntry
        '
        Me.lblColorEntry.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblColorEntry.BackColor = System.Drawing.Color.Red
        Me.lblColorEntry.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblColorEntry.Font = New System.Drawing.Font("ＭＳ ゴシック", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblColorEntry.Location = New System.Drawing.Point(1577, 30)
        Me.lblColorEntry.Name = "lblColorEntry"
        Me.lblColorEntry.Size = New System.Drawing.Size(114, 25)
        Me.lblColorEntry.TabIndex = 9
        Me.lblColorEntry.Text = "(XX指定帳票)"
        Me.lblColorEntry.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblColorNotEntry
        '
        Me.lblColorNotEntry.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblColorNotEntry.BackColor = System.Drawing.Color.Red
        Me.lblColorNotEntry.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblColorNotEntry.Font = New System.Drawing.Font("ＭＳ ゴシック", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblColorNotEntry.Location = New System.Drawing.Point(1698, 30)
        Me.lblColorNotEntry.Name = "lblColorNotEntry"
        Me.lblColorNotEntry.Size = New System.Drawing.Size(114, 25)
        Me.lblColorNotEntry.TabIndex = 10
        Me.lblColorNotEntry.Text = "(XX指定帳票)"
        Me.lblColorNotEntry.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'frmMyMsgBoxWithAllImage
        '
        Me.AcceptButton = Me.btnNo
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1824, 811)
        Me.ControlBox = False
        Me.Controls.Add(Me.lblColorNotEntry)
        Me.Controls.Add(Me.lblColorEntry)
        Me.Controls.Add(Me.pnlSlipList)
        Me.Controls.Add(Me.btnNo)
        Me.Controls.Add(Me.btnYes)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "frmMyMsgBoxWithAllImage"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "確認"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnYes As System.Windows.Forms.Button
    Friend WithEvents btnNo As System.Windows.Forms.Button
    Friend WithEvents pnlSlipList As System.Windows.Forms.Panel
    Friend WithEvents lblColorEntry As System.Windows.Forms.Label
    Friend WithEvents lblColorNotEntry As System.Windows.Forms.Label
End Class
