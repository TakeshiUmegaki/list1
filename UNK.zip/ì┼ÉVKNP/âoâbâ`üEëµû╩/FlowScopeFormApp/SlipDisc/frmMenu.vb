﻿Imports CommonSystem
Imports System
Imports System.Text
Imports Oracle.DataAccess

Public Class frmMenu

#Region "定数定義"
    Private Const APP_NAME As String = "帳票再識別"
#End Region

#Region "ウインドウ初期表示処理"
    ''' <summary>
    ''' ウインドウ初期表示処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub frmMenu_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Call 件数表示()
        Me.Text = "協会けんぽ　" & My.Application.mdicConfig("FORM_TITLE") & " - メニュー -"
        Me.ActiveControl = Btn終了

    End Sub
#End Region

#Region "件数表示"
    ''' <summary>
    ''' 件数表示
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub 件数表示()

        Dim f As New frmMain
        Dim dt As DataTable
        Dim btnLabel() As String

        If My.Application.mdicConfig("SELECT_SLIP").Equals("1") Then
            f.rdoNonSS.Checked = False
            f.rdoSS.Checked = True
        Else
            f.rdoSS.Checked = False
            f.rdoNonSS.Checked = True
        End If

        dt = f.GetImage(frmMain.動作モード選択.First)
        btnLabel = btn帳票再識別１回目.Text.Split("～")
        btn帳票再識別１回目.Text = btnLabel(0)
        If IsNothing(dt) = False Then
            btn帳票再識別１回目.Text &= "～" & dt.Rows.Count.ToString & "案件"
            dt.Rows.Clear()
            dt.Dispose()
        Else
            btn帳票再識別１回目.Text &= "～0案件"
        End If

        dt = f.GetImage(frmMain.動作モード選択.Second)
        btnLabel = Btn帳票再識別２回目.Text.Split("～")
        Btn帳票再識別２回目.Text = btnLabel(0)
        If IsNothing(dt) = False Then
            Btn帳票再識別２回目.Text &= "～" & dt.Rows.Count.ToString & "案件"
            dt.Rows.Clear()
            dt.Dispose()
        Else
            Btn帳票再識別２回目.Text &= "～0案件"
        End If

        f.Dispose()
        f = Nothing

    End Sub
#End Region
#Region "帳票再識別１回目ボタン処理"
    ''' <summary>
    ''' 帳票再識別１回目ボタン処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btn帳票再識別１回目_Click(sender As Object, e As EventArgs) Handles btn帳票再識別１回目.Click
        Dim f As New frmMain
        f.m動作モード = frmMain.動作モード選択.First
        f.ShowDialog()
        f.Dispose()
        f = Nothing
        Call 件数表示()
    End Sub
#End Region

#Region "帳票再識別２回目ボタン処理"
    ''' <summary>
    ''' 帳票再々識別ボタン処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Btn帳票再識別２回目_Click(sender As Object, e As EventArgs) Handles Btn帳票再識別２回目.Click
        Dim f As New frmMain
        f.m動作モード = frmMain.動作モード選択.Second
        f.ShowDialog()
        f.Dispose()
        f = Nothing
        Call 件数表示()
    End Sub
#End Region

#Region "オペレータ統計出力ボタン処理"
    ''' <summary>
    ''' オペレータ統計出力ボタン処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Btnオペレータ統計出力_Click(sender As Object, e As EventArgs) Handles Btnオペレータ統計出力.Click
        Dim f As New frmOpeTou
        f.ShowDialog()
        f.Dispose()
        f = Nothing
        Call 件数表示()
    End Sub
#End Region

#Region "終了ボタン処理"
    ''' <summary>
    ''' 終了ボタン処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Btn終了_Click(sender As Object, e As EventArgs) Handles Btn終了.Click
        Try
            Me.Close()
        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

End Class