﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMenu
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMenu))
        Me.btn帳票再識別１回目 = New System.Windows.Forms.Button()
        Me.Btn帳票再識別２回目 = New System.Windows.Forms.Button()
        Me.Btnオペレータ統計出力 = New System.Windows.Forms.Button()
        Me.Btn終了 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btn帳票再識別１回目
        '
        Me.btn帳票再識別１回目.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn帳票再識別１回目.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.btn帳票再識別１回目.Location = New System.Drawing.Point(80, 44)
        Me.btn帳票再識別１回目.Name = "btn帳票再識別１回目"
        Me.btn帳票再識別１回目.Size = New System.Drawing.Size(429, 40)
        Me.btn帳票再識別１回目.TabIndex = 22
        Me.btn帳票再識別１回目.Text = "帳票再識別１回目"
        Me.btn帳票再識別１回目.UseVisualStyleBackColor = True
        '
        'Btn帳票再識別２回目
        '
        Me.Btn帳票再識別２回目.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Btn帳票再識別２回目.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Btn帳票再識別２回目.Location = New System.Drawing.Point(80, 90)
        Me.Btn帳票再識別２回目.Name = "Btn帳票再識別２回目"
        Me.Btn帳票再識別２回目.Size = New System.Drawing.Size(429, 40)
        Me.Btn帳票再識別２回目.TabIndex = 23
        Me.Btn帳票再識別２回目.Text = "帳票再識別２回目"
        Me.Btn帳票再識別２回目.UseVisualStyleBackColor = True
        '
        'Btnオペレータ統計出力
        '
        Me.Btnオペレータ統計出力.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Btnオペレータ統計出力.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Btnオペレータ統計出力.Location = New System.Drawing.Point(80, 136)
        Me.Btnオペレータ統計出力.Name = "Btnオペレータ統計出力"
        Me.Btnオペレータ統計出力.Size = New System.Drawing.Size(429, 40)
        Me.Btnオペレータ統計出力.TabIndex = 24
        Me.Btnオペレータ統計出力.Text = "オペレータ統計出力"
        Me.Btnオペレータ統計出力.UseVisualStyleBackColor = True
        '
        'Btn終了
        '
        Me.Btn終了.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Btn終了.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Btn終了.Location = New System.Drawing.Point(79, 212)
        Me.Btn終了.Name = "Btn終了"
        Me.Btn終了.Size = New System.Drawing.Size(429, 40)
        Me.Btn終了.TabIndex = 25
        Me.Btn終了.Text = "終了"
        Me.Btn終了.UseVisualStyleBackColor = True
        '
        'frmMenu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(585, 326)
        Me.Controls.Add(Me.Btn終了)
        Me.Controls.Add(Me.Btnオペレータ統計出力)
        Me.Controls.Add(Me.Btn帳票再識別２回目)
        Me.Controls.Add(Me.btn帳票再識別１回目)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmMenu"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "協会けんぽ　帳票再識別　- メニュー -"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btn帳票再識別１回目 As System.Windows.Forms.Button
    Friend WithEvents Btn帳票再識別２回目 As System.Windows.Forms.Button
    Friend WithEvents Btnオペレータ統計出力 As System.Windows.Forms.Button
    Friend WithEvents Btn終了 As System.Windows.Forms.Button
End Class
