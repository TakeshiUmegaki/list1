﻿Public Class UserControlSlipDisc

    Dim mStrNo As String = String.Empty
    Dim mStrSlipIDBeforeMod As String = String.Empty
    Dim mStrSlipNameBeforeMod As String = String.Empty
    Dim mStrSlipIDAfterMod As String = String.Empty
    Dim mStrSlipNameAfterMod As String = String.Empty
    Dim mStrImageFileFullPath As String = String.Empty
    Dim mClrBackColor As Color
    Dim mBool大モニター As Boolean

    Public m既ロードイメージ As Bitmap = Nothing
    '指定されたデータを表示する。
    Public Sub setDispData( _
        strNo As String, _
        strSlipIDBeforeMod As String, strSlipNameBeforeMod As String, _
        strSlipIDAfterMod As String, strSlipNameAfterMod As String, _
        strImageFileFullPath As String, _
        ClrBackColor As Color, _
        bool大モニター As Boolean, _
        Optional イメージ表示 As Boolean = False _
    )
        Dim longWidth As Long = -1
        Dim longHeight As Long = -1

        Try
            mStrNo = strNo
            mStrSlipIDBeforeMod = strSlipIDBeforeMod
            mStrSlipNameBeforeMod = strSlipNameBeforeMod
            mStrSlipIDAfterMod = strSlipIDAfterMod
            mStrSlipNameAfterMod = strSlipNameAfterMod
            mStrImageFileFullPath = strImageFileFullPath
            mClrBackColor = ClrBackColor

            mBool大モニター = bool大モニター

            Me.BackColor = ClrBackColor
            txtSlipImage.BackColor = mClrBackColor

            set画面属性()

            '編集後の帳票IDを設定する。
            txtSlipIDAfterMod.Font = New Font("ＭＳ ゴシック", 9)
            txtSlipIDAfterMod.Text = mStrSlipIDAfterMod
            txtSlipIDAfterMod.TextAlign = HorizontalAlignment.Left
            txtSlipIDAfterMod.BackColor = mClrBackColor

            '編集後の帳票名を設定する。
            txtSlipNameAfterMod.Font = New Font("ＭＳ ゴシック", 10)
            txtSlipNameAfterMod.Text = mStrSlipNameAfterMod
            txtSlipNameAfterMod.TextAlign = HorizontalAlignment.Left
            txtSlipNameAfterMod.BackColor = mClrBackColor

            '帳票画像を設定する。
            If イメージ表示 = True Then
                If IsNothing(m既ロードイメージ) = False Then
                    picSlipImage.Image = m既ロードイメージ
                    longWidth = m既ロードイメージ.Width
                    longHeight = m既ロードイメージ.Height
                    If longWidth > longHeight Then
                        picSlipImage.Width = picSlipImage.Width * 2
                    End If
                    picSlipImage.SizeMode = PictureBoxSizeMode.Zoom
                    picSlipImage.BackColor = mClrBackColor
                ElseIf System.IO.File.Exists(mStrImageFileFullPath) Then
                    picSlipImage.ImageLocation = mStrImageFileFullPath
                    'A3の場合は横長表示にする。
                    longWidth = Image.FromFile(mStrImageFileFullPath).Width
                    longHeight = Image.FromFile(mStrImageFileFullPath).Height
                    If longWidth > longHeight Then
                        'picSlipImage.SizeMode = PictureBoxSizeMode.Normal
                        picSlipImage.Width = picSlipImage.Width * 2
                    End If
                    picSlipImage.SizeMode = PictureBoxSizeMode.Zoom
                    picSlipImage.BackColor = mClrBackColor
                Else
                    picSlipImage.Visible = False
                    txtSlipImage.Text = "画像ファイルなし"
                End If
            Else
                picSlipImage.Visible = False
                txtSlipImage.Text = "画像ファイル未ロード"
            End If

            Exit Sub

        Catch ex As Exception
            Throw ex
            Exit Sub
            End
        End Try

    End Sub


    Private Sub set画面属性()
        Try
            Select Case mBool大モニター
                Case True       '大モニター
                    '自オブジェクト
                    Me.Size = New Size(441, 354)
                    '背景枠線
                    txtSlipImage.Size = New Size(441, 350)
                    '帳票画像
                    picSlipImage.Size = New Size(219, 319)
                    '帳票ID
                    txtSlipIDAfterMod.Size = New Size(49, 21)
                    '帳票名
                    txtSlipNameAfterMod.Size = New Size(386, 21)
                Case Else       '非大モニター
                    '自オブジェクト
                    Me.Size = New Size(269, 215)
                    '背景枠線
                    txtSlipImage.Size = New Size(269, 213)
                    '帳票画像
                    picSlipImage.Size = New Size(120, 175)
                    '帳票ID
                    txtSlipIDAfterMod.Size = New Size(49, 21)
                    'txtSlipIDAfterMod.Font = New Font("MS UI Gothic", 8)
                    '帳票名
                    txtSlipNameAfterMod.Size = New Size(218, 21)
                    'txtSlipNameAfterMod.Font = New Font("MS UI Gothic", 8)
            End Select

        Catch ex As Exception
            MessageBox.Show("画面属性が設定できません。", "ユーザオブジェクト", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Throw ex
        End Try

    End Sub

End Class
