﻿Imports CommonSystem

Public Class frmMyMsgBoxWithAllImage

    ''' <summary>
    ''' 処理対象イメージ情報
    ''' </summary>
    ''' <remarks></remarks>
    Public mdtbImg As DataTable = Nothing

    ''' <summary>
    ''' 読込み直後のイメージ情報
    ''' </summary>
    ''' <remarks></remarks>
    Public mdtbImgCopy As DataTable = Nothing

    ''' <summary>
    ''' 帳票定義
    ''' </summary>
    ''' <remarks></remarks>
    Public mdtbSlipList As DataTable = Nothing

    Public mDgvList As DataGridView = Nothing

    Public m登録対象色 As DataTable = Nothing

    Public mイメージ表示 As Boolean = False
    Public m既ロードイメージ As ArrayList = Nothing

    Public mBool大モニター As Boolean = True

#Region "定数定義"
    Private Const APP_NAME As String = "帳票再識別 画像確認画面"
    Public Const DEF_INT_LOCATION_一覧開始位置_X As Integer = 0
    Public Const DEF_INT_LOCATION_一覧開始位置_Y As Integer = 0
    Public Const DEF_INT_LOCATION_一覧の一段の個数 As Integer = 4

    Public Const DEF_SLIP_凡例_1 As String = "エントリー対象"
    Public Const DEF_SLIP_凡例_2 As String = "エントリー対象外"

    Public Const DEF_SLIP_名称_除外帳票 As String = "(除外帳票)"
    Public Const DEF_SLIP_名称_許容外帳票 As String = "(許容外帳票)"
#End Region

    Private Sub frmMyMsgBoxWithAllImage_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim モニタ解像度幅 As Integer = -1

        Try

            'モニター解像度を取得する
            モニタ解像度幅 = System.Windows.Forms.Screen.PrimaryScreen.Bounds.Width
            If モニタ解像度幅 < 1281 Then
                mBool大モニター = False
            End If
            'mBool大モニター = False


            set画面属性()

            'If MessageBox.Show( _
            '    "確認ダイアログに画像イメージを表示しますか？", "確認", MessageBoxButtons.YesNo, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2) = Windows.Forms.DialogResult.Yes _
            'Then
            '    mイメージ表示 = True
            'End If
            mイメージ表示 = True

            '描画先とするImageオブジェクトを作成する
            Dim canvas As New Bitmap(PictureBox1.Width, PictureBox1.Height)
            'ImageオブジェクトのGraphicsオブジェクトを作成する
            Dim g As Graphics = Graphics.FromImage(canvas)
            'システムの疑問符アイコン(WIN32: IDI_QUESTION)
            g.DrawIcon(SystemIcons.Question, 0, 0)

            g.Dispose()

            'PictureBox1に表示する
            PictureBox1.Image = canvas

            'btnYes.Enabled = False

            '凡例を設定する。
            lblColorEntry.Text = DEF_SLIP_凡例_1
            lblColorEntry.BackColor = Color.FromName(My.Application.mdicConfig("NAIL_COLOR_ENT"))
            lblColorNotEntry.Text = DEF_SLIP_凡例_2
            lblColorNotEntry.BackColor = Color.FromName(My.Application.mdicConfig("NAIL_COLOR_NOT_ENT"))

            Dim objList() As UserControlSlipDisc
            Dim intDispPosX As Integer = DEF_INT_LOCATION_一覧開始位置_X
            Dim intDispPosY As Integer = DEF_INT_LOCATION_一覧開始位置_Y
            Dim strNo As String = String.Empty
            Dim strIdBefore As String = String.Empty
            Dim strIdAfter As String = String.Empty
            Dim strNameBefore As String = String.Empty
            Dim strNameAfter As String = String.Empty
            Dim intLoopCnt As Integer
            Dim intLoopCnt2 As Integer
            Dim intLoopSlipCnt As Integer
            Dim strFileFolderPath As String = String.Empty
            Dim strImageFileName As String = String.Empty
            Dim strImageFileFullPath As String = String.Empty

            Dim strDefSlipDefineId As String = String.Empty
            Dim clrBackColor As Color = Color.AliceBlue

            Dim intUCWidth As Integer = -1
            Dim intUCHeight As Integer = -1
            'intUCWidth = pnlSlipList.Controls(0).Width
            intUCWidth = 441
            intUCHeight = 354

            '除外帳票を取得する。
            Dim lstRejectSlip() As String = Split(Replace(My.Application.mdicConfig("REJECT_SLIP"), "'", ""), ",")

            '帳票一覧のデータを表示する。
            For intLoopCnt = 0 To mdtbImg.Rows.Count - 1
                ReDim Preserve objList(intLoopCnt)
                objList(intLoopCnt) = New UserControlSlipDisc
                objList(intLoopCnt).Name = "LIST" & CStr(intLoopCnt + 1)
                objList(intLoopCnt).BorderStyle = BorderStyle.None
                'objList(intLoopCnt).AutoSizeMode = Windows.Forms.AutoSizeMode.GrowOnly
                'objList(intLoopCnt).AutoScaleMode = Windows.Forms.AutoScaleMode.None

                strNo = CStr(intLoopCnt + 1)
                '再識別前の情報を編集する。
                strNameBefore = String.Empty
                strIdBefore = mdtbImgCopy.Rows(intLoopCnt).Item("SLIP_DEFINE_ID")
                If lstRejectSlip.Contains(strIdBefore) Then
                    strNameBefore = DEF_SLIP_名称_除外帳票
                Else
                    For intLoopSlipCnt = 0 To mdtbSlipList.Rows.Count - 1
                        If strIdBefore = mdtbSlipList.Rows(intLoopSlipCnt).Item("SLIP_DEFINE_ID") Then
                            strNameBefore = mdtbSlipList.Rows(intLoopSlipCnt).Item("SLIP_DEFINE_NAME")
                            Exit For
                        End If
                    Next
                    '帳票一覧から帳票名をできなかった場合は許容外帳票とする。
                    If strNameBefore.Equals(String.Empty) Then
                        strNameBefore = DEF_SLIP_名称_許容外帳票
                    End If
                End If

                '再識別後の情報を編集する。
                strNameAfter = String.Empty
                strIdAfter = mdtbImg.Rows(intLoopCnt).Item("SLIP_DEFINE_ID")
                If lstRejectSlip.Contains(strIdAfter) Then
                    strNameAfter = DEF_SLIP_名称_除外帳票
                Else
                    '帳票一覧から帳票名を取得する。
                    For intLoopSlipCnt = 0 To mdtbSlipList.Rows.Count - 1
                        If strIdAfter = mdtbSlipList.Rows(intLoopSlipCnt).Item("SLIP_DEFINE_ID") Then
                            strNameAfter = mdtbSlipList.Rows(intLoopSlipCnt).Item("SLIP_DEFINE_NAME")
                            Exit For
                        End If
                    Next
                    '帳票一覧から帳票名をできなかった場合は許容外帳票とする。
                    If strNameAfter.Equals(String.Empty) Then
                        strNameAfter = DEF_SLIP_名称_許容外帳票
                    End If
                End If

                '帳票画像フルパスを編集する。
                strFileFolderPath = mdtbImg.Rows(intLoopCnt).Item("IMAGE_FILE_PATH").ToString.Trim
                strImageFileName = mdtbImg.Rows(intLoopCnt).Item("IMAGE_FILE_NAME").ToString.Trim
                strImageFileFullPath = IO.Path.Combine(strFileFolderPath, strImageFileName)
                '表示する。
                intDispPosX = DEF_INT_LOCATION_一覧開始位置_X
                intDispPosY = DEF_INT_LOCATION_一覧開始位置_Y + (objList(intLoopCnt).Height * intLoopCnt)

                '親画面より帳票毎の色を取得する。
                'clrBackColor = Color.FromName(My.Application.mdicConfig("COLOR_EXCLUDED"))
                'For intLoopCnt2 = 0 To mDgvList.RowCount - 1
                '    strDefSlipDefineId = mDgvList.Rows(intLoopCnt2).Cells(0).Value.ToString
                '    If strIdAfter.Equals(strDefSlipDefineId) Then
                '        clrBackColor = mDgvList.Rows(intLoopCnt2).Cells(0).Style.BackColor()
                '        Exit For
                '    End If
                'Next
                clrBackColor = Color.FromName(m登録対象色.Rows(intLoopCnt).Item("ネイル色").ToString)

                '帳票一覧(パネル)にデータを追加する。
                For cnt As Integer = 0 To m既ロードイメージ.Count - 1
                    If m既ロードイメージ(cnt).mImageName = strImageFileName Then
                        If IsNothing(m既ロードイメージ(cnt).mBmp) = False Then
                            objList(intLoopCnt).m既ロードイメージ = DirectCast(m既ロードイメージ(cnt).mBmp, Bitmap)
                            'objList(intLoopCnt).m既ロードイメージ = m既ロードイメージ(cnt).mBmp
                            Exit For
                        End If
                    End If
                Next
                objList(intLoopCnt).setDispData(strNo, strIdBefore, strNameBefore, strIdAfter, strNameAfter, strImageFileFullPath, clrBackColor, mBool大モニター, mイメージ表示)
                pnlSlipList.Controls.Add(objList(intLoopCnt))
                set画面属性(objList(intLoopCnt))

            Next
            pnlSlipList.Refresh()
            '帳票一覧の表示位置を再設定する。
            'intDispPosX = DEF_INT_LOCATION_一覧開始位置_X
            Dim int横位置 As Integer = 0
            Dim int段数 As Integer = 0

            For intLoopCnt = 0 To pnlSlipList.Controls.Count - 1
                int横位置 = intLoopCnt Mod DEF_INT_LOCATION_一覧の一段の個数
                int段数 = Math.Floor(intLoopCnt / DEF_INT_LOCATION_一覧の一段の個数)
                'pnlSlipList.Controls(intLoopCnt).Width = intUCWidth
                'pnlSlipList.Controls(intLoopCnt).Height = intUCHeight
                intDispPosX = DEF_INT_LOCATION_一覧開始位置_X + ((pnlSlipList.Controls(intLoopCnt).Width + 4) * int横位置)
                intDispPosY = (DEF_INT_LOCATION_一覧開始位置_Y + pnlSlipList.Controls(intLoopCnt).Height) * int段数
                pnlSlipList.Controls(intLoopCnt).Location = New Point(intDispPosX, intDispPosY)
            Next
            Me.ActiveControl = Me.btnNo
        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)

        End Try
    End Sub

    Private Sub btnYes_Click(sender As Object, e As EventArgs) Handles btnYes.Click
        Me.DialogResult = Windows.Forms.DialogResult.Yes
        Me.Close()
    End Sub

    Private Sub btnNo_Click(sender As Object, e As EventArgs) Handles btnNo.Click
        Me.DialogResult = Windows.Forms.DialogResult.No
        Me.Close()
    End Sub

    Private Sub frmMyMsgBoxWithAllImage_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        If mdtbImg Is Nothing Then
        Else
            mdtbImg.Dispose()
            mdtbImg = Nothing
        End If
        If mdtbImgCopy Is Nothing Then
        Else
            mdtbImgCopy.Dispose()
            mdtbImgCopy = Nothing
        End If
        If mdtbSlipList Is Nothing Then
        Else
            mdtbSlipList.Dispose()
            mdtbSlipList = Nothing
        End If
        For cnt As Integer = 0 To m既ロードイメージ.Count - 1
            DirectCast(m既ロードイメージ(cnt).mBmp, Bitmap).Dispose()
        Next
        m既ロードイメージ.Clear()
        m既ロードイメージ = Nothing
    End Sub

    Private Sub set画面属性(Optional uc As UserControlSlipDisc = Nothing)

        Dim int処理種別 As Integer

        Try
            int処理種別 = 0
            If uc IsNot Nothing Then
                int処理種別 = 1
            End If

            Select Case int処理種別
                Case 0          'ユーザコントロール以外
                    Select Case mBool大モニター
                        Case True       '大モニター
                            '自ダイアログ
                            Me.Size = New Size(1840, 849)
                            '画像パネル
                            pnlSlipList.Size = New Size(1800, 709)
                        Case Else       '非大モニター
                            '自ダイアログ
                            Me.Size = New Size(1159, 584)
                            '画像パネル
                            'pnlSlipList.Size = New Size(1188, 467)
                            pnlSlipList.Size = New Size(1123, 432)
                    End Select
                Case Else       'ユーザコントロール
                    Select Case mBool大モニター
                        Case True       '大モニター
                            uc.Size = New Size(441, 354)
                        Case Else       '非大モニター
                            uc.Size = New Size(269, 215)
                    End Select
            End Select

        Catch ex As Exception
            MessageBox.Show("画面属性が設定できません。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Throw ex
        End Try

    End Sub

End Class
