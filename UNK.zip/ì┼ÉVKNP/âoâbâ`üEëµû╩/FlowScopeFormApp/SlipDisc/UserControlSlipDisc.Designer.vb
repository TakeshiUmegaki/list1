﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class UserControlSlipDisc
    Inherits System.Windows.Forms.UserControl

    'UserControl はコンポーネント一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtSlipNameAfterMod = New System.Windows.Forms.TextBox()
        Me.picSlipImage = New System.Windows.Forms.PictureBox()
        Me.txtSlipImage = New System.Windows.Forms.TextBox()
        Me.txtSlipIDAfterMod = New System.Windows.Forms.TextBox()
        CType(Me.picSlipImage, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtSlipNameAfterMod
        '
        Me.txtSlipNameAfterMod.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtSlipNameAfterMod.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSlipNameAfterMod.Font = New System.Drawing.Font("MS UI Gothic", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.txtSlipNameAfterMod.Location = New System.Drawing.Point(51, 326)
        Me.txtSlipNameAfterMod.Multiline = True
        Me.txtSlipNameAfterMod.Name = "txtSlipNameAfterMod"
        Me.txtSlipNameAfterMod.ReadOnly = True
        Me.txtSlipNameAfterMod.Size = New System.Drawing.Size(386, 21)
        Me.txtSlipNameAfterMod.TabIndex = 3
        Me.txtSlipNameAfterMod.TabStop = False
        Me.txtSlipNameAfterMod.Text = "A4 出産育児一時金支給申請書 両面 ②"
        '
        'picSlipImage
        '
        Me.picSlipImage.BackColor = System.Drawing.Color.DarkSalmon
        Me.picSlipImage.Location = New System.Drawing.Point(3, 3)
        Me.picSlipImage.Name = "picSlipImage"
        Me.picSlipImage.Size = New System.Drawing.Size(219, 319)
        Me.picSlipImage.TabIndex = 6
        Me.picSlipImage.TabStop = False
        '
        'txtSlipImage
        '
        Me.txtSlipImage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSlipImage.Location = New System.Drawing.Point(0, 1)
        Me.txtSlipImage.Multiline = True
        Me.txtSlipImage.Name = "txtSlipImage"
        Me.txtSlipImage.ReadOnly = True
        Me.txtSlipImage.Size = New System.Drawing.Size(441, 350)
        Me.txtSlipImage.TabIndex = 7
        Me.txtSlipImage.TabStop = False
        Me.txtSlipImage.Text = "12345678"
        '
        'txtSlipIDAfterMod
        '
        Me.txtSlipIDAfterMod.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtSlipIDAfterMod.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSlipIDAfterMod.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.txtSlipIDAfterMod.Location = New System.Drawing.Point(3, 326)
        Me.txtSlipIDAfterMod.Multiline = True
        Me.txtSlipIDAfterMod.Name = "txtSlipIDAfterMod"
        Me.txtSlipIDAfterMod.ReadOnly = True
        Me.txtSlipIDAfterMod.Size = New System.Drawing.Size(49, 21)
        Me.txtSlipIDAfterMod.TabIndex = 8
        Me.txtSlipIDAfterMod.TabStop = False
        Me.txtSlipIDAfterMod.Text = "888888"
        '
        'UserControlSlipDisc
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.Controls.Add(Me.txtSlipIDAfterMod)
        Me.Controls.Add(Me.picSlipImage)
        Me.Controls.Add(Me.txtSlipNameAfterMod)
        Me.Controls.Add(Me.txtSlipImage)
        Me.Name = "UserControlSlipDisc"
        Me.Size = New System.Drawing.Size(441, 354)
        CType(Me.picSlipImage, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Public WithEvents txtSlipNameAfterMod As System.Windows.Forms.TextBox
    Public WithEvents picSlipImage As System.Windows.Forms.PictureBox
    Public WithEvents txtSlipImage As System.Windows.Forms.TextBox
    Public WithEvents txtSlipIDAfterMod As System.Windows.Forms.TextBox

End Class
