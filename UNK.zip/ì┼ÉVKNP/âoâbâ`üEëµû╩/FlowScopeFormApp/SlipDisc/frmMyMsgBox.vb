﻿Public Class frmMyMsgBox
    '2018/08/02 再識別変更対応 Start-------------------------------------------------------------------------
    Public Enum 動作モード選択
        First = 0
        Second = 1
    End Enum
    Public m動作モード As Integer = 動作モード選択.First
    '2018/08/02 再識別変更対応 End  -------------------------------------------------------------------------

    Private Sub frmMyMsgBox_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            '描画先とするImageオブジェクトを作成する
            Dim canvas As New Bitmap(PictureBox1.Width, PictureBox1.Height)
            'ImageオブジェクトのGraphicsオブジェクトを作成する
            Dim g As Graphics = Graphics.FromImage(canvas)
            'システムの疑問符アイコン(WIN32: IDI_QUESTION)
            g.DrawIcon(SystemIcons.Question, 0, 0)

            g.Dispose()

            'PictureBox1に表示する
            PictureBox1.Image = canvas

            Me.ActiveControl = Me.btnNo

            '2018/08/02 再識別変更対応 Start-------------------------------------------------------------------------
            If m動作モード = 動作モード選択.First Then
                btnYes.Visible = False
            End If
            '2018/08/02 再識別変更対応 End  -------------------------------------------------------------------------
        Catch ex As Exception

        End Try
    End Sub

    Private Sub btnYes_Click(sender As Object, e As EventArgs) Handles btnYes.Click
        Me.DialogResult = Windows.Forms.DialogResult.Yes
        Me.Close()
    End Sub

    Private Sub btnNo_Click(sender As Object, e As EventArgs) Handles btnNo.Click
        Me.DialogResult = Windows.Forms.DialogResult.No
        Me.Close()
    End Sub

End Class