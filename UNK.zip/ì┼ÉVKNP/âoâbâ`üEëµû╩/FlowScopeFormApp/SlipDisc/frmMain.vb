﻿Imports CommonSystem
Imports System
Imports System.Text
Imports Oracle.DataAccess

Public Class frmMain

#Region "定数定義"
    Private Const APP_NAME As String = "帳票再識別"
    Private Const COMMIT_ENTRY_PAGE As String = "1"
    Private Const COMMIT_ENTRY_PROJ As String = "2"
#End Region

#Region "変数定義"

    ''' <summary>
    ''' 現在の処理行（ページ）
    ''' </summary>
    ''' <remarks></remarks>
    Dim mintRow As Integer = 0

    ''' <summary>
    ''' 処理対象イメージ情報
    ''' </summary>
    ''' <remarks></remarks>
    Dim mdtbImg As DataTable = Nothing

    ''' <summary>
    ''' 読込み直後のイメージ情報
    ''' </summary>
    ''' <remarks></remarks>
    Dim mdtbImgCopy As DataTable = Nothing

    ''' <summary>
    ''' 処理対象イメージの案件特定用のキーコード
    ''' </summary>
    ''' <remarks></remarks>
    Dim mstrSubKey As String = String.Empty

    ''' <summary>
    ''' 残り案件数
    ''' </summary>
    ''' <remarks></remarks>
    Dim mintSubjectCount As Integer = 0

    ''' <summary>
    ''' 各帳票IDのサンプルイメージの所在情報
    ''' </summary>
    ''' <remarks></remarks>
    Dim mdicSampleImage As New Dictionary(Of String, String)

    ''' <summary>
    ''' 納品予定時刻までの時間（分）
    ''' </summary>
    ''' <remarks></remarks>
    Dim mintDeliveryLimit As Integer = 0

    ''' <summary>
    ''' 帳票IDの組み合わせリスト
    ''' </summary>
    ''' <remarks></remarks>
    Dim mlstSlipSet As New List(Of List(Of String))

    ''' <summary>
    ''' 重複可能な帳票IDの辞書
    ''' </summary>
    ''' <remarks></remarks>
    Dim mdicSlipDup As New Dictionary(Of String, String)

    ''' <summary>
    ''' 帳票種類違いの帳票IDの辞書
    ''' </summary>
    ''' <remarks></remarks>
    Dim mdicSlipBad As New Dictionary(Of String, String)

    ''' <summary>
    ''' 再エントリの対象になる帳票IDの辞書
    ''' </summary>
    ''' <remarks></remarks>
    Dim mdicSlipEnt As New Dictionary(Of String, String)

    '2018/08/02 再識別変更対応 Start-------------------------------------------------------------------------
    ''' <summary>
    ''' 動作モード
    ''' </summary>
    ''' <remarks></remarks>
    Public Enum 動作モード選択
        First = 0
        Second = 1
    End Enum
    Public m動作モード As Integer = 動作モード選択.First

    ''' <summary>
    ''' 現申込の組み合わせ不足の状態
    ''' </summary>
    ''' <remarks></remarks>
    Public m組み合わせ不足 As Boolean = False

    ''' <summary>
    ''' 現申込の統計情報
    ''' </summary>
    ''' <remarks></remarks>
    Public m編集開始日時 As DateTime = Now
    '2018/08/02 再識別変更対応 End  -------------------------------------------------------------------------

    ''' <summary>
    ''' 帳票ID統一用辞書
    ''' </summary>
    ''' <remarks></remarks>
    Private mstrSlipConv()() As String = { _
        New String() {"601115", "601160"}, _
        New String() {"601214", "601269"}, _
        New String() {"601313", "601368"}, _
        New String() {"601412", "601467"}, _
        New String() {"601146", "601191"}, _
        New String() {"601245", "601290"}, _
        New String() {"601139", "601184"}, _
        New String() {"601238", "601283"}, _
        New String() {"611114", "611169"}, _
        New String() {"611213", "611268"}, _
        New String() {"611312", "611367"}, _
        New String() {"611145", "611190"}, _
        New String() {"611244", "611299"}, _
        New String() {"611138", "611183"}, _
        New String() {"611237", "611282"}, _
        New String() {"621113", "621168"}, _
        New String() {"621212", "621267"}, _
        New String() {"621120", "621175"}, _
        New String() {"621229", "621274"}, _
        New String() {"631112", "631167"}, _
        New String() {"631211", "631266"}, _
        New String() {"631129", "631174"}, _
        New String() {"631228", "631273"}, _
        New String() {"641111", "641166"}, _
        New String() {"641210", "641265"}, _
        New String() {"641128", "641173"}, _
        New String() {"641227", "641272"}, _
        New String() {"661119", "661164"}, _
        New String() {"661218", "661263"}, _
        New String() {"661126", "661171"}, _
        New String() {"661225", "661270"} _
    }

    ' 帳票ID統一用辞書
    Private mdicSlipConv As New Dictionary(Of String, String)

    ' 帳票識別区分
    Private mstrSlipDiv As String = String.Empty

#End Region

    Private mImgList As New ArrayList()

#Region "画面ロード時の処理"
    ''' <summary>
    ''' 画面ロード時の処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            If My.Application.mdicConfig("SELECT_SLIP").Equals("1") Then
                Me.rdoSS.Checked = True
            Else
                Me.rdoNonSS.Checked = True
            End If

            ' 帳票IDを統一するための変換辞書を作成します
            For Each strSlip() As String In mstrSlipConv
                If Not mdicSlipConv.ContainsKey(strSlip(0)) Then
                    mdicSlipConv.Add(strSlip(0), strSlip(1))
                End If
            Next

            ' 納品期限の取得を行います。
            mintDeliveryLimit = Convert.ToInt32(My.Application.mdicConfig("DELIVERY_LIMIT_MINUTE"))

            ' 外部定義（config）を精査します。
            For Each key As String In My.Application.mdicConfig.Keys
                If key.StartsWith("SLIP_SAMPLE_IMAGE_") Then
                    ' 定義キーの先頭が「SLIP_SAMPLE_IMAGE_」で始まる場合サンプルイメージの所在情報として記憶します。
                    Dim strSlip As String = key.Replace("SLIP_SAMPLE_IMAGE_", String.Empty)
                    mdicSampleImage.Add(strSlip, My.Application.mdicConfig(key))
                End If
                If key.StartsWith("SLIP_SET_") Then
                    ' 定義キーの先頭が「SLIP_SET_」で始まる場合帳票IDの組み合わせ情報として記憶します。
                    Dim strSlip() As String = Split(My.Application.mdicConfig(key), ",")
                    Dim lst As New List(Of String)
                    For Each s As String In strSlip
                        lst.Add(s)
                    Next
                    mlstSlipSet.Add(lst)
                End If
            Next

            ' NG組み合わせ定義を展開します。
            Call LoadNGSet()

            ' 重複可能帳票IDの一覧を記憶します。
            Dim strDup() As String = Split(My.Application.mdicConfig("SLIP_DUP"), ",")
            For Each s As String In strDup
                mdicSlipDup.Add(s, String.Empty)
            Next
            ' 帳票種類違い帳票IDの一覧を記憶します。
            Dim strBad() As String = Split(My.Application.mdicConfig("SLIP_BAD"), ",")
            For Each s As String In strBad
                mdicSlipBad.Add(s, String.Empty)
            Next
            ' 再エントリ対象帳票IDの一覧を記憶します。
            Dim strEnt() As String = Split(My.Application.mdicConfig("SLIP_ENT"), ",")
            For Each s As String In strEnt
                mdicSlipEnt.Add(s, String.Empty)
            Next

            '2018/08/02 再識別変更対応 Start-------------------------------------------------------------------------
            Me.Text = "協会けんぽ　" & My.Application.mdicConfig("FORM_TITLE")
            If m動作モード = 動作モード選択.First Then
                Me.Text &= "　- " & My.Application.mdicConfig("再識別_TITLE") & "１回目 -"
            Else
                Me.Text &= "　- " & My.Application.mdicConfig("再識別_TITLE") & "２回目 -"
            End If
            '2018/08/02 再識別変更対応 End  -------------------------------------------------------------------------


            ' エラー表示を初期化します。
            Me.txtErrorInfo.Text = String.Empty
            ' 処理対象イメージ情報を取得します。
            For cnt As Integer = 0 To mImgList.Count - 1
                mImgList(cnt).mBmp.Dispose()
            Next
            mImgList.Clear()
            mdtbImg = GetImage()
            '2018/08/02 再識別変更対応 Start-------------------------------------------------------------------------
            If IsNothing(mdtbImg) = True Then
                Me.Close()
                Return
            End If
            '2018/08/02 再識別変更対応 End  -------------------------------------------------------------------------
            ' チェックボックスの表示／非表示を切り替えます
            Call ViewControlForCheckBox()
            ' 取得直後の情報を退避しておきます。
            mdtbImgCopy = mdtbImg.Copy
            ' 取得情報を画面に表示します。
            Call ViewImage()
            ' 一覧の背景色を設定します
            Call SetBaclColor()
            Application.DoEvents()
            ' 帳票ID後半の入力ボックスにフォーカスを設定します。
            Me.ActiveControl = Me.txtSlipSurfix
            ' 帳票ID後半の入力ボックス内を全選択にします。
            Me.txtSlipSurfix.SelectAll()

            AddHandler rdoSS.CheckedChanged, AddressOf rdoSS_CheckedChanged
            AddHandler rdoNonSS.CheckedChanged, AddressOf rdoSS_CheckedChanged

        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

#Region "画面が閉じている最中の処理"
    ''' <summary>
    ''' 画面が閉じている最中の処理
    ''' </summary>
    ''' <param name="sender">イベント発生元オブジェクト</param>
    ''' <param name="e">イベントパラメータ</param>
    ''' <remarks></remarks>
    Private Sub frmMain_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Try
            ' 処理中のイメージデータがあるか確認します。
            If My.Application.mblnTransaction Then
                ' 処理中のデータがある場合は終了の確認を行います。
                If MessageBox.Show("作業を中断しますか？", APP_NAME, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) = Windows.Forms.DialogResult.No Then
                    e.Cancel = True
                    Return
                End If
                My.Application.comDB.DB_Rollback()
                My.Application.mblnTransaction = False
            End If

        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

#Region "ショートカットキー処理"
    Private Sub frmMain_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        Try
            Select Case e.KeyCode
                Case Keys.PageUp
                    Call Me.btnPrevPage_Click(sender, e)
                Case Keys.PageDown
                    Call Me.btnNextPage_Click(sender, e)
                Case Keys.F1
                    Call Me.btnZoomDown_Click(sender, e)
                Case Keys.F2
                    Call Me.btnZoomUp_Click(sender, e)
                Case Keys.F3
                    Call Me.btnDisplayFit_Click(sender, e)
                Case Keys.F4
                    Call Me.btnRotate_Click(sender, e)
                Case Keys.F6
                    Call Me.btnPageCommit_Click(sender, e)
                Case Keys.F7
                    If Me.chk4Over.Visible = True Then
                        Me.chk4Over.Checked = Not Me.chk4Over.Checked
                    End If
                Case Keys.F9
                    '2018/08/02 再識別変更対応 Start-------------------------------------------------------------------------
                    'Call Me.btnProCommit_Click(sender, e)
                    '--------------------------------------------------------------------------------------------------------
                    If Me.btnProCommit.Enabled = True Then
                        Call Me.btnProCommit_Click(sender, e)
                    End If
                    '2018/08/02 再識別変更対応 End  -------------------------------------------------------------------------
                Case Keys.F12
                    Call Me.btnBreak_Click(sender, e)
            End Select

        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

#Region "中断ボタン処理"
    ''' <summary>
    ''' 中断ボタン処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnBreak_Click(sender As Object, e As EventArgs) Handles btnBreak.Click
        Try
            Me.Close()
        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region


#Region "処理対象のイメージIDの取得"
    ''' <summary>
    ''' 処理対象のイメージIDの取得
    ''' </summary>
    ''' <param name="mode"></param>
    ''' <returns>イメージID（Nullの場合は該当データなし）</returns>
    ''' <remarks></remarks>
    Public Function GetImage(Optional ByVal mode As Integer = -1, Optional ByVal blnRetry As Boolean = False) As DataTable

        Try
            '2018/08/02 再識別変更対応 Start-------------------------------------------------------------------------
            m編集開始日時 = Now

            If mode = 動作モード選択.First Then
                '１回目件数取得
                m動作モード = 動作モード選択.First
            ElseIf mode = 動作モード選択.Second Then
                '２回目件数取得
                m動作モード = 動作モード選択.Second
            Else
                '通常起動した場合
            End If
            '2018/08/02 再識別変更対応 End  -------------------------------------------------------------------------

            ' 対象イメージIDを初期化します。
            Dim strImageId As String = String.Empty
            With My.Application
                ' 処理対象のステータスになっている事案IDの一覧を取得するSQLを作成します。
                Dim stbSQL As New StringBuilder(String.Empty)
                stbSQL.AppendLine("SELECT DISTINCT")
                stbSQL.AppendLine("    I.RECEIPT_ID,")
                stbSQL.AppendLine("    SUBSTR(I.IMAGE_FILE_NAME,1,23) AS SUB_KEY,")
                stbSQL.AppendLine("    I.PRIORITY ")
                stbSQL.AppendLine("    ,R.ITEM_002 ")
                stbSQL.AppendLine("FROM")
                stbSQL.AppendLine("    T_JJ_IMAGE I")
                stbSQL.AppendLine("    LEFT JOIN T_JJ_OCR_RESULT R")
                stbSQL.AppendLine("    ON")
                stbSQL.AppendLine("        REPLACE(I.EXC_SUBJECT_NO,'-','') = R.ITEM_004")
                stbSQL.AppendLine("WHERE")
                stbSQL.AppendLine("    I.IMAGE_STATUS= '%STATUS%'")
                stbSQL.AppendLine("    AND")
                stbSQL.AppendLine("    I.DELETE_FLG = '0'")

                stbSQL.AppendLine("    AND")
                stbSQL.AppendLine("    (")
                If Me.rdoNonSS.Checked <> blnRetry Then
                    stbSQL.AppendLine("        I.SLIP_DEFINE_ID LIKE '641%'")
                    stbSQL.AppendLine("        OR")
                    stbSQL.AppendLine("        I.SLIP_DEFINE_ID LIKE '661%'")
                Else
                    stbSQL.AppendLine("        I.SLIP_DEFINE_ID LIKE '601%'")
                    stbSQL.AppendLine("        OR")
                    stbSQL.AppendLine("        I.SLIP_DEFINE_ID LIKE '611%'")
                    stbSQL.AppendLine("        OR")
                    stbSQL.AppendLine("        I.SLIP_DEFINE_ID LIKE '621%'")
                    stbSQL.AppendLine("        OR")
                    stbSQL.AppendLine("        I.SLIP_DEFINE_ID LIKE '631%'")
                End If
                stbSQL.AppendLine("    )")

                ' 同一案件中に処理除外イメージステータスが含まれているデータは対象外
                stbSQL.AppendLine("    AND")
                stbSQL.AppendLine("    SUBSTR(I.IMAGE_FILE_NAME,1,23) NOT IN (")
                stbSQL.AppendLine("        SELECT DISTINCT")
                stbSQL.AppendLine("            SUBSTR(I2.IMAGE_FILE_NAME,1,23) AS SUB_KEY")
                stbSQL.AppendLine("        FROM")
                stbSQL.AppendLine("            T_JJ_IMAGE I2")
                stbSQL.AppendLine("        WHERE")
                stbSQL.AppendLine("            I2.IMAGE_STATUS IN (%REJECT_STATUS%) ")
                stbSQL.AppendLine("            AND")
                stbSQL.AppendLine("            I2.DELETE_FLG = '0'")
                '20180801 テスト用ロジック Start -----------------------------------------------------------------
                'stbSQL.AppendLine("            AND")
                'stbSQL.AppendLine("            CREATE_USER = 'carol_test'")
                '20180801 テスト用ロジック End -------------------------------------------------------------------
                stbSQL.AppendLine("    )")

                stbSQL.AppendLine("ORDER BY")
                stbSQL.AppendLine("    I.RECEIPT_ID,")
                stbSQL.AppendLine("    I.PRIORITY ")
                '2018/08/02 再識別変更対応 Start-------------------------------------------------------------------------
                'stbSQL.Replace("%STATUS%", .mdicConfig("INPUT_STATUS"))
                '--------------------------------------------------------------------------------------------------------
                If m動作モード = 動作モード選択.First Then
                    stbSQL.Replace("%STATUS%", .mdicConfig("INPUT_STATUS_1st"))
                Else
                    stbSQL.Replace("%STATUS%", .mdicConfig("INPUT_STATUS_2nd"))
                End If
                '2018/08/02 再識別変更対応 End  -------------------------------------------------------------------------
                stbSQL.Replace("%REJECT_STATUS%", .mdicConfig("REJECT_STATUS"))
                ' 作成されたSQLを実行して処理対処の一覧を取得します。
                Dim dt As DataTable = .comDB.DB_ExecuteQuery(stbSQL.ToString)
                If dt.Rows.Count = 0 Then
                    '2018/08/02 再識別変更対応 Start-------------------------------------------------------------------------
                    'MessageBox.Show("処理対象データがありません。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    'End
                    '--------------------------------------------------------------------------------------------------------
                    If mode = -1 Then
                        If blnRetry Then
                            MessageBox.Show("処理対象データがありません。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Information)
                        Else
                            If MessageBox.Show("処理対象データがありません。帳票種別を切り替えますか？", APP_NAME, MessageBoxButtons.YesNo, MessageBoxIcon.Question) = vbYes Then
                                Dim dtx As DataTable = GetImage(-1, True)
                                If Not dtx Is Nothing AndAlso dtx.Rows.Count > 0 Then
                                    If rdoNonSS.Checked Then
                                        rdoNonSS.Checked = False
                                        rdoSS.Checked = True
                                    Else
                                        rdoSS.Checked = False
                                        rdoNonSS.Checked = True
                                    End If
                                End If
                                Return dtx
                            End If
                        End If
                    End If
                    Return Nothing
                    '2018/08/02 再識別変更対応 End  -------------------------------------------------------------------------
                End If

                ' 残案件数を記憶します。
                mintSubjectCount = dt.Rows.Count

                '2018/08/02 再識別変更対応 Start-------------------------------------------------------------------------
                If mode = 動作モード選択.First Then
                    '１回目件数取得
                    Return dt
                ElseIf mode = 動作モード選択.Second Then
                    '２回目件数取得
                    Return dt
                Else
                    '通常起動した場合
                End If
                '2018/08/02 再識別変更対応 End  -------------------------------------------------------------------------

                ' DBトランザクションを開始します。
                .comDB.DB_Transaction()
                .mblnTransaction = True
                Try
                    ' 取得したイメージIDを１つずつ確認します。
                    For Each dr As DataRow In dt.Rows
                        ' 事案ID指定でイメージデータの排他取得を試みるSQLを作成します。
                        Dim strID As String = Convert.ToString(dr.Item("SUB_KEY"))
                        stbSQL.Length = 0
                        stbSQL.AppendLine("SELECT")
                        stbSQL.AppendLine("    *")
                        stbSQL.AppendLine("FROM")
                        stbSQL.AppendLine("    T_JJ_IMAGE")
                        stbSQL.AppendLine("WHERE")
                        'stbSQL.AppendLine("    IMAGE_STATUS = '%STATUS%'")
                        'stbSQL.AppendLine("    AND")
                        stbSQL.AppendLine("    SUBSTR(IMAGE_FILE_NAME,1,23) = '%SUB_KEY%'")
                        stbSQL.AppendLine("    AND")
                        stbSQL.AppendLine("    DELETE_FLG = '0'")

                        stbSQL.AppendLine("    AND")
                        stbSQL.AppendLine("    SUBSTR(IMAGE_FILE_NAME,1,23) IN (")
                        stbSQL.AppendLine("        SELECT DISTINCT")
                        stbSQL.AppendLine("            SUBSTR(IMAGE_FILE_NAME,1,23) AS SUB_KEY")
                        stbSQL.AppendLine("        FROM")
                        stbSQL.AppendLine("            T_JJ_IMAGE")
                        stbSQL.AppendLine("        WHERE")
                        stbSQL.AppendLine("            IMAGE_STATUS= '%STATUS%'")
                        stbSQL.AppendLine("            AND")
                        stbSQL.AppendLine("            DELETE_FLG = '0'")
                        '20180801 テスト用ロジック Start -----------------------------------------------------------------
                        'stbSQL.AppendLine("            AND")
                        'stbSQL.AppendLine("            CREATE_USER = 'carol_test'")
                        '20180801 テスト用ロジック End -------------------------------------------------------------------
                        stbSQL.AppendLine("    )")

                        stbSQL.AppendLine("ORDER BY")
                        stbSQL.AppendLine("    IMAGE_FILE_NAME ")
                        stbSQL.AppendLine("FOR UPDATE NOWAIT")
                        '2018/08/02 再識別変更対応 Start-------------------------------------------------------------------------
                        'stbSQL.Replace("%STATUS%", .mdicConfig("INPUT_STATUS"))
                        '--------------------------------------------------------------------------------------------------------
                        If m動作モード = 動作モード選択.First Then
                            stbSQL.Replace("%STATUS%", .mdicConfig("INPUT_STATUS_1st"))
                        Else
                            stbSQL.Replace("%STATUS%", .mdicConfig("INPUT_STATUS_2nd"))
                        End If
                        '2018/08/02 再識別変更対応 End  -------------------------------------------------------------------------
                        stbSQL.Replace("%SUB_KEY%", strID)

                        Dim dt2 As DataTable
                        Try
                            ' 作成したSQLでデータの取得を試みます。
                            dt2 = .comDB.DB_ExecuteQuery(stbSQL.ToString)
                        Catch ex As Oracle.DataAccess.Client.OracleException
                            If ex.Number = 54 Then
                                ' 他で既に処理されていた場合（排他されていた場合）は次のイメージデータまでスキップします。
                                Continue For
                            Else
                                Throw ex
                            End If
                        End Try

                        If Not dt2 Is Nothing AndAlso dt2.Rows.Count > 0 Then
                            mintRow = 0
                            mstrSubKey = strID
                            mstrSlipDiv = Convert.ToString(dr.Item("ITEM_002"))
                            Me.dgvList.DataSource = GetSlipList(strID.Substring(13, 3))

                            '2018/08/02 再識別変更対応 Start-------------------------------------------------------------------------
                            Dim titleDiv() As String = Me.Text.Split("【")
                            Me.Text = titleDiv(0) & "【" & Convert.ToString(dr.Item("SUB_KEY")) & "】"
                            '2018/08/02 再識別変更対応 End  -------------------------------------------------------------------------
                            Return dt2
                        End If

                    Next

                Catch ex As Exception
                    'DBトランザクションの破棄
                    .comDB.DB_Rollback()
                    .mblnTransaction = True
                    ' 処理対象イメージIDを初期化します。
                    strImageId = String.Empty
                    Throw ex
                End Try

            End With

            My.Application.comDB.DB_Rollback()
            My.Application.mblnTransaction = False

            If blnRetry Then
                MessageBox.Show("処理対象データがありません。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                If MessageBox.Show("処理対象データがありません。帳票種別を切り替えますか？", APP_NAME, MessageBoxButtons.YesNo, MessageBoxIcon.Question) = vbYes Then
                    Dim dtx As DataTable = GetImage(-1, True)
                    If Not dtx Is Nothing AndAlso dtx.Rows.Count > 0 Then
                        If rdoNonSS.Checked Then
                            rdoNonSS.Checked = False
                            rdoSS.Checked = True
                        Else
                            rdoSS.Checked = False
                            rdoNonSS.Checked = True
                        End If
                    End If
                    Return dtx
                End If
            End If

            '2018/08/02 再識別変更対応 Start-------------------------------------------------------------------------
            'End
            '--------------------------------------------------------------------------------------------------------
            Return Nothing
            '2018/08/02 再識別変更対応 End  -------------------------------------------------------------------------

        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Function
#End Region

#Region "帳票IDリスト取得"
    ''' <summary>
    ''' 帳票IDリスト取得
    ''' </summary>
    ''' <param name="strKey"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetSlipList(strKey As String) As DataTable
        Try
            Dim stbSQL As New StringBuilder(String.Empty)
            stbSQL.AppendLine("SELECT")
            stbSQL.AppendLine("    SLIP_DEFINE_ID")
            stbSQL.AppendLine("   ,SLIP_DEFINE_NAME")
            stbSQL.AppendLine("FROM")
            stbSQL.AppendLine("    M_SLIP_DEFINE")
            stbSQL.AppendLine("WHERE")
            stbSQL.AppendLine("    DELETE_FLG = '0'")
            stbSQL.AppendLine("    AND")
            stbSQL.AppendLine("    SLIP_DEFINE_ID LIKE '" & strKey & "%'")
            stbSQL.AppendLine("    AND")
            stbSQL.AppendLine("    NOT SLIP_DEFINE_ID IN (")
            stbSQL.AppendLine("        " & My.Application.mdicConfig("REJECT_SLIP"))
            stbSQL.AppendLine("    )")
            stbSQL.AppendLine("ORDER BY")
            stbSQL.AppendLine("    SORT_NO")

            Dim dt As DataTable = My.Application.comDB.DB_ExecuteQuery(stbSQL.ToString)
            Return dt
        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Function
#End Region

#Region "帳票一覧セル移動"
    ''' <summary>
    ''' 帳票一覧セル移動
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub dgvList_CellEnter(sender As Object, e As DataGridViewCellEventArgs) Handles dgvList.CellEnter
        Try
            Dim strSlip As String = Convert.ToString(Me.dgvList.Rows(e.RowIndex).Cells(0).Value)
            If mdicSampleImage.ContainsKey(strSlip) Then
                Me.CtlImage2.MakeImage(mdicSampleImage(strSlip))
                Me.CtlImage2.Reset()
                Me.txtSlipSurfix.Text = strSlip.Substring(3)
                Me.txtSlipSurfix.SelectAll()
            Else
                Me.CtlImage2.ClearImage()
            End If
        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

#Region "イメージ情報表示"
    Private Sub ViewImage()
        Try
            Me.txtSubCount.Text = mintSubjectCount.ToString
            Me.txtFileName.Text = Convert.ToString(mdtbImg.Rows(mintRow).Item("IMAGE_FILE_NAME")).Trim

            Dim datCrear As Date = Convert.ToDateTime(mdtbImg.Rows(mintRow).Item("CREATE_DATE"))
            Me.txtReceiptDate.Text = datCrear.ToString("yyyy/MM/dd HH:mm:ss")
            Me.txtDeliveryPlan.Text = datCrear.AddMinutes(mintDeliveryLimit).ToString("yyyy/MM/dd HH:mm")
            Me.txtNowPage.Text = (mintRow + 1).ToString
            Me.txtPageNum.Text = mdtbImg.Rows.Count.ToString

            Dim strSlip As String = Convert.ToString(mdtbImg.Rows(mintRow).Item("SLIP_DEFINE_ID"))
            Me.txtSlipPrefix.Text = strSlip.Substring(0, 3)
            Me.txtSlipSurfix.Text = strSlip.Substring(3, 3)

            Dim strPath As String = Convert.ToString(mdtbImg.Rows(mintRow).Item("IMAGE_FILE_PATH")).Trim
            Dim strName As String = Convert.ToString(mdtbImg.Rows(mintRow).Item("IMAGE_FILE_NAME")).Trim
            Dim strImageFile As String = IO.Path.Combine(strPath, strName)

            'Me.CtlImage1.MakeImage(strImageFile, Nothing)
            'Me.CtlImage1.Reset()
            Dim 既ロードP As Integer = -1
            If IsNothing(mImgList) = False Then
                For cnt As Integer = 0 To mImgList.Count - 1
                    Dim bmpData As clsBitmapData = mImgList(cnt)
                    If bmpData.mImageName = strName Then
                        既ロードP = cnt
                        Exit For
                    End If
                Next
            End If
            If 既ロードP = -1 Then
                Me.CtlImage1.MakeImage(strImageFile, Nothing)
                Me.CtlImage1.Reset()
                Dim bmp As Bitmap = New Bitmap(CtlImage1.img)
                If IsNothing(CtlImage1.img) = False Then
                    mImgList.Add(New clsBitmapData(strName, bmp))
                End If
            Else
                Dim bmpData As clsBitmapData = mImgList(既ロードP)
                If IsNothing(bmpData.mBmp) = False Then
                    Dim bmp As Bitmap = New Bitmap(bmpData.mBmp)
                    Me.CtlImage1.MakeImage(strImageFile, bmp)
                    Me.CtlImage1.Reset()
                End If
            End If

            Call SetListRow(strSlip)

        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

#Region "帳票ID一覧の行設定"
    ''' <summary>
    ''' 帳票ID一覧の行設定
    ''' </summary>
    ''' <param name="strSlip"></param>
    ''' <remarks></remarks>
    Private Sub SetListRow(strSlip As String)
        Try
            For i As Integer = 0 To Me.dgvList.RowCount - 1 Step 1
                Dim strSrc As String = Convert.ToString(dgvList.Rows(i).Cells(0).Value)
                If strSrc.Equals(strSlip) Then
                    Me.dgvList.CurrentCell = Me.dgvList.Rows(i).Cells(0)
                    Return
                End If
            Next
        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

#Region "前ページボタン処理"
    Private Sub btnPrevPage_Click(sender As Object, e As EventArgs) Handles btnPrevPage.Click
        Try
            If mintRow <= 0 Then
                Return
            End If
            mintRow -= 1
            Call ViewImage()
        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

#Region "次ページボタン処理"
    Private Sub btnNextPage_Click(sender As Object, e As EventArgs) Handles btnNextPage.Click
        Try
            If mintRow >= mdtbImg.Rows.Count - 1 Then
                Return
            End If
            mintRow += 1
            Call ViewImage()
        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

    '2018/08/02 再識別変更対応 Start-------------------------------------------------------------------------
#Region "指定ページへジャンプ"
    Private Sub jumpPage(ByVal pageNumber As Integer)
        Try
            If pageNumber >= mdtbImg.Rows.Count OrElse pageNumber < 0 Then
                Return
            End If
            mintRow = pageNumber
            Call ViewImage()
        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region
    '2018/08/02 再識別変更対応 End  -------------------------------------------------------------------------

#Region "縮小ボタン処理"
    Private Sub btnZoomDown_Click(sender As Object, e As EventArgs) Handles btnZoomDown.Click
        Try
            Me.CtlImage1.btnZoomOut_Click(sender, e)
        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

#Region "拡大ボタン処理"
    Private Sub btnZoomUp_Click(sender As Object, e As EventArgs) Handles btnZoomUp.Click
        Try
            Me.CtlImage1.btnZoomIn_Click(sender, e)
        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

#Region "元に戻すボタン処理"
    Private Sub btnDisplayFit_Click(sender As Object, e As EventArgs) Handles btnDisplayFit.Click
        Try
            Me.CtlImage1.Reset()
        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

#Region "右回転ボタン"
    Private Sub btnRotate_Click(sender As Object, e As EventArgs) Handles btnRotate.Click
        Try
            Me.CtlImage1.btnRotate_Click(sender, e)
        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

#Region "ページ番号テキストボックス関連"
    Private Sub txtNowPage_GotFocus(sender As Object, e As EventArgs) Handles txtNowPage.GotFocus
        Try
            Me.txtNowPage.SelectAll()
        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub

    Private Sub txtNowPage_LostFocus(sender As Object, e As EventArgs) Handles txtNowPage.LostFocus
        Try
            Me.txtNowPage.Text = (mintRow + 1).ToString
        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub

    Private Sub txtNowPage_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtNowPage.KeyPress
        Try
            '0～9と、バックスペース以外の時は、イベントをキャンセルする
            If (e.KeyChar < "0"c OrElse "9"c < e.KeyChar) AndAlso _
                    e.KeyChar <> ControlChars.Back Then
                e.Handled = True
            End If
        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub

    Private Sub txtNowPage_KeyDown(sender As Object, e As KeyEventArgs) Handles txtNowPage.KeyDown
        Try
            If e.KeyCode <> Keys.Enter Then
                Return
            End If

            Dim intPage As Integer = 0
            Dim bln As Boolean = Integer.TryParse(Me.txtNowPage.Text, intPage)
            If Not bln Then
                Me.txtNowPage.Text = (mintRow + 1).ToString
                Return
            End If
            If intPage > mdtbImg.Rows.Count OrElse intPage <= 0 Then
                Me.txtNowPage.Text = (mintRow + 1).ToString
                Return
            End If
            mintRow = intPage - 1
            Call ViewImage()
            Application.DoEvents()
            Me.ActiveControl = Me.txtSlipSurfix
            Me.txtSlipSurfix.SelectAll()
        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

#Region "帳票番号テキストボックス関連処理"
    Private Sub txtSlipSurfix_GotFocus(sender As Object, e As EventArgs) Handles txtSlipSurfix.GotFocus
        Try
            Me.txtSlipSurfix.SelectAll()
        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try

    End Sub

    Private Sub txtSlipSurfix_LostFocus(sender As Object, e As EventArgs) Handles txtSlipSurfix.LostFocus
        Try
            'Dim strSlip As String = Convert.ToString(mdtbImg.Rows(mintRow).Item("SLIP_DEFINE_ID"))
            'Me.txtSlipSurfix.Text = strSlip.Substring(3, 3)
        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub

    Private Sub txtSlipSurfix_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtSlipSurfix.KeyPress
        Try
            '0～9と、バックスペース以外の時は、イベントをキャンセルする
            If (e.KeyChar < "0"c OrElse "9"c < e.KeyChar) AndAlso _
                    e.KeyChar <> ControlChars.Back Then
                e.Handled = True
            End If
        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub

    Private Sub txtSlipSurfix_KeyDown(sender As Object, e As KeyEventArgs) Handles txtSlipSurfix.KeyDown
        Try
            Select Case e.KeyCode
                Case Keys.Up
                    Dim intRow As Integer = Me.dgvList.CurrentCell.RowIndex
                    If intRow = 0 Then
                        intRow = Me.dgvList.RowCount - 1
                    Else
                        intRow -= 1
                    End If
                    Me.dgvList.CurrentCell = Me.dgvList.Rows(intRow).Cells(0)

                Case Keys.Down
                    Dim intRow As Integer = Me.dgvList.CurrentCell.RowIndex
                    If intRow = Me.dgvList.RowCount - 1 Then
                        intRow = 0
                    Else
                        intRow += 1
                    End If
                    Me.dgvList.CurrentCell = Me.dgvList.Rows(intRow).Cells(0)

                Case Keys.Enter
                    Dim strSlip As String = Me.txtSlipPrefix.Text.Trim & _
                                            Me.txtSlipSurfix.Text.Trim
                    For i As Integer = 0 To Me.dgvList.Rows.Count - 1 Step 1
                        Dim strMySlip As String = Convert.ToString(Me.dgvList.Rows(i).Cells(0).Value)
                        If strSlip.Equals(strMySlip) Then
                            Me.dgvList.CurrentCell = Me.dgvList.Rows(i).Cells(0)
                            Me.btnPageCommit.Focus()
                            Return
                        End If
                    Next
                    MessageBox.Show("無効な帳票番号です。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    strSlip = Convert.ToString(mdtbImg.Rows(mintRow).Item("SLIP_DEFINE_ID"))
                    Me.txtSlipSurfix.Text = strSlip.Substring(3, 3)
                    Me.txtSlipSurfix.SelectAll()

            End Select

        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

#Region "ページ確定ボタン処理"
    Private Sub btnPageCommit_Click(sender As Object, e As EventArgs) Handles btnPageCommit.Click
        Try
            Dim strSlip As String = Me.txtSlipPrefix.Text.Trim & _
                                    Me.txtSlipSurfix.Text.Trim
            mdtbImg.Rows(mintRow).Item("SLIP_DEFINE_ID") = strSlip
            ' 一覧の背景色を設定します
            Call SetBaclColor()

            If mintRow = (mdtbImg.Rows.Count - 1) Then
                Call CommitEntry(COMMIT_ENTRY_PAGE)
            Else
                mintRow += 1
                Call ViewImage()
                Me.txtSlipSurfix.Focus()
            End If

        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

#Region "案件確定ボタン処理"
    Private Sub btnProCommit_Click(sender As Object, e As EventArgs) Handles btnProCommit.Click
        Try
            Dim strSlip As String = Me.txtSlipPrefix.Text.Trim & _
                                    Me.txtSlipSurfix.Text.Trim
            mdtbImg.Rows(mintRow).Item("SLIP_DEFINE_ID") = strSlip
            ' 一覧の背景色を設定します
            Call SetBaclColor()

            Call CommitEntry(COMMIT_ENTRY_PROJ)

        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region


#Region "登録処理"
    Private Sub CommitEntry(ByVal strProcMode As String)

        Dim 登録対象色 As DataTable = Nothing

        Try
            Dim stbMsg As New StringBuilder(String.Empty)
            Dim strMsg As String = String.Empty

            Dim blnHead3 As Boolean = CheckSlipHead3()

            If Not blnHead3 Then
                MessageBox.Show("同一案件内で帳票種類が一致していません。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Exit Sub
            End If

            If Not CheckNgSlipSet() Then
                MessageBox.Show("禁止されている帳票の組み合わせが見つかりました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Exit Sub
            End If

            Dim blnDup As Boolean = CheckSlipDup(strMsg)

            Me.txtErrorInfo.Text = strMsg

            If Not blnDup Then
                MessageBox.Show("帳票番号に重複があります。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Exit Sub
            End If

            '2018/08/02 再識別変更対応 Start-------------------------------------------------------------------------
            'Dim blnSet As Boolean = CheckSlipSet()
            'If Not blnSet Then
            '    Dim frmMsg As New frmMyMsgBox
            '    If frmMsg.ShowDialog = Windows.Forms.DialogResult.No Then
            '        Return
            '    End If
            'Else
            '    stbMsg.Append("登録しますか？")
            '    Dim dlgAns As DialogResult = MessageBox.Show(stbMsg.ToString, APP_NAME, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2)
            '    If dlgAns = vbNo Then
            '        Return
            '    End If
            'End If
            '========================================================================================================
            '   １回目  ２回目        動作
            '========================================================================================================
            '①正常                  そのまま登録
            '②ＮＧ    正常          そのまま登録
            '③ＮＧ    ＮＧ（はい）  Alt+Ctrl+F5が押されてから登録
            '④ＮＧ    ＮＧ（いいえ）２はいを押されるまで登録しない
            '========================================================================================================
            If btnProCommit.Enabled = True Then
                m組み合わせ不足 = False
                Dim blnSet As Boolean = CheckSlipSet()
                If Not blnSet Then
                    m組み合わせ不足 = True
                    Dim frmMsg As New frmMyMsgBox
                    frmMsg.m動作モード = frmMyMsgBox.動作モード選択.First
                    btnProCommit.Enabled = False
                    frmMsg.ShowDialog()
                    jumpPage(0)
                    Return
                Else                                                                '①
                    '20180801 メッセージボックス差替 Start -----------------------------------------------------------------
                    'stbMsg.Append("登録しますか？")
                    'Dim frmMsg As New frmMyMsgBoxView
                    'If frmMsg.ShowDialog = Windows.Forms.DialogResult.No Then
                    '    Return
                    'End If
                    登録対象色 = 登録対象色セット(mdtbImg)
                    Dim frmMsg As New frmMyMsgBoxWithAllImage
                    frmMsg.mdtbImg = mdtbImg
                    frmMsg.mdtbImgCopy = mdtbImgCopy
                    frmMsg.mdtbSlipList = Me.dgvList.DataSource
                    frmMsg.mDgvList = dgvList
                    frmMsg.m登録対象色 = 登録対象色
                    frmMsg.m既ロードイメージ = mImgList
                    If frmMsg.ShowDialog = Windows.Forms.DialogResult.No Then
                        Return
                    End If
                    '20180801 メッセージボックス差替 End   -----------------------------------------------------------------
                End If
            Else
                Dim blnSet As Boolean = CheckSlipSet()
                If Not blnSet Then
                    '20180801 メッセージボックス差替 Start -----------------------------------------------------------------
                    'Dim frmMsg As New frmMyMsgBoxView
                    'If frmMsg.ShowDialog = Windows.Forms.DialogResult.No Then
                    '    Return
                    'End If
                    登録対象色 = 登録対象色セット(mdtbImg)
                    Dim frmMsg As New frmMyMsgBoxWithAllImage
                    frmMsg.mdtbImg = mdtbImg
                    frmMsg.mdtbImgCopy = mdtbImgCopy
                    frmMsg.mdtbSlipList = Me.dgvList.DataSource
                    frmMsg.mDgvList = dgvList
                    frmMsg.m登録対象色 = 登録対象色
                    frmMsg.m既ロードイメージ = mImgList
                    If frmMsg.ShowDialog = Windows.Forms.DialogResult.No Then
                        Return
                    End If
                    '20180801 メッセージボックス差替 End   -----------------------------------------------------------------
                Else                                                                '①
                    '20180801 メッセージボックス差替 Start -----------------------------------------------------------------
                    登録対象色 = 登録対象色セット(mdtbImg)
                    Dim frmMsg As New frmMyMsgBoxWithAllImage
                    frmMsg.mdtbImg = mdtbImg
                    frmMsg.mdtbImgCopy = mdtbImgCopy
                    frmMsg.mdtbSlipList = Me.dgvList.DataSource
                    frmMsg.mDgvList = dgvList
                    frmMsg.m登録対象色 = 登録対象色
                    frmMsg.m既ロードイメージ = mImgList
                    If frmMsg.ShowDialog = Windows.Forms.DialogResult.No Then
                        Return
                    End If
                    '20180801 メッセージボックス差替 End   -----------------------------------------------------------------
                End If
            End If
            '2018/08/02 再識別変更対応 End  -------------------------------------------------------------------------


            'Dim blnBad As Boolean = False
            'For Each r As DataRow In mdtbImg.Rows
            '    Dim strSlip As String = Convert.ToString(r.Item("SLIP_DEFINE_ID"))
            '    If mdicSlipBad.ContainsKey(strSlip) Then
            '        blnBad = True
            '        Exit For
            '    End If
            'Next

            Dim strStatus As String = String.Empty
            For i As Integer = 0 To mdtbImg.Rows.Count - 1 Step 1
                Dim strImageId As String = Convert.ToString(mdtbImgCopy.Rows(i).Item("IMAGE_ID"))
                '2018/08/02 再識別変更対応 Start-------------------------------------------------------------------------
                'Dim strOldSlip As String = Convert.ToString(mdtbImgCopy.Rows(i).Item("SLIP_DEFINE_ID"))
                'Dim strNewSlip As String = Convert.ToString(mdtbImg.Rows(i).Item("SLIP_DEFINE_ID"))
                '--------------------------------------------------------------------------------------------------------
                Dim strOldSlip As String = ""
                Dim strNewSlip As String = ""
                If m動作モード = 動作モード選択.First Then
                    strOldSlip = Convert.ToString(mdtbImgCopy.Rows(i).Item("SLIP_DEFINE_ID"))
                    strNewSlip = Convert.ToString(mdtbImg.Rows(i).Item("SLIP_DEFINE_ID"))
                Else
                    strOldSlip = Convert.ToString(mdtbImgCopy.Rows(i).Item("EXC_IMAGE_KEY02"))
                    strNewSlip = Convert.ToString(mdtbImg.Rows(i).Item("SLIP_DEFINE_ID"))
                End If
                '2018/08/02 再識別変更対応 End  -------------------------------------------------------------------------

                ' 案件確定ボタン押下時
                If strProcMode.Equals(COMMIT_ENTRY_PROJ) Then
                    If strNewSlip.Substring(3, 3).Equals("000") Then
                        strNewSlip = strNewSlip.Substring(0, 3) & "999"
                    End If
                End If


                '2018/08/02 再識別変更対応 Start-------------------------------------------------------------------------
                'If mdicSlipBad.ContainsKey(strNewSlip) Then
                '    strStatus = My.Application.mdicConfig("OUT_STATUS_BAD")
                'Else
                '    If strOldSlip.Equals(strNewSlip) Then
                '        If mdicSlipEnt.ContainsKey(strNewSlip) Then
                '            If IsDBNull(mdtbImgCopy.Rows(i).Item("ENTRY_DATE")) Then
                '                strStatus = My.Application.mdicConfig("OUT_STATUS_ENT")
                '            Else
                '                strStatus = My.Application.mdicConfig("OUT_STATUS_NOCHG")
                '            End If
                '        Else
                '            strStatus = My.Application.mdicConfig("OUT_STATUS_NOCHG")
                '        End If
                '    Else
                '        If mdicSlipEnt.ContainsKey(strNewSlip) Then
                '            strStatus = My.Application.mdicConfig("OUT_STATUS_ENT")
                '        Else
                '            strStatus = My.Application.mdicConfig("OUT_STATUS_NO_ENT")
                '        End If
                '    End If
                'End If
                '=========================================================================================================================================================================
                '※APP.CONFIGの設定について
                '    INPUT_STATUS
                '      １回目はINPUT_STATUS_1st
                '      ２回目はINPUT_STATUS_2nd
                '      INPUT_STATUS_2ndとOUT_STATUS_2ndENTRYと同じにしておく
                'OUT_STATUS_BAD     ＝帳票違いのイメージ状態
                'OUT_STATUS_ENT     ＝再エントリ対象のイメージ状態
                'OUT_STATUS_NO_ENT  ＝再エントリしないイメージ状態
                'OUT_STATUS_NOCHG   ＝帳票未変更のイメージ状態
                'OUT_STATUS_2ndENTRY＝組み合わせ不足のため２回目エントリーへ
                '=========================================================================================================================================================================
                '      エントリー回数  組み合わせ不足        帳票種類違いの帳票IDの辞書     帳票ID             再エントリの対象になる帳票IDの辞書      ENTRY_DATE    イメージステータス
                '=========================================================================================================================================================================
                '（ 1）１回目          不足あり              ---                            ---                ---                                     ---           OUT_STATUS_SECOND
                '（ 2）                不足なし              あり                           ---                ---                                     ---           OUT_STATUS_BAD
                '（ 3）                                      なし                           修正前＝修正後     あり                                    ＝ブランク    OUT_STATUS_ENT
                '（ 4）                                      なし                           修正前＝修正後     あり                                    ＜＞ブランク  OUT_STATUS_NOCHG
                '（ 5）                                      なし                           修正前＝修正後     なし                                    ---           OUT_STATUS_NOCHG
                '（ 6）                                      なし                           修正前＜＞修正後   あり                                    ---           OUT_STATUS_ENT
                '（ 7）                                      なし                           修正前＜＞修正後   なし                                    ---           OUT_STATUS_NO_ENT
                '（ 8）２回目          ---                   あり                           ---                ---                                     ---           OUT_STATUS_BAD
                '（ 9）                                      なし                           修正前＝修正後     あり                                    ＝ブランク    OUT_STATUS_ENT
                '（10）                                      なし                           修正前＝修正後     あり                                    ＜＞ブランク  OUT_STATUS_NOCHG
                '（11）                                      なし                           修正前＝修正後     なし                                    ---           OUT_STATUS_NOCHG
                '（12）                                      なし                           修正前＜＞修正後   あり                                    ---           OUT_STATUS_ENT
                '（13）                                      なし                           修正前＜＞修正後   なし                                    ---           OUT_STATUS_NO_ENT
                '=========================================================================================================================================================================
                strStatus = String.Empty
                If m動作モード = 動作モード選択.First Then
                    If m組み合わせ不足 = True Then
                        strStatus = My.Application.mdicConfig("OUT_STATUS_2ndENTRY")                '(1)
                    End If
                End If
                If strStatus = String.Empty Then
                    If mdicSlipBad.ContainsKey(strNewSlip) Then
                        strStatus = My.Application.mdicConfig("OUT_STATUS_BAD")                     '(2)(8)
                    Else
                        If strOldSlip.Equals(strNewSlip) Then
                            If mdicSlipEnt.ContainsKey(strNewSlip) Then
                                If IsDBNull(mdtbImgCopy.Rows(i).Item("ENTRY_DATE")) Then
                                    strStatus = My.Application.mdicConfig("OUT_STATUS_ENT")         '(3)(9)
                                Else
                                    strStatus = My.Application.mdicConfig("OUT_STATUS_NOCHG")       '(4)(10)
                                End If
                            Else
                                strStatus = My.Application.mdicConfig("OUT_STATUS_NOCHG")           '(5)(11)
                            End If
                        Else
                            If mdicSlipEnt.ContainsKey(strNewSlip) Then
                                strStatus = My.Application.mdicConfig("OUT_STATUS_ENT")             '(6)(12)
                            Else
                                strStatus = My.Application.mdicConfig("OUT_STATUS_NO_ENT")          '(7)(13)
                            End If
                        End If
                    End If
                End If
                '2018/08/02 再識別変更対応 End  -------------------------------------------------------------------------
                Call UpdateImage(strImageId, strOldSlip, strNewSlip, strStatus)
                Call InsertHistory(strImageId, strStatus)

            Next

            '2018/08/02 再識別変更対応 Start-------------------------------------------------------------------------
            btnProCommit.Enabled = True
            Dim 編集終了日時 As DateTime = Now
            Inser統計情報(mdtbImg, mdtbImgCopy, m編集開始日時, 編集終了日時)
            '2018/08/02 再識別変更対応 End  -------------------------------------------------------------------------

            My.Application.comDB.DB_Commit()
            My.Application.mblnTransaction = False

            MessageBox.Show("正常に更新されました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Information)

            ' エラー表示を初期化します。
            Me.txtErrorInfo.Text = String.Empty
            mImgList.Clear()
            mdtbImg = GetImage()
            '2018/08/02 再識別変更対応 Start-------------------------------------------------------------------------
            If IsNothing(mdtbImg) = True Then
                Me.Close()
                Return
            End If
            '2018/08/02 再識別変更対応 End  -------------------------------------------------------------------------
            ' チェックボックスの表示／非表示を切り替えます
            Call ViewControlForCheckBox()
            mdtbImgCopy = mdtbImg.Copy
            Call ViewImage()
            ' 一覧の背景色を設定します
            Call SetBaclColor()
            Application.DoEvents()
            Me.ActiveControl = Me.txtSlipSurfix
            Me.txtSlipSurfix.SelectAll()

            Me.chk4Over.Checked = False

        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        Finally
            If IsNothing(登録対象色) = False Then
                登録対象色.Rows.Clear()
                登録対象色.Dispose()
                登録対象色 = Nothing
            End If
        End Try
    End Sub
#End Region

#Region "登録対象色セット"
    '2018/08/02 再識別変更対応 Start-------------------------------------------------------------------------
    Private Function 登録対象色セット(ByVal mdtbImg As DataTable) As DataTable

        Dim 登録対象色 As DataTable = Nothing
        Dim 帳票マスタ As DataTable = Nothing

        Try
            登録対象色 = New DataTable
            登録対象色.Columns.Add("ネイル色")

            ' 事案ID指定でイメージデータの排他取得を試みるSQLを作成します。
            Dim stbSQL As New StringBuilder(String.Empty)
            stbSQL.AppendLine("SELECT ")
            stbSQL.AppendLine("   SLIP_DEFINE_ID ")
            stbSQL.AppendLine("  ,SLIP_DEFINE_NAME ")
            stbSQL.AppendLine("  ,ENTRY_TARGET_FLG ")
            stbSQL.AppendLine("FROM")
            stbSQL.AppendLine("  M_SLIP_DEFINE ")
            stbSQL.AppendLine("WHERE ")
            stbSQL.AppendLine("  DELETE_FLG = '0'")
            stbSQL.AppendLine("ORDER BY")
            stbSQL.AppendLine("    SLIP_DEFINE_ID ")

            帳票マスタ = My.Application.comDB.DB_ExecuteQuery(stbSQL.ToString)

            For i As Integer = 0 To mdtbImg.Rows.Count - 1 Step 1
                Dim strImageId As String = Convert.ToString(mdtbImgCopy.Rows(i).Item("IMAGE_ID"))
                Dim strOldSlip As String = Convert.ToString(mdtbImgCopy.Rows(i).Item("SLIP_DEFINE_ID"))
                Dim strNewSlip As String = Convert.ToString(mdtbImg.Rows(i).Item("SLIP_DEFINE_ID"))

                Dim colorStr As String = My.Application.mdicConfig("NAIL_COLOR_NOT_ENT")

                Dim 帳票マスタ該当データ() As DataRow = 帳票マスタ.Select(" SLIP_DEFINE_ID = '" & strNewSlip & "' ")
                If 帳票マスタ該当データ.Count > 0 Then
                    If 帳票マスタ該当データ(0).Item("ENTRY_TARGET_FLG").ToString.Trim() = "1" Then
                        colorStr = My.Application.mdicConfig("NAIL_COLOR_ENT")
                    End If
                End If

                登録対象色.Rows.Add()
                登録対象色.Rows(登録対象色.Rows.Count - 1).Item("ネイル色") = colorStr

            Next

            Return 登録対象色

        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try

    End Function
    '2018/08/02 再識別変更対応 End  -------------------------------------------------------------------------
#End Region

#Region "帳票番号の組み合わせチェック"
    Private Function CheckSlipSet() As Boolean
        Try
            Dim dtbConv As DataTable = MakeSlipConvertTable()
            For Each lst As List(Of String) In mlstSlipSet
                Dim blnMach1 As Boolean = True
                For Each s As String In lst
                    Dim blnFind As Boolean = False
                    For Each r As DataRow In dtbConv.Rows
                        If mdicSlipDup.ContainsKey(Convert.ToString(r.Item("SLIP_DEFINE_ID"))) Then
                            Continue For
                        End If
                        If mdicSlipBad.ContainsKey(Convert.ToString(r.Item("SLIP_DEFINE_ID"))) Then
                            Continue For
                        End If
                        If Convert.ToString(r.Item("SLIP_DEFINE_ID")).Equals(s) Then
                            blnFind = True
                            Exit For
                        End If
                    Next
                    If Not blnFind Then
                        blnMach1 = False
                        Exit For
                    End If
                Next
                If Not blnMach1 Then
                    Continue For
                End If

                Dim blnMach2 As Boolean = True
                For Each r As DataRow In dtbConv.Rows
                    If mdicSlipDup.ContainsKey(Convert.ToString(r.Item("SLIP_DEFINE_ID"))) Then
                        Continue For
                    End If
                    If mdicSlipBad.ContainsKey(Convert.ToString(r.Item("SLIP_DEFINE_ID"))) Then
                        Continue For
                    End If
                    Dim blnFind As Boolean = False
                    For Each s As String In lst
                        If Convert.ToString(r.Item("SLIP_DEFINE_ID")).Equals(s) Then
                            blnFind = True
                            Exit For
                        End If
                    Next
                    If Not blnFind Then
                        blnMach2 = False
                        Exit For
                    End If
                Next
                If Not blnMach2 Then
                    Continue For
                End If

                Return True
            Next

            Return False
        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Function
#End Region

#Region "帳票番号の重複チェック"
    Private Function CheckSlipDup(ByRef strMsg As String) As Boolean
        Try
            Dim dtbConv As DataTable = MakeSlipConvertTable()
            Dim dicSlip As New Dictionary(Of String, List(Of String))
            For i As Integer = 0 To dtbConv.Rows.Count - 1 Step 1
                Dim r As DataRow = dtbConv.Rows(i)
                Dim strSlip As String = Convert.ToString(r.Item("SLIP_DEFINE_ID"))
                If Not dicSlip.ContainsKey(strSlip) Then
                    Dim lst As New List(Of String)
                    dicSlip.Add(strSlip, lst)
                End If
                dicSlip(strSlip).Add((i + 1).ToString())
            Next

            Dim blnDup As Boolean = True
            Dim stbMsg As New StringBuilder(String.Empty)
            For Each strSlip As String In dicSlip.Keys
                If mdicSlipDup.ContainsKey(strSlip) Then
                    Continue For
                End If
                If dicSlip(strSlip).Count > 1 Then
                    stbMsg.Append(Join(dicSlip(strSlip).ToArray, ","))
                    stbMsg.Append("ページで、帳票番号「")
                    stbMsg.Append(strSlip)
                    stbMsg.AppendLine("」が重複しています。")
                    blnDup = False
                End If
            Next

            strMsg = stbMsg.ToString

            Return blnDup

        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Function
#End Region

#Region "帳票番号の頭3桁不一致チェック"
    Private Function CheckSlipHead3() As Boolean
        Try
            Dim dicSlip As New Dictionary(Of String, List(Of String))
            For i As Integer = 0 To mdtbImg.Rows.Count - 1 Step 1
                Dim r As DataRow = mdtbImg.Rows(i)
                Dim strSlip As String = Convert.ToString(r.Item("SLIP_DEFINE_ID")).Substring(0, 3)
                If Not dicSlip.ContainsKey(strSlip) Then
                    Dim lst As New List(Of String)
                    dicSlip.Add(strSlip, lst)
                End If
                dicSlip(strSlip).Add((i + 1).ToString())
            Next

            Dim blnHead3 As Boolean = True
            Dim strSlipId As String = String.Empty

            For Each strSlip As String In dicSlip.Keys
                If Not strSlipId.Equals(String.Empty) AndAlso Not strSlipId.Equals(strSlip) Then
                    blnHead3 = False
                    Exit For
                End If

                strSlipId = strSlip
            Next

            Return blnHead3

        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Function
#End Region


#Region "T_JJ_IMAGEの更新"
    Private Sub UpdateImage(ByVal strImageId As String, _
                            ByVal strOldSlip As String, _
                            ByVal strNewSlip As String, _
                            ByVal strStatus As String)
        Try
            ' T_JJ_IMAGE更新用SQLを作成します。
            Dim stbUpdateSQL As New StringBuilder(String.Empty)
            stbUpdateSQL.AppendLine("UPDATE")
            stbUpdateSQL.AppendLine("    T_JJ_IMAGE")
            stbUpdateSQL.AppendLine("SET")
            stbUpdateSQL.AppendLine("     IMAGE_STATUS    = '__IMAGE_STATUS__'")
            stbUpdateSQL.AppendLine("    ,SLIP_DEFINE_ID  = '__NEW_SLIP__'")
            stbUpdateSQL.AppendLine("    ,EXC_IMAGE_KEY02 = '__OLD_SLIP__'")
            stbUpdateSQL.AppendLine("    ,UPDATE_USER     = '__USER__'")
            stbUpdateSQL.AppendLine("    ,UPDATE_DATE     = SYSDATE")
            If strStatus.Equals(My.Application.mdicConfig("OUT_STATUS_ENT")) Then
                stbUpdateSQL.AppendLine("     ,PRIORITY    = '__PRIORITY__'")
                stbUpdateSQL.Replace("__PRIORITY__", My.Application.mdicConfig("PRIORITY"))
            End If
            '2018/08/02 再識別変更対応 Start-------------------------------------------------------------------------
            If strStatus <> My.Application.mdicConfig("OUT_STATUS_2ndENTRY") Then
                If strOldSlip <> strNewSlip Then
                    stbUpdateSQL.AppendLine("     ,RJCT_RESULT_EXIT_FLG = '0' ")
                End If
            End If
            '2018/08/02 再識別変更対応 End  -------------------------------------------------------------------------

            ' 2019/10/25 追加 Start
            If Me.chk4Over.Checked Then
                stbUpdateSQL.AppendLine("     ,EXC_IMAGE_KEY08 = '1' ")
            Else
                stbUpdateSQL.AppendLine("     ,EXC_IMAGE_KEY08 = '0' ")
            End If
            ' 2019/10/25 追加 End

            stbUpdateSQL.AppendLine("WHERE")
            stbUpdateSQL.AppendLine("    IMAGE_ID = __IMAGE_ID__")

            ' 作成したSQLの設定値の部分を実際の値に置換します。
            stbUpdateSQL.Replace("__IMAGE_STATUS__", strStatus)
            stbUpdateSQL.Replace("__NEW_SLIP__", strNewSlip)
            stbUpdateSQL.Replace("__OLD_SLIP__", strOldSlip)
            stbUpdateSQL.Replace("__USER__", My.Application.mstrUserID)
            stbUpdateSQL.Replace("__IMAGE_ID__", strImageId)

            ' 作成したSQLを実行してT_RECEIPT_IMAGEを更新します。
            Dim intInsertRet As Integer = My.Application.comDB.DB_ExecuteNonQuery(stbUpdateSQL.ToString)
            If Not intInsertRet = 1 Then
                Throw New Exception("イメージデータの更新に失敗しました。")
            End If

        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

#Region "T_STATUS_HISTORYの登録"
    Private Sub InsertHistory(ByVal strImageId As String, ByVal strStatus As String)
        Try
            Dim strUpdateStatus As String = strStatus

            ' イメージ状態履歴登録用SQLを作成します。
            Dim stbInsertSQL As New System.Text.StringBuilder(String.Empty)
            stbInsertSQL.AppendLine("INSERT INTO T_JJ_IMAGE_HISTORY (")
            stbInsertSQL.AppendLine("     IMAGE_ID")
            stbInsertSQL.AppendLine("    ,IMAGE_STATUS")
            stbInsertSQL.AppendLine("    ,CREATE_DATE")
            stbInsertSQL.AppendLine("    ,CREATE_USER")
            stbInsertSQL.AppendLine(") VALUES (")
            stbInsertSQL.AppendLine("     __IMAGE_ID__")
            stbInsertSQL.AppendLine("    ,'__STATUS__'")
            stbInsertSQL.AppendLine("    ,SYSTIMESTAMP")
            stbInsertSQL.AppendLine("    ,'__USER__'")
            stbInsertSQL.AppendLine(")")
            ' 作成したSQLの設定値の部分を実際の値に置換します。
            stbInsertSQL.Replace("__STATUS__", strStatus)
            stbInsertSQL.Replace("__USER__", My.Application.mstrUserID)
            stbInsertSQL.Replace("__IMAGE_ID__", strImageId)

            ' イメージ状態履歴を登録します。
            Dim intInsertRet As Integer = My.Application.comDB.DB_ExecuteNonQuery(stbInsertSQL.ToString)
            If Not intInsertRet = 1 Then
                Throw New Exception("イメージ履歴の登録に失敗しました。")
            End If

        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

#Region "統計情報の登録"
    '2018/08/02 再識別変更対応 Start-------------------------------------------------------------------------
    Private Sub Inser統計情報(ByVal mdtbImg As DataTable, ByVal mdtbImgCopy As DataTable, 開始日時 As DateTime, 終了日時 As DateTime)

        Try

            '出力する値を整理する。
            Dim 案件番号 As String = Convert.ToString(mdtbImg.Rows(0).Item("EXC_SUBJECT_NO"))
            Dim 処理日 As String = Now.ToString("yyyyMMdd")
            Dim 処理時刻 As String = Now.ToString("HHmmss")
            Dim 個社ID As String = My.Application.mdicConfig("個社ID")
            Dim 業務ID As String = 個社ID & My.Application.mdicConfig("業務ID")
            Dim 工程ID As String = ""
            Dim 作業レベル As String = ""
            If m動作モード = 動作モード選択.First Then    '１回目エントリー
                工程ID = My.Application.mdicConfig("工程ID_識別１回目")
                作業レベル = "1"
            Else
                工程ID = My.Application.mdicConfig("工程ID_識別２回目")
                作業レベル = "2"
            End If
            Dim 帳票ID As String = Convert.ToString(mdtbImg.Rows(0).Item("SLIP_DEFINE_ID")).Substring(0, 3)

            Dim 実働時間Work As TimeSpan = (終了日時 - 開始日時)
            Dim 実働時間 As String = CLng(実働時間Work.TotalSeconds).ToString
            Dim 稼働時間 As String = 実働時間

            Dim 変更ページ数Work As Long = 0
            For l As Long = 0 To mdtbImg.Rows.Count - 1
                Dim strOldSlip As String = Convert.ToString(mdtbImgCopy.Rows(l).Item("SLIP_DEFINE_ID"))
                Dim strNewSlip As String = Convert.ToString(mdtbImg.Rows(l).Item("SLIP_DEFINE_ID"))
                If strOldSlip <> strNewSlip Then
                    変更ページ数Work += 1
                End If
            Next
            Dim 変更ページ数 As String = 変更ページ数Work.ToString
            Dim 総ページ数 As String = mdtbImg.Rows.Count.ToString

            ' 統計情報登録用SQLを作成します。
            Dim stbInsertSQL As New System.Text.StringBuilder(String.Empty)
            stbInsertSQL.AppendLine("INSERT INTO T_JJ_OPE_EFFICIENCY (")
            stbInsertSQL.AppendLine("     SHORI_DATE ")
            stbInsertSQL.AppendLine("    ,SHORI_TIME ")
            stbInsertSQL.AppendLine("    ,LOCATION_ID ")
            stbInsertSQL.AppendLine("    ,DEP_CODE ")
            stbInsertSQL.AppendLine("    ,OPERATOR_ID ")
            stbInsertSQL.AppendLine("    ,COMPANY_ID ")
            stbInsertSQL.AppendLine("    ,BUSINESS_ID ")
            stbInsertSQL.AppendLine("    ,PROJECT_ID ")
            stbInsertSQL.AppendLine("    ,SUBJECT_NO ")
            stbInsertSQL.AppendLine("    ,WORK_LEVEL ")
            stbInsertSQL.AppendLine("    ,SLIP_DEF ")
            stbInsertSQL.AppendLine("    ,WORK_TIME ")
            stbInsertSQL.AppendLine("    ,OPE_TIME ")
            stbInsertSQL.AppendLine("    ,OPE_CNT ")
            stbInsertSQL.AppendLine("    ,KNJI_INPT_CHAR_CNT ")
            stbInsertSQL.AppendLine("    ,KNJI_UNRE_CHAR_CNT ")
            stbInsertSQL.AppendLine("    ,KNJI_MISS_ITEM_CNT ")
            stbInsertSQL.AppendLine("    ,KNJI_TOTL_ITEM_CNT ")
            stbInsertSQL.AppendLine("    ,KNJI_VALD_ITEM_CNT ")
            stbInsertSQL.AppendLine("    ,KANA_INPT_CHAR_CNT ")
            stbInsertSQL.AppendLine("    ,KANA_UNRE_CHAR_CNT ")
            stbInsertSQL.AppendLine("    ,KANA_MISS_ITEM_CNT ")
            stbInsertSQL.AppendLine("    ,KANA_TOTL_ITEM_CNT ")
            stbInsertSQL.AppendLine("    ,KANA_VALD_ITEM_CNT ")
            stbInsertSQL.AppendLine("    ,EIJI_INPT_CHAR_CNT ")
            stbInsertSQL.AppendLine("    ,EIJI_UNRE_CHAR_CNT ")
            stbInsertSQL.AppendLine("    ,EIJI_MISS_ITEM_CNT ")
            stbInsertSQL.AppendLine("    ,EIJI_TOTL_ITEM_CNT ")
            stbInsertSQL.AppendLine("    ,EIJI_VALD_ITEM_CNT ")
            stbInsertSQL.AppendLine("    ,SUJI_INPT_CHAR_CNT ")
            stbInsertSQL.AppendLine("    ,SUJI_UNRE_CHAR_CNT ")
            stbInsertSQL.AppendLine("    ,SUJI_MISS_ITEM_CNT ")
            stbInsertSQL.AppendLine("    ,SUJI_TOTL_ITEM_CNT ")
            stbInsertSQL.AppendLine("    ,SUJI_VALD_ITEM_CNT ")
            stbInsertSQL.AppendLine("    ,UNREAD_ITEM_CNT ")
            stbInsertSQL.AppendLine("    ,UNREAD_AVERAGE ")
            stbInsertSQL.AppendLine("    ,MISS_ITEM_CNT ")
            stbInsertSQL.AppendLine("    ,MISS_AVERAGE ")
            stbInsertSQL.AppendLine("    ,OPE_AVERAGE ")
            stbInsertSQL.AppendLine("    ,CHANGE_PAGE_CNT ")
            stbInsertSQL.AppendLine("    ,TOTAL_PAGE_CNT ")
            stbInsertSQL.AppendLine("    ,DELETE_FLG ")
            stbInsertSQL.AppendLine("    ,CREATE_DATE ")
            stbInsertSQL.AppendLine("    ,CREATE_USER ")
            stbInsertSQL.AppendLine("    ,UPDATE_DATE ")
            stbInsertSQL.AppendLine("    ,UPDATE_USER ")
            stbInsertSQL.AppendLine(") VALUES (")
            stbInsertSQL.AppendLine("     '" & 処理日 & "' ")
            stbInsertSQL.AppendLine("    ,'" & 処理時刻 & "' ")
            stbInsertSQL.AppendLine("    ,'1' ")
            stbInsertSQL.AppendLine("    ,'1' ")
            stbInsertSQL.AppendLine("    ,'__USER__' ")
            stbInsertSQL.AppendLine("    ,'" & 個社ID & "' ")
            stbInsertSQL.AppendLine("    ,'" & 業務ID & "' ")
            stbInsertSQL.AppendLine("    ,'" & 工程ID & "' ")
            stbInsertSQL.AppendLine("    ,'" & 案件番号 & "' ")
            stbInsertSQL.AppendLine("    ,'" & 作業レベル & "' ")
            stbInsertSQL.AppendLine("    ,'" & 帳票ID & "' ")
            stbInsertSQL.AppendLine("    ," & 実働時間 & " ")
            stbInsertSQL.AppendLine("    ," & 稼働時間 & " ")
            stbInsertSQL.AppendLine("    ,1 ")
            stbInsertSQL.AppendLine("    ,0 ")
            stbInsertSQL.AppendLine("    ,0 ")
            stbInsertSQL.AppendLine("    ,0 ")
            stbInsertSQL.AppendLine("    ,0 ")
            stbInsertSQL.AppendLine("    ,0 ")
            stbInsertSQL.AppendLine("    ,0 ")
            stbInsertSQL.AppendLine("    ,0 ")
            stbInsertSQL.AppendLine("    ,0 ")
            stbInsertSQL.AppendLine("    ,0 ")
            stbInsertSQL.AppendLine("    ,0 ")
            stbInsertSQL.AppendLine("    ,0 ")
            stbInsertSQL.AppendLine("    ,0 ")
            stbInsertSQL.AppendLine("    ,0 ")
            stbInsertSQL.AppendLine("    ,0 ")
            stbInsertSQL.AppendLine("    ,0 ")
            stbInsertSQL.AppendLine("    ,0 ")
            stbInsertSQL.AppendLine("    ,0 ")
            stbInsertSQL.AppendLine("    ,0 ")
            stbInsertSQL.AppendLine("    ,0 ")
            stbInsertSQL.AppendLine("    ,0 ")
            stbInsertSQL.AppendLine("    ,0 ")
            stbInsertSQL.AppendLine("    ,0.0 ")
            stbInsertSQL.AppendLine("    ,0 ")
            stbInsertSQL.AppendLine("    ,0.0 ")
            stbInsertSQL.AppendLine("    ,0.0 ")
            stbInsertSQL.AppendLine("    ," & 変更ページ数 & " ")
            stbInsertSQL.AppendLine("    ," & 総ページ数 & " ")
            stbInsertSQL.AppendLine("    ,'0' ")
            stbInsertSQL.AppendLine("    ,SYSTIMESTAMP ")
            stbInsertSQL.AppendLine("    ,'__USER__' ")
            stbInsertSQL.AppendLine("    ,SYSTIMESTAMP ")
            stbInsertSQL.AppendLine("    ,'__USER__' ")
            stbInsertSQL.AppendLine(")")

            ' 作成したSQLの設定値の部分を実際の値に置換します。
            stbInsertSQL.Replace("__USER__", My.Application.mstrUserID)

            ' イメージ状態履歴を登録します。
            Dim intInsertRet As Integer = My.Application.comDB.DB_ExecuteNonQuery(stbInsertSQL.ToString)
            If Not intInsertRet = 1 Then
                Throw New Exception("統計情報の登録に失敗しました。")
            End If

        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
    '2018/08/02 再識別変更対応 End  -------------------------------------------------------------------------
#End Region

#Region "一覧の背景色設定"
    Private Sub SetBaclColor()
        Try
            Dim colNormal As Color = Color.FromName(My.Application.mdicConfig("COLOR_NORMAL"))
            Dim colSingle As Color = Color.FromName(My.Application.mdicConfig("COLOR_SINGLE"))
            Dim colMulti As Color = Color.FromName(My.Application.mdicConfig("COLOR_MULTI"))

            Dim dicSlip As New Dictionary(Of String, Integer)
            For Each r As DataRow In mdtbImg.Rows
                Dim strSlip As String = Convert.ToString(r.Item("SLIP_DEFINE_ID"))
                If dicSlip.ContainsKey(strSlip) Then
                    dicSlip(strSlip) += 1
                Else
                    dicSlip.Add(strSlip, 1)
                End If
            Next

            For i As Integer = 0 To Me.dgvList.RowCount - 1 Step 1
                Dim strSrc As String = Convert.ToString(dgvList.Rows(i).Cells(0).Value)
                If Not dicSlip.ContainsKey(strSrc) Then
                    dgvList.Rows(i).Cells(0).Style.BackColor = colNormal
                    dgvList.Rows(i).Cells(1).Style.BackColor = colNormal
                Else
                    If dicSlip(strSrc) = 1 Then
                        dgvList.Rows(i).Cells(0).Style.BackColor = colSingle
                        dgvList.Rows(i).Cells(1).Style.BackColor = colSingle
                    Else
                        dgvList.Rows(i).Cells(0).Style.BackColor = colMulti
                        dgvList.Rows(i).Cells(1).Style.BackColor = colMulti
                    End If
                End If
            Next

        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

    Private mdicNgSlipSet As New Dictionary(Of String, List(Of String))

#Region "禁止組み合わせ読込み"
    Private Sub LoadNGSet()
        Try
            For Each strKey As String In My.Application.mdicConfig.Keys
                If Not strKey.StartsWith("NG_SLIP_SET_") Then
                    Continue For
                End If
                Dim strSlip() As String = Split(My.Application.mdicConfig(strKey), ",")
                If Not mdicNgSlipSet.ContainsKey(strSlip(0)) Then
                    Dim lst As New List(Of String)
                    mdicNgSlipSet.Add(strSlip(0), lst)
                End If
                mdicNgSlipSet(strSlip(0)).Add(strSlip(1))
            Next

        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

#Region "禁止組み合わせ一致チェック"
    Private Function CheckNgSlipSet() As Boolean
        Try
            Dim dtbConv As DataTable = MakeSlipConvertTable()
            For Each r As DataRow In dtbConv.Rows
                Dim strKeySlip As String = Convert.ToString(r.Item("SLIP_DEFINE_ID"))
                If Not mdicNgSlipSet.ContainsKey(strKeySlip) Then
                    Continue For
                End If
                For Each rr As DataRow In dtbConv.Rows
                    Dim strSlip As String = Convert.ToString(rr.Item("SLIP_DEFINE_ID"))
                    For Each strNG As String In mdicNgSlipSet(strKeySlip)
                        If strNG.Equals(strSlip) Then
                            Return False
                        End If
                    Next
                Next
            Next

            Return True

        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Function
#End Region

    ' 2019/10/25 追加 shinohara@sshantery
#Region "４件も移行データ有チェックボックスの表示制御"
    Private Sub ViewControlForCheckBox()
        Try
            If mdtbImg Is Nothing Then
                Me.chk4Over.Checked = False
                Me.chk4Over.Visible = False
                Return
            End If

            For Each dr As DataRow In mdtbImg.Rows
                Dim strSlipID As String = Convert.ToString(dr.Item("SLIP_DEFINE_ID"))
                If strSlipID.StartsWith("641") Then
                    Me.chk4Over.Visible = True
                    Return
                End If
            Next

            Me.chk4Over.Checked = False
            Me.chk4Over.Visible = False

        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

#Region "SS/非SS切り替え"
    Private Sub rdoSS_CheckedChanged(sender As Object, e As EventArgs)
        RemoveHandler rdoSS.CheckedChanged, AddressOf rdoSS_CheckedChanged
        RemoveHandler rdoNonSS.CheckedChanged, AddressOf rdoSS_CheckedChanged
        Try
            If Not DirectCast(sender, RadioButton).Checked Then
                Return
            End If

            ' 処理中のイメージデータがあるか確認します。
            If My.Application.mblnTransaction Then
                ' 処理中のデータがある場合は切り替えの確認を行います。
                If MessageBox.Show("帳票種別を切り替えますか？", APP_NAME, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) = Windows.Forms.DialogResult.No Then
                    If rdoSS.Checked Then
                        rdoSS.Checked = False
                        rdoNonSS.Checked = True
                    Else
                        rdoNonSS.Checked = False
                        rdoSS.Checked = True
                    End If
                    Return
                End If
                My.Application.comDB.DB_Rollback()
                My.Application.mblnTransaction = False
            End If

            Me.btnProCommit.Enabled = True

            ' エラー表示を初期化します。
            Me.txtErrorInfo.Text = String.Empty
            mImgList.Clear()
            mdtbImg = GetImage()
            If IsNothing(mdtbImg) = True Then
                Me.Close()
                Return
            End If
            ' チェックボックスの表示／非表示を切り替えます
            Call ViewControlForCheckBox()
            mdtbImgCopy = mdtbImg.Copy
            Call ViewImage()
            ' 一覧の背景色を設定します
            Call SetBaclColor()
            Application.DoEvents()
            Me.ActiveControl = Me.txtSlipSurfix
            Me.txtSlipSurfix.SelectAll()

        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        Finally
            AddHandler rdoSS.CheckedChanged, AddressOf rdoSS_CheckedChanged
            AddHandler rdoNonSS.CheckedChanged, AddressOf rdoSS_CheckedChanged
        End Try
    End Sub
#End Region

#Region "帳票ID統一後のテーブル作成"
    Private Function MakeSlipConvertTable() As DataTable
        Try
            Dim dt As DataTable = mdtbImg.Copy
            For Each dr As DataRow In dt.Rows
                Dim strSlip As String = Convert.ToString(dr.Item("SLIP_DEFINE_ID"))
                If mdicSlipConv.ContainsKey(strSlip) Then
                    If mstrSlipDiv.Equals("062") Then
                        Select Case strSlip
                            Case "661119"
                                dr.Item("SLIP_DEFINE_ID") = "661669"
                            Case "661218"
                                dr.Item("SLIP_DEFINE_ID") = "661768"
                            Case "661126"
                                dr.Item("SLIP_DEFINE_ID") = "661676"
                            Case "661225"
                                dr.Item("SLIP_DEFINE_ID") = "661775"
                            Case Else
                                dr.Item("SLIP_DEFINE_ID") = mdicSlipConv(strSlip)
                        End Select
                    Else
                        dr.Item("SLIP_DEFINE_ID") = mdicSlipConv(strSlip)
                    End If
                End If
            Next
            Return dt
        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Function
#End Region

End Class

Public Class clsBitmapData
    Public mImageName As String
    Public mBmp As Bitmap
    Public Sub New(ByVal imageName As String, ByVal bmp As Bitmap)
        mImageName = imageName
        mBmp = bmp
    End Sub
End Class
