﻿Imports CommonSystem
Imports System
Imports System.Text
Imports DataGridViewAutoFilter

Public Class frmMain

#Region "定数定義"
    Private Const APP_NAME As String = "エントリ依頼制御"

#End Region

#Region "内部変数定義"

    ' 処理対象イメージID辞書
    Private mdicImageID As New Dictionary(Of String, List(Of String))

#End Region

#Region "フォームロード処理"
    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try

            Call GetData()

        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

#Region "データ抽出"
    Private Sub GetData()
        Try
            mdicImageID.Clear()

            Dim stbSQL As New StringBuilder(String.Empty)
            stbSQL.AppendLine("SELECT")
            stbSQL.AppendLine("     0 AS CHK")
            stbSQL.AppendLine("    ,I.IMAGE_ID")
            stbSQL.AppendLine("    ,I.RECEIPT_ID")
            stbSQL.AppendLine("    ,I.SLIP_DEFINE_ID")
            stbSQL.AppendLine("    ,S.SLIP_DEFINE_NAME")
            stbSQL.AppendLine("    ,I.DEF_REV_COUNT")
            stbSQL.AppendLine("    ,I.PRIORITY")
            stbSQL.AppendLine("    ,0 AS CNT")
            stbSQL.AppendLine("FROM")
            stbSQL.AppendLine("    T_JJ_IMAGE I")
            stbSQL.AppendLine("    LEFT JOIN M_SLIP_DEFINE S")
            stbSQL.AppendLine("        ON")
            stbSQL.AppendLine("        S.DELETE_FLG = '0'")
            stbSQL.AppendLine("        AND")
            stbSQL.AppendLine("        S.SLIP_DEFINE_ID = I.SLIP_DEFINE_ID")
            stbSQL.AppendLine("WHERE")
            stbSQL.AppendLine("    I.DELETE_FLG = '0'")
            stbSQL.AppendLine("    AND")
            stbSQL.AppendLine("    I.IMAGE_STATUS IN (%STATUS%)")
            stbSQL.AppendLine("ORDER BY")
            stbSQL.AppendLine("     I.RECEIPT_ID")
            stbSQL.AppendLine("    ,I.SLIP_DEFINE_ID")
            stbSQL.AppendLine("    ,I.DEF_REV_COUNT")
            stbSQL.AppendLine("    ,I.PRIORITY")
            stbSQL.AppendLine("    ,I.IMAGE_ID")
            stbSQL.Replace("%STATUS%", My.Application.mdicConfig("INPUT_STATUS"))

            Dim dt As DataTable = My.Application.comDB.DB_ExecuteQuery(stbSQL.ToString)
            Dim dt2 = dt.Clone

            For Each dr As DataRow In dt.Rows
                Dim strImageID As String = Convert.ToString(dr.Item("IMAGE_ID"))
                Dim strSubKey() As String = { _
                                            Convert.ToString(dr.Item("RECEIPT_ID")), _
                                            Convert.ToString(dr.Item("SLIP_DEFINE_ID")), _
                                            Convert.ToString(dr.Item("DEF_REV_COUNT")), _
                                            Convert.ToString(dr.Item("PRIORITY")) _
                                            }
                Dim strKey As String = Join(strSubKey, "-")
                If Not mdicImageID.ContainsKey(strKey) Then
                    Dim lst As New List(Of String)
                    mdicImageID.Add(strKey, lst)
                    dt2.ImportRow(dr)
                End If
                mdicImageID(strKey).Add(strImageID)
            Next

            For Each dr As DataRow In dt2.Rows
                Dim strSubKey() As String = { _
                                            Convert.ToString(dr.Item("RECEIPT_ID")), _
                                            Convert.ToString(dr.Item("SLIP_DEFINE_ID")), _
                                            Convert.ToString(dr.Item("DEF_REV_COUNT")), _
                                            Convert.ToString(dr.Item("PRIORITY")) _
                                            }
                Dim strKey As String = Join(strSubKey, "-")
                dr.Item("CNT") = mdicImageID(strKey).Count.ToString
            Next


            Dim dataSource As New BindingSource(dt2, Nothing)
            Me.dgvList.DataSource = dataSource

            ' DataGridViewのオートフィルタバグ対応 初期表示時のセル位置を２列目にしておく
            If dt2.Rows.Count > 0 Then
                Me.dgvList.CurrentCell = Me.dgvList.Rows(0).Cells("RECEIPT_ID")
            End If

        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

#Region "終了ボタン処理"
    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        End
    End Sub
#End Region

#Region "リスト更新ボタン処理"
    Private Sub btnList_Click(sender As Object, e As EventArgs) Handles btnList.Click
        Try
            DataGridViewAutoFilterColumnHeaderCell.RemoveFilter(dgvList)
            Call GetData()
        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

#Region "全部チェック処理"
    Private Sub dgvList_ColumnHeaderMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles dgvList.ColumnHeaderMouseClick
        Try
            If e.ColumnIndex = 0 Then
                For i As Integer = 0 To dgvList.RowCount - 1 Step 1
                    Me.dgvList.Rows(i).Cells("CHK").Value = 1
                Next
            End If
        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

#Region "全行チェック解除"
    Private Sub dgvList_ColumnHeaderMouseDoubleClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles dgvList.ColumnHeaderMouseDoubleClick
        Try
            If e.ColumnIndex = 0 Then
                For i As Integer = 0 To dgvList.RowCount - 1 Step 1
                    Me.dgvList.Rows(i).Cells("CHK").Value = 0
                Next
            End If
        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

#Region "エントリ依頼ボタン"
    Private Sub btnChange_Click(sender As Object, e As EventArgs) Handles btnChange.Click
        Try
            Dim lstImageID As New List(Of String)
            For i As Integer = 0 To dgvList.RowCount - 1 Step 1
                If Me.dgvList.Rows(i).Cells("CHK").Value = 0 Then
                    Continue For
                End If
                Dim strSubKey() As String = { _
                                            Convert.ToString(Me.dgvList.Rows(i).Cells("RECEIPT_ID").Value), _
                                            Convert.ToString(Me.dgvList.Rows(i).Cells("SLIP_DEFINE_ID").Value), _
                                            Convert.ToString(Me.dgvList.Rows(i).Cells("DEF_REV_COUNT").Value), _
                                            Convert.ToString(Me.dgvList.Rows(i).Cells("PRIORITY").Value) _
                                            }
                Dim strKey As String = Join(strSubKey, "-")
                For Each strImageID As String In mdicImageID(strKey)
                    lstImageID.Add(strImageID)
                Next
            Next

            If lstImageID.Count = 0 Then
                MessageBox.Show("更新対象データを指定してください。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Return
            End If

            Dim lstImageIdSplit As New List(Of String())
            Dim lst As New List(Of String)
            For Each strImageID As String In lstImageID
                lst.Add(strImageID)
                If lst.Count = 1000 Then
                    lstImageIdSplit.Add(lst.ToArray)
                    lst = New List(Of String)
                End If
            Next
            If lst.Count > 0 AndAlso lst.Count < 1000 Then
                lstImageIdSplit.Add(lst.ToArray)
            End If

            My.Application.comDB.DB_Transaction()
            Try
                For Each strImg() As String In lstImageIdSplit
                    UpdateDB(strImg)
                Next
                My.Application.comDB.DB_Commit()
            Catch ex As Exception
                My.Application.comDB.DB_Rollback()
                Throw ex
            End Try


            MessageBox.Show("正常に更新されました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Information)

            DataGridViewAutoFilterColumnHeaderCell.RemoveFilter(dgvList)
            Call GetData()

        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

#Region "DB更新"
    Private Sub UpdateDB(strImageID() As String)
        Try

            Dim stbSQL As New StringBuilder(String.Empty)
            stbSQL.AppendLine("UPDATE")
            stbSQL.AppendLine("    T_JJ_IMAGE")
            stbSQL.AppendLine("SET")
            stbSQL.AppendLine("     IMAGE_STATUS        = '%IMAGE_STATUS%'")
            stbSQL.AppendLine("    ,BEFORE_IMAGE_STATUS = IMAGE_STATUS")
            stbSQL.AppendLine("    ,UPDATE_DATE         = SYSDATE")
            stbSQL.AppendLine("    ,UPDATE_USER         = '%UPDATE_USER%'")
            If Me.cmbPriority.SelectedIndex > 0 Then
                stbSQL.AppendLine("    ,PRIORITY            = '%PRIORITY%'")
                stbSQL.Replace("%PRIORITY%", Me.cmbPriority.Text)
            End If
            stbSQL.AppendLine("WHERE")
            stbSQL.AppendLine("    DELETE_FLG = '0'")
            stbSQL.AppendLine("    AND")
            stbSQL.AppendLine("    IMAGE_ID IN (%IMAGE_ID%)")
            stbSQL.Replace("%IMAGE_STATUS%", My.Application.mdicConfig("OUTPUT_STATUS"))
            stbSQL.Replace("%UPDATE_USER%", My.Application.mstrUserID)
            stbSQL.Replace("%IMAGE_ID%", Join(strImageID, ","))

            ' イメージステータスと優先度を更新します。
            My.Application.comDB.DB_ExecuteNonQuery(stbSQL.ToString)


            stbSQL.Length = 0
            stbSQL.AppendLine("INSERT INTO T_JJ_IMAGE_HISTORY")
            stbSQL.AppendLine("(")
            stbSQL.AppendLine("     IMAGE_ID    ")
            stbSQL.AppendLine("    ,IMAGE_STATUS")
            stbSQL.AppendLine("    ,CREATE_DATE ")
            stbSQL.AppendLine("    ,CREATE_USER ")
            stbSQL.AppendLine(")")
            stbSQL.AppendLine("SELECT")
            stbSQL.AppendLine("    IMAGE_ID")
            stbSQL.AppendLine("    ,'%IMAGE_STATUS%'  AS IMAGE_STATUS")
            stbSQL.AppendLine("    ,SYSDATE           AS CREATE_DATE")
            stbSQL.AppendLine("    ,'%CREATE_USER%'   AS CREATE_USER")
            stbSQL.AppendLine("FROM")
            stbSQL.AppendLine("    T_JJ_IMAGE")
            stbSQL.AppendLine("WHERE")
            stbSQL.AppendLine("    DELETE_FLG = '0'")
            stbSQL.AppendLine("    AND")
            stbSQL.AppendLine("    IMAGE_ID IN (%IMAGE_ID%)")
            stbSQL.Replace("%IMAGE_STATUS%", My.Application.mdicConfig("OUTPUT_STATUS"))
            stbSQL.Replace("%CREATE_USER%", My.Application.mstrUserID)
            stbSQL.Replace("%IMAGE_ID%", Join(strImageID, ","))

            ' イメージ履歴を登録します。
            My.Application.comDB.DB_ExecuteNonQuery(stbSQL.ToString)

        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            Throw ex
        End Try
    End Sub
#End Region


End Class
