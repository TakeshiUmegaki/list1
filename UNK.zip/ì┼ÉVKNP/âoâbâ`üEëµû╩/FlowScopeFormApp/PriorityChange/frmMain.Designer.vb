﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.dgvList = New System.Windows.Forms.DataGridView()
        Me.cmbPriority = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnChange = New System.Windows.Forms.Button()
        Me.btnList = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.CHK = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.RECEIPT_ID = New DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn()
        Me.SLIP_DEFINE_ID = New DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn()
        Me.SLIP_DEFINE_NAME = New DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn()
        Me.DEF_REV_COUNT = New DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn()
        Me.PRIORITY = New DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn()
        Me.CNT = New DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn()
        Me.IMAGE_ID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.dgvList, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'dgvList
        '
        Me.dgvList.AllowUserToAddRows = False
        Me.dgvList.AllowUserToDeleteRows = False
        Me.dgvList.AllowUserToResizeRows = False
        Me.dgvList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvList.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.CHK, Me.RECEIPT_ID, Me.SLIP_DEFINE_ID, Me.SLIP_DEFINE_NAME, Me.DEF_REV_COUNT, Me.PRIORITY, Me.CNT, Me.IMAGE_ID})
        Me.dgvList.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgvList.Location = New System.Drawing.Point(0, 0)
        Me.dgvList.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.dgvList.MultiSelect = False
        Me.dgvList.Name = "dgvList"
        Me.dgvList.RowHeadersVisible = False
        Me.dgvList.RowTemplate.Height = 21
        Me.dgvList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvList.Size = New System.Drawing.Size(991, 335)
        Me.dgvList.TabIndex = 0
        '
        'cmbPriority
        '
        Me.cmbPriority.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.cmbPriority.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbPriority.FormattingEnabled = True
        Me.cmbPriority.Items.AddRange(New Object() {"", "1", "2", "3", "4", "5", "6", "7", "8", "9"})
        Me.cmbPriority.Location = New System.Drawing.Point(69, 347)
        Me.cmbPriority.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.cmbPriority.Name = "cmbPriority"
        Me.cmbPriority.Size = New System.Drawing.Size(38, 24)
        Me.cmbPriority.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(7, 350)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(56, 16)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "優先度"
        '
        'btnChange
        '
        Me.btnChange.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnChange.Location = New System.Drawing.Point(135, 342)
        Me.btnChange.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnChange.Name = "btnChange"
        Me.btnChange.Size = New System.Drawing.Size(136, 33)
        Me.btnChange.TabIndex = 3
        Me.btnChange.Text = "エントリ依頼"
        Me.btnChange.UseVisualStyleBackColor = True
        '
        'btnList
        '
        Me.btnList.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnList.Location = New System.Drawing.Point(566, 342)
        Me.btnList.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnList.Name = "btnList"
        Me.btnList.Size = New System.Drawing.Size(136, 33)
        Me.btnList.TabIndex = 4
        Me.btnList.Text = "リスト更新"
        Me.btnList.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnClose.Location = New System.Drawing.Point(709, 342)
        Me.btnClose.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(136, 33)
        Me.btnClose.TabIndex = 5
        Me.btnClose.Text = "終了"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.Controls.Add(Me.dgvList)
        Me.Panel1.Location = New System.Drawing.Point(2, 1)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(991, 335)
        Me.Panel1.TabIndex = 6
        '
        'CHK
        '
        Me.CHK.DataPropertyName = "CHK"
        Me.CHK.FalseValue = "0"
        Me.CHK.Frozen = True
        Me.CHK.HeaderText = ""
        Me.CHK.Name = "CHK"
        Me.CHK.TrueValue = "1"
        Me.CHK.Width = 50
        '
        'RECEIPT_ID
        '
        Me.RECEIPT_ID.DataPropertyName = "RECEIPT_ID"
        Me.RECEIPT_ID.HeaderText = "受付ID"
        Me.RECEIPT_ID.MinimumWidth = 120
        Me.RECEIPT_ID.Name = "RECEIPT_ID"
        Me.RECEIPT_ID.ReadOnly = True
        Me.RECEIPT_ID.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.RECEIPT_ID.Width = 120
        '
        'SLIP_DEFINE_ID
        '
        Me.SLIP_DEFINE_ID.DataPropertyName = "SLIP_DEFINE_ID"
        Me.SLIP_DEFINE_ID.HeaderText = "帳票ID"
        Me.SLIP_DEFINE_ID.Name = "SLIP_DEFINE_ID"
        Me.SLIP_DEFINE_ID.ReadOnly = True
        Me.SLIP_DEFINE_ID.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        '
        'SLIP_DEFINE_NAME
        '
        Me.SLIP_DEFINE_NAME.DataPropertyName = "SLIP_DEFINE_NAME"
        Me.SLIP_DEFINE_NAME.HeaderText = "帳票名"
        Me.SLIP_DEFINE_NAME.Name = "SLIP_DEFINE_NAME"
        Me.SLIP_DEFINE_NAME.ReadOnly = True
        Me.SLIP_DEFINE_NAME.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.SLIP_DEFINE_NAME.Width = 300
        '
        'DEF_REV_COUNT
        '
        Me.DEF_REV_COUNT.DataPropertyName = "DEF_REV_COUNT"
        Me.DEF_REV_COUNT.HeaderText = "再識別回数"
        Me.DEF_REV_COUNT.Name = "DEF_REV_COUNT"
        Me.DEF_REV_COUNT.ReadOnly = True
        Me.DEF_REV_COUNT.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DEF_REV_COUNT.Width = 150
        '
        'PRIORITY
        '
        Me.PRIORITY.DataPropertyName = "PRIORITY"
        Me.PRIORITY.HeaderText = "優先度"
        Me.PRIORITY.Name = "PRIORITY"
        Me.PRIORITY.ReadOnly = True
        Me.PRIORITY.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.PRIORITY.Width = 150
        '
        'CNT
        '
        Me.CNT.DataPropertyName = "CNT"
        Me.CNT.HeaderText = "件数"
        Me.CNT.Name = "CNT"
        Me.CNT.ReadOnly = True
        Me.CNT.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        '
        'IMAGE_ID
        '
        Me.IMAGE_ID.DataPropertyName = "IMAGE_ID"
        Me.IMAGE_ID.HeaderText = "IMAGE_ID"
        Me.IMAGE_ID.Name = "IMAGE_ID"
        Me.IMAGE_ID.ReadOnly = True
        Me.IMAGE_ID.Visible = False
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(994, 379)
        Me.ControlBox = False
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnList)
        Me.Controls.Add(Me.btnChange)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.cmbPriority)
        Me.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "エントリ依頼制御"
        CType(Me.dgvList, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents dgvList As System.Windows.Forms.DataGridView
    Friend WithEvents cmbPriority As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnChange As System.Windows.Forms.Button
    Friend WithEvents btnList As System.Windows.Forms.Button
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents CHK As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents RECEIPT_ID As DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn
    Friend WithEvents SLIP_DEFINE_ID As DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn
    Friend WithEvents SLIP_DEFINE_NAME As DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn
    Friend WithEvents DEF_REV_COUNT As DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn
    Friend WithEvents PRIORITY As DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn
    Friend WithEvents CNT As DataGridViewAutoFilter.DataGridViewAutoFilterTextBoxColumn
    Friend WithEvents IMAGE_ID As System.Windows.Forms.DataGridViewTextBoxColumn

End Class
