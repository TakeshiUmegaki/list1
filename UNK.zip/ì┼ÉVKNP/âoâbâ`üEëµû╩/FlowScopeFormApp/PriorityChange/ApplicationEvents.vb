﻿Imports CommonSystem
Imports CommonForm
Imports System
Imports System.Configuration
Imports System.IO
Imports System.Text
Imports System.Configuration.ConfigurationManager
Imports System.Reflection.MethodBase

Namespace My

    ' 次のイベントは MyApplication に対して利用できます:
    ' 
    ' Startup: アプリケーションが開始されたとき、スタートアップ フォームが作成される前に発生します。
    ' Shutdown: アプリケーション フォームがすべて閉じられた後に発生します。このイベントは、通常の終了以外の方法でアプリケーションが終了されたときには発生しません。
    ' UnhandledException: ハンドルされていない例外がアプリケーションで発生したときに発生するイベントです。
    ' StartupNextInstance: 単一インスタンス アプリケーションが起動され、それが既にアクティブであるときに発生します。
    ' NetworkAvailabilityChanged: ネットワーク接続が接続されたとき、または切断されたときに発生します。
    Partial Friend Class MyApplication


#Region "定数定義"
        ''' <summary>
        ''' ログ出力レベル
        ''' </summary>
        ''' <remarks></remarks>
        Public Const CONF_LOG_OUTPUT_LEVEL As String = "LOG_OUTPUT_LEVEL"

        ''' <summary>
        ''' ログ日時分割出力モード
        ''' </summary>
        ''' <remarks></remarks>
        Public Const CONF_LOG_DIVIDE_MODE As String = "LOG_DIVIDE_MODE"

        ''' <summary>
        ''' ログ削除期間
        ''' </summary>
        ''' <remarks></remarks>
        Public Const CONF_DELETE_LOG_PERIOD As String = "DELETE_LOG_PERIOD"

        ''' <summary>
        ''' DB接続情報取得PreFix
        ''' </summary>
        ''' <remarks></remarks>
        Public Const CONF_DB_CONFIG_PREFIX As String = "DB_CONFIG_PREFIX"

        ''' <summary>
        ''' DB接続情報取得PreFix
        ''' </summary>
        ''' <remarks></remarks>
        Public Const CONF_COMPANY_CODE As String = "COMPANY_CODE"
#End Region

#Region "共通項目定義"
        ''' <summary>
        ''' DBアクセス用オブジェクト
        ''' </summary>
        ''' <remarks></remarks>
        Public comDB As New CommonDB

        ''' <summary>
        ''' 外部定義
        ''' </summary>
        ''' <remarks></remarks>
        Public mdicConfig As New Dictionary(Of String, String)

        ''' <summary>
        ''' ログインユーザID
        ''' </summary>
        ''' <remarks></remarks>
        Public mstrUserID As String = String.Empty

        ''' <summary>
        ''' ログインユーザ名
        ''' </summary>
        ''' <remarks></remarks>
        Public mstrUserName As String = String.Empty

        ''' <summary>
        ''' ログインユーザ権限
        ''' </summary>
        ''' <remarks></remarks>
        Public mstrUserRoll As String = String.Empty

        ''' <summary>
        ''' トランザクション実行中フラグ
        ''' </summary>
        ''' <remarks></remarks>
        Public mblnTransaction As Boolean = False
#End Region

        Private Sub MyApplication_Startup(ByVal sender As Object, ByVal e As Microsoft.VisualBasic.ApplicationServices.StartupEventArgs) Handles Me.Startup
            Try
                '---------------------------------
                '* 同一プロセスチェック
                '---------------------------------
                If CommonProcess.ProcessExecCheck = False Then
                    MessageBox.Show("既に起動されています。")
                    End
                End If

                '---------------------------------
                '* AppConfigファイル情報取得
                '---------------------------------
                For Each strkey As String In AppSettings.AllKeys
                    mdicConfig.Add(strkey, AppSettings(strkey))
                Next

                '---------------------------------
                '* ログ設定
                '---------------------------------
                SetLogOutput(mdicConfig)

                '---------------------------------
                '* ログファイル削除
                '---------------------------------
                DeleteLogFile(mdicConfig)

                '---------------------------------
                '* DB接続
                '---------------------------------
                Call SetDataBase(mdicConfig)



                ' 共通ログイン画面にDB接続情報を設定します。
                frmLoginBase.comDB = comDB
                ' 共通ログイン画面に外部定義情報を設定します。
                frmLoginBase.mdicConfig = mdicConfig



            Catch ex As Exception

                CommonLog.WriteLog(GetCurrentMethod.Name & "：ErrorMessage「" & ex.Message & "」", EventLogEntryType.Error)
                MessageBox.Show(ex.Message, "エラー", MessageBoxButtons.OK, MessageBoxIcon.Error)

            Finally

                '---------------------------------
                '* 開放処理
                '---------------------------------
                Call GC.Collect()

            End Try
        End Sub

        Private Sub MyApplication_Shutdown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shutdown
            Try
                If comDB.DB_OpenConfirm Then
                    If mblnTransaction Then
                        comDB.DB_Rollback()
                    End If
                    comDB.DB_Close()
                End If
            Catch ex As Exception

            End Try
        End Sub


#Region "【private】SetLogOutput ログ出力設定"
        ''' ======================================================================
        ''' メソッド名：SetLogOutput
        ''' <summary>
        ''' Log出力モード設定処理
        ''' </summary>
        ''' <param name="dicConfig">AppConfigファイル情報</param>
        ''' <remarks></remarks>
        ''' ======================================================================
        Private Shared Sub SetLogOutput(ByVal dicConfig As Dictionary(Of String, String))

            ' ログ出力レベル設定
            If dicConfig.ContainsKey(CONF_LOG_OUTPUT_LEVEL) Then
                CommonLog.SetLogOutputMode = System.Int32.Parse(dicConfig(CONF_LOG_OUTPUT_LEVEL))
            Else
                CommonLog.SetLogOutputMode = CommonLog.LogOutputMode.Silent
            End If

            ' ログ日時分割出力モード設定
            If dicConfig.ContainsKey(CONF_LOG_DIVIDE_MODE) Then
                CommonLog.SetLogDateHourDivideMode = System.Int32.Parse(dicConfig(CONF_LOG_DIVIDE_MODE))
            Else
                CommonLog.SetLogDateHourDivideMode = CommonLog.LogDateHourDivideMode.Normal
            End If

        End Sub
#End Region

#Region "【Private】DeleteLogFile ログ削除処理"
        ''' ======================================================================
        ''' メソッド名：DeleteLogFile
        ''' <summary>
        ''' ログ削除処理
        ''' </summary>
        ''' <param name="dicConfig">アプリケーションコンフィグファイル情報</param>
        ''' <remarks></remarks>
        ''' ======================================================================
        Private Shared Sub DeleteLogFile(ByVal dicConfig As Dictionary(Of String, String))

            ' ログ削除期間
            Dim strDelLogPeriod As String = dicConfig(CONF_DELETE_LOG_PERIOD)
            ' ログ出力先
            Dim strFilePath As String = Path.GetDirectoryName(Windows.Forms.Application.ExecutablePath)
            ' EXE名
            Dim strExeFileName As String = Path.GetFileNameWithoutExtension(Windows.Forms.Application.ExecutablePath)
            ' ログファイルリスト
            Dim lstFile As Array = IO.Directory.GetFileSystemEntries(strFilePath, "*" & ".txt")
            ' システム日付
            Dim dtSystemdate As DateTime = DateTime.Now

            ' 削除期間から削除する日時を取得
            Dim dtDeleteDate = dtSystemdate.AddDays(-CDbl(strDelLogPeriod))

            For Each strFileFullPath As String In lstFile

                ' ファイルフルパスからファイル名を取得
                Dim strFileName As String = Path.GetFileNameWithoutExtension(strFileFullPath)

                ' ファイル名にEXE名が含まれている場合
                If InStr(strFileName, strExeFileName) > 0 Then

                    ' ファイル更新日が削除日付以下の場合
                    If File.GetLastWriteTime(strFileFullPath) <= dtDeleteDate Then

                        ' サブファイルの属性変更
                        Dim objFileInfo As New System.IO.FileInfo(strFileFullPath)
                        If (objFileInfo.Attributes And System.IO.FileAttributes.ReadOnly) > 0 Then
                            objFileInfo.Attributes = System.IO.FileAttributes.Normal
                        End If

                        'ファイルの中を削除
                        System.IO.File.Delete(strFileFullPath)

                    End If

                End If

            Next

        End Sub

#End Region

#Region "【private】SetDataBase DB接続処理"
        ''' ======================================================================
        ''' メソッド名：SetDataBase
        ''' <summary>
        ''' DB接続処理
        ''' </summary>
        ''' <remarks></remarks>
        ''' ======================================================================  
        Private Shared Sub SetDataBase(ByVal dicConfig As Dictionary(Of String, String))

            ' DB接続

            Dim strPrefix As String = String.Empty

            '' DB接続文字列設定
            strPrefix = strPrefix & dicConfig(CONF_DB_CONFIG_PREFIX)

            ' DB接続
            If My.Application.comDB.DB_Open(strPrefix) = False Then
                Throw New Exception("DB接続に失敗しました")
            End If

        End Sub
#End Region


    End Class


End Namespace

