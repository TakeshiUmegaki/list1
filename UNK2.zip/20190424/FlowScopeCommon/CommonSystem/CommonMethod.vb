﻿Imports System.Text
Imports System.Runtime

Public Module CommonMethod
    ''' <summary>
    ''' オブジェクト開放
    ''' </summary>
    ''' <param name="objCOM"></param>
    ''' <remarks></remarks>
    Public Sub ReleaseObject(ByRef objCOM As Object)
        ' 明示的にCOMオブジェクトの参照を解放
        Try
            ' オブジェクトが有効(Nothing以外)か判断
            If Not objCOM Is Nothing Then
                ' COMオブジェクトであるか判断(念のため)
                If InteropServices.Marshal.IsComObject(objCOM) Then
                    ' 参照カウントを0になるまで減算
                    Dim CNT As Integer
                    Do
                        CNT = InteropServices.Marshal.ReleaseComObject(objCOM)
                    Loop Until CNT <= 0
                End If
            End If
        Catch
            ' ここでのエラーは無視
        End Try
        ' 参照を解除する
        objCOM = Nothing
    End Sub

#Region "スクランブル変換"
    ''' <summary>
    ''' スクランブル変換
    ''' </summary>
    ''' <param name="strBefore"></param>
    ''' <param name="risonaFlg"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function DoScrumble(ByVal strBefore As String, ByVal risonaFlg As Boolean) As String

        Dim temp As String = strBefore.Trim()
        Dim strBdResult As New StringBuilder

        If Not temp Is Nothing Then
            If risonaFlg Then
                'りそなの場合
                For i As Integer = 0 To temp.Length - 1
                    Dim val As String = temp.Substring(i, 1)
                    Select Case val
                        Case "-" : strBdResult.Append("0")
                        Case "R" : strBdResult.Append("1")
                        Case "Z" : strBdResult.Append("2")
                        Case "E" : strBdResult.Append("3")
                        Case "U" : strBdResult.Append("4")
                        Case "S" : strBdResult.Append("5")
                        Case "O" : strBdResult.Append("6")
                        Case "I" : strBdResult.Append("7")
                        Case "N" : strBdResult.Append("8")
                        Case "C" : strBdResult.Append("9")
                        Case Else : strBdResult.Append(val)
                    End Select

                Next
            Else
                'その他
                For i As Integer = 0 To temp.Length - 1
                    Dim val As String = temp.Substring(i, 1)
                    Select Case val
                        Case "B" : strBdResult.Append("0")
                        Case "G" : strBdResult.Append("1")
                        Case "D" : strBdResult.Append("2")
                        Case "J" : strBdResult.Append("3")
                        Case "F" : strBdResult.Append("4")
                        Case "A" : strBdResult.Append("5")
                        Case "K" : strBdResult.Append("6")
                        Case "E" : strBdResult.Append("7")
                        Case "H" : strBdResult.Append("8")
                        Case "C" : strBdResult.Append("9")
                        Case Else : strBdResult.Append(val)
                    End Select

                Next

            End If

        End If

        Return strBdResult.ToString()
    End Function

#End Region

#Region "文字列編集メソッド"
    ''' <summary>
    ''' 文字列編集メソッド
    ''' </summary>
    ''' <param name="value">対象文字列</param>
    ''' <remarks>ダブルコートで括る</remarks>
    Public Function ManipulateItem(ByVal value As String, Optional ByVal commaFlg As Boolean = True) As String
        Dim str As String
        str = """" & value.Replace("""", "'").Replace(ChrW(&H201D), "’").TrimEnd() & """"
        If commaFlg Then
            str &= ","
        End If

        Return str

    End Function

#End Region

#Region "ダブルクォーテーションを意識したカンマによる文字列展開"
    ''' <summary>
    ''' ダブルクォーテーションを意識したカンマによる文字列展開
    ''' </summary>
    ''' <param name="strSRC"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function LocalSplit(ByVal strSRC As String) As String()

        Dim intStrLength As Integer = strSRC.Length         'ベースとなる文字列の全文字数
        Dim intStrPosition As Integer = 0                   '現在処理中の文字の位置
        Dim stbItem As New StringBuilder(String.Empty)      '展開後の文字列編集バッファ
        Dim arySplit As New ArrayList                       '展開結果一次格納領域

        '１文字ずつ切り出してその内容を判定します。
        Do
            '最後の文字まで達してしまった場合は編集中の最後の項目を一次格納領域に追加して
            'ループを抜け出します。（編集完了）
            If intStrPosition >= intStrLength Then
                arySplit.Add(stbItem.ToString)
                Exit Do
            End If

            'ベースとなる文字列から一文字切り出します。
            '切り出したら切り出し位置を１つ進めておきます。
            Dim strWord As String = strSRC.Substring(intStrPosition, 1)
            intStrPosition += 1

            Select Case strWord
                Case ","
                    '区切り文字を発見したらその手前までの編集結果を一次格納領域に追加して
                    '編集結果を初期化します。
                    arySplit.Add(stbItem.ToString)
                    stbItem.Length = 0

                Case """"
                    'ダブルクォーテーションを発見したら終端のダブルクォーテーションまでの文字列を
                    '切り出します。
                    Dim stbSubItem As New StringBuilder(String.Empty)
                    Do
                        '最後の文字まで達してしまった場合はループを抜け出します。
                        '（ダブルクォーテーション内の文字切り出し完了）
                        If intStrPosition >= intStrLength Then
                            Exit Do
                        End If

                        'ベースとなる文字列から一文字切り出します。
                        '切り出したら切り出し位置を１つ進めておきます。
                        Dim strSubWord As String = strSRC.Substring(intStrPosition, 1)
                        intStrPosition += 1

                        '切り出した文字の後ろにもまだ文字がある場合はその文字も取得しておきます。
                        Dim strSubWordNext As String = String.Empty
                        If intStrPosition < intStrLength - 1 Then
                            strSubWordNext = strSRC.Substring(intStrPosition, 1)
                        End If

                        Select Case strSubWord
                            Case """"
                                If strSubWordNext.Equals("""") Then
                                    'ダブルクォーテーションの後ろもダブルクォーテーションだった場合は
                                    'ダブルクォーテーションをひとつだけ編集文字列に加えます。
                                    stbSubItem.Append(strSubWord)
                                    intStrPosition += 1
                                Else
                                    'ダブルクォーテーションの後ろがダブルクォーテーション以外の場合は
                                    '切り出しを完了します。（ループを抜け出します）
                                    Exit Do
                                End If
                            Case Else
                                'ダブルクォーテーション以外の文字の場合は編集文字列に加えます。
                                stbSubItem.Append(strSubWord)
                        End Select
                    Loop
                    '編集した文字列（ダブルクォーテーションの内側の文字列）を現在の編集項目の後ろに追加します。
                    stbItem.Append(stbSubItem.ToString)

                Case Else
                    'カンマ、ダブルクォーテーション以外の文字の場合は編集項目の後ろにそのまま追加します。
                    stbItem.Append(strWord)

            End Select
        Loop

        '一次格納領域の内容をString配列に転送してそれを返します。
        Dim strSplit(arySplit.Count - 1) As String
        For intLoop As Integer = 0 To arySplit.Count - 1 Step 1
            strSplit(intLoop) = arySplit(intLoop)
        Next

        Return strSplit
    End Function
#End Region

End Module
