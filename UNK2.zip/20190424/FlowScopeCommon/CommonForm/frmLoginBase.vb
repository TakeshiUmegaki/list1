﻿Imports System
Imports System.Text
Imports System.Windows
Imports System.Windows.Forms
Imports CommonSystem
Imports System.Security.Cryptography

''' <summary>
''' 共通ログイン画面
''' </summary>
''' <remarks></remarks>
Public Class frmLoginBase

    ''' <summary>
    ''' DB接続情報
    ''' </summary>
    ''' <remarks></remarks>
    Public Shared comDB As CommonDB

    ''' <summary>
    ''' 外部定義情報
    ''' </summary>
    ''' <remarks></remarks>
    Public Shared mdicConfig As Dictionary(Of String, String)


#Region "ログインボタン処理"
    ''' <summary>
    ''' ログインボタン処理
    ''' </summary>
    ''' <param name="sender">イベント発生元オブジェクト</param>
    ''' <param name="e">イベントパラメータ</param>
    ''' <remarks>ログインボタンがクリックされたときの処理です。</remarks>
    Private Sub btnLogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLogin.Click
        Try
            ' ユーザマスタから指定されたユーザＩＤ＋パスワードのデータを取得します。
            Dim stbSQL As New StringBuilder(String.Empty)
            stbSQL.AppendLine("SELECT")
            stbSQL.AppendLine("    USER_NAME")
            stbSQL.AppendLine("   ,ROLL_CD")
            stbSQL.AppendLine("FROM")
            stbSQL.AppendLine("    M_CM_USER")
            stbSQL.AppendLine("WHERE")
            stbSQL.AppendLine("    USER_ID    = '%USERID%'")
            stbSQL.AppendLine("    AND")
            stbSQL.AppendLine("    PASSWORD   = '%PASSWD%'")
            stbSQL.AppendLine("    AND")
            stbSQL.AppendLine("    DELETE_FLG = '0'")
            stbSQL.Replace("%USERID%", Me.txtUserID.Text.Trim)
            stbSQL.Replace("%PASSWD%", GetHashedString(Me.txtPassword.Text.Trim))

            Dim dt As DataTable = comDB.DB_ExecuteQuery(stbSQL.ToString)

            ' 取得できなかった場合はエラーとします。
            If dt Is Nothing OrElse dt.Rows.Count = 0 Then

                ' ログイン失敗回数の制御を行う
                Dim failLoginDt As DataTable = Me.GetFaildLogin()
                If Not failLoginDt Is Nothing And 0 < failLoginDt.Rows.Count Then
                    Dim count As Integer = Convert.ToInt32(failLoginDt.Rows(0).Item("FAIL_LOGIN_COUNT")) + 1
                    Dim rockDate As DateTime = IIf(IsDBNull(failLoginDt.Rows(0).Item("ROCK_DATE")), _
                                                            0, _
                                                            failLoginDt.Rows(0).Item("ROCK_DATE"))
                    Dim now As DateTime = Convert.ToDateTime(failLoginDt.Rows(0).Item("NOW"))

                    If now < rockDate Then
                        MessageBox.Show("ログインユーザはロックされています。", _
                                        "ログインエラー", _
                                        MessageBoxButtons.OK, _
                                        MessageBoxIcon.Exclamation)
                        Return
                    End If

                    Call UpdateFaildLogin(count)
                    If 3 <= count Then
                        MessageBox.Show("一定回数ログインに失敗したので対象のユーザはロックされます。", _
                                        "ログインエラー", _
                                        MessageBoxButtons.OK, _
                                        MessageBoxIcon.Exclamation)
                        ' カウンタは0に戻しておく
                        Call UpdateFaildLogin(0)
                        Return
                    End If
                End If

                MessageBox.Show("ユーザIDまたはパスワードが違います。", "ログインエラー", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Return
            End If

            ' ログインが成功した場合、失敗回数は0でアップデートします。
            Call UpdateFaildLogin(0)

            ' ユーザ名を取得します。
            Dim strName As String = Convert.ToString(dt.Rows(0).Item("USER_NAME"))
            ' ユーザ権限を取得します。
            Dim strRoll As String = Convert.ToString(dt.Rows(0).Item("ROLL_CD"))

            ' ログイン画面を非表示にします。
            Me.Hide()
            Application.DoEvents()

            ' ログイン処理
            Call Login(Me.txtUserID.Text.Trim, strName, strRoll)

        Catch ex As Exception
            MessageBox.Show("ログイン処理でエラーが発生しました。", "ログインエラー", MessageBoxButtons.OK, MessageBoxIcon.Error)
            ' ログにエラーメッセージとエラー内容を出力します。
            CommonLog.WriteLog("ログイン処理でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            ' 画面をクローズします。
            Me.Close()
        End Try
    End Sub


    ''' <summary>
    ''' ログイン失敗回数を更新します。
    ''' 失敗回数が一定数を超える場合、ROCK_DATEカラムにも更新します。
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetFaildLogin()
        Dim sql As New StringBuilder
        Dim dt As DataTable

        sql.AppendLine("SELECT ")
        sql.AppendLine("    FAIL_LOGIN_COUNT")
        sql.AppendLine("    , NVL2(ROCK_DATE, ROCK_DATE + 30/1440, SYSDATE - 30/1440 ) AS ROCK_DATE")
        sql.AppendLine("    , SYSDATE AS NOW")
        sql.AppendLine("FROM")
        sql.AppendLine("    M_CM_USER")
        sql.AppendLine("WHERE")
        sql.AppendLine("    USER_ID = '%USER_ID%'")
        sql.Replace("%USER_ID%", Me.txtUserID.Text)

        dt = comDB.DB_ExecuteQuery(sql.ToString)

        Return dt
    End Function

    ''' <summary>
    ''' ログイン失敗回数を更新します。
    ''' 失敗回数が一定数を超える場合、ROCK_DATEカラムにも更新します。
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub UpdateFaildLogin(ByVal count As Integer)
        Dim sql As New StringBuilder

        sql.AppendLine("UPDATE M_CM_USER SET")
        sql.AppendLine("    FAIL_LOGIN_COUNT = %COUNT%")
        If 3 <= count Then
            sql.AppendLine("    , ROCK_DATE = SYSTIMESTAMP")
        End If
        sql.AppendLine("WHERE")
        sql.AppendLine("    USER_ID = '%USER_ID%'")
        sql.Replace("%COUNT%", count)
        sql.Replace("%USER_ID%", Me.txtUserID.Text.Trim)

        comDB.DB_ExecuteNonQuery(sql.ToString)

    End Sub

#End Region

#Region " 文字列をハッシュ化した文字列を返します "
    ''' <summary>
    ''' 文字列をハッシュ化した文字列を返します
    ''' </summary>
    ''' <param name="sourceString">元の文字列</param>
    ''' <returns>ハッシュ化された文字列</returns>
    ''' <remarks></remarks>
    Friend Shared Function GetHashedString(ByVal sourceString As String) As String

        Dim ret As String = String.Empty
        Dim sha512 As New SHA512Managed()
        Dim sourceData As Byte() = Encoding.UTF8.GetBytes(sourceString)
        Dim hashedData As Byte() = sha512.ComputeHash(sourceData)
        ret = BitConverter.ToString(hashedData).Replace("-", String.Empty).ToLower()
        Return ret

    End Function
#End Region


#Region "キャンセルボタン処理"
    ''' <summary>
    ''' キャンセルボタン処理
    ''' </summary>
    ''' <param name="sender">イベント発生元オブジェクト</param>
    ''' <param name="e">イベントパラメータ</param>
    ''' <remarks>画面を閉じます。</remarks>
    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Try
            ' 画面をクローズします。
            Me.Close()
        Catch ex As Exception
            MessageBox.Show("ログイン処理でエラーが発生しました。", "ログインエラー", MessageBoxButtons.OK, MessageBoxIcon.Error)
            ' ログにエラーメッセージとエラー内容を出力します。
            CommonLog.WriteLog("ログイン処理でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            ' 画面をクローズします。
            Me.Close()
        End Try
    End Sub
#End Region

#Region "ログイン処理（ダミー）"
    ''' <summary>
    ''' ログイン処理（ダミー）
    ''' </summary>
    ''' <remarks>ログインが正常に行われた場合の処理を継承先で
    ''' 記述するためのダミー処理です。</remarks>
    Protected Overridable Sub Login(ByVal strID As String, ByVal strName As String, ByVal strRoll As String)
    End Sub
#End Region

End Class