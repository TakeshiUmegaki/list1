'================================================================================
'�a�o�r����
'���ʃp�����[�^�N���X�FCommonSystem/CommonParam
'Rev00 2009/06/22
'================================================================================
Public Class CommonParam

    Private mstrSystemName As String = String.Empty
    Private mstrAppliName As String = String.Empty
    Private mstrCompanyCode As String = String.Empty
    Private mobjCommonXML As CommonXML
    Private mobjCommonDB As CommonDB

    Public Property SystemName() As String
        Get
            Return mstrSystemName
        End Get
        Set(ByVal value As String)
            mstrSystemName = value
        End Set
    End Property

    Public Property AppliName() As String
        Get
            Return mstrAppliName
        End Get
        Set(ByVal value As String)
            mstrAppliName = value
        End Set
    End Property

    Public Property CompanyCode() As String
        Get
            Return mstrCompanyCode
        End Get
        Set(ByVal value As String)
            mstrCompanyCode = value
        End Set
    End Property

    Public Property CommonXML() As CommonXML
        Get
            Return mobjCommonXML
        End Get
        Set(ByVal value As CommonXML)
            mobjCommonXML = value
        End Set
    End Property

    Public Property CommonDB() As CommonDB
        Get
            Return mobjCommonDB
        End Get
        Set(ByVal value As CommonDB)
            mobjCommonDB = value
        End Set
    End Property
End Class
