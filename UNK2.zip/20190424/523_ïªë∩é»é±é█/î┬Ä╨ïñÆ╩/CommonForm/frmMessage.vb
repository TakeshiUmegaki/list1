﻿Imports CommonSystem
Imports System.Windows.Forms

''' <summary>
''' 申送り入力画面
''' </summary>
''' <remarks></remarks>
Public Class frmMessage

#Region "外部変数定義"
    ''' <summary>
    ''' 申送り内容
    ''' </summary>
    ''' <remarks></remarks>
    Public Message As String
#End Region

#Region "画面ロード処理"
    ''' <summary>
    ''' 画面ロード処理
    ''' </summary>
    ''' <param name="sender">イベント発生元オブジェクト</param>
    ''' <param name="e">イベントパラメータ</param>
    ''' <remarks></remarks>
    Private Sub frmMessage_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            ' 申送り内容を初期化します。
            Message = String.Empty
            Me.txtMessage.Text = String.Empty
        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog("frmMessage_Loadでエラーが発生しました。", EventLogEntryType.Error)
            Throw ex
        End Try
    End Sub
#End Region

#Region "OKボタン処理"
    ''' <summary>
    ''' OKボタン処理
    ''' </summary>
    ''' <param name="sender">イベント発生元オブジェクト</param>
    ''' <param name="e">イベントパラメータ</param>
    ''' <remarks></remarks>
    Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
        Try
            ' 画面に入力された申送り内容を取得します。
            Dim strMes As String = Me.txtMessage.Text.Replace(vbNewLine, String.Empty).Trim
            ' 取得した申送り内容が空ならメッセージを表示して処理を終了します。
            If strMes.Length = 0 Then
                MessageBox.Show("申送り内容の入力は必須です。", "お知らせ", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Return
            End If

            ' メッセージを記憶して画面をOK状態で終了します。
            Message = Me.txtMessage.Text
            Me.DialogResult = Windows.Forms.DialogResult.OK

        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog("btnOK_Clickでエラーが発生しました。", EventLogEntryType.Error)
            Throw ex
        End Try
    End Sub
#End Region

#Region "キャンセルボタン処理"
    ''' <summary>
    ''' キャンセルボタン処理
    ''' </summary>
    ''' <param name="sender">イベント発生元オブジェクト</param>
    ''' <param name="e">イベントパラメータ</param>
    ''' <remarks></remarks>
    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Try
            ' 画面をキャンセル状態で終了します。
            Me.DialogResult = Windows.Forms.DialogResult.Cancel
        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog("btnCancel_Clickでエラーが発生しました。", EventLogEntryType.Error)
            Throw ex
        End Try
    End Sub
#End Region

End Class