﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' アセンブリに関する一般情報は以下の属性セットをとおして制御されます。 
' アセンブリに関連付けられている情報を変更するには、
' これらの属性値を変更してください。

' アセンブリ属性の値を確認します。

<Assembly: AssemblyTitle("MakeDelivery")> 
<Assembly: AssemblyDescription("協会けんぽ様用 納品データ作成")> 
<Assembly: AssemblyCompany("株式会社シャンテリー")> 
<Assembly: AssemblyProduct("MakeDelivery")> 
<Assembly: AssemblyCopyright("Copyright (C) 株式会社シャンテリー 2011")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

'このプロジェクトが COM に公開される場合、次の GUID がタイプ ライブラリの ID になります。
<Assembly: Guid("ba14a469-1fda-492e-814d-6fc72711c2c2")> 

' アセンブリのバージョン情報は、以下の 4 つの値で構成されています:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' すべての値を指定するか、下のように '*' を使ってビルドおよびリビジョン番号を 
' 既定値にすることができます:
' <Assembly: AssemblyVersion("1.0.*")> 
'**************************************************
' 機能概要　：新規作成
'<Assembly: AssemblyVersion("1.0.0.0")> 
'<Assembly: AssemblyFileVersion("1.0.0.0")> 
'**************************************************
'**************************************************
' 年月日    ：2015/02/04
' 機能概要　：本番リハーサル用
'<Assembly: AssemblyVersion("2.0.0.0")> 
'<Assembly: AssemblyFileVersion("2.0.0.0")> 
'**************************************************
' 年月日    ：2015/02/08
' 機能概要　：待ち合わせ+頭紙制御 etc
'<Assembly: AssemblyVersion("3.0.0.2")> 
'<Assembly: AssemblyFileVersion("3.0.0.2")> 
'**************************************************
' 年月日    ：2015/11/17
' 機能概要　：東西４種計８種出力件数指定/最後尾文字列置換正規表現取りやめ/速度改善
<Assembly: AssemblyVersion("3.0.0.3")> 
<Assembly: AssemblyFileVersion("3.0.0.3")> 
