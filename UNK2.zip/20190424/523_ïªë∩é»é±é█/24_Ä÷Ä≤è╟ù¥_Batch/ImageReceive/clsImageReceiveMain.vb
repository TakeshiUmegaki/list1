﻿Imports CommonSystem
Imports CommonBase
Imports System
Imports System.IO
Imports System.Text
Imports System.Web

Public Class clsImageReceiveMain
    Inherits clsBatchBase

#Region "共通変数"

    ''' <summary>
    ''' 自端末処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Shared mainProc As clsImageReceiveMain

#End Region

#Region "メイン処理[Main]"

    ''' ======================================================================
    ''' メソッド名：Main
    ''' <summary>
    ''' メイン処理
    ''' </summary>
    ''' <remarks></remarks>
    ''' ======================================================================
    Shared Function Main(ByVal CmdArgs() As String) As Integer

        mainProc = New clsImageReceiveMain

        ' 処理の戻り値を返却
        Return mainProc.Run(False)

    End Function

#End Region

#Region "バッチ処理本体"
    ''' ======================================================================
    ''' メソッド名：Execute
    ''' <summary>
    ''' バッチ処理本体
    ''' </summary>
    ''' <remarks></remarks>
    ''' ======================================================================
    Protected Overrides Sub Execute()

        Try
            ' 受信フォルダの保存先を取得
            Dim strReceiveDir As String = mdicConfig("RECEIVE_FOLDER")

            ' 解凍フォルダの一覧を取得
            Dim strUnzipDirs() As String = GetUnzipDirList(strReceiveDir)

            ' 解凍フォルダを１つずつ処理
            For Each strUnzipDir As String In strUnzipDirs

                ' 解凍フォルダのバックアップ
                Call BackupUnzipDir(strUnzipDir)

                ' バッチフォルダの一覧を取得
                Dim strBatchDirs() As String = GetBatchDirList(strUnzipDir)

                ' バッチフォルダが1つも存在しない場合はエラーとする
                If strBatchDirs.Length = 0 Then
                    CommonLog.WriteLog("受信ファイル「" & Path.GetFileName(strUnzipDir) & "」にバッチフォルダが存在しません。", EventLogEntryType.Error)
                    ' イベントログを出力します。
                    MyBase.WriteLog("イメージファイル取り込み中にエラーを検出しました。", EventLogEntryType.Error)
                End If

                ' バッチフォルダを１つずつ処理
                For Each strBatchDir As String In strBatchDirs

                    ' CSVファイルの一覧を取得
                    Dim strCsvFiles() As String = GetCsvFileList(strBatchDir)

                    ' CSVファイルを１つずつ処理
                    For Each strCsvFile As String In strCsvFiles

                        ' 圧縮ファイル(イメージファイル)の解凍
                        Dim strUserSlipKey As String = ExtractFile(strBatchDir, strCsvFile)

                        ' イメージファイルのチェック
                        Call CheckImageFile(strBatchDir, strCsvFile)

                        ' イメージファイルのコピー
                        Dim strSlipDirs() As String = CopyImage(strBatchDir, strCsvFile)

                        ' 帳票ID単位に処理
                        For Each strSlipDir As String In strSlipDirs
                            ' インタフェースファイルの作成
                            Dim strInterface As String = MakeInterface(strSlipDir, strBatchDir, strUserSlipKey)
                            ' トリガーファイルを作成します。
                            Call CreateTrigerFile(strInterface)
                        Next
                    Next
                Next

                ' 解凍フォルダの削除
                Directory.Delete(strUnzipDir, True)
            Next

        Catch ex As Exception
            MyBase.WriteLog(ex.ToString, EventLogEntryType.Error)
        Finally

        End Try

    End Sub
#End Region

#Region "受信フォルダに存在する解凍フォルダの一覧取得"
    Private Function GetUnzipDirList(ByVal strReceiveDir As String) As String()
        Try
            ' 解凍フォルダの一覧を取得
            Dim strDirs() As String = Directory.GetDirectories(strReceiveDir)

            Dim lstDirs As New List(Of String)
            For Each strDir As String In strDirs
                ' フォルダ名が14桁以外のもの以外は処理対象外とする
                If Not Path.GetFileName(strDir).Length = 14 Then
                    Continue For
                End If
                ' フォルダ内に制御ファイルが存在しないもは処理対象外とする
                Dim strCtrlFile As String = Path.Combine(strDir, mdicConfig("CONTROL_FILE"))
                If Not File.Exists(strCtrlFile) Then
                    Continue For
                End If
                ' リストに登録
                lstDirs.Add(strDir.Substring(0))
            Next

            Return lstDirs.ToArray

        Catch ex As Exception
            CommonLog.WriteLog("受信フォルダの一覧が取得出来ません。", EventLogEntryType.Error)
            Throw ex
        End Try
    End Function
#End Region

#Region "バッチフォルダに存在するCSVファイルの一覧取得"
    Private Function GetCsvFileList(ByVal strBatchDir As String) As String()
        Try
            ' CSVファイルの一覧を取得
            Dim strFiles() As String = Directory.GetFiles(strBatchDir, "*.csv")

            Dim lstFiles As New List(Of String)
            For Each strFile As String In strFiles
                ' CSVファイルの中身が0件ファイルの内容であれば処理対象外とする
                Dim strLines() As String = GetLineStringArrayFromTextFile(strFile)
                Dim strItems() As String = strLines(0).Split(",")
                If strItems(0) = "none" Then
                    Continue For
                End If
                ' リストに登録
                lstFiles.Add(strFile.Substring(0))
            Next

            Return lstFiles.ToArray

        Catch ex As Exception
            CommonLog.WriteLog("CSVファイルの一覧が取得出来ません。", EventLogEntryType.Error)
            Throw ex
        End Try
    End Function
#End Region

#Region "解凍フォルダに存在するバッチフォルダの一覧取得"
    Private Function GetBatchDirList(ByVal strUnzipDir As String) As String()
        Try
            ' バッチフォルダの一覧を取得
            Dim strDirs() As String = Directory.GetDirectories(strUnzipDir)

            Dim lstDirs As New List(Of String)
            For Each strDir As String In strDirs
                ' フォルダ名が15桁以外のもの以外は処理対象外とする
                If Not Path.GetFileName(strDir).Length = 15 Then
                    Throw New Exception("解凍フォルダ「" & Path.GetFileName(strUnzipDir) & "」にフォルダ名が不正なフォルダが存在します。")
                End If
                ' リストに登録
                lstDirs.Add(strDir.Substring(0))
            Next

            Return lstDirs.ToArray

        Catch ex As Exception
            CommonLog.WriteLog("バッチフォルダの一覧が取得出来ません。", EventLogEntryType.Error)
            Throw ex
        End Try
    End Function
#End Region

#Region "解凍フォルダのバックアップ"
    Private Sub BackupUnzipDir(ByVal strUnzipDir As String)
        Try
            ' バックアップフォルダの作成
            Dim strBackupDir As String = mdicConfig("BACKUP_FOLDER")
            If Not Directory.Exists(strBackupDir) Then
                ' バックアップ先フォルダの作成
                Directory.CreateDirectory(strBackupDir)
            End If

            ' 解凍フォルダをバックアップフォルダにコピー
            Dim strDestDirName As String = Path.GetFileName(strUnzipDir)
            Dim strDestDir As String = Path.Combine(strBackupDir, Path.GetFileName(strDestDirName))
            CopyDirectory(strUnzipDir, strDestDir)

        Catch ex As Exception
            CommonLog.WriteLog("解凍フォルダのバックアップに失敗しました。", EventLogEntryType.Error)
            Throw ex
        End Try
    End Sub
#End Region

#Region "イメージファイルの解凍"
    Private Function ExtractFile(ByVal strBatchDir As String, ByVal strCsvFile As String) As String
        Try
            ' 戻り値（ユーザー側の2桁の帳票種類コード）
            Dim strUserSlipKey As String = String.Empty

            ' バッチフォルダ内のZIPファイルのパス
            'Dim strZipFileName As String = Path.GetFileNameWithoutExtension(strCsvFile) & ".zip"
            'Dim strZipFile As String = Path.Combine(strBatchDir, strzipfilename)
            'If Not File.Exists(strZipFile) Then
            '    Throw New Exception("CSVファイル「" & Path.GetFileName(strCsvFile) & "」に対応するZIPファイルが存在しません。")
            'End If

            Dim strZipFile As String = String.Empty
            Dim strZipFiles() As String = Directory.GetFiles(strBatchDir, "*.zip")
            If strZipFiles.Length = 1 Then
                strZipFile = strZipFiles(0)
            Else
                Throw New Exception("CSVファイル「" & Path.GetFileName(strCsvFile) & "」に対応するZIPファイルが存在しないか、または複数ファイル存在します。")
            End If

            ' 帳票種類コードの取得
            strUserSlipKey = Path.GetFileName(strZipFile).Substring(5, 2)

            ' 解凍プログラム実行用プロセス
            Dim clsUpload As New Process

            ' プログラム実行用環境設定を行います。
            clsUpload.StartInfo.FileName = mdicConfig("ZIP_EXE")                                        '実行ファイル名
            clsUpload.StartInfo.Arguments = mdicConfig("ZIP_PARAM").Replace("%FILE%", strZipFile)       'パラメータ
            clsUpload.StartInfo.CreateNoWindow = True                                                   'プロセスは新しいウィンドウで起動します。
            clsUpload.StartInfo.ErrorDialog = False                                                     '実行失敗時にダイアログは出しません。
            clsUpload.StartInfo.UseShellExecute = True                                                  'シェルコマンドを使用します。
            clsUpload.StartInfo.WindowStyle = ProcessWindowStyle.Hidden                                 '実行時にウィンドウを隠します。
            clsUpload.StartInfo.WorkingDirectory = strBatchDir

            ' プロセスを実行します。
            clsUpload.Start()

            ' プロセスが終了するのを無限に待ちます。
            clsUpload.WaitForExit()

            ' 終了コードを取得します。
            Dim intExit As Integer = clsUpload.ExitCode

            ' 実行後の後始末
            clsUpload.Dispose()

            Return strUserSlipKey

        Catch ex As Exception
            CommonLog.WriteLog("ZIPファイルの解凍に失敗しました。", EventLogEntryType.Error)
            Throw ex
        End Try
    End Function
#End Region

#Region "イメージファイルのチェツク"
    Private Sub CheckImageFile(ByVal strBatchDir As String, ByVal strCsvFile As String)
        Try
            ' バッチフォルダ内の解凍フォルダの存在確認
            'Dim strSubDirName As String = Path.GetFileNameWithoutExtension(strCsvFile)
            'Dim strSubDir As String = Path.Combine(strBatchDir, strSubDirName)
            'If Not Directory.Exists(strSubDir) Then
            '    Throw New Exception("CSVファイル「" & Path.GetFileName(strCsvFile) & "」に該当する解凍フォルダが存在しません。")
            'End If

            Dim strSubDirName As String = String.Empty
            Dim strSubDir As String = String.Empty
            Dim strSubDirs() As String = Directory.GetDirectories(strBatchDir)
            If strSubDirs.Length = 1 Then
                strSubDir = strSubDirs(0)
                strSubDirName = Path.GetFileName(strSubDir)
            Else
                Throw New Exception("CSVファイル「" & Path.GetFileName(strCsvFile) & "」に対応する解凍フォルダが存在しないか、または複数ファイル存在します。")
            End If

            ' 解凍フォルダ内のイメージフォルダの存在確認
            Dim strImageDirs() As String = Directory.GetDirectories(strSubDir)
            If strImageDirs.Length = 0 Then
                Throw New Exception("解凍フォルダ「" & strSubDirName & "」にイメージフォルダが存在しません。")
            End If

            ' CSVファイルを配列に読み込む
            Dim strCsvFileLines() As String = GetLineStringArrayFromTextFile(strCsvFile, Encoding.Default)
            Dim htCsvFile As New Hashtable
            For Each line As String In strCsvFileLines
                Dim items() As String = line.Split(",")
                htCsvFile.Add(items(0), "1")
            Next

            ' イメージファイルの一覧を取得する
            Dim strImageFiles() As String = Directory.GetFiles(strSubDir, "*.jpg", SearchOption.AllDirectories)
            If strImageFiles.Length = 0 Then
                Throw New Exception("解凍フォルダ「" & strSubDirName & "」にイメージファイルが存在しません。")
            End If

            Dim htImageFile As New Hashtable
            For Each file As String In strImageFiles
                htImageFile.Add(Path.GetFileName(file), "1")
            Next

            ' CSVファイルの行数とイメージファイル数の確認
            If Not strCsvFileLines.Length = strImageFiles.Length Then
                Throw New Exception("解凍フォルダ「" & strSubDirName & "」のイメージファイル数とCSVファイル行数が一致していません。")
            End If

            ' イメージファイル名がCSVファイル内に存在するかどうかの確認
            For Each item As DictionaryEntry In htImageFile
                If htCsvFile(item.Key) = Not Nothing Then
                    Throw New Exception("解凍フォルダ「" & strSubDirName & "」のCSVファイルとイメージファイルの整合が取れていません。ファイル名「" & item.Key & "」")
                End If
            Next

            ' CSVファイル内のイメージファイル名がイメージファイルとして実在するかどうかの確認
            For Each item As DictionaryEntry In htCsvFile
                If htImageFile(item.Key) = Nothing Then
                    Throw New Exception("解凍フォルダ「" & strSubDirName & "」のCSVファイルとイメージファイルの整合が取れていません。ファイル名「" & item.Key & "」")
                End If
            Next

        Catch ex As Exception
            CommonLog.WriteLog("イメージファイルのチェツク時に不正なファイルを検知しました。", EventLogEntryType.Error)
            Throw ex
        End Try
    End Sub
#End Region

#Region "イメージファイルのコピー"
    Private Function CopyImage(ByVal strBatchDir As String, ByVal strCsvFile As String) As String()
        Try
            ' 戻り値（イメージコピー後の帳票IDフォルダのリスト）
            Dim lstSlipDirs As New List(Of String)

            ' イメージファイルのコピー先の日付フォルダの作成
            Dim strImageDateDir As String = Path.Combine(mdicConfig("IMAGE_FOLDER"), DateTime.Now.ToString("yyyyMMdd"))
            If Not Directory.Exists(strImageDateDir) Then
                Directory.CreateDirectory(strImageDateDir)
            End If

            ' イメージファイルのコピー先フォルダの作成
            Dim strImageDirName As String = Path.GetFileName(strBatchDir)
            Dim strImageDir As String = Path.Combine(strImageDateDir, strImageDirName)

            ' イメージをコピーする
            'Dim strSubDirName As String = Path.GetFileNameWithoutExtension(strCsvFile)
            'Dim strSubDir As String = Path.Combine(strBatchDir, strSubDirName)
            'If Not Directory.Exists(strSubDir) Then
            '    Throw New Exception("CSVファイル「" & Path.GetFileName(strCsvFile) & "」に該当する解凍フォルダが存在しません。")
            'End If

            Dim strSubDirName As String = String.Empty
            Dim strSubDir As String = String.Empty
            Dim strSubDirs() As String = Directory.GetDirectories(strBatchDir)
            If strSubDirs.Length = 1 Then
                strSubDir = strSubDirs(0)
                strSubDirName = Path.GetFileName(strSubDir)
            Else
                Throw New Exception("CSVファイル「" & Path.GetFileName(strCsvFile) & "」に対応する解凍フォルダが存在しないか、または複数ファイル存在します。")
            End If


            Dim strDestDir As String = Path.Combine(strImageDir, Path.GetFileName(strSubDir))
            CopyDirectory(strSubDir, strDestDir)

            ' イメージを帳票ID単位に仕分けする
            Dim strDestSubDir() As String = Directory.GetDirectories(strDestDir)
            For i As Int32 = 0 To strDestSubDir.Length - 1
                Dim strImageFiles() As String = Directory.GetFiles(strDestSubDir(i), "*.jpg")
                For j As Int32 = 0 To strImageFiles.Length - 1
                    Dim strImageFileName As String = Path.GetFileName(strImageFiles(j))
                    Dim strImageFileNameParts() As String = strImageFileName.Split("-")
                    Dim strSlipID As String = String.Empty
                    If strImageFileNameParts.Length = 6 Then
                        strSlipID = strImageFileNameParts(3) & "000"
                    Else
                        Throw New Exception("バッチフォルダ「" & Path.GetFileName(strBatchDir) & "」にイメージファイル名が不正なファイルが存在します。ファイル名「" & strImageFileName & "」")
                    End If

                    Dim strSlipDir As String = Path.Combine(strImageDir, strSlipID)
                    If Not Directory.Exists(strSlipDir) Then
                        Directory.CreateDirectory(strSlipDir)
                        lstSlipDirs.Add(strSlipDir.Substring(0))
                    End If

                    Dim strSlipDirImage As String = Path.Combine(strSlipDir, strImageFileName)
                    File.Copy(strImageFiles(j), strSlipDirImage)
                    File.Delete(strImageFiles(j))

                Next j

            Next i

            Directory.Delete(strDestDir, True)

            Return lstSlipDirs.ToArray

        Catch ex As Exception
            CommonLog.WriteLog("イメージファイルのコピーに失敗しました。", EventLogEntryType.Error)
            Throw ex
        End Try
    End Function
#End Region

#Region "インタフェースファイルの作成"
    Private Function MakeInterface(ByVal strSlipDir As String, ByVal strBatchDir As String, ByVal strUserSlipKey As String) As String
        Try
            ' 戻り値（インタフェースファイル作成先フォルダ）
            Dim strIFDir As String = String.Empty

            ' インタフェースファイルを作成するためのフォルダを作成します。
            Dim intRetry As Integer = Convert.ToInt32(mdicConfig("BACKUP_RETRY"))
            Dim intCount As Integer = 0
            Do
                strIFDir = Path.Combine(mdicConfig("RECEIPT_FOLDER"), DateTime.Now.ToString("yyyyMMddHHmmss"))
                If Not Directory.Exists(strIFDir) Then
                    ' 現在存在しないフォルダなら作成する。
                    Directory.CreateDirectory(strIFDir)
                    Exit Do
                End If
                If intCount > intRetry Then
                    ' 外部定義で指定された回数だけリトライしてもフォルダが作成できない場合はエラー
                    Throw New Exception("インタフェースファイル作成先フォルダが作成出来ません。")
                End If
                ' リトライ回数をカウントアップして１秒待機
                intCount += 1
                System.Threading.Thread.Sleep(1000)
            Loop

            ' 現在のシステム日時を取得します。
            Dim datSendDate As Date = DateTime.Now

            Dim sbRequestRecord As New StringBuilder

            ' ヘッダーレコード作成
            sbRequestRecord.Append(getHeaderRecord(datSendDate, strBatchDir))

            ' 明細行作成
            Dim intRecordCount As Integer = 0

            ' フォルダ名から帳票IDを取得する
            Dim strSlipID As String = Path.GetFileName(strSlipDir)
            ' フォルダの下にあるJPGファイルの一覧を取得する
            Dim strImageFiles() As String = Directory.GetFiles(strSlipDir, "*.jpg")
            ' イメージファイルを１件ずつインタフェースファイルに出力します
            For Each strImageFile As String In strImageFiles
                ' 明細行作成
                sbRequestRecord.Append(getDetailRecord(datSendDate, strSlipID, strImageFile, intRecordCount + 1, strUserSlipKey))
                intRecordCount += 1
            Next

            ' フッター行作成
            sbRequestRecord.Append(getFotterRecord(intRecordCount, datSendDate))

            ' ファイル作成
            Using sw As New StreamWriter(Path.Combine(strIFDir, clsConst.CNST_DOWNLOAD_FILE), False, Encoding.GetEncoding(clsConst.CNST_ENCODING_SHIFT_JIS))
                ' 書き込み処理
                sw.Write(sbRequestRecord.ToString)
            End Using

            Return strIFDir

        Catch ex As Exception
            CommonLog.WriteLog("インタフェースファイルの作成に失敗しました。", EventLogEntryType.Error)
            Throw ex
        End Try
    End Function
#End Region

#Region "ヘッダーレコード作成[getHeaderRecord]"
    ''' ======================================================================
    ''' メソッド名：getHeaderRecord
    ''' <summary>
    ''' ヘッダーレコード作成
    ''' </summary>
    ''' <param name="datSendDate">システム日付</param>
    ''' <returns>作成したヘッダレコード</returns>
    ''' <remarks>エントリ依頼ファイルのヘッダレコード（レコード種別１～４）を作成します。</remarks>
    ''' ======================================================================
    Private Function getHeaderRecord(ByVal datSendDate As Date, ByVal strBatchDir As String) As String

        Dim sbRet As New StringBuilder

        ' レコード種別
        sbRet.Append("1")
        sbRet.Append(",")
        ' 予備
        sbRet.Append("")
        sbRet.Append(",")
        ' 予備
        sbRet.Append("")
        sbRet.Append(",")
        ' 送信日時
        sbRet.Append(datSendDate.ToString("yyyyMMdd HHmmss"))
        sbRet.Append(",")
        ' ファイルID
        sbRet.Append(mdicConfig("FILE_ID"))
        sbRet.AppendLine("")

        ' レコード種別
        sbRet.Append("2")
        sbRet.Append(",")
        ' 優先度フラグ
        sbRet.Append(mdicConfig("PRIORITY"))
        sbRet.Append(",")
        ' 処理日時
        sbRet.Append(datSendDate.ToString("yyyyMMdd"))
        sbRet.Append(",")

        ' 連係情報０１ 受信ファイル名
        sbRet.Append(Path.GetFileName(Path.GetFileName(strBatchDir)))
        sbRet.Append(",")
        ' 連携情報０２ 受信日
        sbRet.Append(datSendDate.ToString("HHmmss"))
        sbRet.Append(",")
        ' 連係情報０３
        sbRet.Append("")
        sbRet.Append(",")
        ' 連係情報０４
        sbRet.Append("")
        sbRet.Append(",")
        ' 連係情報０５
        sbRet.Append("")
        sbRet.Append(",")
        ' 連係情報０６
        sbRet.Append("")
        sbRet.Append(",")
        ' 連係情報０７
        sbRet.Append("")
        sbRet.Append(",")
        ' 連係情報０８
        sbRet.Append("")
        sbRet.Append(",")
        ' 連係情報０９
        sbRet.Append("")
        sbRet.Append(",")
        ' 連係情報１０
        sbRet.Append("")
        sbRet.AppendLine("")

        ' レコード種別
        sbRet.Append("4")
        sbRet.Append(",")
        ' 予備
        sbRet.Append("")
        sbRet.Append(",")
        ' 予備
        sbRet.Append("")
        sbRet.Append(",")
        ' 予備
        sbRet.Append("")
        sbRet.AppendLine("")

        Return sbRet.ToString

    End Function
#End Region

#Region "明細レコード作成[getDetailRecord]"
    ''' ======================================================================
    ''' メソッド名：getDetailRecord
    ''' <summary>
    ''' 明細レコード作成
    ''' </summary>
    ''' <returns>作成した明細レコード</returns>
    ''' <remarks></remarks>
    ''' ======================================================================
    Private Function getDetailRecord(ByVal datSendDate As Date, ByVal strSlipID As String, ByVal strImageFile As String, ByVal intSeq As Integer, ByVal strUserSlipKey As String) As String

        Dim sbRet As New StringBuilder

        ' イメージファイル名
        Dim strImageFileName As String = Path.GetFileNameWithoutExtension(strImageFile)

        ' 案件番号
        Dim strSubjectNo As String = strImageFileName.Substring(0, 23)
        ' イメージ番号
        Dim strImageNo As String = strImageFileName.Substring(0, 26)

        ' レコード種別
        sbRet.Append("5")
        sbRet.Append(",")
        ' 通し番号
        sbRet.Append(String.Format("{0:D9}", intSeq))
        sbRet.Append(",")
        ' 受付番号
        sbRet.Append(strImageNo)
        sbRet.Append(",")
        ' イメージファイルパス
        sbRet.Append(strImageFile.Trim)
        sbRet.Append(",")
        ' 業務日付
        sbRet.Append(datSendDate.ToString("yyyyMMdd"))
        sbRet.Append(",")
        ' 書類コード
        sbRet.Append(strSlipID)
        sbRet.Append(",")
        ' 用紙コード
        sbRet.Append("01")
        sbRet.Append(",")
        ' 案件ID
        sbRet.Append(strSubjectNo)
        sbRet.Append(",")

        ' 連係情報１
        sbRet.Append(strUserSlipKey)
        sbRet.Append(",")
        ' 連携情報２
        sbRet.Append("")
        sbRet.Append(",")
        ' 連係情報３
        sbRet.Append("")
        sbRet.Append(",")
        ' 連係情報４
        sbRet.Append("")
        sbRet.Append(",")
        ' 連係情報５
        sbRet.Append("")
        sbRet.Append(",")
        ' 連係情報６
        sbRet.Append("")
        sbRet.Append(",")
        ' 連係情報７
        sbRet.Append("")
        sbRet.Append(",")
        ' 連係情報８
        sbRet.Append("")
        sbRet.Append(",")
        ' 連係情報９
        sbRet.Append("")
        sbRet.Append(",")
        ' 連係情報１０
        sbRet.Append("")
        sbRet.Append(",")

        ' 連係情報１１
        sbRet.Append("")
        sbRet.Append(",")
        ' 連携情報１２
        sbRet.Append("")
        sbRet.Append(",")
        ' 連係情報１３
        sbRet.Append("")
        sbRet.Append(",")
        ' 連係情報１４
        sbRet.Append("")
        sbRet.Append(",")
        ' 連係情報１５
        sbRet.Append("")
        sbRet.Append(",")
        ' 連係情報１６
        sbRet.Append("")
        sbRet.Append(",")
        ' 連係情報１７
        sbRet.Append("")
        sbRet.Append(",")
        ' 連係情報１８
        sbRet.Append("")
        sbRet.Append(",")
        ' 連係情報１９
        sbRet.Append("")
        sbRet.Append(",")
        ' 連係情報２０
        sbRet.Append("")
        sbRet.Append(",")

        ' 連係情報２１
        sbRet.Append("")
        sbRet.Append(",")
        ' 連携情報２２
        sbRet.Append("")
        sbRet.Append(",")
        ' 連係情報２３
        sbRet.Append("")
        sbRet.Append(",")
        ' 連係情報２４
        sbRet.Append("")
        sbRet.Append(",")
        ' 連係情報２５
        sbRet.Append("")
        sbRet.Append(",")
        ' 連係情報２６
        sbRet.Append("")
        sbRet.Append(",")
        ' 連係情報２７
        sbRet.Append("")
        sbRet.Append(",")
        ' 連係情報２８
        sbRet.Append("")
        sbRet.Append(",")
        ' 連係情報２９
        sbRet.Append("")
        sbRet.Append(",")
        ' 連係情報３０
        sbRet.Append("")
        sbRet.AppendLine("")

        Return sbRet.ToString

    End Function

#End Region

#Region "フッターレコード作成[getFotterRecord]"

    ''' ======================================================================
    ''' メソッド名：getFotterRecord
    ''' <summary>
    ''' フッターレコード作成
    ''' </summary>
    ''' <remarks></remarks>
    ''' ======================================================================
    Private Function getFotterRecord(ByVal intCreateCount As Integer, ByVal datSendDate As Date) As String

        Dim sbRet As New StringBuilder

        ' レコード種別
        sbRet.Append("9")
        sbRet.Append(",")
        ' データ件数
        sbRet.Append(intCreateCount.ToString)
        sbRet.Append(",")
        ' 処理結果メッセージ(送信時のシステム日時)
        sbRet.Append(datSendDate.ToString("yyyyMMdd HHmmss"))
        sbRet.AppendLine("")

        Return sbRet.ToString

    End Function
#End Region

#Region "トリガーファイル作成[CreateTrigerFile]"
    ''' ======================================================================
    ''' メソッド名：CreateTrigerFile
    ''' <summary>
    ''' トリガーファイル作成
    ''' </summary>
    ''' <param name="strRequestDir">作成ディレクトリ</param>
    ''' <remarks></remarks>
    ''' ======================================================================
    Private Sub CreateTrigerFile(ByVal strRequestDir As String)
        Try
            Dim strTrigger As String = mdicConfig("TRIGGER_FILE")

            ' トリガーファイル作成
            Using fs As FileStream = File.Create(Path.Combine(strRequestDir, strTrigger))
                If Not (fs Is Nothing) Then
                    fs.Close()
                End If
            End Using

        Catch ex As Exception
            CommonLog.WriteLog("トリガーファイルの作成に失敗しました。", EventLogEntryType.Error)
            Throw ex
        End Try
    End Sub
#End Region

#Region "ディレクトリのコピー[CopyDirectory]"
    ''' <summary>
    ''' ディレクトリのコピー
    ''' </summary>
    ''' <param name="srcDirectory">コピー元ディレクトリ</param>
    ''' <param name="destDirectory">コピー先ディレクトリ</param>
    ''' <remarks></remarks>
    Public Sub CopyDirectory(ByVal srcDirectory As String, ByVal destDirectory As String)
        Try
            'コピー先のディレクトリが存在しない場合は作成する
            If Not Directory.Exists(destDirectory) Then
                Directory.CreateDirectory(destDirectory)
                '属性もコピー
                File.SetAttributes(destDirectory, File.GetAttributes(srcDirectory))
            End If

            'コピー先のディレクトリ名の末尾に"\"をつける
            If destDirectory.Chars((destDirectory.Length - 1)) <> Path.DirectorySeparatorChar Then
                destDirectory = destDirectory + Path.DirectorySeparatorChar
            End If

            'コピー元のディレクトリにあるファイルをコピー
            Dim fs As String() = Directory.GetFiles(srcDirectory)
            Dim f As String
            For Each f In fs
                File.Copy(f, destDirectory + Path.GetFileName(f), True)
            Next

            'コピー元のディレクトリにあるディレクトリをコピー
            Dim dirs As String() = Directory.GetDirectories(srcDirectory)
            Dim dir As String
            For Each dir In dirs
                CopyDirectory(dir, destDirectory + Path.GetFileName(dir))
            Next
        Catch ex As Exception
            CommonLog.WriteLog("トリガーファイルの作成に失敗しました。", EventLogEntryType.Error)
            Throw ex
        End Try
    End Sub

#End Region

#Region "テキストファイルを文字列配列に読み込む[GetLineStringArrayFromTextFile]"
    ''' <summary>
    ''' 指定したテキストファイルを行単位で区切り、その各行を文字列配列として返す
    ''' </summary>
    ''' <param name="srcTextFile">テキストファイルのパス</param>
    ''' <param name="srcEncoding">エンコード</param>
    ''' <remarks></remarks>
    Public Shared Function GetLineStringArrayFromTextFile(ByVal srcTextFile As String, ByVal srcEncoding As System.Text.Encoding) As String()

        Dim LineAry As New ArrayList

        Try
            If srcTextFile = String.Empty Then
                Throw New Exception("SourceFile Is Not Specify")
            End If

            If Not System.IO.File.Exists(srcTextFile) Then
                Throw New Exception("SourceFile Is Not Found")
            End If

            Dim srFile As System.IO.StreamReader = Nothing
            Try
                srFile = New System.IO.StreamReader(srcTextFile, srcEncoding)
                Dim lineString As String
                While srFile.Peek() > -1
                    lineString = srFile.ReadLine
                    LineAry.Add(lineString)
                End While
            Catch ex As Exception
                Throw ex
            Finally
                srFile.Close()
            End Try

        Catch ex As Exception
            CommonLog.WriteLog("CSVファイルの読み込みに失敗しました。", EventLogEntryType.Error)
            Throw ex
            LineAry.Clear()

        End Try

        Return DirectCast(LineAry.ToArray(GetType(String)), String())

    End Function

    '上記メソッドのオーバーロード（文字コードはデフォルトでShift-JIS）
    Public Shared Function GetLineStringArrayFromTextFile(ByVal srcTextFile As String) As String()
        Return GetLineStringArrayFromTextFile(srcTextFile, System.Text.Encoding.Default)
    End Function
#End Region

End Class
