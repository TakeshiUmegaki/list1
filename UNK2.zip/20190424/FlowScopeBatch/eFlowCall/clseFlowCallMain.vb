﻿Imports CommonSystem
Imports CommonBase
Imports System
Imports System.IO
Imports System.Text

Public Class clseFlowCallMain
    Inherits clsBatchBase

#Region "共通変数"

    ''' <summary>
    ''' 自端末処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Shared mainProc As clseFlowCallMain

#End Region

#Region "内部変数定義"

    ''' <summary>
    ''' 正常ステータス辞書
    ''' </summary>
    ''' <remarks></remarks>
    Private mdicOutputSttaus As New Dictionary(Of String, String)

    ''' <summary>
    ''' 処理中ステータス辞書
    ''' </summary>
    ''' <remarks></remarks>
    Private mdicProcessSttaus As New Dictionary(Of String, String)

    ''' <summary>
    ''' エラーステータス辞書
    ''' </summary>
    ''' <remarks></remarks>
    Private mdicErrorSttaus As New Dictionary(Of String, String)

    ''' <summary>
    ''' 処理日時
    ''' </summary>
    ''' <remarks></remarks>
    Private mstrDate As String = String.Empty

#End Region

#Region "メイン処理[Main]"

    ''' ======================================================================
    ''' メソッド名：Main
    ''' <summary>
    ''' メイン処理
    ''' </summary>
    ''' <remarks></remarks>
    ''' ======================================================================
    Shared Function Main(ByVal CmdArgs() As String) As Integer

        mainProc = New clseFlowCallMain

        ' 処理の戻り値を返却
        Return mainProc.Run()

    End Function

#End Region

#Region "バッチ処理本体"
    ''' ======================================================================
    ''' メソッド名：Execute
    ''' <summary>
    ''' バッチ処理本体
    ''' </summary>
    ''' <remarks></remarks>
    ''' ======================================================================
    Protected Overrides Sub Execute()
        Try
            ' ステータス辞書の作成を行います。
            Call MakeStatusDictionary()

            Dim lstSec As New List(Of String)
            For Each s As String In mdicConfig("SEC_NAME").Split(",")
                lstSec.Add(s)
            Next

            '20180703 KRA ADD
            Dim lstSlipEnt As New List(Of String)
            For Each s As String In mdicConfig("SLIP_ENT").Split(",")
                lstSlipEnt.Add(s)
            Next

            ' 処理対象データを取得します。
            Dim dtbImage As DataTable = GetData()
            If dtbImage Is Nothing OrElse dtbImage.Rows.Count = 0 Then
                Return
            End If

            ' 処理対象データを依頼上限数単位で分割します。
            Dim intReqCount As Integer = Convert.ToInt32(mdicConfig("REQUEST_COUNT"))
            Dim lstImage As New List(Of DataRow())
            For i As Integer = 0 To dtbImage.Rows.Count - 1 Step intReqCount
                Dim lst As New List(Of DataRow)
                For j As Integer = i To i + intReqCount - 1 Step 1
                    If j = dtbImage.Rows.Count Then
                        Exit For
                    End If
                    lst.Add(dtbImage.Rows(j))
                Next
                lstImage.Add(lst.ToArray)
            Next


            ' SQL禁則文字を取得します
            Dim chrKinsoku() As Char = mdicConfig("SQL_KINSOKU").ToCharArray


            For Each img() As DataRow In lstImage

                ' イメージファイル名辞書を初期化します。
                Dim dicImageID As New Dictionary(Of String, String)
                Dim dicSlipID As New Dictionary(Of String, String)

                Dim strResultPath As String = String.Empty
                Do
                    mstrDate = DateTime.Now.ToString("yyyyMMddHHmmss")
                    strResultPath = Path.Combine(mdicConfig("eFlow_RESULT_PATH"), mstrDate)
                    If Not Directory.Exists(strResultPath) Then
                        Directory.CreateDirectory(strResultPath)
                        Exit Do
                    End If
                    Threading.Thread.Sleep(1000)
                Loop

                Dim strImageFile As String = Path.Combine(strResultPath, mdicConfig("eFlow_TEXT_FILE"))
                Dim dicStatus As New Dictionary(Of String, String)
                Dim lstImageFile As New List(Of String)

                ' DBトランザクションを開始します。
                mobjCommonDB.DB_Transaction()
                Try
                    For Each dr As DataRow In img
                        ' 帳票IDを取得します。
                        Dim strSlipID As String = Convert.ToString(dr.Item("SLIP_DEFINE_ID"))
                        ' イメージIDを取得します。
                        Dim strImageID As String = Convert.ToString(dr.Item("IMAGE_ID"))
                        ' イメージ状態を取得します。
                        Dim strInputStatus As String = Convert.ToString(dr.Item("IMAGE_STATUS"))

                        ' 帳票IDを記憶します
                        dicSlipID.Add(strImageID.PadLeft(15, "0"c), strSlipID)

                        ' イメージ状態を記憶します。
                        dicStatus.Add(strImageID.PadLeft(15, "0"c), strInputStatus)

                        ' 元イメージパスを取得します。
                        Dim strNameCol As String = mdicConfig("IMAGE_NAME_COLUMN")
                        Dim strPathCol As String = mdicConfig("IMAGE_PATH_COLUMN")

                        ' イメージID辞書に追加します。
                        Dim strFile As String = Path.GetFileNameWithoutExtension(Convert.ToString(dr.Item(strNameCol)).Trim)
                        dicImageID.Add(strFile, strImageID.PadLeft(15, "0"c))

                        Dim strSrcName As String = Convert.ToString(dr.Item(strNameCol)).Trim
                        Dim strSrcPath As String = Convert.ToString(dr.Item(strPathCol)).Trim
                        Dim strSrc As String = Path.Combine(strSrcPath, strSrcName)
                        If mdicConfig("CHANGE_EXTN").Length > 0 Then
                            Dim strExtn() As String = Split(mdicConfig("CHANGE_EXTN"), "|")
                            If strSrc.EndsWith(strExtn(0)) Then
                                strSrc = Path.ChangeExtension(strSrc, strExtn(1))
                            End If
                        End If

                        lstImageFile.Add(strSrc)

                        Dim strStatus As String = mdicProcessSttaus(strInputStatus)

                        ' イメージステータスを更新します。
                        Call UpdateImageData(strImageID, strStatus)
                        ' ステータス履歴を登録します。
                        Call InsertHistory(strImageID, strStatus)
                    Next

                    ' インタフェースファイルを出力します。
                    Using sw As New StreamWriter(strImageFile, False, Encoding.GetEncoding("shift-jis"))
                        For Each s As String In lstImageFile
                            sw.WriteLine(s)
                        Next
                    End Using

                    ' DBトランザクションを確定します。
                    mobjCommonDB.DB_Commit()

                Catch ex As Exception
                    ' DBトランザクションを破棄します。
                    mobjCommonDB.DB_Rollback()
                    Throw ex
                End Try

                ' eflowを実行します。
                Dim blnResult As Boolean = eFlowExec(strResultPath, strImageFile)
                Dim strOutStatus As String = String.Empty
                If Not blnResult Then
                    For Each id As String In dicStatus.Keys
                        ' 出力ステータスを取得します。
                        strOutStatus = mdicErrorSttaus(dicStatus(id))
                        ' イメージステータスを更新します。
                        Call UpdateImageData(id, strOutStatus)
                        ' ステータス履歴を登録します。
                        Call InsertHistory(id, strOutStatus)
                    Next
                    Throw New Exception("eFlowでエラーが検知されました。")
                End If

                ' DBトランザクションを開始します。
                mobjCommonDB.DB_Transaction()
                Try
                    Dim strCsvResult As String = Path.Combine(strResultPath, "OCR_RESULT")
                    Dim strCsvFiles() As String = Directory.GetFiles(strCsvResult, "*.csv")
                    For Each f As String In strCsvFiles
                        Dim strImageID As String = dicImageID(Path.GetFileNameWithoutExtension(f))
                        Dim strImgResult As String = Path.Combine(strResultPath, "OCR_IMAGE")
                        Dim strImagePath As String = Path.Combine(strImgResult, strImageID & ".tif")
                        If Not File.Exists(strImagePath) Then
                            strImagePath = String.Empty
                        End If

                        ' 出力ステータスを取得します。
                        strOutStatus = mdicOutputSttaus(dicStatus(strImageID))

                        Dim strF001 As String = String.Empty
                        Dim strSlipDiscSlipID As String = String.Empty
                        Using sr As New StreamReader(f, Encoding.GetEncoding("shift-jis"))
                            Do Until sr.EndOfStream
                                Dim strLine As String = sr.ReadLine
                                Dim strItem() As String = Split(strLine, vbTab)
                                Select Case strItem(0)
                                    Case "1"
                                        ' 帳票IDの更新します。
                                        strSlipDiscSlipID = strItem(5)
                                        Call UpdateImageDataEx(strImageID, strOutStatus, strImagePath, strItem, lstSlipEnt)
                                        ' ステータス履歴を登録します。
                                        Call InsertHistory(strImageID, strOutStatus)
                                        ' 既存のeFlow補正情報を削除します。
                                        Call DeleteEflowCorrection(strImageID)
                                        ' eFlow補正情報を登録します
                                        Call InsertEFlowCorrection(strImageID, strItem)
                                    Case "5"
                                        For i As Integer = 1 To 5 Step 1
                                            If i = 3 Then
                                                Continue For
                                            End If
                                            For Each c As Char In chrKinsoku
                                                Dim s As String = c.ToString
                                                strItem(i) = strItem(i).Replace(s, mdicConfig("SQL_KINSOKU_CHANGE"))
                                            Next
                                        Next
                                        InsertOCR(strImageID, strItem)

                                        ' ITEM_IDの編集("F"固定＋末尾3桁の連番)
                                        Dim strItemID As String = "F" & strItem(1).Substring(strItem(1).Length - 3, 3)
                                        If strItemID.Equals("F001") Then
                                            strF001 = strItem(2)
                                        End If
                                End Select
                            Loop
                        End Using

                        ' t_jj_eflow_correction テーブルに保持している帳票定義（SLIP_DISC_SLIP_ID）がconfig(SEC_NAME)で指定されている場合、
                        ' t_jj_eflow_resultテーブルに保持している「アイテムＩＤが”Ｆ001”」のＯＣＲ結果（OCR_STR）を取得し、
                        ' SLIP_DISC_SLIP_IDと、OCR_STRの帳票定義（数値６桁）を比較する。
                        ' アンマッチの場合のみ、t_jj_image テーブルの帳票定義（SLIP_DEFINE_ID）をＯＣＲ結果（OCR_STR）の内容で更新する。
                        ' ※追記：STR_OCRの先頭３桁が現時点の帳票IDの先頭3桁と一致すること
                        If mdicConfig("UPDATE_UNMATCH_SLIP_DEFINE_ID").Equals("1") Then
                            If lstSec.Contains(strSlipDiscSlipID) AndAlso _
                               strF001.StartsWith(dicSlipID(strImageID).Substring(0, 3)) Then
                                If Not strSlipDiscSlipID.Substring(1).Equals(strF001) AndAlso _
                                   strF001.Length = 6 AndAlso _
                                    IsNumeric(strF001) Then
                                    Call UpdateImageDataSlip(strImageID, strF001)
                                End If
                            End If
                        End If

                    Next

                    ' DBトランザクションを確定します。
                    mobjCommonDB.DB_Commit()

                Catch ex As Exception
                    ' DBトランザクションを破棄します。
                    mobjCommonDB.DB_Rollback()

                    ' DBトランザクションを開始します。
                    mobjCommonDB.DB_Transaction()
                    Try
                        For Each id As String In dicStatus.Keys
                            ' 出力ステータスを取得します。
                            strOutStatus = mdicErrorSttaus(dicStatus(id))
                            ' イメージステータスを更新します。
                            Call UpdateImageData(id, strOutStatus)
                            ' ステータス履歴を登録します。
                            Call InsertHistory(id, strOutStatus)
                        Next
                        ' DBトランザクションを確定します。
                        mobjCommonDB.DB_Commit()
                    Catch exOra As Exception
                        ' DBトランザクションを破棄します。
                        mobjCommonDB.DB_Rollback()
                    End Try

                    Throw ex

                End Try

                ' 後続処理を起動します。
                Call eAfterExec()

            Next

        Catch ex As Exception
            MyBase.WriteLog(ex.ToString, EventLogEntryType.Error)
        Finally
        End Try
    End Sub
#End Region

#Region "ステータス辞書の作成"
    ''' <summary>
    ''' ステータス辞書の作成
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub MakeStatusDictionary()
        Try
            Dim strIN() As String = Split(mdicConfig("INPUT_STATUS"), ",")
            Dim strOUT() As String = Split(mdicConfig("OUTPUT_STATUS"), ",")
            Dim strERR() As String = Split(mdicConfig("OUTPUT_STATUS_ERROR"), ",")
            Dim strPRC() As String = Split(mdicConfig("PROCESS_STATUS"), ",")
            For i As Integer = 0 To strIN.Count - 1 Step 1
                mdicProcessSttaus.Add(strIN(i), strPRC(i))
                mdicOutputSttaus.Add(strIN(i), strOUT(i))
                mdicErrorSttaus.Add(strIN(i), strERR(i))
            Next

        Catch ex As Exception
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            Throw ex
        End Try
    End Sub
#End Region

#Region "処理対象イメージデータ取得"
    ''' <summary>
    ''' 処理対象イメージデータ取得
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetData() As DataTable
        Dim stbSQL As New StringBuilder(String.Empty)
        Try
            ' configの入力ステータスをSQLに加えるために"'"括りのカンマ区切りに変換します。
            Dim strIN() As String = Split(mdicConfig("INPUT_STATUS"), ",")
            Dim lst As New List(Of String)
            For Each s As String In strIN
                lst.Add("'" & s & "'")
            Next
            Dim strInputStatus As String = Join(lst.ToArray, ",")

            ' T_JJ_IMAGEからイメージ状態が『イメージ変換待ち』になっているレコード
            ' を抽出します。
            ' 20180703 KRA_UPD 
            stbSQL.AppendLine("SELECT")
            stbSQL.AppendLine("    I.*")
            stbSQL.AppendLine("FROM")
            stbSQL.AppendLine("    T_JJ_IMAGE I")
            stbSQL.AppendLine("WHERE")
            stbSQL.AppendLine("    I.IMAGE_STATUS IN (%STATUS%)")
            stbSQL.AppendLine("    AND")
            stbSQL.AppendLine("    ROWNUM <= (%REQUEST_COUNT%)")
            stbSQL.AppendLine("    AND")
            stbSQL.AppendLine("    I.DELETE_FLG = '0'")
            stbSQL.AppendLine("ORDER BY")
            stbSQL.AppendLine("    I.IMAGE_ID")
            stbSQL.AppendLine("for update nowait")

            stbSQL.Replace("%STATUS%", strInputStatus)
            stbSQL.Replace("%REQUEST_COUNT%", Convert.ToInt32(mdicConfig("REQUEST_COUNT")))

            Dim dt As DataTable = mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)
            Return dt

        Catch ex As Exception
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(stbSQL.ToString, EventLogEntryType.Error)
            Throw ex
        End Try
    End Function
#End Region

#Region "T_JJ_IMAGEの更新（ステータス）"
    ''' <summary>
    ''' T_JJ_IMAGEの更新（ステータス）
    ''' </summary>
    ''' <param name="strImageID">更新対象イメージID</param>
    ''' <param name="strStatus">更新ステータス</param>
    ''' <remarks></remarks>
    Private Sub UpdateImageData(ByVal strImageID As String, ByVal strStatus As String)
        Dim stbUpdateSQL As New StringBuilder(String.Empty)
        Try
            ' T_RECEIPT_IMAGE更新用SQLを作成します。
            stbUpdateSQL.AppendLine("UPDATE")
            stbUpdateSQL.AppendLine("    T_JJ_IMAGE")
            stbUpdateSQL.AppendLine("SET")
            stbUpdateSQL.AppendLine("     IMAGE_STATUS             = '__IMAGE_STATUS__'")
            stbUpdateSQL.AppendLine("    ,BEFORE_IMAGE_STATUS      = IMAGE_STATUS")
            stbUpdateSQL.AppendLine("    ,UPDATE_USER              = 'ImageConvert'")
            stbUpdateSQL.AppendLine("    ,UPDATE_DATE              = SYSDATE")
            stbUpdateSQL.AppendLine("WHERE")
            stbUpdateSQL.AppendLine("    IMAGE_ID = __IMAGE_ID__")

            ' 作成したSQLの設定値の部分を実際の値に置換します。
            stbUpdateSQL.Replace("__IMAGE_STATUS__", strStatus)
            stbUpdateSQL.Replace("__IMAGE_ID__", strImageID)

            ' 作成したSQLを実行してT_RECEIPT_IMAGEを更新します。
            Dim intInsertRet As Integer = MyBase.mobjCommonDB.DB_ExecuteNonQuery(stbUpdateSQL.ToString)
            If Not intInsertRet = 1 Then
                Throw New Exception("イメージデータの更新に失敗しました。")
            End If

        Catch ex As Exception
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(stbUpdateSQL.ToString, EventLogEntryType.Error)
            Throw ex
        End Try
    End Sub
#End Region

#Region "T_JJ_IMAGEの更新（帳票ID）"
    ''' <summary>
    ''' T_JJ_IMAGEの更新（帳票ID）
    ''' </summary>
    ''' <param name="strImageID">更新対象イメージID</param>
    ''' <param name="strStatus">更新ステータス</param>
    ''' <remarks></remarks>
    Private Sub UpdateImageDataEx(ByVal strImageID As String, ByVal strStatus As String, strPath As String, strItem() As String, lstSlipEnt As List(Of String))
        Dim stbUpdateSQL As New StringBuilder(String.Empty)
        Try
            Dim strP As String = String.Empty
            Dim strN As String = String.Empty
            If strPath.Length > 0 Then
                strP = Path.GetDirectoryName(strPath)
                strN = Path.GetFileName(strPath)
            End If

            ' T_JJ_IMAGE更新用SQLを作成します。
            stbUpdateSQL.AppendLine("UPDATE")
            stbUpdateSQL.AppendLine("    T_JJ_IMAGE")
            stbUpdateSQL.AppendLine("SET")
            stbUpdateSQL.AppendLine("     IMAGE_STATUS             = '__IMAGE_STATUS__'")
            stbUpdateSQL.AppendLine("    ,BEFORE_IMAGE_STATUS      = IMAGE_STATUS")
            stbUpdateSQL.AppendLine("    ,UPDATE_USER              = 'ImageConvert'")
            stbUpdateSQL.AppendLine("    ,UPDATE_DATE              = SYSDATE")

            'stbUpdateSQL.AppendLine("    ,OCR_PROC_DATE              = '" & strItem(1) & "'")
            'stbUpdateSQL.AppendLine("    ,SLIP_DISC_SLIP_ID          = '" & strItem(5) & "'")
            'stbUpdateSQL.AppendLine("    ,SLIP_DISC_CERTAINTY_FACTOR = " & strItem(6))
            'stbUpdateSQL.AppendLine("    ,UNREAD_CHAR_FLG            = '" & strItem(7) & "'")
            'stbUpdateSQL.AppendLine("    ,IMAGE_CORRECTION_SLOPE     = " & strItem(8))
            'stbUpdateSQL.AppendLine("    ,IMAGE_CORRECTION_SCALE     = " & strItem(9))
            'stbUpdateSQL.AppendLine("    ,IMAGE_CORRECTION_SHIFT_Y   = " & strItem(10))
            'stbUpdateSQL.AppendLine("    ,IMAGE_CORRECTION_SHIFT_X   = " & strItem(11))
            'stbUpdateSQL.AppendLine("    ,SLIP_DISC_START_TIME       = '" & strItem(12) & "'")
            'stbUpdateSQL.AppendLine("    ,SLIP_DISC_END_TIME         = '" & strItem(13) & "'")
            'stbUpdateSQL.AppendLine("    ,OCR_PROC_START_TIME        = '" & strItem(14) & "'")
            'stbUpdateSQL.AppendLine("    ,OCR_PROC_END_TIME          = '" & strItem(15) & "'")
            'stbUpdateSQL.AppendLine("    ,IMAGE_FILE_NAME_EFLOW_OUT  = '" & strN & "'")
            'stbUpdateSQL.AppendLine("    ,IMAGE_FILE_PATH_EFLOW_OUT  = '" & strP & "'")

            ' 帳票IDの更新有無を取得してSQLに追加します。
            If mdicConfig("UPDATE_SLIP_DEFINE_ID") = "1" Then
                ' eFlow認識結果の帳票IDでSLIP_DEFINE_IDを更新します。(認識不可の場合は更新しない)
                If Not strItem(5) = String.Empty Then
                    '帳票認識有りの場合（定型帳票）
                    Dim streFlowSlipID As String = strItem(5).Substring(1, 6)
                    stbUpdateSQL.AppendLine("    ,SLIP_DEFINE_ID           = '" & streFlowSlipID & "'")
                    stbUpdateSQL.AppendLine("    ,BEFORE_SLIP_DEFINE_ID    = SLIP_DEFINE_ID")
                Else
                    '添付帳票の場合
                    stbUpdateSQL.AppendLine("    ,SLIP_DEFINE_ID           = SUBSTR(SLIP_DEFINE_ID,1,3) || '999'")
                    stbUpdateSQL.AppendLine("    ,BEFORE_SLIP_DEFINE_ID    = SLIP_DEFINE_ID")
                End If
            End If

            '20180703 KRA UPD
            If lstSlipEnt.Contains(strItem(5).Substring(1, 6)) Then
                stbUpdateSQL.AppendLine("    ,RJCT_RESULT_EXIT_FLG = True ")
            End If
            stbUpdateSQL.AppendLine("    ,RJCT_RECV_FLG = False ")


            stbUpdateSQL.AppendLine("WHERE")
            stbUpdateSQL.AppendLine("    IMAGE_ID = __IMAGE_ID__")

            ' 作成したSQLの設定値の部分を実際の値に置換します。
            stbUpdateSQL.Replace("__IMAGE_STATUS__", strStatus)
            stbUpdateSQL.Replace("__IMAGE_ID__", strImageID)

            ' 作成したSQLを実行してT_JJ_IMAGEを更新します。
            Dim intInsertRet As Integer = MyBase.mobjCommonDB.DB_ExecuteNonQuery(stbUpdateSQL.ToString)
            If Not intInsertRet = 1 Then
                Throw New Exception("イメージデータの更新に失敗しました。")
            End If

        Catch ex As Exception
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(stbUpdateSQL.ToString, EventLogEntryType.Error)
            Throw ex
        End Try
    End Sub
#End Region

#Region "T_JJ_IMAGE_HISTORYの登録"
    ''' <summary>
    ''' T_JJ_IMAGE_HISTORYの登録
    ''' </summary>
    ''' <param name="strImageID">対象のイメージID</param>
    ''' <param name="strStatus">更新したイメージステータス</param>
    ''' <remarks></remarks>
    Private Sub InsertHistory(ByVal strImageID As String, ByVal strStatus As String)
        Dim stbInsertSQL As New System.Text.StringBuilder(String.Empty)
        Try
            ' イメージ状態履歴登録用SQLを作成します。
            stbInsertSQL.AppendLine("INSERT INTO T_JJ_IMAGE_HISTORY (")
            stbInsertSQL.AppendLine("     IMAGE_ID")
            stbInsertSQL.AppendLine("    ,IMAGE_STATUS")
            stbInsertSQL.AppendLine("    ,CREATE_DATE")
            stbInsertSQL.AppendLine("    ,CREATE_USER")
            stbInsertSQL.AppendLine(") VALUES (")
            stbInsertSQL.AppendLine("     __IMAGE_ID__")
            stbInsertSQL.AppendLine("    ,'__IMAGE_STATUS__'")
            stbInsertSQL.AppendLine("    ,SYSTIMESTAMP")
            stbInsertSQL.AppendLine("    ,'MakeDelivery'")
            stbInsertSQL.AppendLine(")")

            stbInsertSQL.Replace("__IMAGE_ID__", strImageID)
            stbInsertSQL.Replace("__IMAGE_STATUS__", strStatus)

            ' イメージ状態履歴を登録します。
            Dim intInsertRet As Integer = MyBase.mobjCommonDB.DB_ExecuteNonQuery(stbInsertSQL.ToString)
            If Not intInsertRet = 1 Then
                Throw New Exception("イメージ履歴の登録に失敗しました。")
            End If

        Catch ex As Exception
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(stbInsertSQL.ToString, EventLogEntryType.Error)
            Throw ex
        End Try
    End Sub
#End Region

#Region "T_JJ_EFLOW_RESULTの登録"
    ''' <summary>
    ''' T_JJ_EFLOW_RESULTの登録
    ''' </summary>
    ''' <param name="strImageID">対象のイメージID</param>
    ''' <param name="strItem">更新データ</param>
    ''' <remarks></remarks>
    Private Sub InsertOCR(ByVal strImageID As String, ByVal strItem() As String)
        Dim stbInsertSQL As New System.Text.StringBuilder(String.Empty)
        Try
            Dim intPosItem As Integer = Convert.ToInt32(mdicConfig("ITEM_LENGTH"))
            Dim strPosItem As String = strItem(5)
            If strPosItem.Length > intPosItem Then
                strPosItem = mdicConfig("ITEM_OVER_TEXT")
            End If

            Dim intPosChar As Integer = Convert.ToInt32(mdicConfig("CHAR_LENGTH"))
            Dim strPosChar As String = strItem(6)
            If strPosChar.Length > intPosChar Then
                strPosChar = mdicConfig("CHAR_OVER_TEXT")
            End If

            ' ITEM_IDの編集("F"固定＋末尾3桁の連番)
            Dim strItemID As String = "F" & strItem(1).Substring(strItem(1).Length - 3, 3)

            ' OCR結果登録用SQLを作成します。
            stbInsertSQL.AppendLine("INSERT INTO T_JJ_EFLOW_RESULT (        ")
            stbInsertSQL.AppendLine("     IMAGE_ID                 ")
            stbInsertSQL.AppendLine("    ,ITEM_ID                  ")
            stbInsertSQL.AppendLine("    ,OCR_STR                  ")
            stbInsertSQL.AppendLine("    ,OCR_CERTAINTY_FACTOR_ITEM")
            stbInsertSQL.AppendLine("    ,OCR_CERTAINTY_FACTOR_CHAR")
            stbInsertSQL.AppendLine("    ,OCR_POSITION_ITEM        ")
            stbInsertSQL.AppendLine("    ,OCR_POSITION_CHAR        ")
            stbInsertSQL.AppendLine("    ,DELETE_FLG               ")
            stbInsertSQL.AppendLine("    ,CREATE_DATE              ")
            stbInsertSQL.AppendLine("    ,CREATE_USER              ")
            stbInsertSQL.AppendLine("    ,UPDATE_DATE              ")
            stbInsertSQL.AppendLine("    ,UPDATE_USER              ")
            stbInsertSQL.AppendLine(") VALUES (                    ")
            stbInsertSQL.AppendLine("     " & strImageID)
            'stbInsertSQL.AppendLine("    ,'" & strItem(1) & "'")
            stbInsertSQL.AppendLine("    ,'" & strItemID & "'")
            stbInsertSQL.AppendLine("    ,'" & strItem(2) & "'")
            stbInsertSQL.AppendLine("    ," & strItem(3))
            stbInsertSQL.AppendLine("    ,'" & strItem(4) & "'")
            stbInsertSQL.AppendLine("    ,'" & strPosItem & "'")
            stbInsertSQL.AppendLine("    ,'" & strPosChar & "'")
            stbInsertSQL.AppendLine("    ,'0'")
            stbInsertSQL.AppendLine("    ,SYSDATE")
            stbInsertSQL.AppendLine("    ,'eFlowCall'")
            stbInsertSQL.AppendLine("    ,SYSDATE")
            stbInsertSQL.AppendLine("    ,'eFlowCall'")
            stbInsertSQL.AppendLine(")")

            ' OCR結果を登録します。
            Dim intInsertRet As Integer = MyBase.mobjCommonDB.DB_ExecuteNonQuery(stbInsertSQL.ToString)
            If Not intInsertRet = 1 Then
                Throw New Exception("OCR結果の登録に失敗しました。")
            End If

        Catch ex As Exception
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(stbInsertSQL.ToString, EventLogEntryType.Error)
            Throw ex
        End Try
    End Sub
#End Region

#Region "eFlowの起動"
    Private Function eFlowExec(strResultPath As String, strImageFile As String) As Boolean
        Try
            Dim lst As New List(Of String)
            lst.Add("""" & mdicConfig("eFlow_APP_NAME") & """")
            lst.Add("""" & mdicConfig("eFlow_FLOW_ID") & """")
            lst.Add("""" & mdicConfig("eFlow_BIZZ_ID") & """")
            lst.Add("""" & "000000000000001" & """")
            lst.Add("""" & "000001" & """")
            lst.Add("""" & String.Empty & """")
            lst.Add("""" & strImageFile & """")
            lst.Add("""" & strResultPath & """")
            lst.Add("""" & mdicConfig("eFlow_IMAGE_MODE") & """")

            'ProcessStartInfoオブジェクトを作成する
            Dim psi As New System.Diagnostics.ProcessStartInfo()
            '起動する実行ファイルのパスを設定します
            psi.FileName = mdicConfig("eFlow_EXE_PATH")
            ' 実行時ディレクトリを設定します。
            psi.WorkingDirectory = Path.GetDirectoryName(mdicConfig("eFlow_EXE_PATH"))
            'コマンドライン引数を指定します
            psi.Arguments = Join(lst.ToArray, " ")
            '起動します
            Dim p As System.Diagnostics.Process = System.Diagnostics.Process.Start(psi)
            ' プロセスの終了を待ちます。
            p.WaitForExit()

            Select Case p.ExitCode
                Case 0
                    Dim strTriggerPath As String = Path.Combine(strResultPath, mdicConfig("eFlow_TRIGGER_FILE"))
                    If Not File.Exists(strTriggerPath) Then
                        CommonLog.WriteLog("eFlowの同期ファイルが見つかりませんでした。", EventLogEntryType.Error)
                        Return False
                    End If
                    Return True
                Case Else
                    CommonLog.WriteLog("eFlowは終了コード[" & p.ExitCode.ToString & "で終了しました。", EventLogEntryType.Error)
                    Return False
            End Select


        Catch ex As Exception
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            Throw ex
        End Try
    End Function
#End Region

#Region "後続処理の起動"
    Private Function eAfterExec() As Boolean
        Try
            If mdicConfig("AFTER_EXE_PATH").Length = 0 Then
                Return True
            End If

            'ProcessStartInfoオブジェクトを作成する
            Dim psi As New System.Diagnostics.ProcessStartInfo()
            '起動する実行ファイルのパスを設定します
            psi.FileName = mdicConfig("AFTER_EXE_PATH")
            'コマンドライン引数を指定します
            psi.Arguments = String.Empty
            '起動します
            Dim p As System.Diagnostics.Process = System.Diagnostics.Process.Start(psi)
            ' プロセスの終了を待ちます。
            p.WaitForExit()

            Return True

        Catch ex As Exception
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            Throw ex
        End Try
    End Function
#End Region

#Region "T_JJ_EFLOW_CORRECTIONの削除"
    ''' <summary>
    ''' T_JJ_EFLOW_CORRECTIONの削除
    ''' </summary>
    ''' <param name="strImageID">更新対象イメージID</param>
    ''' <remarks></remarks>
    Private Sub DeleteEflowCorrection(ByVal strImageID As String)
        Dim stbDeleteSQL As New StringBuilder(String.Empty)
        Try
            If mdicConfig("OUT_CORRECTION").Equals("0") Then
                Return
            End If

            stbDeleteSQL.AppendLine("DELETE FROM")
            stbDeleteSQL.AppendLine("    T_JJ_EFLOW_CORRECTION")
            stbDeleteSQL.AppendLine("WHERE")
            stbDeleteSQL.AppendLine("    IMAGE_ID = __IMAGE_ID__")

            ' 作成したSQLの設定値の部分を実際の値に置換します。
            stbDeleteSQL.Replace("__IMAGE_ID__", strImageID)

            ' 作成したSQLを実行してT_JJ_EFLOW_CORRECTIONを更新します。
            Dim intInsertRet As Integer = MyBase.mobjCommonDB.DB_ExecuteNonQuery(stbDeleteSQL.ToString)

        Catch ex As Exception
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(stbDeleteSQL.ToString, EventLogEntryType.Error)
            Throw ex
        End Try
    End Sub
#End Region

#Region "T_JJ_EFLOW_CORRECTIONの登録"
    ''' <summary>
    ''' T_JJ_EFLOW_CORRECTIONの登録
    ''' </summary>
    ''' <param name="strImageID">対象のイメージID</param>
    ''' <param name="strItem">更新データ</param>
    ''' <remarks></remarks>
    Private Sub InsertEFlowCorrection(ByVal strImageID As String, ByVal strItem() As String)
        Dim stbInsertSQL As New System.Text.StringBuilder(String.Empty)
        Try
            If mdicConfig("OUT_CORRECTION").Equals("0") Then
                Return
            End If

            ' OCR結果登録用SQLを作成します。
            stbInsertSQL.AppendLine("INSERT INTO T_JJ_EFLOW_CORRECTION (        ")
            stbInsertSQL.AppendLine("     IMAGE_ID                 ")
            stbInsertSQL.AppendLine("    ,OCR_PROC_DATE             ")
            stbInsertSQL.AppendLine("    ,SLIP_DISC_SLIP_ID         ")
            stbInsertSQL.AppendLine("    ,SLIP_DISC_CERTAINTY_FACTOR")
            stbInsertSQL.AppendLine("    ,UNREAD_CHAR_FLG           ")
            stbInsertSQL.AppendLine("    ,IMAGE_CORRECTION_SLOPE    ")
            stbInsertSQL.AppendLine("    ,IMAGE_CORRECTION_SCALE    ")
            stbInsertSQL.AppendLine("    ,IMAGE_CORRECTION_SHIFT_Y  ")
            stbInsertSQL.AppendLine("    ,IMAGE_CORRECTION_SHIFT_X  ")
            stbInsertSQL.AppendLine("    ,SLIP_DISC_START_TIME      ")
            stbInsertSQL.AppendLine("    ,SLIP_DISC_END_TIME        ")
            stbInsertSQL.AppendLine("    ,OCR_PROC_START_TIME       ")
            stbInsertSQL.AppendLine("    ,OCR_PROC_END_TIME         ")
            stbInsertSQL.AppendLine("    ,IMAGE_FILE_NAME_EFLOW_OUT ")
            stbInsertSQL.AppendLine("    ,IMAGE_FILE_PATH_EFLOW_OUT ")
            stbInsertSQL.AppendLine("    ,DELETE_FLG                ")
            stbInsertSQL.AppendLine("    ,CREATE_DATE               ")
            stbInsertSQL.AppendLine("    ,CREATE_USER               ")
            stbInsertSQL.AppendLine("    ,UPDATE_DATE               ")
            stbInsertSQL.AppendLine("    ,UPDATE_USER               ")
            stbInsertSQL.AppendLine(") VALUES (                    ")
            stbInsertSQL.AppendLine("     " & strImageID)
            stbInsertSQL.AppendLine("    ,'" & strItem(1) & "'")
            stbInsertSQL.AppendLine("    ,'" & strItem(5) & "'")
            stbInsertSQL.AppendLine("    ," & strItem(6))
            stbInsertSQL.AppendLine("    ,'" & strItem(7) & "'")
            stbInsertSQL.AppendLine("    ," & strItem(8))
            stbInsertSQL.AppendLine("    ," & strItem(9))
            stbInsertSQL.AppendLine("    ," & strItem(10))
            stbInsertSQL.AppendLine("    ," & strItem(11))
            stbInsertSQL.AppendLine("    ,'" & strItem(12) & "'")
            stbInsertSQL.AppendLine("    ,'" & strItem(13) & "'")
            stbInsertSQL.AppendLine("    ,'" & strItem(14) & "'")
            stbInsertSQL.AppendLine("    ,'" & strItem(15) & "'")
            stbInsertSQL.AppendLine("    ,NULL")
            stbInsertSQL.AppendLine("    ,NULL")
            stbInsertSQL.AppendLine("    ,'0'")
            stbInsertSQL.AppendLine("    ,SYSDATE")
            stbInsertSQL.AppendLine("    ,'eFlowCall'")
            stbInsertSQL.AppendLine("    ,SYSDATE")
            stbInsertSQL.AppendLine("    ,'eFlowCall'")
            stbInsertSQL.AppendLine(")")

            ' T_JJ_EFLOW_CORRECTIONを登録します。
            Dim intInsertRet As Integer = MyBase.mobjCommonDB.DB_ExecuteNonQuery(stbInsertSQL.ToString)
            If Not intInsertRet = 1 Then
                Throw New Exception("T_JJ_EFLOW_CORRECTIONの登録に失敗しました。")
            End If

        Catch ex As Exception
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(stbInsertSQL.ToString, EventLogEntryType.Error)
            Throw ex
        End Try
    End Sub
#End Region

#Region "T_JJ_IMAGEの更新（頭紙の再セット）"
    ''' <summary>
    ''' T_JJ_IMAGEの更新（頭紙の再セット）
    ''' </summary>
    ''' <param name="strImageID">更新対象イメージID</param>
    ''' <param name="strSlipDefineID">頭紙帳票ＩＤ</param>
    ''' <remarks></remarks>
    Private Sub UpdateImageDataSlip(ByVal strImageID As String, strSlipDefineID As String)
        Dim stbUpdateSQL As New StringBuilder(String.Empty)
        Try

            ' T_JJ_IMAGE更新用SQLを作成します。
            stbUpdateSQL.AppendLine("UPDATE")
            stbUpdateSQL.AppendLine("    T_JJ_IMAGE")
            stbUpdateSQL.AppendLine("SET")
            stbUpdateSQL.AppendLine("     SLIP_DEFINE_ID           = '" & strSlipDefineID & "'")
            stbUpdateSQL.AppendLine("    ,BEFORE_SLIP_DEFINE_ID    = SLIP_DEFINE_ID")
            stbUpdateSQL.AppendLine("WHERE")
            stbUpdateSQL.AppendLine("    IMAGE_ID = __IMAGE_ID__")

            ' 作成したSQLの設定値の部分を実際の値に置換します。
            stbUpdateSQL.Replace("__IMAGE_ID__", strImageID)

            ' 作成したSQLを実行してT_JJ_IMAGEを更新します。
            Dim intInsertRet As Integer = MyBase.mobjCommonDB.DB_ExecuteNonQuery(stbUpdateSQL.ToString)
            If Not intInsertRet = 1 Then
                Throw New Exception("イメージデータの更新に失敗しました。（帳票ID）")
            End If

        Catch ex As Exception
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(stbUpdateSQL.ToString, EventLogEntryType.Error)
            Throw ex
        End Try
    End Sub
#End Region

End Class
