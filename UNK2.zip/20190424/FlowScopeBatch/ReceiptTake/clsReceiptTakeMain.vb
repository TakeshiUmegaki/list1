﻿Imports CommonSystem
Imports CommonBase
Imports System
Imports System.IO
Imports System.Text
Imports Oracle.DataAccess.Client

Public Class clsReceiptTakeMain
    Inherits clsBatchBase

#Region "共通変数"

    ''' <summary>
    ''' 自端末処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Shared mainProc As clsReceiptTakeMain

#End Region

#Region "外部定義（コンフィグ）取得用定数"

    ' *************************************
    ' ステータス関連
    ' *************************************

    ''' <summary>
    ''' DB登録する受付ステータス
    ''' </summary>
    ''' <remarks></remarks>
    Private Const CONF_RECEIPT_SATTUS As String = "OUTPUT_RECEIPT_STATUS"

    ''' <summary>
    ''' DB登録するイメージステータス
    ''' </summary>
    ''' <remarks></remarks>
    Private Const CONF_IMAGE_STATUS As String = "OUTPUT_IMAGE_STATUS"


    ' *************************************
    ' 取得ファイル情報関連
    ' *************************************

    ''' <summary>
    ''' 結果ファイル取得先ルートフォルダ
    ''' </summary>
    ''' <remarks></remarks>
    Private Const CONF_RECEIVE_PATH As String = "RECEIVE_PATH"

    ''' <summary>
    ''' トリガーファイル名
    ''' </summary>
    ''' <remarks></remarks>
    Private Const CONF_TRIGGER_FILE As String = "TRIGGER_FILE"

    ''' <summary>
    ''' NG結果ファイル移動先ルートフォルダ
    ''' </summary>
    ''' <remarks></remarks>
    Private Const CONF_NG_PATH As String = "NG_PATH"

    ''' <summary>
    ''' OK結果ファイル移動先ルートフォルダ
    ''' </summary>
    ''' <remarks></remarks>
    Private Const CONF_OK_PATH As String = "OK_PATH"



#End Region

#Region "内部変数定義"

    ''' <summary>
    ''' 受信フォルダの名前の年月日時分秒
    ''' </summary>
    ''' <remarks></remarks>
    Private mstrFolderDateTime As String = String.Empty

#End Region




#Region "メイン処理[Main]"

    ''' ======================================================================
    ''' メソッド名：Main
    ''' <summary>
    ''' メイン処理
    ''' </summary>
    ''' <remarks></remarks>
    ''' ======================================================================
    Shared Function Main(ByVal CmdArgs() As String) As Integer

        mainProc = New clsReceiptTakeMain

        ' 処理の戻り値を返却
        Return mainProc.Run()

    End Function

#End Region

#Region "バッチ処理本体"
    ''' ======================================================================
    ''' メソッド名：Execute
    ''' <summary>
    ''' バッチ処理本体
    ''' </summary>
    ''' <remarks></remarks>
    ''' ======================================================================
    Protected Overrides Sub Execute()

        Try

            ' 外部定義（コンフィグ）から定義内容を取得します。
            Dim strNGRootFolder As String = mdicConfig(CONF_NG_PATH) 'NGフォルダ移動先ルートフォルダ
            Dim strOKRootFolder As String = mdicConfig(CONF_OK_PATH) 'OKフォルダ移動先ルートフォルダ


            ' 取得対象データの存在するフォルダのリストを取得します。
            Dim strFolders As List(Of String) = GetTargetFolders()

            ' リストにあるフォルダを一つずつ処理します。
            For Each strFolder As String In strFolders

                ' 受信した結果ファイルの格納されているフォルダ名を取得しておきます。（処理後の移動or削除のため）
                Dim strFolderName As String = Path.GetFileName(strFolder)

                ' フォルダ名の先頭１４桁（YYYYMMDDHHMMSS）を記憶します。（イメージ更新時に利用します）
                mstrFolderDateTime = strFolderName.Substring(0, 14)

                ' DBトランザクションを開始します。
                MyBase.mobjCommonDB.DB_Transaction()

                Try

                    ' *************************************************************************
                    ' イメージをDBに登録します。（戻り値は登録したイメージ数です。）
                    ' *************************************************************************
                    Dim intImageCount As Integer = Receive(strFolder)


                    If intImageCount < 0 Then

                        ' 処理対象のフォルダをNGフォルダ内に移動します。
                        Dim strNGFolder As String = Path.Combine(strNGRootFolder, strFolderName)
                        Directory.Move(strFolder, strNGFolder)

                        ' 登録イメージ数がゼロ未満ならトランザクションを巻き戻します。
                        MyBase.mobjCommonDB.DB_Rollback()

                    Else

                        If strOKRootFolder.Trim.Equals(String.Empty) Then

                            ' 外部定義（コンフィグ）にOKフォルダの移動先が定義されていない場合はOKフォルダを削除します。
                            Directory.Delete(strFolder, True)

                        Else

                            ' 処理対象のフォルダをOKフォルダ内に移動します。
                            Dim strOKFolder As String = Path.Combine(strOKRootFolder, strFolderName.Substring(0, 10))
                            If Not Directory.Exists(strOKFolder) Then
                                Directory.CreateDirectory(strOKFolder)
                            End If
                            strOKFolder = Path.Combine(strOKFolder, strFolderName)
                            Directory.Move(strFolder, strOKFolder)

                        End If

                    End If

                    ' トランザクションを完了します。
                    MyBase.mobjCommonDB.DB_Commit()

                Catch ex As Exception

                    ' トランザクションを巻き戻します。
                    MyBase.mobjCommonDB.DB_Rollback()

                    ' エラー検知時の処理対象フォルダーがまだ存在するかチェックします。
                    If Directory.Exists(strFolder) Then
                        ' 処理対象のフォルダをNGフォルダ内に移動します。
                        Dim strNgFolderName As String = Path.GetFileName(strFolder)
                        Dim strNGFolder As String = Path.Combine(strNGRootFolder, strNgFolderName)
                        Directory.Move(strFolder, strNGFolder)
                    End If

                    Throw New Exception("受信データ取込中にエラーを検出しました。")

                End Try
            Next

        Catch ex As Exception

            MyBase.WriteLog(ex.ToString, EventLogEntryType.Error)

        Finally

        End Try

    End Sub
#End Region

#Region "処理対象フォルダのリスト作成"
    ''' ======================================================================
    ''' メソッド名：GetTargetFolders
    ''' <summary>
    ''' 処理対象フォルダのリスト作成
    ''' </summary>
    ''' <returns>作成したヘ処理対象フォルダのリスト</returns>
    ''' <remarks></remarks>
    ''' ======================================================================
    Private Function GetTargetFolders() As List(Of String)

        ' 外部定義（コンフィグ）から定義内容を取得します。
        Dim strRootFolder As String = mdicConfig(CONF_RECEIVE_PATH) 'ルートフォルダ
        Dim strTrigger As String = mdicConfig(CONF_TRIGGER_FILE)    'トリガーファイルの名前

        Dim FolderList As New List(Of String)

        ' ルートフォルダの直下にあるフォルダ名を全て取得します。
        Dim strFolders() As String = Directory.GetDirectories(strRootFolder)

        ' 取得したフォルダ名を一つずつ精査します。
        For Each strFolder As String In strFolders

            ' トリガーファイルPathを作成します。
            Dim strTRG As String = Path.Combine(strFolder, strTrigger)

            ' 取得したフォルダ内にトリガーファイルが存在する場合に
            ' そのフォルダを処理対象フォルダのリストに追加します。
            If File.Exists(strTRG) Then
                FolderList.Add(strFolder)
            End If

        Next

        ' 全ての処理対象フォルダがリストに登録されたらフォルダ名で整列します。
        FolderList.Sort()

        Return FolderList

    End Function
#End Region

#Region "フォルダ単位のデータ取得"
    ''' ======================================================================
    ''' メソッド名：Receive
    ''' <summary>
    ''' フォルダ単位のデータ取得
    ''' </summary>
    ''' <param name="strFolder">処理対象フォルダ</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    ''' ======================================================================
    Private Function Receive(ByVal strFolder As String) As Integer

        Dim strDowload As String = Path.Combine(strFolder, clsConst.CNST_DOWNLOAD_FILE)
        If Not File.Exists(strDowload) Then
            Return -1
        End If

        Dim strPriority As String = String.Empty    ' 優先度
        Dim strFileDate As String = String.Empty    ' ファイル作成システム日付

        ' 新規の受付番号を取得します。
        Dim strReceiptID As String = getReceiptID()

        Dim strSlipID As String = String.Empty

        Dim intImageCount As Integer = 0
        Using sr As New StreamReader(strDowload, Encoding.GetEncoding(clsConst.CNST_ENCODING_SHIFT_JIS))

            Try

                Do While sr.Peek() >= 0

                    Dim strLine As String = sr.ReadLine()
                    Dim strItem() As String = Split(strLine, ","c)

                    'レコード種別によって処理を分岐します。
                    Select Case strItem(0)

                        Case "1", "3", "4", "9"
                            ' レコード種別が、"1", "2", "3", "4", "9"の場合は処理はありません。

                        Case "2"
                            ' ヘッダレコードからの優先度、ファイル作成日、受信ファイル名を取得します。
                            strPriority = strItem(1)    ' 優先度
                            strFileDate = strItem(2)    ' ファイル作成日

                        Case "5"    ' データレコード
                            ' 登録イメージ数を加算します。
                            intImageCount += 1

                            Dim strImagePath As String = Path.GetDirectoryName(strItem(3))
                            Dim strImageName As String = Path.GetFileNameWithoutExtension(strItem(3)).Replace(".", "_")
                            Dim strImageExtn As String = Path.GetExtension(strItem(3))
                            Dim strSrc As String = strItem(3)
                            Dim strDst As String = Path.Combine(strImagePath, strImageName & strImageExtn)
                            File.Copy(strSrc, strDst)
                            File.Delete(strSrc)
                            strItem(3) = strDst

                            ' イメージIDを取得します
                            Dim strImageID As String = getImageID()
                            ' 帳票IDがCSV出力タイプとイメージタイプとで初期登録するイメージIDを変更します。
                            Dim strImageStatus As String = mdicConfig("OUTPUT_IMAGE_STATUS")

                            ' イメージテーブルにデータを１件登録します。
                            Call InsertImage(strImageID, _
                                             strReceiptID, _
                                             strPriority, _
                                             strImageStatus, _
                                             strItem)
                            ' イメージ履歴を登録します。
                            Call InsertImageHistory(strImageID, strImageStatus)

                            ' 帳票IDを記憶します
                            strSlipID = strItem(5)

                        Case Else
                            MyBase.WriteLog("Download.txtの内容が不正です。", EventLogEntryType.Error)
                            CommonLog.WriteLog("対象ディレクトリ:" & strFolder, EventLogEntryType.Error)
                            Return -1

                    End Select

                Loop

                ' 納品サイクルマスタを検索します。
                Dim dr As DataRow = GetDeliveryInfo(strFolder, strSlipID)
                Dim intRcptCnt As Integer = Convert.ToInt32(dr.Item("RECEIPT_COUNT"))
                Dim intDays As Integer = Convert.ToInt32(dr.Item("DELIVERY_DAYS"))
                Dim strDate As String = GetDeliveryDate(strFolder, intDays) & Convert.ToString(dr.Item("DELIVERY_PLAN"))

                ' 受付テーブルを登録します。
                Call InsertReceipt(strReceiptID, intImageCount, intRcptCnt, strDate)
                ' 受付履歴をを登録します
                Call InsertReceiptHistory(strReceiptID)

            Catch ex As Exception

                MyBase.WriteLog("処理不能なエラーを検知しました。", EventLogEntryType.Error)
                CommonLog.WriteLog(ex.ToString, EventLogEntryType.Error)
                Return -1

            End Try

        End Using

        Return intImageCount

    End Function
#End Region

#Region "受付IDの作成"
    Private Function getReceiptID() As String
        ' シーケンスから新規受付IDを取得します。
        Dim dtbReceipt As DataTable = mobjCommonDB.DB_ExecuteQuery("SELECT S_JJ_RECEIPT.NEXTVAL FROM DUAL")
        If dtbReceipt Is Nothing OrElse dtbReceipt.Rows.Count <> 1 Then
            Throw New Exception("新規受付IDを生成できません。")
        End If
        Dim strReceiptNo As String = Convert.ToString(dtbReceipt.Rows(0).Item(0))
        Return strReceiptNo
    End Function
#End Region

#Region "イメージIDの作成"
    Private Function getImageID() As String
        ' シーケンスから新規イメージIDを取得します。
        Dim dtbImage As DataTable = mobjCommonDB.DB_ExecuteQuery("SELECT S_JJ_IMAGE.NEXTVAL FROM DUAL")
        If dtbImage Is Nothing OrElse dtbImage.Rows.Count <> 1 Then
            Throw New Exception("新規イメージIDを生成できません。")
        End If
        Dim strImageID As String = Convert.ToString(dtbImage.Rows(0).Item(0))
        Return strImageID
    End Function
#End Region

#Region "イメージテーブルの登録"
    Private Sub InsertImage(ByVal strImageID As String, _
                            ByVal strReceiptID As String, _
                            ByVal strPriority As String, _
                            ByVal strImageStatus As String, _
                            ByVal strItem() As String)

        ' イメージテーブル登録用のSQLを作成します。
        Dim stbSQL As New StringBuilder(String.Empty)
        stbSQL.AppendLine("INSERT INTO T_JJ_IMAGE (  ")
        stbSQL.AppendLine("     IMAGE_ID             ")
        stbSQL.AppendLine("    ,RECEIPT_ID           ")
        stbSQL.AppendLine("    ,IMAGE_STATUS         ")
        stbSQL.AppendLine("    ,IMAGE_FILE_NAME      ")
        stbSQL.AppendLine("    ,IMAGE_FILE_PATH      ")
        stbSQL.AppendLine("    ,SLIP_DEFINE_ID       ")
        stbSQL.AppendLine("    ,BUSINESS_DATE        ")
        stbSQL.AppendLine("    ,PRIORITY             ")
        stbSQL.AppendLine("    ,EXC_IMAGE_NO         ")
        stbSQL.AppendLine("    ,EXC_SUBJECT_NO       ")
        stbSQL.AppendLine("    ,DELETE_FLG           ")
        stbSQL.AppendLine("    ,CREATE_DATE          ")
        stbSQL.AppendLine("    ,CREATE_USER          ")
        stbSQL.AppendLine("    ,UPDATE_DATE          ")
        stbSQL.AppendLine("    ,UPDATE_USER          ")

        For i As Integer = 1 To 30 Step 1
            stbSQL.AppendLine("    ,EXC_IMAGE_KEY" & i.ToString("00"))
        Next

        stbSQL.AppendLine(") VALUES (                ")
        stbSQL.AppendLine("     __IMAGE_ID__         ")
        stbSQL.AppendLine("    ,__RECEIPT_ID__       ")
        stbSQL.AppendLine("    ,'__IMAGE_STATUS__'   ")
        stbSQL.AppendLine("    ,'__IMAGE_FILE_NAME__'")
        stbSQL.AppendLine("    ,'__IMAGE_FILE_PATH__'")
        stbSQL.AppendLine("    ,'__SLIP_DEFINE_ID__' ")
        stbSQL.AppendLine("    ,'__BUSINESS_DATE__'  ")
        stbSQL.AppendLine("    ,'__PRIORITY__'       ")
        stbSQL.AppendLine("    ,'__EXC_IMAGE_NO__'   ")
        stbSQL.AppendLine("    ,'__EXC_SUBJECT_NO__' ")
        stbSQL.AppendLine("    ,'0'                  ")
        stbSQL.AppendLine("    ,SYSDATE              ")
        stbSQL.AppendLine("    ,'ReceiptTake'        ")
        stbSQL.AppendLine("    ,SYSDATE              ")
        stbSQL.AppendLine("    ,'ReceiptTake'        ")

        For i As Integer = 8 To 37 Step 1
            stbSQL.AppendLine("    ,'" & strItem(i) & "'")
        Next

        stbSQL.AppendLine(")                         ")

        stbSQL.Replace("__IMAGE_ID__", strImageID)
        stbSQL.Replace("__RECEIPT_ID__", strReceiptID)
        stbSQL.Replace("__IMAGE_STATUS__", strImageStatus)
        stbSQL.Replace("__IMAGE_FILE_NAME__", Path.GetFileName(strItem(3)))
        stbSQL.Replace("__IMAGE_FILE_PATH__", Path.GetDirectoryName(strItem(3)))
        stbSQL.Replace("__SLIP_DEFINE_ID__", strItem(5))
        stbSQL.Replace("__BUSINESS_DATE__", strItem(4))
        stbSQL.Replace("__PRIORITY__", strPriority)
        stbSQL.Replace("__EXC_IMAGE_NO__", strItem(2))
        stbSQL.Replace("__EXC_SUBJECT_NO__", strItem(7))

        ' 作成したSQLを実行してイメージテーブルに１件登録します。
        Dim intRet As Integer = mobjCommonDB.DB_ExecuteNonQuery(stbSQL.ToString)

    End Sub
#End Region

#Region "イメージ履歴登録"
    Private Sub InsertImageHistory(ByVal strImageID As String, ByVal strImageStatusas As String)

        Dim stbInsertSQL As New System.Text.StringBuilder(String.Empty)

        ' イメージ状態履歴登録用SQLを作成します。
        stbInsertSQL.AppendLine("INSERT INTO T_JJ_IMAGE_HISTORY (")
        stbInsertSQL.AppendLine("     IMAGE_ID")
        stbInsertSQL.AppendLine("    ,IMAGE_STATUS")
        stbInsertSQL.AppendLine("    ,CREATE_DATE")
        stbInsertSQL.AppendLine("    ,CREATE_USER")
        stbInsertSQL.AppendLine(") VALUES (")
        stbInsertSQL.AppendLine("     :ImageID")
        stbInsertSQL.AppendLine("    ,:OutStatus")
        stbInsertSQL.AppendLine("    ,SYSTIMESTAMP")
        stbInsertSQL.AppendLine("    ,'ReceiptTake'")
        stbInsertSQL.AppendLine(")")

        ' イメージ状態履歴登録用パラメータ宣言
        Dim oraInsertParam(1) As OracleParameter
        oraInsertParam(0) = New OracleParameter("ImageID", OracleDbType.Decimal)
        oraInsertParam(0).Value = Convert.ToInt64(strImageID)
        oraInsertParam(1) = New OracleParameter("OutStatus", OracleDbType.Char)
        oraInsertParam(1).Value = strImageStatusas

        ' イメージ状態履歴を登録します。
        Dim intInsertRet As Integer = MyBase.mobjCommonDB.DB_ExecuteNonQuery(stbInsertSQL.ToString, oraInsertParam)
        If Not intInsertRet = 1 Then
            Throw New Exception("イメージ状態履歴の登録に失敗しました。")
        End If

    End Sub
#End Region

#Region "受付テーブルの登録"
    Private Sub InsertReceipt(ByVal strReceiptID As String, _
                              ByVal intImageCount As Integer, _
                              ByVal intReceiptCount As Integer, _
                              ByVal strDeliveryDate As String)

        ' 受付テーブル登録用のSQLを作成します。
        Dim stbSQL As New StringBuilder(String.Empty)
        stbSQL.AppendLine("INSERT INTO T_JJ_RECEIPT (   ")
        stbSQL.AppendLine("     RECEIPT_ID              ")
        stbSQL.AppendLine("    ,RECEIPT_STATUS          ")
        stbSQL.AppendLine("    ,IMAGE_COUNT             ")
        stbSQL.AppendLine("    ,RECEIPT_DATE            ")
        stbSQL.AppendLine("    ,RECEIPT_COUNT           ")
        stbSQL.AppendLine("    ,DELIVERY_PLAN_TIME      ")
        stbSQL.AppendLine("    ,DELETE_FLG              ")
        stbSQL.AppendLine("    ,CREATE_DATE             ")
        stbSQL.AppendLine("    ,CREATE_USER             ")
        stbSQL.AppendLine("    ,UPDATE_DATE             ")
        stbSQL.AppendLine("    ,UPDATE_USER             ")
        stbSQL.AppendLine(") VALUES (                   ")
        stbSQL.AppendLine("      __RECEIPT_ID__         ")
        stbSQL.AppendLine("    ,'__RECEIPT_STATUS__'    ")
        stbSQL.AppendLine("    , __IMAGE_COUNT__        ")
        stbSQL.AppendLine("    ,TO_DATE('__RECEIPT_DATE__', 'YYYYMMDDHH24MISS')")
        stbSQL.AppendLine("    , __RECEIPT_COUNT__      ")
        stbSQL.AppendLine("    ,'__DELIVERY_PLAN__'")
        stbSQL.AppendLine("    ,'0'                     ")
        stbSQL.AppendLine("    ,SYSDATE                 ")
        stbSQL.AppendLine("    ,'ReceiptTake'           ")
        stbSQL.AppendLine("    ,SYSDATE                 ")
        stbSQL.AppendLine("    ,'ReceiptTake'           ")
        stbSQL.AppendLine(")                            ")

        stbSQL.Replace("__RECEIPT_ID__", strReceiptID)
        stbSQL.Replace("__RECEIPT_STATUS__", mdicConfig("OUTPUT_RECEIPT_STATUS"))
        stbSQL.Replace("__IMAGE_COUNT__", intImageCount.ToString)
        stbSQL.Replace("__RECEIPT_DATE__", mstrFolderDateTime)
        stbSQL.Replace("__RECEIPT_COUNT__", intReceiptCount.ToString)
        stbSQL.Replace("__DELIVERY_PLAN__", strDeliveryDate)

        ' 作成したSQLを実行して受付テーブルに１件登録します。
        Dim intRet As Integer = mobjCommonDB.DB_ExecuteNonQuery(stbSQL.ToString)

    End Sub
#End Region

#Region "受付履歴登録"
    Private Sub InsertReceiptHistory(ByVal strReceiptID As String)

        Dim stbInsertSQL As New System.Text.StringBuilder(String.Empty)

        ' 受付状態履歴登録用SQLを作成します。
        stbInsertSQL.AppendLine("INSERT INTO T_JJ_RECEIPT_HISTORY (")
        stbInsertSQL.AppendLine("     RECEIPT_ID")
        stbInsertSQL.AppendLine("    ,RECEIPT_STATUS")
        stbInsertSQL.AppendLine("    ,CREATE_DATE")
        stbInsertSQL.AppendLine("    ,CREATE_USER")
        stbInsertSQL.AppendLine(") VALUES (")
        stbInsertSQL.AppendLine("     :ReceiptID")
        stbInsertSQL.AppendLine("    ,:OutStatus")
        stbInsertSQL.AppendLine("    ,SYSTIMESTAMP")
        stbInsertSQL.AppendLine("    ,'ReceiptTake'")
        stbInsertSQL.AppendLine(")")

        ' 受付状態履歴登録用パラメータ宣言
        Dim oraInsertParam(1) As OracleParameter
        oraInsertParam(0) = New OracleParameter("ReceiptID", OracleDbType.Decimal)
        oraInsertParam(0).Value = Convert.ToInt64(strReceiptID)
        oraInsertParam(1) = New OracleParameter("OutStatus", OracleDbType.Char)
        oraInsertParam(1).Value = mdicConfig("OUTPUT_RECEIPT_STATUS")

        ' 受付状態履歴を登録します。
        Dim intInsertRet As Integer = MyBase.mobjCommonDB.DB_ExecuteNonQuery(stbInsertSQL.ToString, oraInsertParam)
        If Not intInsertRet = 1 Then
            Throw New Exception("受付状態履歴の登録に失敗しました。")
        End If

    End Sub
#End Region

#Region ""
    Private Function GetDeliveryDate() As String
        Dim stbSQL As New StringBuilder("SELECT TO_CHAR(SYSDATE,'YYYYMMDDHH24MI') FROM DUAL")
        Dim dt As DataTable = mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)
        Dim strDate As String = Convert.ToString(dt.Rows(0).Item(0))
        Dim strYMD As String = strDate.Substring(0, 8)
        Dim strTime As String = strDate.Substring(8, 4)
        If strTime > mdicConfig("WORK_END_TIME") Then
            strTime = mdicConfig("WORK_START_TIME")
            stbSQL.Length = 0
            stbSQL.AppendLine("SELECT MIN(YYYYMMDD) FROM M_CM_HOLIDAY WHERE HOLIDAY = '0' AND YYYYMMDD > '%DATE%'")
            stbSQL.Replace("%DATE%", strYMD)
            dt = mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)
            strYMD = Convert.ToString(dt.Rows(0).Item(0))
        End If

        Dim intYea As Integer = Convert.ToInt32(strYMD.Substring(0, 4))
        Dim intMon As Integer = Convert.ToInt32(strYMD.Substring(4, 2))
        Dim intDay As Integer = Convert.ToInt32(strYMD.Substring(6, 2))
        Dim intHou As Integer = Convert.ToInt32(strTime.Substring(0, 2))
        Dim intMin As Integer = Convert.ToInt32(strTime.Substring(2, 2))

        Dim datDlvDate As New Date(intYea, intMon, intDay, intHou, intMin, 0)
        datDlvDate = datDlvDate.AddMinutes(Convert.ToDouble(mdicConfig("DELIVERY_PLAN")))

        Dim strDlvDate As String = datDlvDate.ToString("yyyyMMddHHmm")

        Return strDlvDate
    End Function
#End Region

#Region "納品サイクルマスタの取得"
    Private Function GetDeliveryInfo(strFolderPath As String, strSlipID As String) As DataRow
        Try
            Dim strHHMM As String = System.IO.Directory.GetCreationTime(strFolderPath).ToString("HHmm")
            Dim stbSQL As New StringBuilder(String.Empty)
            stbSQL.AppendLine("SELECT")
            stbSQL.AppendLine("    D.*")
            stbSQL.AppendLine("FROM")
            stbSQL.AppendLine("    M_CM_DELIVERY D")
            stbSQL.AppendLine("    INNER JOIN")
            stbSQL.AppendLine("        (")
            stbSQL.AppendLine("            SELECT")
            stbSQL.AppendLine("                MIN(RECEIPT_PLAN) AS RECEIPT_PLAN")
            stbSQL.AppendLine("            FROM")
            stbSQL.AppendLine("                M_CM_DELIVERY")
            stbSQL.AppendLine("            WHERE")
            stbSQL.AppendLine("                DELETE_FLG = '0'")
            stbSQL.AppendLine("                AND")
            stbSQL.AppendLine("                SLIP_DEFINE_ID = '%SLIP%'")
            stbSQL.AppendLine("                AND")
            stbSQL.AppendLine("                RECEIPT_PLAN   > '%HHMM%'")
            stbSQL.AppendLine("        ) H")
            stbSQL.AppendLine("        ON")
            stbSQL.AppendLine("            D.RECEIPT_PLAN = H.RECEIPT_PLAN")
            stbSQL.AppendLine("WHERE")
            stbSQL.AppendLine("    DELETE_FLG = '0'")
            stbSQL.AppendLine("    AND")
            stbSQL.AppendLine("    SLIP_DEFINE_ID = '%SLIP%'")

            stbSQL.Replace("%SLIP%", strSlipID)
            stbSQL.Replace("%HHMM%", strHHMM)

            Dim dt As DataTable = MyBase.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)
            If dt Is Nothing OrElse dt.Rows.Count = 0 Then
                Throw New Exception("納品サイクルマスタに該当データがありません")
            End If

            Return dt.Rows(0)

        Catch ex As Exception
            CommonLog.WriteLog("納品サイクルマスタの取得に失敗しました。", EventLogEntryType.Error)
            Throw ex
        End Try
    End Function
#End Region

#Region "カレンダー取得"
    Private Function GetDeliveryDate(strFolderPath As String, intDays As String) As String
        Try
            Dim strYYYYMMDD As String = System.IO.Directory.GetCreationTime(strFolderPath).ToString("yyyyMMdd")
            Dim stbSQL As New StringBuilder(String.Empty)
            stbSQL.AppendLine("SELECT")
            stbSQL.AppendLine("    YYYYMMDD")
            stbSQL.AppendLine("FROM")
            stbSQL.AppendLine("    M_CM_HOLIDAY")
            stbSQL.AppendLine("WHERE")
            stbSQL.AppendLine("    YYYYMMDD >= '%DATE%'")
            stbSQL.AppendLine("    AND")
            stbSQL.AppendLine("    HOLIDAY = '0'")
            stbSQL.AppendLine("ORDER BY")
            stbSQL.AppendLine("    YYYYMMDD")

            stbSQL.Replace("%DATE%", strYYYYMMDD)

            Dim dt As DataTable = MyBase.mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)
            If dt Is Nothing OrElse dt.Rows.Count < intDays + 1 Then
                Throw New Exception("休日マスタに該当データがありません")
            End If

            Dim strDate As String = Convert.ToString(dt.Rows(intDays).Item(0))
            Return strDate

        Catch ex As Exception
            CommonLog.WriteLog("休日マスタの取得に失敗しました。", EventLogEntryType.Error)
            Throw ex
        End Try
    End Function
#End Region

End Class

