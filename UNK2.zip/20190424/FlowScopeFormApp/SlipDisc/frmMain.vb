﻿Imports CommonSystem
Imports System
Imports System.Text
Imports Oracle.DataAccess





Public Class frmMain

#Region "定数定義"
    Private Const APP_NAME As String = "帳票再識別"
    Private Const COMMIT_ENTRY_PAGE As String = "1"
    Private Const COMMIT_ENTRY_PROJ As String = "2"
#End Region

#Region "変数定義"

    ''' <summary>
    ''' 現在の処理行（ページ）
    ''' </summary>
    ''' <remarks></remarks>
    Dim mintRow As Integer = 0

    ''' <summary>
    ''' 処理対象イメージ情報
    ''' </summary>
    ''' <remarks></remarks>
    Dim mdtbImg As DataTable = Nothing

    ''' <summary>
    ''' 読込み直後のイメージ情報
    ''' </summary>
    ''' <remarks></remarks>
    Dim mdtbImgCopy As DataTable = Nothing

    ''' <summary>
    ''' 処理対象イメージの案件特定用のキーコード
    ''' </summary>
    ''' <remarks></remarks>
    Dim mstrSubKey As String = String.Empty

    ''' <summary>
    ''' 残り案件数
    ''' </summary>
    ''' <remarks></remarks>
    Dim mintSubjectCount As Integer = 0

    ''' <summary>
    ''' 各帳票IDのサンプルイメージの所在情報
    ''' </summary>
    ''' <remarks></remarks>
    Dim mdicSampleImage As New Dictionary(Of String, String)

    ''' <summary>
    ''' 納品予定時刻までの時間（分）
    ''' </summary>
    ''' <remarks></remarks>
    Dim mintDeliveryLimit As Integer = 0

    ''' <summary>
    ''' 帳票IDの組み合わせリスト
    ''' </summary>
    ''' <remarks></remarks>
    Dim mlstSlipSet As New List(Of List(Of String))

    ''' <summary>
    ''' 重複可能な帳票IDの辞書
    ''' </summary>
    ''' <remarks></remarks>
    Dim mdicSlipDup As New Dictionary(Of String, String)

    ''' <summary>
    ''' 帳票種類違いの帳票IDの辞書
    ''' </summary>
    ''' <remarks></remarks>
    Dim mdicSlipBad As New Dictionary(Of String, String)

    ''' <summary>
    ''' 再エントリの対象になる帳票IDの辞書
    ''' </summary>
    ''' <remarks></remarks>
    Dim mdicSlipEnt As New Dictionary(Of String, String)
#End Region

#Region "画面ロード時の処理"
    ''' <summary>
    ''' 画面ロード時の処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            ' 納品期限の取得を行います。
            mintDeliveryLimit = Convert.ToInt32(My.Application.mdicConfig("DELIVERY_LIMIT_MINUTE"))

            ' 外部定義（config）を精査します。
            For Each key As String In My.Application.mdicConfig.Keys
                If key.StartsWith("SLIP_SAMPLE_IMAGE_") Then
                    ' 定義キーの先頭が「SLIP_SAMPLE_IMAGE_」で始まる場合サンプルイメージの所在情報として記憶します。
                    Dim strSlip As String = key.Replace("SLIP_SAMPLE_IMAGE_", String.Empty)
                    mdicSampleImage.Add(strSlip, My.Application.mdicConfig(key))
                End If
                If key.StartsWith("SLIP_SET_") Then
                    ' 定義キーの先頭が「SLIP_SET_」で始まる場合帳票IDの組み合わせ情報として記憶します。
                    Dim strSlip() As String = Split(My.Application.mdicConfig(key), ",")
                    Dim lst As New List(Of String)
                    For Each s As String In strSlip
                        lst.Add(s)
                    Next
                    mlstSlipSet.Add(lst)
                End If
            Next

            ' NG組み合わせ定義を展開します。
            Call LoadNGSet()

            ' 重複可能帳票IDの一覧を記憶します。
            Dim strDup() As String = Split(My.Application.mdicConfig("SLIP_DUP"), ",")
            For Each s As String In strDup
                mdicSlipDup.Add(s, String.Empty)
            Next
            ' 帳票種類違い帳票IDの一覧を記憶します。
            Dim strBad() As String = Split(My.Application.mdicConfig("SLIP_BAD"), ",")
            For Each s As String In strBad
                mdicSlipBad.Add(s, String.Empty)
            Next
            ' 再エントリ対象帳票IDの一覧を記憶します。
            Dim strEnt() As String = Split(My.Application.mdicConfig("SLIP_ENT"), ",")
            For Each s As String In strEnt
                mdicSlipEnt.Add(s, String.Empty)
            Next

            ' エラー表示を初期化します。
            Me.txtErrorInfo.Text = String.Empty
            ' 処理対象イメージ情報を取得します。
            mdtbImg = GetImage()
            ' 取得直後の情報を退避しておきます。
            mdtbImgCopy = mdtbImg.Copy
            ' 取得情報を画面に表示します。
            Call ViewImage()
            ' 一覧の背景色を設定します
            Call SetBaclColor()
            Application.DoEvents()
            ' 帳票ID後半の入力ボックスにフォーカスを設定します。
            Me.ActiveControl = Me.txtSlipSurfix
            ' 帳票ID後半の入力ボックス内を全選択にします。
            Me.txtSlipSurfix.SelectAll()

        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

#Region "画面が閉じている最中の処理"
    ''' <summary>
    ''' 画面が閉じている最中の処理
    ''' </summary>
    ''' <param name="sender">イベント発生元オブジェクト</param>
    ''' <param name="e">イベントパラメータ</param>
    ''' <remarks></remarks>
    Private Sub frmMain_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Try
            ' 処理中のイメージデータがあるか確認します。
            If My.Application.mblnTransaction Then
                ' 処理中のデータがある場合は終了の確認を行います。
                If MessageBox.Show("作業を中断しますか？", APP_NAME, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) = Windows.Forms.DialogResult.No Then
                    e.Cancel = True
                    Return
                End If
                My.Application.comDB.DB_Rollback()
                My.Application.mblnTransaction = False
            End If

        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

#Region "ショートカットキー処理"
    Private Sub frmMain_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        Try
            Select Case e.KeyCode
                Case Keys.PageUp
                    Call Me.btnPrevPage_Click(sender, e)
                Case Keys.PageDown
                    Call Me.btnNextPage_Click(sender, e)
                Case Keys.F1
                    Call Me.btnZoomDown_Click(sender, e)
                Case Keys.F2
                    Call Me.btnZoomUp_Click(sender, e)
                Case Keys.F3
                    Call Me.btnDisplayFit_Click(sender, e)
                Case Keys.F4
                    Call Me.btnRotate_Click(sender, e)
                Case Keys.F6
                    Call Me.btnPageCommit_Click(sender, e)
                Case Keys.F9
                    Call Me.btnProCommit_Click(sender, e)
                Case Keys.F12
                    Call Me.btnBreak_Click(sender, e)
            End Select
        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

#Region "中断ボタン処理"
    ''' <summary>
    ''' 中断ボタン処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnBreak_Click(sender As Object, e As EventArgs) Handles btnBreak.Click
        Try
            Me.Close()
        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region


#Region "処理対象のイメージIDの取得"
    ''' <summary>
    ''' 処理対象のイメージIDの取得
    ''' </summary>
    ''' <returns>イメージID（Nullの場合は該当データなし）</returns>
    ''' <remarks></remarks>
    Public Function GetImage() As DataTable
        Try
            ' 対象イメージIDを初期化します。
            Dim strImageId As String = String.Empty
            With My.Application
                ' 処理対象のステータスになっている事案IDの一覧を取得するSQLを作成します。
                Dim stbSQL As New StringBuilder(String.Empty)
                stbSQL.AppendLine("SELECT DISTINCT")
                stbSQL.AppendLine("    RECEIPT_ID,")
                stbSQL.AppendLine("    SUBSTR(IMAGE_FILE_NAME,1,23) AS SUB_KEY,")
                stbSQL.AppendLine("    PRIORITY ")
                stbSQL.AppendLine("FROM")
                stbSQL.AppendLine("    T_JJ_IMAGE")
                stbSQL.AppendLine("WHERE")
                stbSQL.AppendLine("    IMAGE_STATUS= '%STATUS%'")
                stbSQL.AppendLine("    AND")
                stbSQL.AppendLine("    DELETE_FLG = '0'")

                ' 同一案件中に処理除外イメージステータスが含まれているデータは対象外
                stbSQL.AppendLine("    AND")
                stbSQL.AppendLine("    SUBSTR(IMAGE_FILE_NAME,1,23) NOT IN (")
                stbSQL.AppendLine("        SELECT DISTINCT")
                stbSQL.AppendLine("            SUBSTR(IMAGE_FILE_NAME,1,23) AS SUB_KEY")
                stbSQL.AppendLine("        FROM")
                stbSQL.AppendLine("            T_JJ_IMAGE")
                stbSQL.AppendLine("        WHERE")
                stbSQL.AppendLine("            IMAGE_STATUS IN (%REJECT_STATUS%) ")
                stbSQL.AppendLine("            AND")
                stbSQL.AppendLine("            DELETE_FLG = '0'")
                stbSQL.AppendLine("    )")

                stbSQL.AppendLine("ORDER BY")
                stbSQL.AppendLine("    RECEIPT_ID,")
                stbSQL.AppendLine("    PRIORITY ")
                stbSQL.Replace("%STATUS%", .mdicConfig("INPUT_STATUS"))
                stbSQL.Replace("%REJECT_STATUS%", .mdicConfig("REJECT_STATUS"))
                ' 作成されたSQLを実行して処理対処の一覧を取得します。
                Dim dt As DataTable = .comDB.DB_ExecuteQuery(stbSQL.ToString)
                If dt.Rows.Count = 0 Then
                    MessageBox.Show("処理対象データがありません。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    End
                End If

                ' 残案件数を記憶します。
                mintSubjectCount = dt.Rows.Count

                ' DBトランザクションを開始します。
                .comDB.DB_Transaction()
                .mblnTransaction = True
                Try
                    ' 取得したイメージIDを１つずつ確認します。
                    For Each dr As DataRow In dt.Rows
                        ' 事案ID指定でイメージデータの排他取得を試みるSQLを作成します。
                        Dim strID As String = Convert.ToString(dr.Item("SUB_KEY"))
                        stbSQL.Length = 0
                        stbSQL.AppendLine("SELECT")
                        stbSQL.AppendLine("    *")
                        stbSQL.AppendLine("FROM")
                        stbSQL.AppendLine("    T_JJ_IMAGE")
                        stbSQL.AppendLine("WHERE")
                        'stbSQL.AppendLine("    IMAGE_STATUS = '%STATUS%'")
                        'stbSQL.AppendLine("    AND")
                        stbSQL.AppendLine("    SUBSTR(IMAGE_FILE_NAME,1,23) = '%SUB_KEY%'")
                        stbSQL.AppendLine("    AND")
                        stbSQL.AppendLine("    DELETE_FLG = '0'")

                        stbSQL.AppendLine("    AND")
                        stbSQL.AppendLine("    SUBSTR(IMAGE_FILE_NAME,1,23) IN (")
                        stbSQL.AppendLine("        SELECT DISTINCT")
                        stbSQL.AppendLine("            SUBSTR(IMAGE_FILE_NAME,1,23) AS SUB_KEY")
                        stbSQL.AppendLine("        FROM")
                        stbSQL.AppendLine("            T_JJ_IMAGE")
                        stbSQL.AppendLine("        WHERE")
                        stbSQL.AppendLine("            IMAGE_STATUS= '%STATUS%'")
                        stbSQL.AppendLine("            AND")
                        stbSQL.AppendLine("            DELETE_FLG = '0'")
                        stbSQL.AppendLine("    )")

                        stbSQL.AppendLine("ORDER BY")
                        stbSQL.AppendLine("    IMAGE_FILE_NAME ")
                        stbSQL.AppendLine("FOR UPDATE NOWAIT")
                        stbSQL.Replace("%STATUS%", .mdicConfig("INPUT_STATUS"))
                        stbSQL.Replace("%SUB_KEY%", strID)

                        Dim dt2 As DataTable
                        Try
                            ' 作成したSQLでデータの取得を試みます。
                            dt2 = .comDB.DB_ExecuteQuery(stbSQL.ToString)
                        Catch ex As Oracle.DataAccess.Client.OracleException
                            If ex.Number = 54 Then
                                ' 他で既に処理されていた場合（排他されていた場合）は次のイメージデータまでスキップします。
                                Continue For
                            Else
                                Throw ex
                            End If
                        End Try

                        If Not dt2 Is Nothing AndAlso dt2.Rows.Count > 0 Then
                            mintRow = 0
                            mstrSubKey = strID
                            Me.dgvList.DataSource = GetSlipList(strID.Substring(13, 3))
                            Return dt2
                        End If

                    Next
                Catch ex As Exception
                    'DBトランザクションの破棄
                    .comDB.DB_Rollback()
                    .mblnTransaction = True
                    ' 処理対象イメージIDを初期化します。
                    strImageId = String.Empty
                    Throw ex
                End Try

            End With

            MessageBox.Show("処理対象データがありません。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Information)
            My.Application.comDB.DB_Rollback()
            My.Application.mblnTransaction = False
            End

        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Function
#End Region

#Region "帳票IDリスト取得"
    ''' <summary>
    ''' 帳票IDリスト取得
    ''' </summary>
    ''' <param name="strKey"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetSlipList(strKey As String) As DataTable
        Try
            Dim stbSQL As New StringBuilder(String.Empty)
            stbSQL.AppendLine("SELECT")
            stbSQL.AppendLine("    SLIP_DEFINE_ID")
            stbSQL.AppendLine("   ,SLIP_DEFINE_NAME")
            stbSQL.AppendLine("FROM")
            stbSQL.AppendLine("    M_SLIP_DEFINE")
            stbSQL.AppendLine("WHERE")
            stbSQL.AppendLine("    DELETE_FLG = '0'")
            stbSQL.AppendLine("    AND")
            stbSQL.AppendLine("    SLIP_DEFINE_ID LIKE '" & strKey & "%'")
            stbSQL.AppendLine("    AND")
            stbSQL.AppendLine("    NOT SLIP_DEFINE_ID IN (")
            stbSQL.AppendLine("        " & My.Application.mdicConfig("REJECT_SLIP"))
            stbSQL.AppendLine("    )")
            stbSQL.AppendLine("ORDER BY")
            stbSQL.AppendLine("    SORT_NO")

            Dim dt As DataTable = My.Application.comDB.DB_ExecuteQuery(stbSQL.ToString)
            Return dt
        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Function
#End Region

#Region "帳票一覧セル移動"
    ''' <summary>
    ''' 帳票一覧セル移動
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub dgvList_CellEnter(sender As Object, e As DataGridViewCellEventArgs) Handles dgvList.CellEnter
        Try
            Dim strSlip As String = Convert.ToString(Me.dgvList.Rows(e.RowIndex).Cells(0).Value)
            If mdicSampleImage.ContainsKey(strSlip) Then
                Me.CtlImage2.MakeImage(mdicSampleImage(strSlip))
                Me.CtlImage2.Reset()
                Me.txtSlipSurfix.Text = strSlip.Substring(3)
                Me.txtSlipSurfix.SelectAll()
            Else
                Me.CtlImage2.ClearImage()
            End If
        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

#Region "イメージ情報表示"
    Private Sub ViewImage()
        Try
            Me.txtSubCount.Text = mintSubjectCount.ToString
            Me.txtFileName.Text = Convert.ToString(mdtbImg.Rows(mintRow).Item("IMAGE_FILE_NAME")).Trim

            Dim datCrear As Date = Convert.ToDateTime(mdtbImg.Rows(mintRow).Item("CREATE_DATE"))
            Me.txtReceiptDate.Text = datCrear.ToString("yyyy/MM/dd HH:mm:ss")
            Me.txtDeliveryPlan.Text = datCrear.AddMinutes(mintDeliveryLimit).ToString("yyyy/MM/dd HH:mm")
            Me.txtNowPage.Text = (mintRow + 1).ToString
            Me.txtPageNum.Text = mdtbImg.Rows.Count.ToString

            Dim strSlip As String = Convert.ToString(mdtbImg.Rows(mintRow).Item("SLIP_DEFINE_ID"))
            Me.txtSlipPrefix.Text = strSlip.Substring(0, 3)
            Me.txtSlipSurfix.Text = strSlip.Substring(3, 3)

            Dim strPath As String = Convert.ToString(mdtbImg.Rows(mintRow).Item("IMAGE_FILE_PATH")).Trim
            Dim strName As String = Convert.ToString(mdtbImg.Rows(mintRow).Item("IMAGE_FILE_NAME")).Trim
            Dim strImageFile As String = IO.Path.Combine(strPath, strName)
            Me.CtlImage1.MakeImage(strImageFile)
            Me.CtlImage1.Reset()

            Call SetListRow(strSlip)

        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

#Region "帳票ID一覧の行設定"
    ''' <summary>
    ''' 帳票ID一覧の行設定
    ''' </summary>
    ''' <param name="strSlip"></param>
    ''' <remarks></remarks>
    Private Sub SetListRow(strSlip As String)
        Try
            For i As Integer = 0 To Me.dgvList.RowCount - 1 Step 1
                Dim strSrc As String = Convert.ToString(dgvList.Rows(i).Cells(0).Value)
                If strSrc.Equals(strSlip) Then
                    Me.dgvList.CurrentCell = Me.dgvList.Rows(i).Cells(0)
                    Return
                End If
            Next
        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

#Region "前ページボタン処理"
    Private Sub btnPrevPage_Click(sender As Object, e As EventArgs) Handles btnPrevPage.Click
        Try
            If mintRow <= 0 Then
                Return
            End If
            mintRow -= 1
            Call ViewImage()
        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

#Region "次ページボタン処理"
    Private Sub btnNextPage_Click(sender As Object, e As EventArgs) Handles btnNextPage.Click
        Try
            If mintRow >= mdtbImg.Rows.Count - 1 Then
                Return
            End If
            mintRow += 1
            Call ViewImage()
        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

#Region "縮小ボタン処理"
    Private Sub btnZoomDown_Click(sender As Object, e As EventArgs) Handles btnZoomDown.Click
        Try
            Me.CtlImage1.btnZoomOut_Click(sender, e)
        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

#Region "拡大ボタン処理"
    Private Sub btnZoomUp_Click(sender As Object, e As EventArgs) Handles btnZoomUp.Click
        Try
            Me.CtlImage1.btnZoomIn_Click(sender, e)
        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

#Region "元に戻すボタン処理"
    Private Sub btnDisplayFit_Click(sender As Object, e As EventArgs) Handles btnDisplayFit.Click
        Try
            Me.CtlImage1.Reset()
        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

#Region "右回転ボタン"
    Private Sub btnRotate_Click(sender As Object, e As EventArgs) Handles btnRotate.Click
        Try
            Me.CtlImage1.btnRotate_Click(sender, e)
        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

#Region "ページ番号テキストボックス関連"
    Private Sub txtNowPage_GotFocus(sender As Object, e As EventArgs) Handles txtNowPage.GotFocus
        Try
            Me.txtNowPage.SelectAll()
        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub

    Private Sub txtNowPage_LostFocus(sender As Object, e As EventArgs) Handles txtNowPage.LostFocus
        Try
            Me.txtNowPage.Text = (mintRow + 1).ToString
        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub

    Private Sub txtNowPage_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtNowPage.KeyPress
        Try
            '0～9と、バックスペース以外の時は、イベントをキャンセルする
            If (e.KeyChar < "0"c OrElse "9"c < e.KeyChar) AndAlso _
                    e.KeyChar <> ControlChars.Back Then
                e.Handled = True
            End If
        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub

    Private Sub txtNowPage_KeyDown(sender As Object, e As KeyEventArgs) Handles txtNowPage.KeyDown
        Try
            If e.KeyCode <> Keys.Enter Then
                Return
            End If

            Dim intPage As Integer = 0
            Dim bln As Boolean = Integer.TryParse(Me.txtNowPage.Text, intPage)
            If Not bln Then
                Me.txtNowPage.Text = (mintRow + 1).ToString
                Return
            End If
            If intPage > mdtbImg.Rows.Count OrElse intPage <= 0 Then
                Me.txtNowPage.Text = (mintRow + 1).ToString
                Return
            End If
            mintRow = intPage - 1
            Call ViewImage()
            Application.DoEvents()
            Me.ActiveControl = Me.txtSlipSurfix
            Me.txtSlipSurfix.SelectAll()
        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

#Region "帳票番号テキストボックス関連処理"
    Private Sub txtSlipSurfix_GotFocus(sender As Object, e As EventArgs) Handles txtSlipSurfix.GotFocus
        Try
            Me.txtSlipSurfix.SelectAll()
        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try

    End Sub

    Private Sub txtSlipSurfix_LostFocus(sender As Object, e As EventArgs) Handles txtSlipSurfix.LostFocus
        Try
            'Dim strSlip As String = Convert.ToString(mdtbImg.Rows(mintRow).Item("SLIP_DEFINE_ID"))
            'Me.txtSlipSurfix.Text = strSlip.Substring(3, 3)
        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub

    Private Sub txtSlipSurfix_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtSlipSurfix.KeyPress
        Try
            '0～9と、バックスペース以外の時は、イベントをキャンセルする
            If (e.KeyChar < "0"c OrElse "9"c < e.KeyChar) AndAlso _
                    e.KeyChar <> ControlChars.Back Then
                e.Handled = True
            End If
        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub

    Private Sub txtSlipSurfix_KeyDown(sender As Object, e As KeyEventArgs) Handles txtSlipSurfix.KeyDown
        Try
            Select Case e.KeyCode
                Case Keys.Up
                    Dim intRow As Integer = Me.dgvList.CurrentCell.RowIndex
                    If intRow = 0 Then
                        intRow = Me.dgvList.RowCount - 1
                    Else
                        intRow -= 1
                    End If
                    Me.dgvList.CurrentCell = Me.dgvList.Rows(intRow).Cells(0)

                Case Keys.Down
                    Dim intRow As Integer = Me.dgvList.CurrentCell.RowIndex
                    If intRow = Me.dgvList.RowCount - 1 Then
                        intRow = 0
                    Else
                        intRow += 1
                    End If
                    Me.dgvList.CurrentCell = Me.dgvList.Rows(intRow).Cells(0)

                Case Keys.Enter
                    Dim strSlip As String = Me.txtSlipPrefix.Text.Trim & _
                                            Me.txtSlipSurfix.Text.Trim
                    For i As Integer = 0 To Me.dgvList.Rows.Count - 1 Step 1
                        Dim strMySlip As String = Convert.ToString(Me.dgvList.Rows(i).Cells(0).Value)
                        If strSlip.Equals(strMySlip) Then
                            Me.dgvList.CurrentCell = Me.dgvList.Rows(i).Cells(0)
                            Me.btnPageCommit.Focus()
                            Return
                        End If
                    Next
                    MessageBox.Show("無効な帳票番号です。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    strSlip = Convert.ToString(mdtbImg.Rows(mintRow).Item("SLIP_DEFINE_ID"))
                    Me.txtSlipSurfix.Text = strSlip.Substring(3, 3)
                    Me.txtSlipSurfix.SelectAll()

            End Select

        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

#Region "ページ確定ボタン処理"
    Private Sub btnPageCommit_Click(sender As Object, e As EventArgs) Handles btnPageCommit.Click
        Try
            Dim strSlip As String = Me.txtSlipPrefix.Text.Trim & _
                                    Me.txtSlipSurfix.Text.Trim
            mdtbImg.Rows(mintRow).Item("SLIP_DEFINE_ID") = strSlip
            ' 一覧の背景色を設定します
            Call SetBaclColor()

            If mintRow = (mdtbImg.Rows.Count - 1) Then
                Call CommitEntry(COMMIT_ENTRY_PAGE)
            Else
                mintRow += 1
                Call ViewImage()
                Me.txtSlipSurfix.Focus()
            End If

        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

#Region "案件確定ボタン処理"
    Private Sub btnProCommit_Click(sender As Object, e As EventArgs) Handles btnProCommit.Click
        Try
            Dim strSlip As String = Me.txtSlipPrefix.Text.Trim & _
                                    Me.txtSlipSurfix.Text.Trim
            mdtbImg.Rows(mintRow).Item("SLIP_DEFINE_ID") = strSlip
            ' 一覧の背景色を設定します
            Call SetBaclColor()

            Call CommitEntry(COMMIT_ENTRY_PROJ)
            
        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region


#Region "登録処理"
    Private Sub CommitEntry(ByVal strProcMode As String)
        Try
            Dim stbMsg As New StringBuilder(String.Empty)
            Dim strMsg As String = String.Empty

            Dim blnHead3 As Boolean = CheckSlipHead3()

            If Not blnHead3 Then
                MessageBox.Show("同一案件内で帳票種類が一致していません。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Exit Sub
            End If

            If Not CheckNgSlipSet() Then
                MessageBox.Show("禁止されている帳票の組み合わせが見つかりました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Exit Sub
            End If

            Dim blnDup As Boolean = CheckSlipDup(strMsg)

            Me.txtErrorInfo.Text = strMsg

            If Not blnDup Then
                MessageBox.Show("帳票番号に重複があります。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Exit Sub
            End If

            Dim blnSet As Boolean = CheckSlipSet()
            If Not blnSet Then
                Dim frmMsg As New frmMyMsgBox
                If frmMsg.ShowDialog = Windows.Forms.DialogResult.No Then
                    Return
                End If
            Else
                stbMsg.Append("登録しますか？")
                Dim dlgAns As DialogResult = MessageBox.Show(stbMsg.ToString, APP_NAME, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2)
                If dlgAns = vbNo Then
                    Return
                End If
            End If


            'Dim blnBad As Boolean = False
            'For Each r As DataRow In mdtbImg.Rows
            '    Dim strSlip As String = Convert.ToString(r.Item("SLIP_DEFINE_ID"))
            '    If mdicSlipBad.ContainsKey(strSlip) Then
            '        blnBad = True
            '        Exit For
            '    End If
            'Next

            Dim strStatus As String = String.Empty
            For i As Integer = 0 To mdtbImg.Rows.Count - 1 Step 1
                Dim strImageId As String = Convert.ToString(mdtbImgCopy.Rows(i).Item("IMAGE_ID"))
                Dim strOldSlip As String = Convert.ToString(mdtbImgCopy.Rows(i).Item("SLIP_DEFINE_ID"))
                Dim strNewSlip As String = Convert.ToString(mdtbImg.Rows(i).Item("SLIP_DEFINE_ID"))

                ' 案件確定ボタン押下時
                If strProcMode.Equals(COMMIT_ENTRY_PROJ) Then
                    If strNewSlip.Substring(3, 3).Equals("000") Then
                        strNewSlip = strNewSlip.Substring(0, 3) & "999"
                    End If
                End If

                If mdicSlipBad.ContainsKey(strNewSlip) Then
                    strStatus = My.Application.mdicConfig("OUT_STATUS_BAD")
                Else
                    If strOldSlip.Equals(strNewSlip) Then
                        If mdicSlipEnt.ContainsKey(strNewSlip) Then
                            If IsDBNull(mdtbImgCopy.Rows(i).Item("ENTRY_DATE")) Then
                                strStatus = My.Application.mdicConfig("OUT_STATUS_ENT")
                            Else
                                strStatus = My.Application.mdicConfig("OUT_STATUS_NOCHG")
                            End If
                        Else
                            strStatus = My.Application.mdicConfig("OUT_STATUS_NOCHG")
                        End If
                    Else
                        If mdicSlipEnt.ContainsKey(strNewSlip) Then
                            strStatus = My.Application.mdicConfig("OUT_STATUS_ENT")
                        Else
                            strStatus = My.Application.mdicConfig("OUT_STATUS_NO_ENT")
                        End If
                    End If
                End If

                Call UpdateImage(strImageId, strOldSlip, strNewSlip, strStatus)
                Call InsertHistory(strImageId, strStatus)
            Next

            My.Application.comDB.DB_Commit()
            My.Application.mblnTransaction = False

            MessageBox.Show("正常に更新されました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Information)

            ' エラー表示を初期化します。
            Me.txtErrorInfo.Text = String.Empty
            mdtbImg = GetImage()
            mdtbImgCopy = mdtbImg.Copy
            Call ViewImage()
            ' 一覧の背景色を設定します
            Call SetBaclColor()
            Application.DoEvents()
            Me.ActiveControl = Me.txtSlipSurfix
            Me.txtSlipSurfix.SelectAll()

        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

#Region "帳票番号の組み合わせチェック"
    Private Function CheckSlipSet() As Boolean
        Try
            For Each lst As List(Of String) In mlstSlipSet
                Dim blnMach1 As Boolean = True
                For Each s As String In lst
                    Dim blnFind As Boolean = False
                    For Each r As DataRow In mdtbImg.Rows
                        If mdicSlipDup.ContainsKey(Convert.ToString(r.Item("SLIP_DEFINE_ID"))) Then
                            Continue For
                        End If
                        If mdicSlipBad.ContainsKey(Convert.ToString(r.Item("SLIP_DEFINE_ID"))) Then
                            Continue For
                        End If
                        If Convert.ToString(r.Item("SLIP_DEFINE_ID")).Equals(s) Then
                            blnFind = True
                            Exit For
                        End If
                    Next
                    If Not blnFind Then
                        blnMach1 = False
                        Exit For
                    End If
                Next
                If Not blnMach1 Then
                    Continue For
                End If

                Dim blnMach2 As Boolean = True
                For Each r As DataRow In mdtbImg.Rows
                    If mdicSlipDup.ContainsKey(Convert.ToString(r.Item("SLIP_DEFINE_ID"))) Then
                        Continue For
                    End If
                    If mdicSlipBad.ContainsKey(Convert.ToString(r.Item("SLIP_DEFINE_ID"))) Then
                        Continue For
                    End If
                    Dim blnFind As Boolean = False
                    For Each s As String In lst
                        If Convert.ToString(r.Item("SLIP_DEFINE_ID")).Equals(s) Then
                            blnFind = True
                            Exit For
                        End If
                    Next
                    If Not blnFind Then
                        blnMach2 = False
                        Exit For
                    End If
                Next
                If Not blnMach2 Then
                    Continue For
                End If

                Return True
            Next

            Return False
        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Function
#End Region

#Region "帳票番号の重複チェック"
    Private Function CheckSlipDup(ByRef strMsg As String) As Boolean
        Try
            Dim dicSlip As New Dictionary(Of String, List(Of String))
            For i As Integer = 0 To mdtbImg.Rows.Count - 1 Step 1
                Dim r As DataRow = mdtbImg.Rows(i)
                Dim strSlip As String = Convert.ToString(r.Item("SLIP_DEFINE_ID"))
                If Not dicSlip.ContainsKey(strSlip) Then
                    Dim lst As New List(Of String)
                    dicSlip.Add(strSlip, lst)
                End If
                dicSlip(strSlip).Add((i + 1).ToString())
            Next

            Dim blnDup As Boolean = True
            Dim stbMsg As New StringBuilder(String.Empty)
            For Each strSlip As String In dicSlip.Keys
                If mdicSlipDup.ContainsKey(strSlip) Then
                    Continue For
                End If
                If dicSlip(strSlip).Count > 1 Then
                    stbMsg.Append(Join(dicSlip(strSlip).ToArray, ","))
                    stbMsg.Append("ページで、帳票番号「")
                    stbMsg.Append(strSlip)
                    stbMsg.AppendLine("」が重複しています。")
                    blnDup = False
                End If
            Next

            strMsg = stbMsg.ToString

            Return blnDup

        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Function
#End Region

#Region "帳票番号の頭3桁不一致チェック"
    Private Function CheckSlipHead3() As Boolean
        Try
            Dim dicSlip As New Dictionary(Of String, List(Of String))
            For i As Integer = 0 To mdtbImg.Rows.Count - 1 Step 1
                Dim r As DataRow = mdtbImg.Rows(i)
                Dim strSlip As String = Convert.ToString(r.Item("SLIP_DEFINE_ID")).Substring(0, 3)
                If Not dicSlip.ContainsKey(strSlip) Then
                    Dim lst As New List(Of String)
                    dicSlip.Add(strSlip, lst)
                End If
                dicSlip(strSlip).Add((i + 1).ToString())
            Next

            Dim blnHead3 As Boolean = True
            Dim strSlipId As String = String.Empty

            For Each strSlip As String In dicSlip.Keys
                If Not strSlipId.Equals(String.Empty) AndAlso Not strSlipId.Equals(strSlip) Then
                    blnHead3 = False
                    Exit For
                End If

                strSlipId = strSlip
            Next

            Return blnHead3

        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Function
#End Region


#Region "T_JJ_IMAGEの更新"
    Private Sub UpdateImage(ByVal strImageId As String, _
                            ByVal strOldSlip As String, _
                            ByVal strNewSlip As String, _
                            ByVal strStatus As String)
        Try
            ' T_JJ_IMAGE更新用SQLを作成します。
            Dim stbUpdateSQL As New StringBuilder(String.Empty)
            stbUpdateSQL.AppendLine("UPDATE")
            stbUpdateSQL.AppendLine("    T_JJ_IMAGE")
            stbUpdateSQL.AppendLine("SET")
            stbUpdateSQL.AppendLine("     IMAGE_STATUS    = '__IMAGE_STATUS__'")
            stbUpdateSQL.AppendLine("    ,SLIP_DEFINE_ID  = '__NEW_SLIP__'")
            stbUpdateSQL.AppendLine("    ,EXC_IMAGE_KEY02 = '__OLD_SLIP__'")
            stbUpdateSQL.AppendLine("    ,UPDATE_USER     = '__USER__'")
            stbUpdateSQL.AppendLine("    ,UPDATE_DATE     = SYSDATE")
            If strStatus.Equals(My.Application.mdicConfig("OUT_STATUS_ENT")) Then
                stbUpdateSQL.AppendLine("     ,PRIORITY    = '__PRIORITY__'")
                stbUpdateSQL.Replace("__PRIORITY__", My.Application.mdicConfig("PRIORITY"))
            End If
            stbUpdateSQL.AppendLine("WHERE")
            stbUpdateSQL.AppendLine("    IMAGE_ID = __IMAGE_ID__")

            ' 作成したSQLの設定値の部分を実際の値に置換します。
            stbUpdateSQL.Replace("__IMAGE_STATUS__", strStatus)
            stbUpdateSQL.Replace("__NEW_SLIP__", strNewSlip)
            stbUpdateSQL.Replace("__OLD_SLIP__", strOldSlip)
            stbUpdateSQL.Replace("__USER__", My.Application.mstrUserID)
            stbUpdateSQL.Replace("__IMAGE_ID__", strImageId)

            ' 作成したSQLを実行してT_RECEIPT_IMAGEを更新します。
            Dim intInsertRet As Integer = My.Application.comDB.DB_ExecuteNonQuery(stbUpdateSQL.ToString)
            If Not intInsertRet = 1 Then
                Throw New Exception("イメージデータの更新に失敗しました。")
            End If

        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

#Region "T_STATUS_HISTORYの登録"
    Private Sub InsertHistory(ByVal strImageId As String, ByVal strStatus As String)
        Try
            Dim strUpdateStatus As String = strStatus

            ' イメージ状態履歴登録用SQLを作成します。
            Dim stbInsertSQL As New System.Text.StringBuilder(String.Empty)
            stbInsertSQL.AppendLine("INSERT INTO T_JJ_IMAGE_HISTORY (")
            stbInsertSQL.AppendLine("     IMAGE_ID")
            stbInsertSQL.AppendLine("    ,IMAGE_STATUS")
            stbInsertSQL.AppendLine("    ,CREATE_DATE")
            stbInsertSQL.AppendLine("    ,CREATE_USER")
            stbInsertSQL.AppendLine(") VALUES (")
            stbInsertSQL.AppendLine("     __IMAGE_ID__")
            stbInsertSQL.AppendLine("    ,'__STATUS__'")
            stbInsertSQL.AppendLine("    ,SYSTIMESTAMP")
            stbInsertSQL.AppendLine("    ,'__USER__'")
            stbInsertSQL.AppendLine(")")
            ' 作成したSQLの設定値の部分を実際の値に置換します。
            stbInsertSQL.Replace("__STATUS__", strStatus)
            stbInsertSQL.Replace("__USER__", My.Application.mstrUserID)
            stbInsertSQL.Replace("__IMAGE_ID__", strImageId)

            ' イメージ状態履歴を登録します。
            Dim intInsertRet As Integer = My.Application.comDB.DB_ExecuteNonQuery(stbInsertSQL.ToString)
            If Not intInsertRet = 1 Then
                Throw New Exception("イメージ履歴の登録に失敗しました。")
            End If

        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

#Region "一覧の背景色設定"
    Private Sub SetBaclColor()
        Try
            Dim colNormal As Color = Color.FromName(My.Application.mdicConfig("COLOR_NORMAL"))
            Dim colSingle As Color = Color.FromName(My.Application.mdicConfig("COLOR_SINGLE"))
            Dim colMulti As Color = Color.FromName(My.Application.mdicConfig("COLOR_MULTI"))

            Dim dicSlip As New Dictionary(Of String, Integer)
            For Each r As DataRow In mdtbImg.Rows
                Dim strSlip As String = Convert.ToString(r.Item("SLIP_DEFINE_ID"))
                If dicSlip.ContainsKey(strSlip) Then
                    dicSlip(strSlip) += 1
                Else
                    dicSlip.Add(strSlip, 1)
                End If
            Next

            For i As Integer = 0 To Me.dgvList.RowCount - 1 Step 1
                Dim strSrc As String = Convert.ToString(dgvList.Rows(i).Cells(0).Value)
                If Not dicSlip.ContainsKey(strSrc) Then
                    dgvList.Rows(i).Cells(0).Style.BackColor = colNormal
                    dgvList.Rows(i).Cells(1).Style.BackColor = colNormal
                Else
                    If dicSlip(strSrc) = 1 Then
                        dgvList.Rows(i).Cells(0).Style.BackColor = colSingle
                        dgvList.Rows(i).Cells(1).Style.BackColor = colSingle
                    Else
                        dgvList.Rows(i).Cells(0).Style.BackColor = colMulti
                        dgvList.Rows(i).Cells(1).Style.BackColor = colMulti
                    End If
                End If
            Next

        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

    Private mdicNgSlipSet As New Dictionary(Of String, List(Of String))

#Region "禁止組み合わせ読込み"
    Private Sub LoadNGSet()
        Try
            For Each strKey As String In My.Application.mdicConfig.Keys
                If Not strKey.StartsWith("NG_SLIP_SET_") Then
                    Continue For
                End If
                Dim strSlip() As String = Split(My.Application.mdicConfig(strKey), ",")
                If Not mdicNgSlipSet.ContainsKey(strSlip(0)) Then
                    Dim lst As New List(Of String)
                    mdicNgSlipSet.Add(strSlip(0), lst)
                End If
                mdicNgSlipSet(strSlip(0)).Add(strSlip(1))
            Next

        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Sub
#End Region

#Region "禁止組み合わせ一致チェック"
    Private Function CheckNgSlipSet() As Boolean
        Try
            For Each r As DataRow In mdtbImg.Rows
                Dim strKeySlip As String = Convert.ToString(r.Item("SLIP_DEFINE_ID"))
                If Not mdicNgSlipSet.ContainsKey(strKeySlip) Then
                    Continue For
                End If
                For Each rr As DataRow In mdtbImg.Rows
                    Dim strSlip As String = Convert.ToString(rr.Item("SLIP_DEFINE_ID"))
                    For Each strNG As String In mdicNgSlipSet(strKeySlip)
                        If strNG.Equals(strSlip) Then
                            Return False
                        End If
                    Next
                Next
            Next

            Return True

        Catch ex As Exception
            ' ログにエラーメッセージを出力します。
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & "でエラーが発生しました。", EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)
            MessageBox.Show("システムエラーが発生しました。", APP_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End
        End Try
    End Function
#End Region

End Class