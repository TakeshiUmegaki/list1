﻿Imports CommonSystem
Imports CommonBase
Imports System
Imports System.Configuration
Imports System.IO
Imports System.Text

Public Class clsSlipCheckMain
    Inherits clsBatchBase

#Region "共通変数"
    ''' <summary>
    ''' 自端末処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Shared mainProc As clsSlipCheckMain
#End Region

#Region "内部変数定義"

    ''' <summary>
    ''' 頭紙帳票ID辞書
    ''' </summary>
    ''' <remarks></remarks>
    Private mdicSlipHed As New Dictionary(Of String, String)

    ''' <summary>
    ''' エントリ対象の帳票ID辞書
    ''' </summary>
    ''' <remarks></remarks>
    Private mdicSlipEnt As New Dictionary(Of String, String)

    ''' <summary>
    ''' 重複可能な帳票ID辞書
    ''' </summary>
    ''' <remarks></remarks>
    Private mdicSlipDup As New Dictionary(Of String, String)

    ''' <summary>
    ''' 組合せチェックで無視する帳票ID
    ''' </summary>
    ''' <remarks></remarks>
    Private mdicSlipEgn As New Dictionary(Of String, String)

    ''' <summary>
    ''' 再認識カウントアップ対象イメージステータス
    ''' </summary>
    ''' <remarks></remarks>
    Private mdicCountUp As New Dictionary(Of String, String)

    ''' <summary>
    ''' 帳票組み合わせ辞書リスト
    ''' </summary>
    ''' <remarks></remarks>
    Private mlstSlipSet As New List(Of Dictionary(Of String, String))

#End Region

#Region "メイン処理[Main]"
    ''' ======================================================================
    ''' メソッド名：Main
    ''' <summary>
    ''' メイン処理
    ''' </summary>
    ''' <remarks></remarks>
    ''' ======================================================================
    Shared Function Main(ByVal CmdArgs() As String) As Integer

        mainProc = New clsSlipCheckMain

        ' 処理の戻り値を返却
        Return mainProc.Run()

    End Function

#End Region

#Region "バッチ処理本体"
    ''' <summary>
    ''' バッチ処理本体
    ''' </summary>
    ''' <remarks></remarks>
    Protected Overrides Sub Execute()
        Try

            ' 初期設定を行います。
            Call InitializeBatch()

            ' 処理対象の案件IDの一覧を取得します。
            Dim dtSubject As DataTable = GetTargetSubject()

            ' 案件を１件ずつ処理します。
            For Each dr As DataRow In dtSubject.Rows

                ' 案件IDを取得します。
                Dim strSubject As String = Convert.ToString(dr.Item("SUB_KEY"))

                ' 案件単位の処理を行います。
                Call SubjectProcess(strSubject)

            Next

        Catch ex As Exception

            ' イベントログを出力します。
            MyBase.WriteLog("帳票ID識別でエラーを検出しました。", EventLogEntryType.Error)
            ' ログファイルにエラー内容を出力します。
            CommonLog.WriteLog(ex.ToString, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.Message, EventLogEntryType.Error)
            CommonLog.WriteLog(ex.StackTrace, EventLogEntryType.Error)

        Finally

        End Try
    End Sub
#End Region

#Region "初期設定"
    Private Sub InitializeBatch()
        Try

            ' 頭紙帳票IDの一覧を記憶します。
            Call GetSlipDic("SLIP_HED", mdicSlipHed)

            ' エントリ対象帳票IDの一覧を記憶します。
            Call GetSlipDic("SLIP_ENT", mdicSlipEnt)

            ' 重複可能な帳票IDの一覧を記憶します。
            Call GetSlipDic("SLIP_DUP", mdicSlipDup)

            ' 組合せで無視する帳票IDの一覧を記憶します。
            Call GetSlipDic("SLIP_EGN", mdicSlipEgn)

            ' 再認識カウントアップステータス辞書
            Call GetSlipDic("COUNT_UP_STATUS", mdicCountUp)

            ' 外部定義（config）を精査します。
            For Each key As String In mdicConfig.Keys
                If key.StartsWith("SLIP_SET_") Then
                    ' 定義キーの先頭が「SLIP_SET_」で始まる場合は帳票IDの組み合わせ情報として記憶します。
                    Dim strSlip() As String = Split(mdicConfig(key), ",")
                    Dim dic As New Dictionary(Of String, String)
                    For Each s As String In strSlip
                        If mdicSlipEgn.ContainsKey(s) Then
                            Continue For
                        End If
                        If Not dic.ContainsKey(s) Then
                            dic.Add(s, String.Empty)
                        End If
                    Next
                    mlstSlipSet.Add(dic)
                End If
            Next

        Catch ex As Exception
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & _
                                "でエラーが発生しました。", EventLogEntryType.Error)
            Throw ex
        End Try
    End Sub
#End Region

#Region "帳票ID辞書登録"
    Private Sub GetSlipDic(ByVal strKey As String, ByVal dic As Dictionary(Of String, String))
        Try
            Dim strCnf() As String = Split(mdicConfig(strKey), ",")
            For Each s As String In strCnf
                dic.Add(s, String.Empty)
            Next
        Catch ex As Exception
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & _
                                "でエラーが発生しました。", EventLogEntryType.Error)
            Throw ex
        End Try
    End Sub
#End Region

#Region "処理対象案件番号の取得"
    Private Function GetTargetSubject() As DataTable
        Try
            ' 処理対象のステータスになっている事案IDの一覧を取得するSQLを作成します。
            Dim stbSQL As New StringBuilder(String.Empty)
            stbSQL.AppendLine("SELECT DISTINCT")
            stbSQL.AppendLine("    RECEIPT_ID,")
            stbSQL.AppendLine("    SUBSTR(IMAGE_FILE_NAME,1,23) AS SUB_KEY")
            stbSQL.AppendLine("FROM")
            stbSQL.AppendLine("    T_JJ_IMAGE")
            stbSQL.AppendLine("WHERE")
            stbSQL.AppendLine("    IMAGE_STATUS IN (%STATUS%)")
            stbSQL.AppendLine("    AND")
            stbSQL.AppendLine("    DELETE_FLG = '0'")
            stbSQL.AppendLine("ORDER BY")
            stbSQL.AppendLine("    RECEIPT_ID,")
            stbSQL.AppendLine("    SUBSTR(IMAGE_FILE_NAME,1,23)")
            stbSQL.Replace("%STATUS%", mdicConfig("INPUT_STATUS"))
            ' 作成されたSQLを実行して処理対処の一覧を取得します。
            Dim dt As DataTable = mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)

            Return dt

        Catch ex As Exception
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & _
                                "でエラーが発生しました。", EventLogEntryType.Error)
            Throw ex
        End Try
    End Function
#End Region

#Region "案件単位の処理"
    Private Sub SubjectProcess(ByVal strSubject As String)
        Try
            ' 同一案件番号のイメージデータを取得します。
            Dim dtImage As DataTable = GetImageData(strSubject)
            Dim lstSlip As New List(Of String)

            'CommonLog.WriteLog("【SubjectProcess】帳票ID認識開始", EventLogEntryType.Error)

            For Each dr As DataRow In dtImage.Rows
                ' 認識結果を記憶します。
                lstSlip.Add(Convert.ToString(dr.Item("SLIP_DEFINE_ID")))
            Next

            'CommonLog.WriteLog("【SubjectProcess】頭紙チェック開始", EventLogEntryType.Error)

            ' 頭紙のみかをチェックします。
            If CheckSlipHed(lstSlip) Then
                Call UpdateDB(dtImage, mdicConfig("OUT_STATUS_HED"), mdicConfig("OUT_STATUS_HED"))
                Return
            End If

            'CommonLog.WriteLog("【SubjectProcess】帳票種別違いチェック開始", EventLogEntryType.Error)

            ' 帳票種別違いをチェックします。
            If CheckSlipDif(dtImage) Then
                Call UpdateDB(dtImage, mdicConfig("OUT_STATUS_DIF"), mdicConfig("OUT_STATUS_DIF"))
                Return
            End If

            'CommonLog.WriteLog("【SubjectProcess】帳票ID重複チェック開始", EventLogEntryType.Error)

            ' 帳票IDの重複をチェックします。
            If CheckSlipDup(lstSlip) Then
                Call UpdateDB(dtImage, mdicConfig("OUT_STATUS_DUP"), mdicConfig("OUT_STATUS_DUP"))
                Return
            End If

            'CommonLog.WriteLog("【SubjectProcess】帳票ID組合せチェック開始", EventLogEntryType.Error)

            ' 帳票IDの組合せをチェックします。
            If CheckSlipSet(lstSlip) Then
                Call UpdateDB(dtImage, mdicConfig("OUT_STATUS_SET"), mdicConfig("OUT_STATUS_SET"))
                Return
            End If

            'CommonLog.WriteLog("【SubjectProcess】DB更新処理開始", EventLogEntryType.Error)

            ' 認識結果が正常の場合の更新を行います。
            Call UpdateDB(dtImage, mdicConfig("OUT_STATUS_OK_ENT"), mdicConfig("OUT_STATUS_OK_EGN"))

            'CommonLog.WriteLog("【SubjectProcess】DB更新処理終了", EventLogEntryType.Error)

        Catch ex As Exception
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & _
                                "でエラーが発生しました。", EventLogEntryType.Error)
            Throw ex
        End Try
    End Sub
#End Region

#Region "処理対象イメージ情報の取得"
    Private Function GetImageData(ByVal strSubject As String) As DataTable
        Try
            Dim stbSQL As New StringBuilder(String.Empty)
            stbSQL.AppendLine("SELECT")
            stbSQL.AppendLine("    *")
            stbSQL.AppendLine("FROM")
            stbSQL.AppendLine("    T_JJ_IMAGE")
            stbSQL.AppendLine("WHERE")
            stbSQL.AppendLine("    IMAGE_STATUS IN (%STATUS%)")
            stbSQL.AppendLine("    AND")
            stbSQL.AppendLine("    SUBSTR(IMAGE_FILE_NAME,1,23) = '%SUB_KEY%'")
            stbSQL.AppendLine("    AND")
            stbSQL.AppendLine("    DELETE_FLG = '0'")
            stbSQL.AppendLine("ORDER BY")
            stbSQL.AppendLine("    PRIORITY")
            stbSQL.AppendLine("   ,IMAGE_ID")
            stbSQL.Replace("%STATUS%", mdicConfig("INPUT_STATUS"))
            stbSQL.Replace("%SUB_KEY%", strSubject)

            Dim dt As DataTable = mobjCommonDB.DB_ExecuteQuery(stbSQL.ToString)
            Return dt

        Catch ex As Exception
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & _
                                "でエラーが発生しました。", EventLogEntryType.Error)
            Throw ex
        End Try
    End Function
#End Region

#Region "頭紙チェック"
    Private Function CheckSlipHed(ByVal lstSlip As List(Of String)) As Boolean
        Try
            If lstSlip.Count <> 1 Then
                Return False
            End If

            If mdicSlipHed.ContainsKey(lstSlip(0)) Then
                Return True
            End If

            Return False
        Catch ex As Exception
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & _
                                "でエラーが発生しました。", EventLogEntryType.Error)
            Throw ex
        End Try
    End Function
#End Region

#Region "帳票種別違いチェック"
    Private Function CheckSlipDif(ByVal dt As DataTable) As Boolean
        Try
            Dim blnResult As Boolean = False
            For Each dr As DataRow In dt.Rows
                Dim strSlip As String = Convert.ToString(dr.Item("SLIP_DEFINE_ID"))
                Dim strType As String = Convert.ToString(dr.Item("IMAGE_FILE_NAME")).Substring(13, 3)
                If Not strSlip.StartsWith(strType) Then
                    dr.Item("SLIP_DEFINE_ID") = strType & "888"
                    blnResult = True
                End If
            Next

            Return blnResult
        Catch ex As Exception
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & _
                                "でエラーが発生しました。", EventLogEntryType.Error)
            Throw ex
        End Try
    End Function
#End Region

#Region "重複チェック"
    Private Function CheckSlipDup(ByVal lstSlip As List(Of String)) As Boolean
        Try
            Dim dicSlip As New Dictionary(Of String, String)
            For Each s As String In lstSlip
                If mdicSlipDup.ContainsKey(s) Then
                    Continue For
                End If
                If dicSlip.ContainsKey(s) Then
                    Return True
                End If
                dicSlip.Add(s, String.Empty)
            Next

            Return False
        Catch ex As Exception
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & _
                                "でエラーが発生しました。", EventLogEntryType.Error)
            Throw ex
        End Try
    End Function
#End Region

#Region "組合せチェック"
    Private Function CheckSlipSet(ByVal lstSlip As List(Of String)) As Boolean
        Try
            ' レコード内の帳票IDから組合せ無視の帳票IDを除いて辞書化します。
            Dim dic As New Dictionary(Of String, String)
            For Each s As String In lstSlip
                If mdicSlipEgn.ContainsKey(s) Then
                    Continue For
                End If
                If Not dic.ContainsKey(s) Then
                    dic.Add(s, String.Empty)
                End If
            Next

            ' コンフィグで定義された組合せに一致するものがあるかチェックします。
            For Each d As Dictionary(Of String, String) In mlstSlipSet
                ' 組合せ辞書内の帳票IDの数が一致しないものは無視します。
                If d.Count <> dic.Count Then
                    Continue For
                End If
                ' 組合せがコンフィグと一致するかチェックします。
                Dim blnMach As Boolean = True
                For Each s As String In dic.Keys
                    If Not d.ContainsKey(s) Then
                        blnMach = False
                        Exit For
                    End If
                Next
                If blnMach Then
                    ' 一致した場合
                    Return False
                End If
            Next

            Return True
        Catch ex As Exception
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & _
                                "でエラーが発生しました。", EventLogEntryType.Error)
            Throw ex
        End Try
    End Function
#End Region

#Region "DB更新処理"
    Private Sub UpdateDB(ByVal dt As DataTable, ByVal strEntryStatus As String, ByVal strOtherStatus As String)
        Try
            mobjCommonDB.DB_Transaction()
            Try
                For Each dr As DataRow In dt.Rows
                    Dim strImageID As String = Convert.ToString(dr.Item("IMAGE_ID"))
                    Dim strNewSlip As String = Convert.ToString(dr.Item("SLIP_DEFINE_ID"))
                    Dim strOldSlip As String = Convert.ToString(dr.Item("EXC_IMAGE_KEY02"))


                    If mdicSlipEnt.ContainsKey(strNewSlip) Then
                        Call UpdateImage(strImageID, strNewSlip, strOldSlip, strEntryStatus)
                        Call InsertHistory(strImageID, strEntryStatus)
                    Else
                        Call UpdateImage(strImageID, strNewSlip, strOldSlip, strOtherStatus)
                        Call InsertHistory(strImageID, strOtherStatus)
                    End If
                Next

                If mdicConfig("DB_TRN_COMMIT") = "1" Then
                    'CommonLog.WriteLog("トランザクションをコミットしました。", EventLogEntryType.Information)
                    mobjCommonDB.DB_Commit()
                Else
                    CommonLog.WriteLog("コンフィグファイルの設定により、トランザクションをロールバックしました。", EventLogEntryType.Information)
                    mobjCommonDB.DB_Rollback()
                End If
            Catch ex As Exception
                mobjCommonDB.DB_Rollback()
                Throw ex
            End Try

        Catch ex As Exception
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & _
                                "でエラーが発生しました。", EventLogEntryType.Error)
            Throw ex
        End Try
    End Sub
#End Region

#Region "T_JJ_IMAGEの更新"
    Private Sub UpdateImage(ByVal strImageId As String, _
                            ByVal strNewSlip As String, _
                            ByVal strOldSlip As String, _
                            ByVal strStatus As String)
        Try
            ' T_JJ_IMAGE更新用SQLを作成します。
            Dim stbUpdateSQL As New StringBuilder(String.Empty)
            Dim cntUp As String = "なし"
            stbUpdateSQL.AppendLine("UPDATE")
            stbUpdateSQL.AppendLine("    T_JJ_IMAGE")
            stbUpdateSQL.AppendLine("SET")
            stbUpdateSQL.AppendLine("     IMAGE_STATUS    = '__IMAGE_STATUS__'")
            stbUpdateSQL.AppendLine("    ,SLIP_DEFINE_ID  = '__NEW_SLIP__'")
            stbUpdateSQL.AppendLine("    ,EXC_IMAGE_KEY02 = '__OLD_SLIP__'")
            stbUpdateSQL.AppendLine("    ,UPDATE_USER     = '__USER__'")
            stbUpdateSQL.AppendLine("    ,UPDATE_DATE     = SYSDATE")
            If mdicCountUp.ContainsKey(strStatus) Then
                stbUpdateSQL.AppendLine("    ,DEF_REV_COUNT     = DEF_REV_COUNT + 1")
                cntUp = "あり"
            End If
            stbUpdateSQL.AppendLine("WHERE")
            stbUpdateSQL.AppendLine("    IMAGE_ID = __IMAGE_ID__")

            ' 作成したSQLの設定値の部分を実際の値に置換します。
            stbUpdateSQL.Replace("__IMAGE_STATUS__", strStatus)
            stbUpdateSQL.Replace("__NEW_SLIP__", strNewSlip)
            stbUpdateSQL.Replace("__OLD_SLIP__", strOldSlip)
            stbUpdateSQL.Replace("__USER__", "SlipCheck")
            stbUpdateSQL.Replace("__IMAGE_ID__", strImageId)

            'CommonLog.WriteLog( _
            '    "【UpdateDB】IMAGE_ID:" & strImageId _
            '    & "、IMAGE_STATUS:" & strStatus _
            '    & "、SLIP_DEFINE_ID:" & strNewSlip _
            '    & "、EXC_IMAGE_KEY02:" & strOldSlip _
            '    & "、DEF_REV_COUNT:" & cntUp, _
            '    EventLogEntryType.Information
            ')

            ' 作成したSQLを実行してT_RECEIPT_IMAGEを更新します。
            Dim intInsertRet As Integer = mobjCommonDB.DB_ExecuteNonQuery(stbUpdateSQL.ToString)
            If Not intInsertRet = 1 Then
                Throw New Exception("イメージデータの更新に失敗しました。")
            End If

        Catch ex As Exception
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & _
                                "でエラーが発生しました。", EventLogEntryType.Error)
            Throw ex
        End Try
    End Sub
#End Region

#Region "T_STATUS_HISTORYの登録"
    Private Sub InsertHistory(ByVal strImageId As String, ByVal strStatus As String)
        Try
            Dim strUpdateStatus As String = strStatus

            ' イメージ状態履歴登録用SQLを作成します。
            Dim stbInsertSQL As New System.Text.StringBuilder(String.Empty)
            stbInsertSQL.AppendLine("INSERT INTO T_JJ_IMAGE_HISTORY (")
            stbInsertSQL.AppendLine("     IMAGE_ID")
            stbInsertSQL.AppendLine("    ,IMAGE_STATUS")
            stbInsertSQL.AppendLine("    ,CREATE_DATE")
            stbInsertSQL.AppendLine("    ,CREATE_USER")
            stbInsertSQL.AppendLine(") VALUES (")
            stbInsertSQL.AppendLine("     __IMAGE_ID__")
            stbInsertSQL.AppendLine("    ,'__STATUS__'")
            stbInsertSQL.AppendLine("    ,SYSTIMESTAMP")
            stbInsertSQL.AppendLine("    ,'__USER__'")
            stbInsertSQL.AppendLine(")")
            ' 作成したSQLの設定値の部分を実際の値に置換します。
            stbInsertSQL.Replace("__STATUS__", strStatus)
            stbInsertSQL.Replace("__USER__", "SlipCheck")
            stbInsertSQL.Replace("__IMAGE_ID__", strImageId)

            ' イメージ状態履歴を登録します。
            Dim intInsertRet As Integer = mobjCommonDB.DB_ExecuteNonQuery(stbInsertSQL.ToString)
            If Not intInsertRet = 1 Then
                Throw New Exception("イメージ履歴の登録に失敗しました。")
            End If

        Catch ex As Exception
            CommonLog.WriteLog(System.Reflection.MethodBase.GetCurrentMethod.Name & _
                                "でエラーが発生しました。", EventLogEntryType.Error)
            Throw ex
        End Try
    End Sub
#End Region

End Class
